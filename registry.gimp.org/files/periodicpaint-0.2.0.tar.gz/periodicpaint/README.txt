Periodic Painter / Seamless Tiles Creator
Gimp plugin (not a standalone programm)

LOCATION:
Filters->Artistic-> Periodic Painter

PURPOSE:
It is tu simplify creation of seamles tiles/ patterns. Anything you paint is periodically copied. It has two basic modes: free and tileset. See images/videos in download section on google code.


USAGE:
See introductory videos

HOW IT WORKS INTERNALLY:
The plugin keeps the copy of current image (specific layer or f.e. mask) in its memory, and when you hit "Spread changes"
it searches for differences and propagate them. Therefore the plugin must be running before you start painting...
The content of initial image does not matter indeed.
It might be even a photo, or anything else. No need for it to be all-white or so...
Sometimes, when f.e. undo-ing, you must notify the plugin that what it keeps in memory is not relevant anymore,
and make it take current content and store it in memory as a base for future comparison (This procedure mimics a restart of plugin).
However, when you do significat changes (resize the image/layer or so on) real restart (leave and re-launch
of the plugin) is required - this is just like with other plugins.
The plugin adheres to a policy "Change a pixel of a (virtual) tile only once". So if you paint areas bigger
then defined x and y periods, part of you painting will be ignored and even overpainted.

The tileset mode is and modification to above algorithm, but the copying is restricted to specified "tiles" 


CONSIDERATIONS and ISSUES:
Dont paint big structures - bigger then given periods, the plugin might not behave as you would expect.
No non-interactive mode
The UNDO (from within gimp) might damage integrity of in-memory data, see above.


CHANGELOG:
0.2.0 - tiles mode added (this is quite complex addition)
		- GUI rework
0.1.2 - restart button added
		- speed up and code cleanup
		- support for one-channel drawables (B/W, layer masks)
		- alpha channel support completed
0.1.0	- GUI rework
		- fixed bug when GUI pushed  value for xperiod also to yperiod variable
		- stdout verbosity changed
		- fixed issue when the image was too beg and the pattern was not spread over whole image
0.1.1	- fixed bug with initial scanning of image
		- fixed bug with alpha channel (the algorithme is still insensitive to change ina alpha channel)
		

INSTALLATION:
LINUX:
user>$gimptool-2.0 --install periodicpaint.c
or system-wide:
root>$gimptool-2.0 --install-admin periodicpaint.c

OTHER PLATFORMS:
search on gimpchat.com for windows binaries

RELATED LINKS:
https://code.google.com/p/repeated-painter-gimp-plugin
http://registry.gimp.org/node/28071

Feedback and contact:
tiborb at gmail dot com (preferred) or via registry.gimp.org

24th May 2013
