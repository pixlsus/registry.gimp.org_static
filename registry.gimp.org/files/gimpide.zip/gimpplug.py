#!/usr/bin/python
# -*- coding: utf8 -*-
"""GIMP PlugIn interface"""
import gtk,sys,os.path
import gimpide
import gettext
locale_dir = os.path.join(os.path.dirname(os.path.abspath(gimpide.__file__)),'locale')

gettext.install('gimpplug',\
                locale_dir,\
                unicode=True)

def plugin_main(*args):
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    editor = gimpide.GimpIde()
    editor.main()

try:
    from gimpfu import *    
    register(
            "Gimp_IDE_Tool",
            _("Mini IDE for GimpFu Python scripting"),
            _("This ide for fast plugin building"),
            _("Dmitry Shamov"),
            _("Dmitry Shamov"),
            "2009",
            "<Toolbox>/Xtns/Gimp _Ide",
            "*",
            [],
            [],
            plugin_main)

    register(
            "Gimp_IDE",
            _("Mini IDE for GimpFu Python scripting"),
            _("This ide for fast plugin building"),
            _("Dmitry Shamov"),
            _("Dmitry Shamov"),
            "2009",
            "<Image>/Python-Fu/Gimp _Ide",
            "*",
            [],
            [],
            plugin_main)
    main()
except:
    from gimpide import GimpIde
    editor = GimpIde()
    editor.main()

