# -*- coding: utf-8 -*-
# Sample batch script for use with EZ Perspective
# 
# Allows non-interactive perspective correction of images
# 
#
# Usage
# 
# Place this file in the directory with your images,
# (do NOT place it in the plugins directory!),
# adjust the parameters (filenames, angles)
# and use the following command line:
#
##  gimp --no-interface --batch-interpreter python-fu-eval -b - < ez-batch-script-SAMPLE.py
#
# This runs GIMP non-interactively, and reads in this file.
# This is Unix syntax (using redirection of the “standard streams”);
# you may need to use different syntax on Windows or other platforms.
#
# 
#
# Other options
# 
# If processing multiple files, you should remove the “Quit” so
# it doesn’t start GIMP each time.
# 
# You can also use standard Python functions in this kind of script,
# for instance if you want to loop through a list of files
# or read filenames and parameters from a separate file;
# this is beyond the scope of this example though.
#
#
#
# One-liner
#
# Instead of using a separate file, you can use a single command line, such as:
#
#  gimp --no-interface --batch-interpreter python-fu-eval -b "pdb.python_fu_ez_perspective_correction_non_interactive('bb.jpg', 'out.jpg', 40, 0, 0.3, 89, 'fast', 'crop to result')" -b "pdb.gimp_quit(True)"
#
# This is not very legible, but avoids having to use a separate file
# or stream redirection.
# You can also have several -b lines if you want to process multiple files
# in a single one-liner.


# Filenames
in_file_name = 'bb.jpg'
out_file_name = 'out.jpg'

# Angles: up/down, left/right, rotation (in degrees)
ud = 40
lr = 0
rot = 0.3

# Effective Focal Length of lens used to take picture
efl = 89

# Interpolation quality: "fast" or "good"
quality = "fast"

# Crop style
# "adjust"
#   Don’t clip, don’t crop
# "clip"
#   clip only
# "crop to result"
#   crop to result
# "crop with aspect"
#   crop, preserving aspect ratio
crop = "crop to result"

# Execute the function
pdb.python_fu_ez_perspective_correction_non_interactive(
    in_file_name, out_file_name,
    ud, lr, rot,
    efl,
    quality, crop)

# Quit
#  remove this line if processing multiple files,
#  so can use existing Gimp instance
pdb.gimp_quit(True) # True = quit without asking
