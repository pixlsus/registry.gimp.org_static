gimp-normalmap 1.2.1 for GIMP 2.4
(C) Copyright 2007 Shawn Kirst <skirst@fuse.net>

To install, extract normalmap.exe and glew32.dll to your GIMP plugins
directory.  Place libgtkglext-win32-1.0-0.dll and libgdkglext-win32-1.0-0.dll
in the C:\Program Files\Common Files\GTK\2.0\bin directory.

