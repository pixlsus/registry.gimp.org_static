//Color reducer and cartoonizer - gimp plugin
//to install (on linux) - for user:
//   gimptool-2.0 --install cartoonizer.c
//and for system-wide installation:
//   gimptool-2.0 --install-admin cartoonizer.c
// following might be needed beforehand: 
//   export LDFLAGS="$LDFLAGS -lm"
//wiki: http://code.google.com/p/cartooner-color-reducer/wiki/cartoonerIntroduction
//contact: tiborb95 at gmail dot com,
//any feedback welcomed


#define VERSION 0.8.0
#define VERBOSE FALSE
#define RESPONSE_RESET   99
#define RESPONSE_OK      1
#define COLORSDEF 6
#define WEIGHTDEF 2
#define SPTRESHDEF 0
#define SPITDEF 2
#define LINBRTRESHDEF 0.07
#define LINHUETRESHDEF 0.02
#define LINREMDEF 0
#define STEPPING 50
#define MAPPERLENGTH 1000000
#define CHECKCOLORS 1
#define LINESONLY 0
#define MAXCOLORS 50
#define MAXEFFECTIVE 288
#define MAXDERIVED 300
#define ERODEDEF 20
#define STRICT TRUE
#define LOOSE FALSE
#define ITERATE(x,start,end) for(x=start;x<end;x++)
#define MODEDEF 0
#define FAIR 0
#define DITHER 1
#define CAMO 2
#define ENHANCED 3
#define DITHER31 4
#define ADAPTIVE 6
#define SAMPLEINT 0.015
#define NONE 0
#define PASTEL 1
#define SATURATED 2
#define GOLD 3
#define DARKPASTEL 4
#define SIMPLESAT 0   //get_saturation()
#define SIMPLE 0
#define QUADR 1
#define PENALTYDEF 0
#define WMODEDEF 4
#define COUNT 0
#define BYSAT 1
#define BYNEIGH 2
#define UNIQUE 3
#define MIX 4
#define SATONLY 1


#include <libgimp/gimp.h>
#include <gtk/gtk.h>
#include <stdio.h>
#include <libgimp/gimpui.h>
#include <string.h>
#include <stdlib.h> 
#include <unistd.h> 


typedef struct {
	gfloat r;
	gfloat g;
	gfloat b;
	gfloat wr;
	gfloat wg;
	gfloat wb;
	gfloat step_r[10]; //for line distance
	gfloat step_g[10];
	gfloat step_b[10];
	gint steps;
	guchar R;
	guchar G;
	guchar B;
	gint parent[4];
	gint parents;  // number of parents
	//gfloat sat;
	gint count;   //statistics of occurence in image
} Color;

static Color primaryc[MAXCOLORS];
static Color effectivec[MAXEFFECTIVE];
static Color derivedc[MAXDERIVED];

//functions
static void query (void);
static void run   (const gchar      *name,
                   gint              nparams,
                   const GimpParam  *param,
                   gint             *nreturn_vals,
                   GimpParam       **return_vals);

static void process (GimpDrawable *source,GimpPreview *preview);
static gboolean gui_window (GimpDrawable *source);
static void response_callback (GtkWidget *widget,  gint response_id);
static void recalculate_sizes(void);
static void do_sampling(void);
static void get_fcolors(void);
static void show_fcolors(void) ;
static void indexing(void);
static void deindexing(void);
static void denoising(gint firsttresh,gint secondtresh,gint maxiter,gboolean strict);
static void despotting2(void);
static void dolines_changed(void);
static void doerode_changed(void);
static void denoising_changed(void);
static void legend_changed(void);
static void do_lines(void);
static void exportwrapper (GimpDrawable *source);
static void insert_legend(void);
static void remove_short(gboolean *outlinemask,gboolean checkcolors,gint treshold);
static void temp_change_col(int channel, int color, float change);
static void tmp_color_reject(void);
static void do_weight(gfloat r, gfloat g, gfloat b, gfloat *newr,gfloat *newg, gfloat *newb);
static void undo_weight(gfloat r, gfloat g, gfloat b, gfloat *newr,gfloat *newg, gfloat *newb);
static void cb_changed( GtkComboBox *combo, gpointer data );
static void colors_warning(gboolean on) ;
static float get_saturation(gfloat r,gfloat g,gfloat b,gint type);
static void find_best2(gfloat wr,gfloat wg,gfloat wb,gint *pos,gfloat *dist,gint mode);
static void cascade_colors(gboolean printinfo,gint forcedmode);
static float get_brightness(gfloat r,gfloat g,gfloat b,gint type);

//global variables

typedef struct
{
	gint colors;
	gint sptresh;
	gint spit;
	gint weight;
	gboolean exportlayer;
	gfloat linbrtresh;
	gfloat linhuetresh;
	gboolean legend;
	gint linesrem;
	gboolean doerode;
	gint erode;
	gboolean denoising;
	gint mode;
	gint postprocess;
	gint wmode;
	gboolean forcebw;
	gint channels;
	gboolean dolines;
	gboolean previewbool;
	gint derivedcolors;
	gint effective;
	gfloat startrange;  //for linedist
	gfloat maxdiff;		//for dithering
	
} MySharpVals;
static MySharpVals maindata = { COLORSDEF,SPTRESHDEF,SPITDEF,WEIGHTDEF,FALSE,LINBRTRESHDEF,LINHUETRESHDEF,
		FALSE,LINREMDEF,FALSE, ERODEDEF,TRUE,MODEDEF,NONE,WMODEDEF,FALSE  };

typedef struct {
	gint channel;
	gint color;
	gfloat value;
} tmpchange;
static tmpchange origcolor={0,0,0};

typedef struct {
	gint startx;
	gint endx;
	gint starty;
	gint endy;
	gint width;
	gint height;
} Sizes;
static Sizes image;
static Sizes warea;
static Sizes parea;

typedef struct {
	gfloat r; // content depends on colorspace
	gfloat g;
	gfloat b;
	gfloat wr; // content depends on colorspace
	gfloat wg;
	gfloat wb;
	gfloat count;
	gfloat sat;
	gfloat neigh;
	gfloat uniq;
	gfloat weight;
	gfloat reg_importance;
} Sample;
static Sample samples[STEPPING*STEPPING];


static gchar *mode1  = "Plain       ";
static gchar *mode2  = "Dither 4*1   ";
static gchar *mode3  = "Camouflage   ";
static gchar *mode4  = "Enhanced     ";
static gchar *mode5  = "Dither 3+1   ";
static gchar *mode8  = "Adaptive     ";
static gchar *wmode1 = "No weighting";
static gchar *wmode2 = "By saturation";
static gchar *wmode3 = "Neighbourhood";
static gchar *wmode4 = "Unique colors";
static gchar *wmode5 = "Combined";
static gchar *post1  = "None";
static gchar *post2  = "Pastel";
static gchar *post3  = "Saturated";
static gchar *post4  = "Gold";
static gchar *post5  = "Dark Pastel";
static gchar *title  = "Color Reducer and Cartoonizer (v. 0.8.0)";
static gfloat		gammed_values[256]; //to be used for fast conversion 
								//from raw RGB to gammed 0-1 values
gboolean process_image = FALSE;
static guchar *rect_img;
static guchar *rect_wrk;
static guchar *rect_out;
static gint *rect_indx;
static gboolean rect_wrk_initialized=FALSE;
static gboolean rect_out_initialized=FALSE;
static gboolean rect_indx_initialized=FALSE;
static gint samplescount;
gint32 image_ID,drawable_ID;

GimpRGB RGBvalues;	
GimpHSV HSVvalues;	

static GtkWidget *spin_count,*spin_weight,*spin_sp_tresh,*spin_sp_it,*spin_erode_it,*spin_lin_br_tresh,*spin_lin_hue_tresh,
		*spin_lin_rem;
static GtkObject *spin_count_adj,*spin_weight_adj,*spin_sp_tresh_adj,*spin_sp_it_adj,*spin_erode_it_adj
		,*spin_lin_br_tresh_adj,*spin_lin_hue_tresh_adj,*spin_lin_rem_adj;
static GtkWidget *dolines_button,*legend_button,*denoising_button,*doerode_button,*forcebw_button;
static GtkWidget *infolabel_var, *infolabel_warn;
static GtkWidget *combo,*combo2,*combo3;


GimpPlugInInfo PLUG_IN_INFO = { NULL, NULL, query, run};


MAIN()


static void query (void)
{
  static GimpParamDef args[] =
  {
    { GIMP_PDB_INT32,"run-mode", "Run mode" },
    { GIMP_PDB_IMAGE,"image","Input image"  },
    { GIMP_PDB_DRAWABLE,"drawable","Input drawable" }
  };

  gimp_install_procedure (
    "plug-in-cartoonizer",
    "Color Reduced and Cartoonizer",
    "Color Reducer and Cartoonizer v. 0.8.0 Reduce number of colors in image, clean up fragmentation and/or add lines.",
    "Tibor Bamhor",
    "Copyright Tibor Bamhor",
    "2012",
    "_Cartoonizer",
    "RGB*",
    GIMP_PLUGIN,
    G_N_ELEMENTS (args), 0,
    args, NULL);

  gimp_plugin_menu_register ("plug-in-cartoonizer",
                             "<Image>/Filters/Artistic");
}

static void
run (const gchar      *name,
     gint              nparams,
     const GimpParam  *param,
     gint             *nreturn_vals,
     GimpParam       **return_vals)
{
  static GimpParam  values[1];
  GimpPDBStatusType status = GIMP_PDB_SUCCESS;
  GimpRunMode       run_mode;
  GimpDrawable     *drawable; //<- original layer


  image_ID = param[1].data.d_image; //<- zistujem imageID
  if (VERBOSE) printf("Image ID is: %d\n", image_ID);  


  /* Setting mandatory output values */
  *nreturn_vals = 1;
  *return_vals  = values;

  values[0].type = GIMP_PDB_STATUS;
  values[0].data.d_status = status;

  /* Getting run_mode - we won't display a dialog if
   * we are in NONINTERACTIVE mode
   */
  run_mode = param[0].data.d_int32;

  // getting original drawable
  drawable = gimp_drawable_get (param[2].data.d_drawable);
   
  //starting GUI - sharp_dialog;
   if (! gui_window (drawable)) return; //if it fails, plugin terminates
  
  //processing
  process (drawable, NULL);
 
  gimp_displays_flush ();
  gimp_drawable_detach (drawable);

  return;
}
	

void denoising_changed(void){
	maindata.denoising=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (denoising_button));
	if (VERBOSE) printf("denoising checkbutton changed %d\n",gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (denoising_button)) );
	}


void dolines_changed(void){
	maindata.dolines=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (dolines_button));
	if (VERBOSE) printf("dolines_changed %d\n",gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (dolines_button)) );
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (dolines_button))){
		gtk_widget_set_sensitive  (spin_lin_br_tresh,TRUE);
		gtk_widget_set_sensitive  (spin_lin_hue_tresh,TRUE);
		gtk_widget_set_sensitive  (spin_lin_rem,TRUE);
		gtk_combo_box_set_active(GTK_COMBO_BOX( combo2), 0);}
	else {
		gtk_widget_set_sensitive  (spin_lin_br_tresh,FALSE);
		gtk_widget_set_sensitive  (spin_lin_hue_tresh,FALSE);
		gtk_widget_set_sensitive  (spin_lin_rem,FALSE);}
	}


void doerode_changed(void){
	maindata.doerode=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (doerode_button));
	if (VERBOSE) printf("doerodes_changed %d\n",gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (doerode_button)) );
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (doerode_button))){
		gtk_widget_set_sensitive  (spin_erode_it,TRUE);
		}
	else {
		gtk_widget_set_sensitive  (spin_erode_it,FALSE);}
	}


void forcebw_changed(void){
	maindata.forcebw=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (forcebw_button));
	if (VERBOSE) printf("Forced Black+White changed %d\n",gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (forcebw_button)) );

	}


static void colors_warning(gboolean on) {
	static char labeltextwarn [70];
	gboolean debug=FALSE;
	
	if (debug) printf ("Setting the warning label: %1s\n",(on)?"ON":"OFF");
	
	if (on) {
	if (debug) printf (" WARNING: Number of subcolors exceeded, results will not be adequate...\n");
	sprintf(labeltextwarn, "WARNING: Too many colors!");
	gtk_widget_set_tooltip_text(infolabel_warn, "You set too many colors for this mode, result will not be adequate");
	gtk_label_set_label(GTK_LABEL(infolabel_warn),labeltextwarn ); }
	else {
	sprintf(labeltextwarn, " ");
	gtk_widget_set_tooltip_text(infolabel_warn, NULL);
	gtk_label_set_label(GTK_LABEL(infolabel_warn),labeltextwarn ); }		
	}

	
void legend_changed(void){
	maindata.legend=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (legend_button));
	if (VERBOSE) printf("legend_changed %d\n",gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (legend_button)) );
	}


void  cb_changed( GtkComboBox *combo, gpointer data ) {
    
    //changes blur mode (1- standard,2-selective,3-RGB selective)
    if ( strncmp( gtk_combo_box_get_active_text( combo ), mode1,11) == 0) {
    	maindata.mode=FAIR;}
    if ( strncmp((gtk_combo_box_get_active_text( combo )),mode2,11) == 0) {
    	maindata.mode=DITHER;}
    if ( strncmp((gtk_combo_box_get_active_text( combo )),mode3,11) == 0) {
    	maindata.mode=CAMO;}
    if ( strncmp((gtk_combo_box_get_active_text( combo )),mode4,11) == 0) {
    	maindata.mode=ENHANCED;}
    if ( strncmp((gtk_combo_box_get_active_text( combo )),mode5,11) == 0) {
    	maindata.mode=DITHER31;}
    //if ( strncmp((gtk_combo_box_get_active_text( combo )),mode6,11) == 0) {
    	//maindata.mode=DITHER31S;}
    if ( strncmp((gtk_combo_box_get_active_text( combo )),mode8,11) == 0) {
    	maindata.mode=ADAPTIVE;}

    	
    if (VERBOSE) printf( "cb_changed: Changing type of mask to %d\n",maindata.mode );
}


void  wmode_changed( GtkComboBox *combo3, gpointer data ) {
    
    //changes blur mode (1- standard,2-selective,3-RGB selective)
    if ( strncmp( gtk_combo_box_get_active_text( combo3 ), wmode1,5) == 0) {
    	maindata.wmode=COUNT;}
    if ( strncmp((gtk_combo_box_get_active_text( combo3 )),wmode2,5) == 0) {
    	maindata.wmode=BYSAT;}
    if ( strncmp((gtk_combo_box_get_active_text( combo3 )),wmode3,5) == 0) {
    	maindata.wmode=BYNEIGH;}
    if ( strncmp((gtk_combo_box_get_active_text( combo3 )),wmode4,5) == 0) {
    	maindata.wmode=UNIQUE;}
    if ( strncmp((gtk_combo_box_get_active_text( combo3 )),wmode5,5) == 0) {
    	maindata.wmode=MIX;}
    	
    if (VERBOSE) printf( "cb_changed: Changing type of mask to %d\n",maindata.mode );
}


void  post_changed( GtkComboBox *combo2, gpointer data ) {
    
    //changes blur mode (1- standard,2-selective,3-RGB selective)
    if ( strncmp( gtk_combo_box_get_active_text( combo2 ), post1,5) == 0) {
    	maindata.postprocess=NONE;}
    if ( strncmp((gtk_combo_box_get_active_text( combo2 )),post2,5) == 0) {
    	maindata.postprocess=PASTEL;
    	gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (dolines_button  ),FALSE);}
    if ( strncmp((gtk_combo_box_get_active_text( combo2 )),post3,5) == 0) {
    	maindata.postprocess=SATURATED;
    	gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (dolines_button  ),FALSE);}
    if ( strncmp((gtk_combo_box_get_active_text( combo2 )),post4,4) == 0) {
    	maindata.postprocess=GOLD;
    	gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (dolines_button  ),FALSE);}
    if ( strncmp((gtk_combo_box_get_active_text( combo2 )),post5,4) == 0) {
    	maindata.postprocess=DARKPASTEL;
    	gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (dolines_button  ),FALSE);}
    if (VERBOSE) printf( "post_changed: Changing postprocessing mode to %d\n",maindata.postprocess );
}


static void do_weight(gfloat r, gfloat g, gfloat b, gfloat *newr,gfloat *newg, gfloat *newb) {
	gfloat avg,rdiff,gdiff,bdiff;
	avg=get_brightness(r,g,b,SIMPLE);		

	rdiff=r-avg;
	gdiff=g-avg;
	bdiff=b-avg;

	*newr=rdiff*maindata.weight + avg;
	*newg=gdiff*maindata.weight + avg;
	*newb=bdiff*maindata.weight + avg;	
}


static void undo_weight(gfloat r, gfloat g, gfloat b, gfloat *newr,gfloat *newg, gfloat *newb) {
	gfloat avg,rdiff,gdiff,bdiff;
	avg=get_brightness(r,g,b,SIMPLE);
	rdiff=(r-avg)/maindata.weight;
	gdiff=(g-avg)/maindata.weight;
	bdiff=(b-avg)/maindata.weight;
	
	*newr=rdiff + avg;
	*newg=gdiff + avg;
	*newb=bdiff + avg;	
}


static void fcolors_to_int(void) {
	gfloat r,g,b;
	gint i;
	
	for (i=0;i<maindata.colors;i=i+1){
		r=pow(primaryc[i].r,2.2) * 255;
		g=pow(primaryc[i].g,2.2) * 255;
		b=pow(primaryc[i].b,2.2) * 255;	
		primaryc[i].R=(int)MAX(MIN(ROUND(r),255),0);
		primaryc[i].G=(int)MAX(MIN(ROUND(g),255),0);
		primaryc[i].B=(int)MAX(MIN(ROUND(b),255),0);}
	}
		
	
static void get_gold_colors(){
	gfloat avg;
	gint i;
	
	for (i=0;i<maindata.colors;i+=1) {
		//undo_weight(derived[i].wr,derived[i].wg,derived[i].wb,&r,&g,&b);	
		avg=(primaryc[i].r+primaryc[i].g+primaryc[i].b)/3.0;
		primaryc[i].r =(1-avg)*0.62+avg*0.89+(primaryc[i].r-avg)*0.2;
		primaryc[i].g =(1-avg)*0.28+avg*0.85+(primaryc[i].g-avg)*0.2;
		primaryc[i].b =(1-avg)*0.0+avg*0.59+(primaryc[i].b-avg)*0.2;
		//if (VERBOSE) printf ("   Changing RGB values for color %1d to %.3f %.3f %.3f\n",i,r,g,b);
	}
}


static void get_saturated_colors() {
	//we presume that rgb values contain final (ungammed) colors and we are going to change them
	gint i;
	gfloat sat,satboost,avg;
	
	
	//first we need average saturation
	for (i=0;i<maindata.colors;i+=1) {
		//undo_weight(base[i].wr,base[i].wg,base[i].wb,&r,&g,&b);
		avg=(primaryc[i].r+primaryc[i].g+primaryc[i].b)/3.0;
		sat=get_saturation(primaryc[i].r,primaryc[i].g,primaryc[i].b,SIMPLESAT);
		if (sat>0.25 || sat ==0) satboost=0;
		else {
			satboost=(pow((sat/0.25),0.5)*0.25)/sat;}

		//if (VERBOSE) printf ("  Saturation boost for color %1d: %.3f (current sat.: %.3f)\n",i,satboost,sat);
		primaryc[i].r=(primaryc[i].r-avg)*satboost + avg ;
		primaryc[i].g=(primaryc[i].g-avg)*satboost + avg ;
		primaryc[i].b=(primaryc[i].b-avg)*satboost + avg ;
		//if (VERBOSE) printf ("   New RGB values: %.3f %.3f %.3f\n",r,g,b);
		//show_fcolors();
	}}	


static void get_pastel_colors(gfloat avgoffset,gfloat avgrange) {
	//we presume that rgb values contain final (ungammed) colors and we are going to change them
	gint i;
	gfloat r,g,b,newr,newb,newg,oldavg,newavg,oldspread, newspread,oldRdiff,oldGdiff,oldBdiff,spreadratio;
	gboolean debug=FALSE;

	
	for (i=0;i<maindata.colors;i+=1) {
		r=primaryc[i].r;
		g=primaryc[i].g;
		b=primaryc[i].b;
		oldavg=get_brightness(r,g,b,SIMPLE);
		oldspread=MAX(r,MAX(g,b))-MIN(r,MIN(g,b));

		newavg=oldavg*avgrange + avgoffset;
		newspread=oldspread*0.10 + 0.20;
		if (oldspread>0) spreadratio=newspread/oldspread;
		else 			 spreadratio=0;
		if(debug) printf ("postprocessing: oldspread: %.3f, new spread: %.3f\n",oldspread,newspread);
				
		oldRdiff=r-oldavg;
		oldGdiff=g-oldavg;
		oldBdiff=b-oldavg;
		newr=newavg+oldRdiff*spreadratio;
		newg=newavg+oldGdiff*spreadratio;
		newb=newavg+oldBdiff*spreadratio;
		if(debug) printf ("  Changing %3.3f, %3.3f %3.3f with avg %.3f to %3.3f, %3.3f %3.3f with avg %.3f\n",r,g,b,oldavg,newr,newg,newb,newavg);


		primaryc[i].r=newr;
		primaryc[i].g=newg;
		primaryc[i].b=newb;
		}
	}
	

void exportwrapper (GimpDrawable *source){ 
	maindata.exportlayer=TRUE;
	process (source,NULL);
	maindata.exportlayer=FALSE;	}


inline gint get_basepos(gint x, gint y,gint ch, gint width){
	return ch*y*width + ch*x;}

	
inline gint get_basepos2(gint x, gint y, gint width){
	return y*width + x;}


static void denoising(gint firsttresh,gint secondtresh,gint maxiter,gboolean strict) {
	gint col,row,i;
	gint nearx[8]={0,1,1,1,0,-1,-1,-1};
	gint neary[8]={1,1,0,-1,-1,-1,0,1};
	gint *occ;    //[maindata.colors];
	gint centralcolor, nearcolor;
	gint sumdiff,iter;
	gint substitute,maxocc;
	gboolean debug=FALSE;
	gint changed;
	gint localtresh;
	
	gboolean *dirty,*newdirty;
	
	dirty=g_new(gboolean,warea.width*warea.height);
	newdirty=g_new(gboolean,warea.width*warea.height);
	for (i=0;i<warea.width*warea.height;i+=1) { dirty[i]=TRUE;}//setting initial values
	
	occ=g_new(gint, maindata.effective);
	
	for (iter=0;iter<maxiter;iter=iter+1){	
		
		if (i<=1) localtresh=firsttresh;
		else      localtresh=secondtresh;

		for (i=0;i<warea.width*warea.height;i+=1) {	newdirty[i]=FALSE;} //resetting newdirty
		
		changed=0;
		
		for (col=1;col<warea.width-1;col=col+1) {for (row=1;row<warea.height-1;row=row+1){
			
			//skip the pixel if not dirty
			if (dirty[get_basepos2(col,row,warea.width)]==FALSE) continue;
			
			for (i=0;i<maindata.effective;i=i+1) occ[i]=0; //resetting occurences
			sumdiff=0;
			
			centralcolor=rect_indx[get_basepos2(col,row,warea.width)];
			for (i=0;i<8;i=i+1) {
				nearcolor = rect_indx[get_basepos2(col+nearx[i],row+neary[i],warea.width)];
				if (centralcolor == nearcolor) continue;
				occ[nearcolor]=occ[nearcolor]+1;
				sumdiff=sumdiff+1;
				}
			
			//if (debug) printf ("sumdiff: %.i\n",sumdiff);
			
			if (sumdiff<localtresh) continue;
			
			if (debug) printf ("sumdiff: %.i\n",sumdiff);
			
			//so we are going to change the pixel
			//search for most frequent colors
			maxocc=0;
			
			//finding most frequent color in near pixels
			for (i=0;i<maindata.effective;i=i+1) {if (occ[i]>maxocc) {maxocc=occ[i]; substitute=i;}}
						
			if (strict && maxocc<localtresh) continue; // used by erode
			
			if (debug) printf ("New color: %1d\n",substitute);
			
			rect_indx[get_basepos2(col,row,warea.width)]=substitute;
			changed=changed+1;
			
			//setting pixels in newdirty as dirthy
			newdirty[get_basepos2(col,row,warea.width)]=TRUE;
			for (i=0;i<8;i=i+1) newdirty[get_basepos2(col+nearx[i],row+neary[i],warea.width)]=TRUE;
			
		}}
		if (VERBOSE) printf (" Denoising: changed pixels: %0d (iteration: %.i)\n",changed,iter+1);
		if (changed<1) break;
		
		//pushing content of new dirty to dirty
		for (i=0;i<warea.width*warea.height;i+=1)  dirty[i]=newdirty[i];
		}
}


static void indexing(){
	//puts base colors into rect_indx
	gint col,row,count,i;
	gfloat r,g,b;
	gint basepos;
	gint pos;
	gfloat dist;
	gboolean debug;
	debug=TRUE;
	gint xpos[4]={0,0,1,1};
	gint ypos[4]={0,1,0,1};
	
	if (maindata.mode==DITHER ||maindata.mode==DITHER31||maindata.mode==ADAPTIVE ) {
		for (col=0;col<warea.width;col=col+2) {for (row=0;row<warea.height;row=row+2){
			r=0;g=0;b=0;count=0;
			for (i=0;i<4;i+=1) {
				if ( (col+xpos[i])>=warea.width || (row+ypos[i])>=warea.height ) continue;
				basepos=get_basepos(col+xpos[i],row+ypos[i],maindata.channels,warea.width);			
				r=r + gammed_values[rect_wrk[basepos  ]];
				g=g + gammed_values[rect_wrk[basepos+1]];
				b=b + gammed_values[rect_wrk[basepos+2]];
				count+=1;}
			r=r/count;
			g=g/count;
			b=b/count;
			do_weight(r,g,b,&r,&g,&b);
			find_best2(r,g,b,&pos,&dist,maindata.mode);
			if (debug && ( pos<0 || pos>=maindata.effective) ) {
				printf (" Out of range index: %1d - range (0 - %1d)\n", pos,maindata.effective);
				exit(1);}
			for (i=0;i<4;i+=1) {
				if ( (col+xpos[i])>=warea.width || (row+ypos[i])>=warea.height ) continue;
				basepos=get_basepos2(col+xpos[i],row+ypos[i],warea.width);	
				rect_indx[basepos]=pos;}
		}}
		}
	
	else {
		for (col=0;col<warea.width;col=col+1) {for (row=0;row<warea.height;row=row+1){
			basepos=get_basepos(col,row,maindata.channels,warea.width);
			//basepos2=get_basepos2(col,row,warea.width);
			r=gammed_values[rect_wrk[basepos  ]];
			g=gammed_values[rect_wrk[basepos+1]];
			b=gammed_values[rect_wrk[basepos+2]];
			do_weight(r,g,b,&r,&g,&b);
			//finding best color from fcolors
			find_best2(r,g,b,&pos,&dist,maindata.mode);
			/*if (debug && col%200==0 && row%200==0) printf (" pixel %.i - converting to fcolor: %.i (=%.3f,%.3f,%.3f)\n",\
			basepos2,pos,base[pos].r,base[pos].g,base[pos].b);*/
			rect_indx[get_basepos2(col,row,warea.width)]=pos;
		}}
	}

}
		
static void deindexing(){
	//rect_indx contain base color for all modes, except for DITHER where it contains derived pos
	gint col,row,eff_color,prim_color;
	gint basepos,basepos2,parentpos=0;
	//static char labeltextprc [70];
	gboolean debug=TRUE;



	fcolors_to_int();  //to be sure
	
	for (col=0;col<warea.width;col=col+1) {for (row=0;row<warea.height;row=row+1){
		basepos2=get_basepos2(col,row,warea.width);
		basepos=get_basepos(col,row,maindata.channels,warea.width);
		eff_color=rect_indx[basepos2];
		if (debug && (eff_color>= maindata.effective || eff_color<0) )
			printf ("Effective color index out of range: %.i (0 - %1d)\n",  eff_color,maindata.effective);
		
		if (maindata.mode==DITHER||maindata.mode==DITHER31) {
			parentpos=row%2*2 + col%2;}
		else parentpos=0;
		
		prim_color=effectivec[eff_color].parent[parentpos];
		
		//doing statistics
		primaryc[prim_color].count=primaryc[prim_color].count +1;	
		
		if (debug && (prim_color>= maindata.colors || prim_color<0) )
			printf ("Primary color index out of range: %.i (0 - %1d)\n",  prim_color,maindata.effective);		
		rect_out[basepos  ]=primaryc[prim_color].R;
		rect_out[basepos+1]=primaryc[prim_color].G;
		rect_out[basepos+2]=primaryc[prim_color].B;	
		//if (debug && col%100==0 && row%100==0) printf (" deindex: Entering %1d: %1d %1d %1d\n",
			//prim_color,rect_out[basepos  ],rect_out[basepos+1],rect_out[basepos+2]);
		if (debug && (rect_out[basepos] >255 || rect_out[basepos]<0)) printf ("Out of 0-255 range)\n");
		if (debug && (rect_out[basepos+1] >255 || rect_out[basepos+1]<0)) printf ("Out of 0-255 range)\n");
		if (debug && (rect_out[basepos+2] >255 || rect_out[basepos+2]<0)) printf ("Out of 0-255 range)\n");	
		if (debug && (parentpos<0 || parentpos>4)) 	 printf ("parentpos out of 0-255 range !\n");		
		if (maindata.channels==4)rect_out[basepos+3]=rect_wrk[basepos+3];
		}}
		
	//statistic:
	//gint sum=0,least=100000000;
	//for (i=0;i<maindata.colors;i+=1) {
		//sum=primaryc[i].count +sum;
		//if (primaryc[i].count<least) least=primaryc[i].count;}
		
	//sprintf(labeltextprc, "Least color freq:  %.2f%%",(gfloat)least*100/sum);
	//gtk_label_set_label(GTK_LABEL(infolabel_prc),labeltextprc ); 	
	}


static void insert_legend(){
	//inserting legend (samples of colors)
	gint borderwidth,samplesize,legendheight,legendwidth,offset,rowstart,rowend;
	gint tmp;
	gint i,j;
	gint col,row;
	gint basepos;
	gint color;
	gint *sortedcolors,*colorsfreq;
	gboolean debug=FALSE;
	
	offset=image.width*0.01;
	tmp=(image.width*0.8)/maindata.colors;
	if (tmp>image.width*0.04) tmp=image.width*0.04; //limiting the size of legend
	samplesize=tmp*0.7;
	borderwidth=tmp-samplesize;
	legendheight=2*borderwidth+samplesize;
	legendwidth=borderwidth*(1+maindata.colors)+maindata.colors*samplesize;
	rowstart=image.height-legendheight-offset;
	rowend=image.height-offset;
	
	//getting order of colors
	sortedcolors=g_new(gint,maindata.colors);
	colorsfreq  =g_new(gint,maindata.colors);
	
	for (i=0;i<maindata.colors;i+=1) {
		sortedcolors[i]=i;
		colorsfreq[i]=primaryc[i].count;}
		
	for (i=0;i<maindata.colors;i+=1){
		for (j=0;j<maindata.colors-1;j+=1)
			if (colorsfreq[j] < colorsfreq[j+1]) {
				tmp=colorsfreq[j+1];colorsfreq[j+1]=colorsfreq[j];colorsfreq[j]=tmp;
				tmp=sortedcolors[j+1];sortedcolors[j+1]=sortedcolors[j];sortedcolors[j]=tmp;}}
	//printing details
	if (VERBOSE) for (i=0;i<maindata.colors;i+=1) printf ("  Adding color %2d (occ: %8d) to legend\n", sortedcolors[i],colorsfreq[i]);
	
	if (debug) printf (" Samplesize=%.i; borderwidth=%.i,legend size= %.ix%.i\n",samplesize,borderwidth,borderwidth,legendwidth);
	for (col=offset;col<offset+legendwidth;col=col+1) {for (row=rowstart;row<rowend;row=row+1) {
		basepos=get_basepos(col,row,maindata.channels,image.width);
		//bottom strip
		if (row<rowstart+borderwidth || row>rowend-borderwidth) {
			if (debug) printf("  Adding white to %.i x %.i (%.i)\n",col,row,basepos);
			rect_out[basepos  ]=255;
			rect_out[basepos+1]=255;
			rect_out[basepos+2]=255;}	
		else if ((col-offset)%(samplesize+borderwidth)<borderwidth) {
			rect_out[basepos  ]=255;
			rect_out[basepos+1]=255;
			rect_out[basepos+2]=255;}
		else {color=(col-offset)/(samplesize+borderwidth);
			rect_out[basepos  ]=primaryc[sortedcolors[color]].R;
			rect_out[basepos+1]=primaryc[sortedcolors[color]].G;
			rect_out[basepos+2]=primaryc[sortedcolors[color]].B;}
	}}			
				
}


static gfloat get_linedist(gfloat wr,gfloat wg,gfloat wb,gint dcolor){
	gfloat minlindist=1000,curlindist,dist;
	gint i,bestpos;
	static gint debugcount=0;
	gboolean debug=FALSE;

	
	for (i=0;i<derivedc[dcolor].steps+1;i+=1){
		curlindist=	ABS(wr-derivedc[dcolor].step_r[i]) +
					ABS(wg-derivedc[dcolor].step_g[i]) +
					ABS(wb-derivedc[dcolor].step_b[i]);
		if (curlindist<minlindist) {
			minlindist=curlindist;
			bestpos=i;}
		if (minlindist < curlindist) break;
		}		

	
	dist=	(derivedc[dcolor].step_r[bestpos]-wr)*(derivedc[dcolor].step_r[bestpos]-wr)+
			(derivedc[dcolor].step_g[bestpos]-wg)*(derivedc[dcolor].step_g[bestpos]-wg)+
			(derivedc[dcolor].step_b[bestpos]-wb)*(derivedc[dcolor].step_b[bestpos]-wb)  ;
	if (debug && debugcount%10000==0 && derivedc[dcolor].steps >3)
		printf ("  Closest position on line: %1d/%1d, dist: %.3f\n",
		bestpos,derivedc[dcolor].steps,dist);
	debugcount+=1;
	return dist;
	}



static void find_best2(gfloat wr,gfloat wg,gfloat wb,gint *pos,gfloat *dist,gint mode){
	//return index color (effective color)
	//input - weighted r,g,b
	gint i;
	gfloat disttmp;
	//gboolean debug=FALSE;
	
	*dist=100000;

	for (i=0;i<maindata.derivedcolors;i=i+1){
		if (mode == FAIR) 
			disttmp=(wr-derivedc[i].wr)*(wr-derivedc[i].wr) + (wg-derivedc[i].wg)*(wg-derivedc[i].wg) + (wb-derivedc[i].wb)*(wb-derivedc[i].wb);
		else
			disttmp=get_linedist(wr,wg,wb,i);
		
			
		if (disttmp<*dist) {
			*dist=disttmp;
			*pos=i;}
		}

	*pos=derivedc[*pos].parent[0];
	*dist=pow(*dist,0.5);
	}

		
static void show_fcolors() {
	gint i;
	//gfloat mindist;
	
	if (VERBOSE==FALSE) return;
	
	for (i=0;i<maindata.colors;i=i+1){
		//mindist=find_least_dist(i);
		printf (" Color %2d: %.3f,%.3f,%.3f => %3d,%3d,%3d. Sat.: %.3f Occurence: %8d \n"
			,i,primaryc[i].r, primaryc[i].g,primaryc[i].b,
			primaryc[i].R,primaryc[i].G,primaryc[i].B, get_saturation(primaryc[i].r,
			primaryc[i].g,primaryc[i].b,SIMPLESAT),primaryc[i].count );		
		
		}
	}

static void temp_change_col(int channel, int color, float change){
	if (channel==0) origcolor.value = primaryc[color].r;
	if (channel==1) origcolor.value = primaryc[color].g;
	if (channel==2) origcolor.value = primaryc[color].b;
	origcolor.channel=channel;
	origcolor.color=color;
	if (channel==0) primaryc[color].r +=change;
	if (channel==1) primaryc[color].g +=change;
	if (channel==2) primaryc[color].b +=change;
	}


static void tmp_color_reject(){
	if (origcolor.channel==0) primaryc[origcolor.color].r=origcolor.value;
	if (origcolor.channel==1) primaryc[origcolor.color].g=origcolor.value;
	if (origcolor.channel==2) primaryc[origcolor.color].b=origcolor.value;}	


static float get_brightness(gfloat r,gfloat g,gfloat b,gint type) {
	if (type==SIMPLE) return 0.33*r+0.34*g+0.33*b;
	else printf ("Unknow brightness type\n");
	return 0;}
	
	
static float get_saturation(gfloat r,gfloat g,gfloat b,gint type) {
	gfloat avg;
	if (type==QUADR) { 
		avg=0.241*pow(r,2.0)+0.691*pow(g,2.0)+0.068*pow(b,2.0);
		avg=CLAMP(avg,0,1);
		avg=pow(avg,0.5);}
	else 	avg=get_brightness(r,g,b,SIMPLE);
	return (ABS(avg-r) + ABS(avg-g) + ABS(avg-b))/3.0;}


static gboolean get_dither_colors(){
	gint i,j,k,l,pos;
	gfloat dist_to_avg;
	gfloat avgri,avggi,avgbi;
	gfloat avgrj,avggj,avgbj;
	gfloat avgrk,avggk,avgbk;	
	gboolean debug=FALSE;
	//gfloat r,g,b;
						
	pos=0;
	for (i=0;i<maindata.colors;i+=1) {
		avgri=primaryc[i].r;avggi=primaryc[i].g;avgbi=primaryc[i].b;
		//avgr=avgri;avgg=avggi;avgb=avgbi;
		if (debug) printf (" i (%1d) accepted by default\n",i);
		if (debug) printf (" Starting values/avg: %.3f %.3f %.3f\n",avgri,avgbi,avgbi);		
		for (j=0;j<maindata.colors;j+=1) {
			if (j<i) continue;
			if (maindata.mode==DITHER31 && (!(i==j))) continue;
			dist_to_avg=pow((primaryc[j].r - avgri) * (primaryc[j].r - avgri) +
							(primaryc[j].g - avggi) * (primaryc[j].g - avggi) +
							(primaryc[j].b - avgbi) * (primaryc[j].b - avgbi) , 0.5);
			//printf ("  Calculated dist: %.3f (color %.3f, %.3f %.3f)\n",
				//dist_to_avg,primaryc[j].r,primaryc[j].g,primaryc[j].b);
			if (dist_to_avg> maindata.maxdiff/2) continue;
			avgrj=(avgri+primaryc[j].r)/2.0;avggj=(avggi+primaryc[j].g)/2.0;avgbj=(avgbi+primaryc[j].b)/2.0;
			if (debug) printf ("  New averages: %.3f %.3f %.3f\n",avgrj,avgbj,avgbj);
			if (debug) printf ("  j (%1d) is good\n",j);
					
			for (k=0;k<maindata.colors;k+=1) {
				if (k<j) continue;				
				if (maindata.mode==DITHER31 && (!(i==j))) continue;
				dist_to_avg=pow((primaryc[k].r - avgrj) * (primaryc[k].r - avgrj) +
								(primaryc[k].g - avggj) * (primaryc[k].g - avggj) +
								(primaryc[k].b - avgbj) * (primaryc[k].b - avgbj) , 0.5);
				if (dist_to_avg> maindata.maxdiff/2) continue;
				avgrk=(avgrj*2.0+primaryc[k].r)/3;avggk=(avggj*2.0+primaryc[k].g)/3;avgbk=(avgbj*2.0+primaryc[k].b)/3;
				if (debug) printf ("   New averages: %.3f %.3f %.3f\n",avgrk,avgbk,avgbk);
				if (debug) printf ("   k (%1d) is good\n",k);				
				
				for (l=0;l<maindata.colors;l+=1) {
					if (l<k) continue;
					dist_to_avg=pow((primaryc[l].r - avgrk) * (primaryc[l].r - avgrk) +
									(primaryc[l].g - avggk) * (primaryc[l].g - avggk) +
									(primaryc[l].b - avgbk) * (primaryc[l].b - avgbk) , 0.5);
					if (debug) printf ("    dist_toavg: %.3f (max: %.3f)\n",dist_to_avg,maindata.maxdiff/2);
					if (dist_to_avg> maindata.maxdiff/2) continue;					
					if (debug) printf ("     l*(%1d) is good\n",l);										
					
					effectivec[pos].wr=(primaryc[i].wr + primaryc[j].wr + primaryc[k].wr + primaryc[l].wr)/4.0;	
					effectivec[pos].wg=(primaryc[i].wg + primaryc[j].wg + primaryc[k].wg + primaryc[l].wg)/4.0;	
					effectivec[pos].wb=(primaryc[i].wb + primaryc[j].wb + primaryc[k].wb + primaryc[l].wb)/4.0;	
					effectivec[pos].parent[0]=i;
					effectivec[pos].parent[1]=j;
					effectivec[pos].parent[2]=k;
					effectivec[pos].parent[3]=l;
					effectivec[pos].parents=4;
					pos+=1;
					if (pos>=MAXEFFECTIVE) {maindata.effective=pos;return TRUE;}
					if (debug) printf (" Eff. color %1d accepted - parrents: %1d %1d %1d %1d\n",pos,i,j,k,l);
					}}}}
	if (pos==0) {printf (" ERROR: no derived colors generated\n");exit (1);}
	if (debug) printf ("Got %1d derived colors\n",pos);
	maindata.effective=pos;
	return FALSE;
}

static void populate_linedistdata(gfloat startrange,gint type){
	gfloat end_wr,end_wg,end_wb,dist,avg,avg_wr=0,avg_wb=0,avg_wg=0;
	gint i,j,steps;
	gboolean debug=FALSE;
	
	
	if (type==CAMO) {
		for (i=0;i<maindata.derivedcolors;i+=1) {
			avg_wr=avg_wr+derivedc[i].wr;
			avg_wg=avg_wg+derivedc[i].wg;
			avg_wb=avg_wb+derivedc[i].wb;}
		avg_wr=avg_wr/maindata.derivedcolors;			
		avg_wg=avg_wg/maindata.derivedcolors;	
		avg_wb=avg_wb/maindata.derivedcolors;
		}	
			
	for (i=0;i<maindata.derivedcolors;i+=1) {

		avg=get_brightness(derivedc[i].wr,derivedc[i].wg,derivedc[i].wb,SIMPLE);
		if (type==SATONLY){
			avg_wr=avg;avg_wg=avg;avg_wb=avg;}
		else if (type==CAMO) {
			avg_wr=avg_wr*0.35 + avg*0.65;
			avg_wb=avg_wb*0.35 + avg*0.65;
			avg_wg=avg_wg*0.35 + avg*0.65;}
			
		end_wr=derivedc[i].wr*startrange + avg_wr*(1-startrange);
		end_wg=derivedc[i].wg*startrange + avg_wg*(1-startrange);
		end_wb=derivedc[i].wb*startrange + avg_wb*(1-startrange);
		
		dist= pow( (derivedc[i].wr-end_wr)*(derivedc[i].wr-end_wr) + 
			(derivedc[i].wg-end_wg)*(derivedc[i].wg-end_wg) + 
			(derivedc[i].wb-end_wb)*(derivedc[i].wb-end_wb) ,0.5);
		steps=dist/0.02;
		if (steps>9) steps=9;
		derivedc[i].steps=steps;
		
		if (debug) printf ("Distance for linedistdata: %.3f - steps: %1d (dcolor: %2d)\n",dist,steps,i);
		if (debug) printf (" Range: %.3f %.3f %.3f to %.3f %.3f %.3f\n",derivedc[i].wr,derivedc[i].wg,
			derivedc[i].wb,end_wr,end_wg,end_wb);
		
		derivedc[i].step_r[0]=derivedc[i].wr;
		derivedc[i].step_g[0]=derivedc[i].wg;
		derivedc[i].step_b[0]=derivedc[i].wb;
		for (j=0;j<steps;j+=1){
			derivedc[i].step_r[j+1]=derivedc[i].wr+(end_wr-derivedc[i].wr)*(j+1)/9;
			derivedc[i].step_g[j+1]=derivedc[i].wg+(end_wg-derivedc[i].wg)*(j+1)/9;
			derivedc[i].step_b[j+1]=derivedc[i].wb+(end_wb-derivedc[i].wb)*(j+1)/9;}
		//printing subpoints
			//printf (" Derivedc: %.3f %.3f %.3f\n", derivedc[i].wr,derivedc[i].wg,derivedc[i].wb);
			for (j=0;j<steps+1;j+=1){
				if (debug) printf ("  Subpoint: %.3f %.3f %.3f\n",derivedc[i].step_r[j],
					derivedc[i].step_g[j],derivedc[i].step_b[j]);}
		}
	}


static void cascade_colors(gboolean printinfo,gint forcedmode){
	gint i,j,k,efftmp;
	gint oldtype=-1;
	
	if (forcedmode>=0){
		oldtype=maindata.mode;
		maindata.mode=forcedmode;}
	
	//calculating w
	for (i=0;i<maindata.colors;i+=1) {
	do_weight(primaryc[i].r,primaryc[i].g,primaryc[i].b,&primaryc[i].wr,&primaryc[i].wg,&primaryc[i].wb);}
	
	//populating effective colors
	if (maindata.mode==FAIR || maindata.mode==ENHANCED || maindata.mode==CAMO \
	|| maindata.mode==ADAPTIVE ) {
		for (i=0;i<maindata.colors;i+=1) {
			effectivec[i].wr=primaryc[i].wr;
			effectivec[i].wg=primaryc[i].wg;
			effectivec[i].wb=primaryc[i].wb;
			effectivec[i].parent[0]=i;
			effectivec[i].parents=1;
			}
		maindata.effective=maindata.colors;
		}
	else if (maindata.mode==DITHER || maindata.mode==DITHER31) {		//DITHER
		get_dither_colors();
		}
	else {
		printf ("ERROR: cascade_colors(): Undefined mode: %1d\n",maindata.mode);
		exit(1);} 
		
	
	for (i=0;i<maindata.effective;i+=1) {
		derivedc[i].wr=effectivec[i].wr;
		derivedc[i].wg=effectivec[i].wg;
		derivedc[i].wb=effectivec[i].wb;
		derivedc[i].parent[0]=i;
		derivedc[i].parents=1;
		}
		maindata.derivedcolors=maindata.effective;
	
	
	//for line distance mode
	if ( maindata.mode==CAMO) populate_linedistdata(maindata.startrange,CAMO);
	else if ( !(maindata.mode==FAIR)) populate_linedistdata(maindata.startrange,SATONLY);

	
	if (printinfo) {
		printf ("   Primary -> Effective -> Derived colors\n");
		for (i=0;i<maindata.derivedcolors;i+=1){
			printf ("derived color: %1d\n",i);
			for(j=0;j<derivedc[i].parents;j+=1){
				printf (" Parrent %1d :                %1d (effective color)\n",j,derivedc[i].parent[j]);
				efftmp=derivedc[i].parent[j];
				////printf ("effectivec parents count: %1d for %1d\n",effectivec[efftmp].parents,efftmp);
				for (k=0;k<effectivec[efftmp].parents;k+=1){
					////derivedcolor: i
					printf ("  Parrent %1d :                %1d (primary color)\n",
						k,effectivec[efftmp].parent[k]);
					}
					}
			}}

	if (oldtype>=0) maindata.mode=oldtype;

	}	


static void get_startingcolors(void){
	//creting temporary array with samples, sorting it and selecting few samples as a starting colors
	gint origpos[STEPPING*STEPPING];
	gfloat sampleweight[STEPPING*STEPPING];
	gfloat ftmp;
	gint itmp;
	gint i,j;
	gfloat k;
	gint primaryc_count=0,primaryc_count_start=0;
	gboolean tobeadded=FALSE;
	gfloat dist,targetdist;
	gboolean debug=FALSE;
	
	targetdist=0.04*pow(maindata.weight,0.5);
	//calculating region importance
	for (i=0;i<samplescount;i=i+1) samples[i].reg_importance=samples[i].weight;
	for (i=0;i<samplescount;i=i+1) {
		for (j=0;j<samplescount;j=j+1) {
			if  (j<=i) continue;
			dist=pow( 	(samples[i].r-samples[j].r)*(samples[i].r-samples[j].r)+
						(samples[i].r-samples[j].g)*(samples[i].r-samples[j].g)+
						(samples[i].r-samples[j].b)*(samples[i].r-samples[j].b) , 0.5);
			if (dist<targetdist) {
				samples[i].reg_importance=samples[i].reg_importance+samples[j].weight;
				samples[j].reg_importance=samples[j].reg_importance+samples[i].weight;}
	}}
	if (debug) {
		for (i=0;i<samplescount;i=i+1)
			printf ("Sample %1d importance: %3f (orig. weight: %.3f)\n",
				i,samples[i].reg_importance,		samples[i].weight);}
			
	for (i=0;i<samplescount;i=i+1){
		origpos[i]=i;
		sampleweight[i]=samples[i].reg_importance;}
	
	//sorting
	for (j=0;j<samplescount;j=j+1){
		for (i=0;i<samplescount-1;i=i+1){
			if (sampleweight[i]<sampleweight[i+1]){
				itmp=origpos[i];origpos[i]=origpos[i+1];origpos[i+1]=itmp;
				ftmp=sampleweight[i];sampleweight[i]=sampleweight[i+1];sampleweight[i+1]=ftmp;}
	}}
	
	//printing first n samples
	if (debug){
		for (i=0;i<200;i+=1){
			printf ("Position: %2d, weight %2.3f\n",origpos[i],sampleweight[i]);}}

	//populating primaryc
	if(maindata.forcebw){
		primaryc[0].r=0;primaryc[0].g=0;primaryc[0].b=0;
		primaryc[1].r=1;primaryc[1].g=1;primaryc[1].b=1;
		primaryc_count_start=2;}
		
	for (k=0.8;k>=0;k=k-0.05){
		primaryc_count=primaryc_count_start;
		for (j=0;j<samplescount;j=j+1){
			if (samples[origpos[j]].reg_importance<k*10) continue;
			//printf ("importance: %.3f\n", samples[origpos[j]].reg_importance);
			tobeadded=TRUE;
			for (i=0;i<primaryc_count;i+=1){
				dist=ABS (primaryc[i].r-samples[origpos[j]].r) + 
					 ABS (primaryc[i].g-samples[origpos[j]].g) + 
					 ABS (primaryc[i].b-samples[origpos[j]].b) ;
				if (dist<k){tobeadded=FALSE;break;}
			}
			if (tobeadded){
				primaryc[primaryc_count].r=samples[origpos[j]].r;
				primaryc[primaryc_count].g=samples[origpos[j]].g;				 
				primaryc[primaryc_count].b=samples[origpos[j]].b;	
				primaryc_count+=1;
				if (debug) printf (" Adding color %1d ₍%.3f, %.3f %.3f), importance: %3f\n",
					j,samples[origpos[j]].r,samples[origpos[j]].g,samples[origpos[j]].b,samples[origpos[j]].reg_importance);
				}
			if (primaryc_count==maindata.colors) break;}
		
		if (debug) {
			printf ("Primary colors achieved for tresh %.3f: %1d/%1d\n", k,primaryc_count,maindata.colors);
			//for (i=0;i<primaryc_count;i+=1){
				//printf (" Primary color %1d: RGB_ %.3f, %.3f %.3f\n",
				//i, primaryc[i].r,primaryc[i].g,primaryc[i].b,);}
			}
		
		//if we got needed colors no more iterating
		if (primaryc_count==maindata.colors) break;
	}
	
	if (primaryc_count<maindata.colors) {
		if (VERBOSE || debug) printf ("Small internal shortcoming - not enough starting colors generated\n");
		for (i=primaryc_count;i<maindata.colors;i+=1){
			primaryc[i].r=0.5;
			primaryc[i].g=0.5;				 
			primaryc[i].b=0.5;}
		}
	
}
										
static void get_fcolors(){
	gint i,m,n,o,p;
	//gfloat value;
	gfloat distminglobal,disttmp,distsum;
	gboolean debug;
	gint pos;//,primaryc_pos; //defines color in fcolors
	debug=FALSE;
	gfloat tweakstep,localstep,olddistminglobal,efficiency;
	gint wait_break=0;
	static char labeltextvar [70];
	//gfloat startmin,startup,avg; //range where fcolors will be positioned
	gfloat oldcolorspread, newcolorspread;  // only for defining saturation !!!
	
	get_startingcolors();
	fcolors_to_int();
	//show_fcolors();  // temporarily
	cascade_colors(FALSE,-1);

	show_fcolors();

		
	//calculating distance
	distsum=0;	
	for (m=0;m<samplescount;m=m+1){
		find_best2(samples[m].wr,samples[m].wg,samples[m].wb,&pos,&disttmp,maindata.mode);
		disttmp=disttmp*samples[m].weight;
		distsum=distsum+disttmp;
		if (debug && m%100==0) printf ("  corresponding color for sample %.1d: %1d\n",m,pos);
		}
	//printf ("Distsum: %.3f\n",distsum);

	distminglobal=distsum;
	
	//changing colors
	tweakstep=0.03; //0.15
	//Doing 50 iterations, as maximum
	for (i=0;i<70;i=i+1) {
		if (debug) printf ("iteration: %1d, tweakstep: %.3f\n",i,tweakstep);
		olddistminglobal=distminglobal;
		//changing individual colors
		//n color pos,o -channgel,p +-tweak
		for (n=0;n<maindata.colors;n=n+1) { for (o=0;o<3;o=o+1) { for (p=0;p<2;p=p+1) {
			if (p==0) localstep=tweakstep;
			else localstep=-tweakstep;
			
			//for force B/W do not change 1st and 2nd color
			if (maindata.forcebw && (n==0 || n==1)) continue;
			
			if (maindata.postprocess ==PASTEL && i>5)
				oldcolorspread=get_saturation(primaryc[n].r,primaryc[n].g,primaryc[n].b,SIMPLESAT);
			
			temp_change_col(o,n,localstep); //temporarily changing one color
			cascade_colors(FALSE,-1);
			
			// checking distance of colors
			if (maindata.postprocess == PASTEL && i>5) {
				newcolorspread=get_saturation(primaryc[n].r,primaryc[n].g,primaryc[n].b,SIMPLESAT);
				if ( newcolorspread < 0.04 && newcolorspread < oldcolorspread){
					tmp_color_reject();
					cascade_colors(FALSE,-1);
					continue;}	}		

			if (primaryc[n].r<0 || primaryc[n].g<0 || primaryc[n].b<0 || primaryc[n].r>1 || primaryc[n].g>1 || primaryc[n].b>1) {
				tmp_color_reject();
				cascade_colors(FALSE,-1);}
			
			if (debug) printf ("  Changing color %1d, channel %1d, modification: %.3f:\n",n,o,localstep);
			//if (debug) show_fcolors();

			//calculating new dist
			// iterating over samples to get current difference
			distsum=0;
			for (m=0;m<samplescount;m=m+1){
				find_best2(samples[m].wr,samples[m].wg,samples[m].wb,&pos,&disttmp,maindata.mode);
				//printf (" disttmp: %.3f\n", disttmp);
				
				disttmp=disttmp*samples[m].weight;
				distsum=distsum+disttmp;
				//if (debug) printf ("Result dist: %.3f\n",disttmp);
				}
			if (debug) printf ("  Result for this fcolors: %.3f vs current global dist: %.3f\n",distsum,distminglobal);		

			if (distsum<distminglobal){ 	//modifying distminglobal and preserving changes
				if (debug) printf ("  good change...\n");
				distminglobal=distsum;
				
				}
			else {						 	//if not returning to previous state
				if (debug) printf ("  not good change (reverting value)...\n");
				tmp_color_reject();
				cascade_colors(FALSE,-1);
				//fcolors_from_w_for(base, n);
				}}}}
				
		//all variations are tested
 
		efficiency=1.0-distminglobal/olddistminglobal;		
		if (VERBOSE) printf (" Iteration  %2d, variance reduced by %2.1f%%, tweakstep: %.3f: %.2f -> %.2f\n",i,efficiency*100,tweakstep,olddistminglobal,distminglobal);

		if (efficiency <0.003 && tweakstep<0.0011) {
			wait_break=wait_break+1;
			if (wait_break>2){
				if (VERBOSE) printf ("  Gains are too low, breaking the loop...\n");
				break;}		
		}
		
		if (efficiency<0.01) tweakstep=tweakstep-0.008;
		if (tweakstep<0.001) tweakstep=0.001;
		
		olddistminglobal=distminglobal; 
	}

	//for debug
	//cascade_colors(TRUE,-1);
	
	if (VERBOSE && (maindata.mode==DITHER || maindata.mode==DITHER31))
		printf ("  %1d effective colors generated\n", maindata.effective);
	
	sprintf(labeltextvar, "Final variance:    %.2f",distminglobal);
	gtk_label_set_label(GTK_LABEL(infolabel_var),labeltextvar ); 
	
	
}

static gfloat get_weight(gint x,gint y){
	gint nearx[8]={0,1,1,1,0,-1,-1,-1};
	gint neary[8]={1,1,0,-1,-1,-1,0,1};
	gint prc,i,j,localx,localy,basepos;//one percent based on image sizes
	gfloat r,g,b,r_local,g_local,b_local,maxdist,dist,sumcount,sumdist,count;
	
	prc=(image.height+image.width)/200;
	//printf (" prc: %.d\n",prc);

	basepos=get_basepos(x,y,maindata.channels,image.width);
	r=gammed_values[rect_img[basepos  ]];
	g=gammed_values[rect_img[basepos+1]];
	b=gammed_values[rect_img[basepos+2]];
	//printf ("RGB: %.3f, %.3f %.3f\n",r,g,b);
			
	sumdist=0;sumcount=0;
	for (i=0;i<8;i+=1) {
		maxdist=0;count=0;
		for (j=1;j<4;j+=1) {
			localx=x+nearx[i]*j*2*prc;
			localy=y+neary[i]*j*2*prc;
			if (localx<0|| localy<0 || localx>=image.width || localy >=image.height) continue;
			//printf (" near pixel: %.d %.d for central pixel: %.d x %d\n",localx,localy,x,y);
			basepos=get_basepos(localx,localy,maindata.channels,image.width);
			r_local=gammed_values[rect_img[basepos  ]];
			g_local=gammed_values[rect_img[basepos+1]];
			b_local=gammed_values[rect_img[basepos+2]];
			//printf ("RGB_local: %.3f, %.3f %.3f\n",r_local,g_local,b_local);
			dist=ABS(r_local-r)+ABS(g_local-g)+ABS(b_local-b);
			//printf (" dist: %.3f\n",dist);
			if (dist>maxdist) maxdist=dist;
			count+=1;
		}
		if (count>1) {sumdist=sumdist+dist; sumcount+=1;}
		}
	
	return sumdist/sumcount;
}

static void postdithering(){
	//will iterate over image check one pixel above and previous pixel (those
	//will contain unsatisfied values and calculate goals for current pixel, find nearest color
	//change rect_indx and put residual in current pixels
	gfloat *wr_res_rect,*wg_res_rect,*wb_res_rect;
	gint row,col,basepos,basepos2;	
	gfloat r,g,b,wr,wg,wb; //actual colors of current pixel
	gint pos;
	gfloat wr_res,wg_res,wb_res,dist;

	wr_res_rect=g_new(gfloat,warea.width*warea.height);
	wg_res_rect=g_new(gfloat,warea.width*warea.height);
	wb_res_rect=g_new(gfloat,warea.width*warea.height);	
	
		
	cascade_colors(FALSE,-1); //workaround	
								
	for (col=0;col<warea.width;col+=1) {
		for (row=0;row<warea.height;row+=1) {
			////if (row%100==0) printf ("  Row: %1d\n",row);
			basepos=get_basepos(col,row,maindata.channels,warea.width);
			basepos2=get_basepos2(col,row,warea.width);
			
			//getting targets
			r=gammed_values[rect_wrk[basepos  ]];
			g=gammed_values[rect_wrk[basepos+1]];
			b=gammed_values[rect_wrk[basepos+2]];	
			do_weight(r,g,b,&wr,&wg,&wb);
			
			//adding previous residuals
			wr_res=wr;
			wg_res=wg;
			wb_res=wb;
			if (row>0) {
				wr_res=wr_res + wr_res_rect[basepos2-warea.width];
				wg_res=wg_res + wg_res_rect[basepos2-warea.width];
				wb_res=wb_res + wb_res_rect[basepos2-warea.width];	}
			if (col>0) {
				wr_res=wr_res + wr_res_rect[basepos2-1];
				wg_res=wg_res + wg_res_rect[basepos2-1];
				wb_res=wb_res + wb_res_rect[basepos2-1];	}
			find_best2(wr_res,wg_res,wb_res,&pos,&dist,FAIR);
			rect_indx[basepos2]=pos;
			//putting new values into residuals rect
			wr_res=wr_res-primaryc[effectivec[pos].parent[0]].wr;
			wg_res=wg_res-primaryc[effectivec[pos].parent[0]].wg;
			wb_res=wb_res-primaryc[effectivec[pos].parent[0]].wb;
			//if (wr_res>maindata.weight || wr_res<-maindata.weight)
			wr_res=CLAMP(wr_res,-maindata.weight*0.5,maindata.weight*0.5);
			wg_res=CLAMP(wg_res,-maindata.weight*0.5,maindata.weight*0.5);
			wb_res=CLAMP(wb_res,-maindata.weight*0.5,maindata.weight*0.5);
			wr_res_rect[basepos2]=wr_res/2.0;
			wg_res_rect[basepos2]=wg_res/2.0;
			wb_res_rect[basepos2]=wb_res/2.0;}}						
	
	g_free(wr_res_rect);g_free(wg_res_rect);g_free(wb_res_rect);
	
	}



static void do_sampling(){
	gint i,j,k; //iterators
	gint col,row;
	gint basepos;
	gfloat r,g,b,wr,wg,wb;
	gboolean debug;
	gboolean new_sample;
	gfloat maxweight,minweight;
	//gfloat totalweight=0;
	gfloat total1,total2,total3,total4;
	debug=FALSE;
	
	//zeroing count
	for (i=0;i<STEPPING;i=i+1) samples[i].count=1;
	for (i=0;i<STEPPING;i=i+1) samples[i].sat=-1;
	
	samplescount=0;   //for positioning in samples
	maxweight=0;minweight=100; //starting values
	for (i=0;i<STEPPING;i=i+1) {for(j=0;j<STEPPING;j=j+1){
		col=image.width/(STEPPING+1)*(i+0.5);
		row=image.height/(STEPPING+1)*(j+0.5);	
		
		if (debug) printf ("Doing pixel: %i x %i\n",col,row);
		basepos=get_basepos(col,row,maindata.channels,image.width);
		//if (debug) printf ("%i, %i, %i\n",rect_img[basepos  ],rect_img[basepos+1],rect_img[basepos +2]);
		r=gammed_values[rect_img[basepos  ]];
		g=gammed_values[rect_img[basepos+1]];
		b=gammed_values[rect_img[basepos+2]];
		
		r=ROUND(r/SAMPLEINT)*SAMPLEINT;
		g=ROUND(g/SAMPLEINT)*SAMPLEINT;
		b=ROUND(b/SAMPLEINT)*SAMPLEINT;

		do_weight(r,g,b,&wr,&wg,&wb);
				
		new_sample=TRUE;
		//testing previous colors
		for (k=0;k<samplescount;k+=1){
			if (wr==samples[k].wr && wg==samples[k].wg && wb==samples[k].wb) {
				new_sample=FALSE;
				if (maindata.wmode==COUNT || maindata.wmode==MIX ) samples[k].count+=1;
				if (maindata.wmode==BYNEIGH || maindata.wmode==MIX ) 
					samples[k].neigh=samples[k].neigh+get_weight(col,row);
				continue;}}
		
		if (new_sample) {
			samples[samplescount].r=r;
			samples[samplescount].g=g;		
			samples[samplescount].b=b;
			samples[samplescount].wr=wr;
			samples[samplescount].wg=wg;		
			samples[samplescount].wb=wb;
			//populating weight
			if (maindata.wmode==BYSAT || maindata.wmode==MIX)
				samples[samplescount].sat=get_saturation(r,g,b,SIMPLESAT);
			if (maindata.wmode==BYNEIGH || maindata.wmode==MIX)
				samples[samplescount].neigh=get_weight(col,row);
			samples[samplescount].uniq=1;
			samples[samplescount].count=1;
			samplescount+=1;}

		if (debug) printf (" Put into samples: %.3f,  %.3f, %.3f, sat: %.3f\n",samples[k].wr,samples[k].wg,samples[k].wb,samples[k].sat);
		k=k+1;
	}}
	
	//normalizing samples to value 400
	total1=0,total2=0,total3=0,total4=0;
	for (i=0;i<samplescount;i+=1) { 
		total1=total1+samples[i].count;
		total2=total2+samples[i].sat;		
		total3=total3+samples[i].uniq;		
		total4=total4+samples[i].neigh;}
		
	//if (debug) printf ("Totalweight of sampled pixels: %.3f\n",totalweight);
	for (i=0;i<samplescount;i+=1) { 
		samples[i].count =(gfloat)samples[i].count*400.0/total1;
		//printf (" resetting saturation from %.3f (/ %.3f)f\n",	samples[i].sat,total2);		
		samples[i].sat   =(gfloat)samples[i].sat*400.0/total2;	
		//printf ("                               to %.3f\n",	samples[i].sat);
		samples[i].uniq  =(gfloat)samples[i].uniq*400.0/total3;		
		samples[i].neigh=(gfloat)samples[i].neigh*400.0/total4;}
		
	//calculating final weight
	for (i=0;i<samplescount;i+=1) { 
		if (maindata.wmode==COUNT) samples[i].weight=samples[i].count;
		else if (maindata.wmode==BYSAT) samples[i].weight=samples[i].sat;
		else if (maindata.wmode==UNIQUE) samples[i].weight=samples[i].uniq;
		else if (maindata.wmode==BYNEIGH) samples[i].weight=samples[i].neigh;
		else samples[i].weight=0.25*samples[i].count + 0.25*samples[i].sat +
			0.25*samples[i].neigh + 0.25*samples[i].uniq;
		if (samples[i].weight<minweight) minweight=samples[i].weight;
		if (samples[i].weight>maxweight) maxweight=samples[i].weight;}
		
	if (VERBOSE) {
		if (minweight>0) printf ("  Min/max weights of sample pixels: %.3f / %.3f (diff: %.1fx)\n",minweight,maxweight,maxweight/minweight);
		else printf ("  Min/max weights of sample pixels: %.3f / %.3f\n",minweight,maxweight);}
	

	if (VERBOSE){
		 printf ("  Colors with high importance (if any):\n");
		for (k=0;k<samplescount;k+=1) {
			samples[k].weight=(2+samples[k].weight)/3;
			if (samples[k].weight>4 ) printf ("  Color %2d: %.3f, %.3f %.3f, weight: %.3f\n",k,samples[k].wr
			,samples[k].wg,samples[k].wb,samples[k].weight);}}
		
	if (VERBOSE) printf (" Count of unique sample colors: %1d\n",samplescount);
	}

static void recalculate_sizes(){
	if (maindata.previewbool) {
		warea.startx=parea.startx-10;
		if (warea.startx<0) warea.startx=0;
		warea.starty=parea.starty-10;
		if (warea.starty<0) warea.starty=0;
		
		parea.endx=parea.startx+parea.width;
		parea.endy=parea.starty+parea.height;
		warea.endx=parea.endx+10;
		if (warea.endx>image.endx) warea.endx=image.endx;
		warea.endy=parea.endy+10;
		if (warea.endy>image.endy) warea.endy=image.endy;}
	else {
		warea.startx=image.startx;
		warea.starty=image.starty;
		warea.endx=image.endx;
		warea.endy=image.endy;}
	warea.width=warea.endx-warea.startx;
	warea.height=warea.endy-warea.starty;	
	image.width=image.endx-image.startx;
	image.height=image.endy-image.starty;
	}	

static void despotting2(){
	//first we will get maps with pixels that have to be removed
	//then we will heal those pixels (spots)
	gint i,j,col,row,basepos,near_basepos, highest, result, sum,changed;
	gboolean *mask;
	gint *newvalues;
	gint *col_occ;
	gint relpos_x[8]={-1,-1, 0, 1, 1, 1, 0,-1};
	gint relpos_y[8]={ 0, 1, 1, 1, 0,-1,-1,-1};	
	gboolean debug=FALSE;
		
	mask= g_new(gboolean,warea.width*warea.height);
	newvalues= g_new(gint,warea.width*warea.height);
	for (i=0;i<warea.width*warea.height;i=i+1) mask[i]=TRUE;
	for (i=0;i<warea.width*warea.height;i=i+1) newvalues[i]=-1;	
	col_occ=g_new(gint,maindata.effective);
	
	//this will creage 'holes' into mask
	remove_short(&mask[0],CHECKCOLORS,maindata.sptresh);
	
	//iterating over holes in mask and calculating new values
	for (j=0;j<50;j=j+1) {
		if (debug) printf (" Despotting iteration: %1d\n",j);
		for (row=0;row<warea.height;row=row+1) { 
			//if (row%100==0) printf (" row: %1d\n",row);
			for (col=0;col<warea.width;col=col+1) {	
				
				basepos=get_basepos2(col,row,warea.width);
				if (mask[basepos]==TRUE) continue;
				for (i=0;i<maindata.effective;i=i+1) {col_occ[i]=0;}
				
				for (i=0;i<8;i=i+1) {
					if (col+relpos_x[i] <0 ||col+relpos_x[i]>=warea.width || row+relpos_y[i]<0 || row+relpos_y[i]>= warea.height) continue;
					near_basepos=get_basepos2(col+relpos_x[i],row+relpos_y[i],warea.width);
					if (mask[near_basepos]==FALSE) continue;
					col_occ[rect_indx[near_basepos]]=col_occ[rect_indx[near_basepos]]+1;}
				
				//now we have col_occ populated
				sum=0;
				for (i=0;i<maindata.effective;i=i+1) sum=sum+col_occ[i];
				if (sum<3) continue;
				
				highest=0;result=-1;
				for (i=0;i<maindata.effective;i=i+1) if (highest<col_occ[i]) {highest=col_occ[i];result=i;}
				//printf ("resulting color: %1d, occ: %1d\n",result,highest);
				
				newvalues[basepos]=result;}}
		
		//putting values into rect_indx
		changed=0;
		for (i=0;i<warea.width*warea.height;i=i+1) {
			//if (i%1000==0) 
			//printf ( "doing pixel: %1d\n",i);
			if (mask[i]==FALSE && newvalues[i]>-1){
				rect_indx[i]=newvalues[i];
				mask[i]=TRUE;
				changed=changed+1;}}
		if (VERBOSE) printf ("  Changed pixels: %7d (despotting)\n", changed);
		if (changed==0) break;

	}
	g_free(mask);
	g_free(newvalues);
	g_free(col_occ);
	
	
}
	
static void  remove_short(gboolean* outlinemask,gboolean checkcolors,gint treshold){
	//creating array with numbers of lines, so each pixel will be part of one line
	gint *lines_id;
	gint col,row,i,j,k,basepos,nearbasepos,changed;
	gint next_id=0;
	gint relpos_x[4]={-1,-1,0,1};
	gint relpos_y[4]={0,-1,-1,-1};	
	gint *mapper;  //for lines that are in fact other lines
	gint *id_occ;
	gboolean debug=FALSE;
	gint spotstats[3]={0,0,0};//total, below tresh,max
	
	lines_id = g_new(int,warea.width*warea.height);
	mapper = g_new(int,MAPPERLENGTH);
	id_occ = g_new(int,MAPPERLENGTH);	
	
	//inserting values to demap
	for (i=0;i<MAPPERLENGTH;i=i+1) mapper[i]=i;
	
	//pupulating with -1
	for (i=0; i<warea.width*warea.height;i=i+1) lines_id[i]=-1;
	if (debug) printf ( " Populating with -1 done\n");


	//iterating over outlinemask
	for (k=0;k<5;k=k+1) {
		//printf ("x- lines_id: %1d\n",lines_id[0]);
		if (debug) printf (" Short lines/spots identification - iteration %1d\n",k);
		for (row=0;row<warea.height;row=row+1) { 
			for (col=0;col<warea.width;col=col+1) {
				//if (col==0 && row ==0 && debug ) printf ("  position %1d x %1d\n",col,row);
				
				basepos=get_basepos2(col,row,warea.width);
				
				// pixel is not a part of outline
				if (outlinemask[basepos]==FALSE) { //Conditional jump or move depends on uninitialised value(s)

					//if (debug) printf ("    not in outlinemask (%.i)\n",basepos);
					continue;}
				
				for (i=0;i<4;i=i+1){
					if (col+relpos_x[i] <0 ||col+relpos_x[i]>=warea.width || row+relpos_y[i]<0) continue;
	
					nearbasepos=get_basepos2(col+relpos_x[i],row+relpos_y[i],warea.width);
					//if (debug) printf ("  Testing near pixel pixel %0d, (%1d x %1d)\n", i,col+relpos_x[i],row+relpos_y[i]);				
					
					if (checkcolors && (!(rect_indx[basepos] == rect_indx[nearbasepos]) )) continue; //for spots 
					
					if (outlinemask[nearbasepos ] == FALSE) continue;
					
					//two basic options are possible, central pixel has id set or do not have it set
					if (lines_id[basepos]==-1) {
						lines_id[basepos]=lines_id[nearbasepos];
						//if (debug) printf ("  adjacent pixel to ID %1d\n",lines_id[nearbasepos]);
						}
					else if (lines_id[basepos] == lines_id[nearbasepos]); //nothing needed to do
					else if (!(mapper[lines_id[basepos]]==lines_id[basepos])); //nothing can be done
					else { 
						mapper[lines_id[basepos]]=lines_id[nearbasepos];
						//if (debug) printf ("  mapping to %1d\n",lines_id[nearbasepos]);
						}
					
				}
				//if the pixel is still without value this will be new color
				if (lines_id[basepos]==-1) {
					lines_id[basepos]=next_id;
					next_id=next_id+1;
					if (next_id>=MAPPERLENGTH) {printf ("next_id exhausted: %1d\n",next_id); exit (1);}	}
					
			}}	  //end of iteration over pixels		
	

		for (j=0;j<100;j=j+1) {
			changed=0;
			for (i=0;i<next_id;i=i+1) {
				//if (i==mapper[i]) continue;
				if (mapper[i]==mapper[mapper[i]]) continue;
				mapper[i]=mapper[mapper[i]];
				changed=changed+1;}
			if (debug) printf ("   Demapping (iter. %1d): changed values: %1d\n", j, changed);
			if (changed==0) break;
		}

	//remapping id of lines in image
	for (j=0;j<warea.width*warea.height;j=j+1) {if (lines_id[j]>-1) lines_id[j]=mapper[lines_id[j]];};

	//resetting values in demap
	for (i=0;i<MAPPERLENGTH;i=i+1) mapper[i]=i;
		//printf ("b- lines_id: %1d\n",lines_id[0]);	

	}

	if (debug) printf (" Mapping done..\n");

	//getting lines count
	for (i=0;i<next_id;i=i+1) id_occ[i]=0;
	for (j=0;j<warea.height*warea.width;j=j+1){
		if (lines_id[j]==-1) continue;
		id_occ[lines_id[j]]=id_occ[lines_id[j]]+1;}

	//printing length of lines
	if (debug) {
		for (i=0;i<next_id;i=i+1){
			spotstats[0]=spotstats[0]+1;
			if (id_occ[i]<treshold) spotstats[1]=spotstats[1]+1;
			if (id_occ[i]>spotstats[2]) spotstats[2]=id_occ[i];
			}
	if (VERBOSE) printf ("  Spots: %1d, below treshold: %1d. Biggest one: %1d\n", spotstats[0],spotstats[1],spotstats[2]);
	}
		
	//finally removing long lines
	for (j=0;j<warea.width*warea.height;j=j+1) {
		if (id_occ[lines_id[j]]<treshold) outlinemask[j]=FALSE;}
	
	g_free(lines_id);
	g_free(mapper);	
	g_free(id_occ);	
			
	}



static void do_lines(){
	//this puts lines directly to rect_out
	gint i,j,k;
	gfloat brdiff,huediff,r,g,b;
	gboolean isline;
	gint nearx[8]={0,1,1,1,0,-1,-1,-1};
	gint neary[8]={1,1,0,-1,-1,-1,0,1};
	gint basepos;
	gboolean debug=FALSE;
	gboolean *outlinemask;
	gfloat *brtable, *huetable;
	GimpRGB rgbcolor;
	GimpHSV hsvcolor;


	//first doing DOLINETABLE (there will be combinations of all colors and values will indicate if a pixel
	// will be part of line
	gboolean linestab[maindata.effective][maindata.effective]; //defines if a comb of colors creates a outline

	if (debug) printf("   starting do_lines()\n");
	outlinemask = g_new (gboolean, warea.width * warea.height);
	brtable     = g_new (gfloat,maindata.effective);
	huetable    = g_new (gfloat,maindata.effective);	
	
	if (debug) printf("   outlinemask allocated\n");


	//populating br&hue tables
	for (i=0;i<maindata.effective;i+=1) {
		undo_weight(effectivec[i].wr,effectivec[i].wg,effectivec[i].wb,&r,&g,&b);
		brtable[i]=(r+g+b)/3.0;
		rgbcolor.r=r;
		rgbcolor.g=g;
		rgbcolor.b=b;
		gimp_rgb_to_hsv (&rgbcolor,&hsvcolor);
		huetable[i]=hsvcolor.h;
		if (debug) printf (" Populating br&hue tables with: %.3f and %.3f\n", brtable[i],huetable[i]);
	}	
	
	
	for (i=0;i<maindata.effective;i=i+1) { for (j=0;j<maindata.effective;j=j+1) {
		brdiff =ABS(brtable[i]-brtable[j]);
		huediff=ABS(huetable[i]-huetable[j]);
		if (huediff>0.5) huediff=1-huediff;
		
		if (brdiff >=maindata.linbrtresh  && huediff >= maindata.linhuetresh) linestab[i][j]=TRUE;		
		else linestab[i][j]=FALSE;
		if (debug) printf ("Building linestab[%1d][%1d]: %1d\n",i,j,linestab[i][j]);
		}
	}

	if (debug) printf("   linestab done\n");
	
	//iterating over image to create OUTLINEMASK
	for (i=1;i<warea.width-1;i=i+1) { for (j=1;j<warea.height-1;j=j+1) {
		isline=FALSE;
		for (k=0;k<8;k=k+1) {
			if (linestab[rect_indx[get_basepos2(i,j,warea.width)]][rect_indx[get_basepos2(i+nearx[k],j+neary[k],warea.width)]]) {
				isline=TRUE;
				break;}}
		if (isline) outlinemask[get_basepos2(i,j,warea.width)]=TRUE;
		else  outlinemask[get_basepos2(i,j,warea.width)]=FALSE;
	}}
	if (debug) printf("   outline mask done\n");	


	// REMOVING LONG lines
	if (maindata.linesrem>0) remove_short(&outlinemask[0],LINESONLY,maindata.linesrem );

	if (debug) printf ("  end of removing short lines section\n");

	//putting values into rect_out
	for (i=0;i<warea.width;i=i+1) { for (j=0;j<warea.height;j=j+1) {
		//printf ("i: %01d, j: %01d\n",i,j);
		basepos=get_basepos(i,j,maindata.channels,warea.width);
		if (outlinemask[get_basepos2(i,j,warea.width)]) {
			//printf ("  %01d x %01d: line is here\n",i,j);
			rect_out[basepos]=0;
			rect_out[basepos+1]=0;
			rect_out[basepos+2]=0;
			rect_out[basepos+3]=0;
			if (maindata.channels == 4 ) rect_out[basepos+3]=255;	}
		else {
			rect_out[basepos]=255;
			rect_out[basepos+1]=255;
			rect_out[basepos+2]=255;
			if (maindata.channels == 4 ) rect_out[basepos+3]=0;	
			}
	}}
	if (debug) printf("   values in rect_out\n");
	g_free(outlinemask);g_free(brtable);g_free(huetable);
}

static void get_limits(){
	if (maindata.mode ==DITHER ) {
		maindata.maxdiff=(gfloat)(2-maindata.colors*0.175);
		if (maindata.maxdiff<0.6) maindata.maxdiff=0.6;}
	else if ( maindata.mode ==DITHER31){
		maindata.maxdiff=(gfloat)(2.2-maindata.colors*0.2);
		if (maindata.maxdiff<0.6) maindata.maxdiff=0.6;}	
	else
		maindata.maxdiff=1;
	
	if (maindata.mode==ENHANCED) maindata.startrange=0.5;
	else if (maindata.mode==CAMO) maindata.startrange=0.3;
	else if (maindata.mode==ADAPTIVE) maindata.startrange=0.6;
	else if (maindata.mode==DITHER || maindata.mode==DITHER31 ){
 		if (maindata.colors>=7) maindata.startrange=1;
 		else maindata.startrange=(1-(gfloat)(7-maindata.colors)/10);}
 	else maindata.startrange=1;
}
 	
 		
void export_to_layer()
{
	GimpDrawable *new_layer;
	gint layer_ID,basepos_nl,basepos_ro;
	gint x,y;
	//gfloat br; //brightness
	GimpPixelRgn rgn_out_nl;
	guchar *rect_out_nl;
	
	if (VERBOSE) printf("== Exporting to a layer..\n");
	
	//creating and attaching new layer
	layer_ID = gimp_layer_new (image_ID, "Cartoon", image.width, image.height, GIMP_RGBA_IMAGE, 100.0,  GIMP_NORMAL_MODE);
	new_layer = gimp_drawable_get (layer_ID);
	gimp_image_add_layer (image_ID,layer_ID,-1);
	

	rect_out_nl      = g_new (guchar, image.width * image.height * 4);	
	gimp_pixel_rgn_init (&rgn_out_nl, new_layer, 0, 0, image.width, image.height, FALSE, TRUE);

	//populating rgn_out with data
	ITERATE(x,0,image.width) {ITERATE (y,0,image.height) {
		basepos_nl=get_basepos(x,y,4,image.width);
		basepos_ro=get_basepos(x,y,maindata.channels,image.width);
		rect_out_nl[basepos_nl    ] = rect_out[basepos_ro    ];
		rect_out_nl[basepos_nl + 1] = rect_out[basepos_ro +1 ];
		rect_out_nl[basepos_nl + 2] = rect_out[basepos_ro +2 ];	
		if (maindata.dolines && (!(maindata.mode==ADAPTIVE )))
			if (rect_out_nl[basepos_nl    ] ==0 ) rect_out_nl[basepos_nl + 3] = 255;
			else rect_out_nl[basepos_nl + 3] = 0;
		else if ( maindata.channels ==4)
			rect_out_nl[basepos_nl + 3] = rect_out[basepos_ro +3 ];	
		else
			rect_out_nl[basepos_nl + 3] =255;
		}}
   
	//nahratie udajov do rgn_out
    gimp_pixel_rgn_set_rect (&rgn_out_nl, rect_out_nl,0, 0,image.width,image.height);
	//printf ("   h\n");
	g_free (rect_out_nl);
	
	gimp_drawable_flush (new_layer);
	gimp_drawable_merge_shadow (new_layer->drawable_id, TRUE);
	gimp_drawable_update (new_layer->drawable_id,0, 0, image.width,image.height);
	
	gimp_progress_end();
}		


static void process (GimpDrawable *source,GimpPreview *preview) {
	gint i;
	GimpPixelRgn rgn_img; //whole image for samples
	GimpPixelRgn rgn_wrk; //portion (or whole) image for processing
	GimpPixelRgn rgn_out; //output
	
	colors_warning(FALSE) ;
	
	for (i=0;i<256;i++) { //to speed up conversion from raw RGB to gammed values
		gammed_values[i]=pow((gfloat)i/255,1/2.2);}
	for (i=0;i<maindata.colors;i+=1) primaryc[i].count=0;	
	
	get_limits();
		
	if (VERBOSE) {
		printf ("===  Running cartoonizer's core  ====\n");
		printf (" Fcolors target: %.i\n",maindata.colors);
		if (maindata.dolines) printf (" Treshold for lines: %.3f\n",maindata.linbrtresh);		
		if (maindata.linesrem>0) printf (" Removing lines shorten then: %1d\n",maindata.linesrem);	
		if (maindata.sptresh>0) printf (" Removing spots smaller then: %1d\n",maindata.sptresh);
		printf (" Weighting mode: %1d\n",maindata.wmode);
		printf (" Mode: %1d...\n",maindata.mode);	
		printf (" Limits: startrange: %.3f, maxdiff: %.3f\n",maindata.startrange,maindata.maxdiff);
		}
	//colorscount=maindata.colors;  // default
			
	// getting coordinates of what will be processed
	if ( preview ){
          gimp_preview_get_position (preview, &parea.startx, &parea.starty);
          gimp_preview_get_size (preview, &parea.width, &parea.height);
         maindata.previewbool=TRUE;
			}
	else {
    	maindata.previewbool=FALSE;	}

	if ( (! maindata.previewbool) ) {
				gimp_progress_init ("Cartoonizing...");
				gimp_progress_update (0.01);}
    
    if (VERBOSE) printf (" Is this preview? %01d\n",maindata.previewbool);
    	
    gimp_drawable_mask_bounds (source->drawable_id,&image.startx, &image.starty,&image.endx, &image.endy); 

	maindata.channels = gimp_drawable_bpp (source->drawable_id);//getting number of channels
	if (VERBOSE) printf (" Dimensions retrieved ...\n");
	
	//quit processing if preview sizes are 1
	if (VERBOSE && maindata.previewbool && parea.width<=1) {
		printf (" Small preview got, quitting...\n");
		return;
	}
	
	//recalculating above size
	recalculate_sizes();
	if (VERBOSE) printf ("  Processing section: %1dx%1d to %1dx%1d, sizes: %1dx%1d, Image sizes: %1dx%1d\n",warea.startx,warea.starty,warea.endx,warea.endy,warea.width,warea.height,image.width,image.height);
		
	//initializing pixelrgn for input and output section
	gimp_pixel_rgn_init (&rgn_img , source, image.startx,image.starty,image.width,image.height, FALSE, FALSE); 
	//loading all data from image
	rect_img  =   g_new (guchar, maindata.channels  * image.width * image.height); 
	gimp_pixel_rgn_get_rect (&rgn_img,rect_img,image.startx,image.starty,image.width,image.height);	
	if (VERBOSE) printf ("== Received entire image to be used for sampling ...\n");

	do_sampling();
	if (VERBOSE) printf ("== Sampling done  ..\n");
	if ( maindata.previewbool == FALSE ) gimp_progress_update (0.05);

	//if (VERBOSE) printf ("point 1\n");	
	get_fcolors();
	if ( maindata.previewbool == FALSE ) gimp_progress_update (0.3);
	if (VERBOSE) printf ("== Fcolors calculated ...\n");
	if (maindata.effective>=MAXEFFECTIVE-2 || maindata.effective>=MAXDERIVED-4) colors_warning(TRUE);

	//getting rectangle to be processed
	gimp_pixel_rgn_init (&rgn_wrk , source, warea.startx,warea.starty,warea.width,warea.height, FALSE, FALSE); 
	//loading all data from image
	if (rect_wrk_initialized==FALSE){
		rect_wrk = g_new (guchar, maindata.channels * image.width * image.height); 
		rect_wrk_initialized=TRUE;}	
	gimp_pixel_rgn_get_rect (&rgn_wrk,rect_wrk,warea.startx,warea.starty,warea.width,warea.height);	
	if (VERBOSE) printf ("== Working part of image retrieved ...\n");

	//converting rect_wrk to indexed image
	if (rect_indx_initialized==FALSE){
		rect_indx =g_new (int, image.width * image.height); 
		rect_indx_initialized=TRUE;}

	//skipping part of workflow
	if (maindata.mode==ADAPTIVE ) goto end_of_middle;	

	// indexing
	indexing();
	if ( maindata.previewbool == FALSE ) gimp_progress_update (0.4);
	if (VERBOSE) printf ("== Image indexed\n");
	
	// elimination of small noise
	if (maindata.denoising) {
		denoising(7,8,100,LOOSE);
		if (VERBOSE) printf ("== Denoising done ...\n");}
	if ( maindata.previewbool == FALSE ) gimp_progress_update (0.55);
			
	// elimination of spots
	if (maindata.sptresh>0 && maindata.spit>0) {
		for (i=0;i<maindata.spit;i=i+1) {
			despotting2();
			if (VERBOSE) printf ("== Despotting #%d done ...\n",i+1);}}
	if ( maindata.previewbool == FALSE ) gimp_progress_update (0.65);
	
	// erode shapes
	if (maindata.doerode && maindata.erode > 0) {
		denoising(5,5,maindata.erode,STRICT);
		if (VERBOSE) printf ("== Eroding done done ...\n");
	}
	if ( maindata.previewbool == FALSE ) gimp_progress_update (0.6);		
	
	//allocating space for rect_out
	if (rect_out_initialized==FALSE){
		rect_out =g_new (guchar,maindata.channels *  image.width * image.height); 
		rect_out_initialized=TRUE;}

	//doing lines or ...
	if (maindata.dolines){
		do_lines();
		if ( maindata.previewbool == FALSE ) gimp_progress_update (0.8);
		if (VERBOSE) printf ("== Outlining done\n");}	
	else {
		// ...doing adaptive (post-)dithering...
		end_of_middle:
		if (maindata.mode==ADAPTIVE ) postdithering();
		if ( maindata.previewbool == FALSE ) gimp_progress_update (0.8);
		// ... and posprocesing if needed
		if (maindata.postprocess==PASTEL) 	get_pastel_colors(0.7,0.25);
		if (maindata.postprocess==DARKPASTEL) 	get_pastel_colors(0.4,0.55);
		if (maindata.postprocess==GOLD)   	get_gold_colors();
		if (maindata.postprocess==SATURATED)get_saturated_colors(); 
		
		fcolors_to_int();   //selfexplanatory
		if (VERBOSE) printf ("== Final RGB values calculated\n");
		
		deindexing();   // changing index to RGB
		if (VERBOSE) printf ("== Image deindexed\n");	
		
		if(maindata.legend && maindata.previewbool==FALSE){//if legend is choosed and not preview
			insert_legend();
			if (VERBOSE) printf ("== Legend added\n");	}
		}
	if ( maindata.previewbool == FALSE ) gimp_progress_update (0.90);

	fcolors_to_int();
	show_fcolors();

	if (maindata.exportlayer) {
		export_to_layer();
		return;}

	//putting data back to rgn_out
	gimp_pixel_rgn_init (&rgn_out, source, warea.startx,warea.starty,warea.width,warea.height, preview == NULL, TRUE);
	gimp_pixel_rgn_set_rect (&rgn_out, rect_out,warea.startx,warea.starty,warea.width,warea.height);
		
   //update (graphical) of preview/image
    if (VERBOSE) printf ("== Sending results back to gimp (preview: %1d)\n",maindata.previewbool);  
	if (maindata.previewbool ) {
    	gimp_drawable_preview_draw_region (GIMP_DRAWABLE_PREVIEW (preview),&rgn_out);}
    else {
		gimp_drawable_flush (source);
		gimp_drawable_merge_shadow (source->drawable_id, TRUE);
		gimp_drawable_update (source->drawable_id,image.startx,image.starty,image.width,image.height);}
	gimp_progress_end();
	g_free(rect_img);
}


static gboolean gui_window (GimpDrawable *source)
{
		GtkWidget *dialog;
		GtkWidget *main_hbox,*vbox2,*vbox1;
		GtkWidget *table; 
		GtkWidget *l_colors,*l_count,*l_sat,*l_weighting, *l_dolines, *l_spot,*info_exp,*l_alg,
				*l_doerode,*l_postprocess,*l_forcebw;
		GtkWidget *l_spotsize, *l_spotiter,*l_linebrstresh,*l_lineshuetresh,*l_legend, *l_linremove,*infolabel,*l_denoise,*l_erode;
		GtkWidget *exportbutton;
		GtkWidget *preview;
		
		
		gimp_ui_init ("Cartoonizer", FALSE);
		
		
		gimp_dialogs_show_help_button (FALSE);
		dialog = gimp_dialog_new (title, "gimp plugin",
                            NULL, 0,
                            gimp_standard_help_func, "plug-in-cartoonizer",
                            GIMP_STOCK_RESET, RESPONSE_RESET,
                            GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                            GTK_STOCK_OK,     RESPONSE_OK,

                            NULL);

	main_hbox = gtk_hbox_new (FALSE, 10);
	gtk_container_add (GTK_CONTAINER (GTK_DIALOG (dialog)->vbox), main_hbox);
	gtk_container_set_border_width (GTK_CONTAINER (main_hbox), 15);
	gtk_widget_show (main_hbox);
	
	//1.VBOXs
	vbox1 = gtk_vbox_new (FALSE, 5);
	gtk_box_pack_start (GTK_BOX (main_hbox), vbox1, TRUE, TRUE, 0);
	gtk_container_set_border_width (GTK_CONTAINER (vbox1), 6);
	gtk_widget_show (vbox1);
  
  
	vbox2 = gtk_vbox_new (FALSE, 5);
	gtk_box_pack_start (GTK_BOX (main_hbox), vbox2, FALSE,FALSE, 0);
	gtk_container_set_border_width (GTK_CONTAINER (vbox2), 6);
	gtk_widget_show (vbox2);
	
	preview = gimp_drawable_preview_new (source, NULL);
	gtk_box_pack_start (GTK_BOX (vbox1), preview, TRUE, TRUE, 0);
	gtk_widget_set_tooltip_text(preview, "Preview is AUTOEXPANDING. Technical comment: \
 when calculating this preview, only visible area + 10 px in all directions are considered. \
 So especially 'spot removal' and 'short lines removal' functionality might lead to slightly \
 different results when processing entire image afterwards.");
	gtk_widget_show (preview);
	
	infolabel_warn=gtk_label_new("");
	gtk_box_pack_start (GTK_BOX (vbox1), infolabel_warn, FALSE, FALSE, 0);
	gtk_misc_set_alignment (GTK_MISC (infolabel_warn), 0, 0.5);
	gtk_widget_show (infolabel_warn);	
	
	infolabel_var=gtk_label_new("");
	gtk_widget_set_tooltip_text(infolabel_var, "This indicates how different the final image is to source image (not relevant for Adaptive Dithering).");
	gtk_box_pack_start (GTK_BOX (vbox1), infolabel_var, FALSE, FALSE, 0);
	gtk_misc_set_alignment (GTK_MISC (infolabel_var), 0, 0.5);
	gtk_widget_show (infolabel_var);
	
	info_exp = gtk_expander_new  ("<span foreground=\"#505050\">For more info:</span>" );
	gtk_expander_set_use_markup (GTK_EXPANDER(info_exp), TRUE);
	gtk_box_pack_end (GTK_BOX (vbox1), info_exp, FALSE, FALSE, 30);
	gtk_widget_set_tooltip_text( info_exp, "Visit plugin's homepage (link in expander) to learn more about the plugin, check for new versions or to give any feedback.");
	gtk_widget_show (info_exp);
  	
	 	infolabel=gtk_label_new("Visit wiki and downloads section on homepage: http://code.google.com/p/cartooner-color-reducer/");
	 	gtk_label_set_line_wrap (GTK_LABEL(infolabel), TRUE);
	 	gtk_label_set_use_markup (GTK_LABEL(infolabel), TRUE);
	 	gtk_widget_set_size_request(infolabel,230,50);
	 	gtk_container_add (GTK_CONTAINER (info_exp), infolabel);
		//gtk_widget_set_tooltip_text(infolabel, "....");
		gtk_misc_set_alignment (GTK_MISC (infolabel), 0, 0.5);
		gtk_widget_show (infolabel);
  
	table=gtk_table_new(19,2,FALSE);
	gtk_box_pack_start (GTK_BOX (vbox2), table, FALSE, FALSE, 0);
	gtk_table_set_col_spacings (GTK_TABLE(table),8);
	gtk_table_set_row_spacings (GTK_TABLE(table),1);
	gtk_table_set_row_spacing  (GTK_TABLE(table),10,16);
	gtk_table_set_row_spacing  (GTK_TABLE(table),12,8);
	gtk_table_set_row_spacing  (GTK_TABLE(table),16,20);
	gtk_table_set_row_spacing  (GTK_TABLE(table),17,20);
	gtk_widget_show (table);
    
	l_colors = gtk_label_new ("<b>Color reduction:</b>");
	//gtk_widget_set_tooltip_text(l_colors, "Target number of colors.");
	gtk_label_set_use_markup (GTK_LABEL(l_colors), TRUE);
	gtk_widget_set_size_request(l_colors,0,35);
	gtk_table_attach_defaults (GTK_TABLE(table),l_colors,0,2,0,1);
	gtk_misc_set_alignment (GTK_MISC (l_colors), 0, 0.7);
	gtk_widget_show (l_colors);

	l_count = gtk_label_new ("Number of colors:");
	gtk_widget_set_tooltip_text(l_count, "Target number of colors.");
	gtk_label_set_use_markup (GTK_LABEL(l_count), TRUE);
	gtk_table_attach_defaults (GTK_TABLE(table),l_count,0,1,1,2);
	gtk_misc_set_alignment (GTK_MISC (l_count), 0, 0.5);
	gtk_widget_show (l_count);
	

	l_sat = gtk_label_new ("Color weight:");
	gtk_widget_set_tooltip_text(l_sat, "Something like internal saturation of image - used to increase weight of color against brightness. \
(1 - no change)");
	gtk_label_set_use_markup (GTK_LABEL(l_sat), TRUE);
	gtk_table_attach_defaults (GTK_TABLE(table),l_sat,0,1,2,3);
	gtk_misc_set_alignment (GTK_MISC (l_sat), 0, 0.5);
	gtk_widget_show (l_sat);

	l_weighting = gtk_label_new ("Color/pixel weighting:");
	gtk_widget_set_tooltip_text(l_weighting, "Pixels and their colors can have various weight when computing final colors.");
	gtk_label_set_use_markup (GTK_LABEL(l_weighting), TRUE);
	gtk_table_attach_defaults (GTK_TABLE(table),l_weighting,0,1,3,4);
	gtk_misc_set_alignment (GTK_MISC (l_weighting), 0, 0.5);
	gtk_widget_show (l_weighting);


	l_alg = gtk_label_new ("Processing algorithm:");
	//gtk_widget_set_tooltip_text(l_alg, "");
	gtk_label_set_use_markup (GTK_LABEL(l_alg), TRUE);
	gtk_table_attach_defaults (GTK_TABLE(table),l_alg,0,1,4,5);
	gtk_misc_set_alignment (GTK_MISC (l_alg), 0, 0.5);
	gtk_widget_show (l_alg);

	l_forcebw = gtk_label_new ("Force Black+White:");
	gtk_widget_set_tooltip_text(l_forcebw, "Check this to force white and black color into final colors. \
(However this does not quarantee that black and white colors will be used in final image alltogether).");
	//gtk_widget_set_size_request(l_legend,0,35);
	gtk_table_attach_defaults (GTK_TABLE(table),l_forcebw,0,1,5,6);
	gtk_misc_set_alignment (GTK_MISC (l_forcebw), 0, 0.5);
	gtk_widget_show (l_forcebw);
	
	l_legend = gtk_label_new ("Insert legend:");
	gtk_widget_set_tooltip_text(l_legend, "Insert legend (samples of final colors) to the bottom of image. Not shown in preview.");
	gtk_table_attach_defaults (GTK_TABLE(table),l_legend,0,1,6,7);
	gtk_misc_set_alignment (GTK_MISC (l_legend), 0, 0.5);
	gtk_widget_show (l_legend);

	l_denoise = gtk_label_new ("<b>Denoise:</b>");
	gtk_widget_set_tooltip_text(l_denoise, "Get rid of standalone pixels = change color of pixels if all neighbours are of different color.");
	gtk_label_set_use_markup (GTK_LABEL(l_denoise), TRUE);
	gtk_widget_set_size_request(l_denoise,0,35);
	gtk_table_attach_defaults (GTK_TABLE(table),l_denoise,0,1,7,8);
	gtk_misc_set_alignment (GTK_MISC (l_denoise), 0, 0.5);
	gtk_widget_show (l_denoise);
 
	l_spot = gtk_label_new ("<b>Spot removal:</b>");
	gtk_widget_set_tooltip_text(l_spot, "Identify and get rid of discrete areas of the same color.");
	gtk_widget_set_size_request(l_spot,0,35);
	gtk_label_set_use_markup (GTK_LABEL(l_spot), TRUE);
	gtk_table_attach_defaults (GTK_TABLE(table),l_spot,0,2,8,9);
	gtk_misc_set_alignment (GTK_MISC (l_spot), 0, 0.7);
	gtk_widget_show (l_spot);
 
	l_spotsize  = gtk_label_new ("Spot size (px):");
	gtk_widget_set_tooltip_text(l_spotsize, "Size of a discrete spot (in pixels) to be rid of... Default is 0 = disabled");
	gtk_label_set_use_markup (GTK_LABEL(l_spotsize), TRUE);
	gtk_table_attach_defaults (GTK_TABLE(table),l_spotsize,0,1,9,10);
	gtk_misc_set_alignment (GTK_MISC (l_spotsize), 0, 0.5);
	gtk_widget_show (l_spotsize);

	l_spotiter  = gtk_label_new ("Iterations:");
	gtk_widget_set_tooltip_text(l_spotiter, "Count of passes...");
	gtk_label_set_use_markup (GTK_LABEL(l_spotiter), TRUE);
	gtk_table_attach_defaults (GTK_TABLE(table),l_spotiter,0,1,10,11);
	gtk_misc_set_alignment (GTK_MISC (l_spotiter), 0, 0.5);
	gtk_widget_show (l_spotiter);

	l_doerode = gtk_label_new ("<b>Erode shapes:</b>");
	gtk_widget_set_tooltip_text(l_doerode, "Get rid of sharp outreaching sections, it is strongly recommend to have spot removal (spotsize>0) enabled.");
	gtk_label_set_use_markup (GTK_LABEL(l_doerode), TRUE);
	//gtk_widget_set_size_request(l_doerode,0,35);
	gtk_table_attach_defaults (GTK_TABLE(table),l_doerode,0,1,11,12);
	gtk_misc_set_alignment (GTK_MISC (l_doerode), 0, 0.5);
	gtk_widget_show (l_doerode);
	
	l_erode = gtk_label_new ("Iterations limit:");
	gtk_widget_set_tooltip_text(l_erode, "Maximum number of iterations over image, eroding might be stopped sooner if no further pixels can be modified.");
	gtk_label_set_use_markup (GTK_LABEL(l_erode), TRUE);
	//gtk_widget_set_size_request(l_denoise,0,35);
	gtk_table_attach_defaults (GTK_TABLE(table),l_erode,0,1,12,13);
	gtk_misc_set_alignment (GTK_MISC (l_erode), 0, 0.5);
	gtk_widget_show (l_erode);
	

	l_dolines = gtk_label_new ("<b>Generate lines:</b>");
	gtk_widget_set_tooltip_text(l_dolines, 
		"Lines are created (~ individual pixel is made black) only if both tresholds below are satisfied. Lines are created on own layer and with alpha channel.");
	gtk_label_set_use_markup (GTK_LABEL(l_dolines), TRUE);
	gtk_widget_set_size_request(l_dolines,0,35);
	gtk_table_attach_defaults (GTK_TABLE(table),l_dolines,0,1,13,14);
	gtk_misc_set_alignment (GTK_MISC (l_dolines), 0, 0.6);
	gtk_widget_show (l_dolines);

	l_linebrstresh = gtk_label_new ("Brightness tresh.:");
	gtk_widget_set_tooltip_text(l_linebrstresh, "Minimal difference in brightness of adjacent pixels. 0 = all lines will be generated.");
	//gtk_label_set_use_markup (GTK_LABEL(l_linebrstresh), TRUE);
	gtk_table_attach_defaults (GTK_TABLE(table),l_linebrstresh,0,1,14,15);
	gtk_misc_set_alignment (GTK_MISC (l_linebrstresh), 0, 0.5);
	gtk_widget_show (l_linebrstresh);

	l_lineshuetresh = gtk_label_new ("Hue treshold:");
	gtk_widget_set_tooltip_text(l_lineshuetresh, "Minimal difference in hue of adjacent pixels. 0 = all lines will be generated.");
	//gtk_label_set_use_markup (GTK_LABEL(l_linebrstresh), TRUE);
	gtk_table_attach_defaults (GTK_TABLE(table),l_lineshuetresh,0,1,15,16);
	gtk_misc_set_alignment (GTK_MISC (l_lineshuetresh), 0, 0.5);
	gtk_widget_show (l_lineshuetresh);

	l_linremove = gtk_label_new ("Remove short:");
	gtk_widget_set_tooltip_text(l_linremove, "Lines with lesser size (in pixels) will be removed.");
	//gtk_label_set_use_markup (GTK_LABEL(l_linebrstresh), TRUE);
	gtk_table_attach_defaults (GTK_TABLE(table),l_linremove,0,1,16,17);
	gtk_misc_set_alignment (GTK_MISC (l_linremove), 0, 0.5);
	gtk_widget_show (l_linremove);
	
	l_postprocess = gtk_label_new ("<b>Postprocessing:</b>");
	gtk_label_set_use_markup (GTK_LABEL(l_postprocess), TRUE);
	gtk_widget_set_tooltip_text(l_postprocess, "Final modification of calculated colors.");
	//gtk_label_set_use_markup (GTK_LABEL(l_linebrstresh), TRUE);
	gtk_table_attach_defaults (GTK_TABLE(table),l_postprocess,0,1,17,18);
	gtk_misc_set_alignment (GTK_MISC (l_postprocess), 0, 0.5);
	gtk_widget_show (l_postprocess);


	//NUMBER BOXes
	
	spin_count_adj = gtk_adjustment_new (maindata.colors, 2,MAXCOLORS, 1, 1, 0);
	spin_count = gtk_spin_button_new (GTK_ADJUSTMENT (spin_count_adj), 1, 0);
	gtk_widget_show (spin_count);
	gtk_table_attach_defaults (GTK_TABLE(table),spin_count,1,2,1,2);
	gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_count), TRUE);
	gtk_widget_show (spin_count);

	spin_weight_adj = gtk_adjustment_new (WEIGHTDEF, 1,15, 1, 1, 0);
	spin_weight = gtk_spin_button_new (GTK_ADJUSTMENT (spin_weight_adj), 1, 0);
	gtk_widget_set_tooltip_text(spin_weight, "With higher number you can sacrifice \
brightness range for benefit of colors.");
	gtk_widget_show (spin_weight);
	gtk_table_attach_defaults (GTK_TABLE(table),spin_weight,1,2,2,3);
	gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_weight), TRUE);
	gtk_widget_show (spin_weight);

	combo3 = gtk_combo_box_new_text();
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo3),wmode1 );
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo3),wmode2);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo3),wmode3);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo3),wmode4);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo3),wmode5);
	gtk_table_attach_defaults (GTK_TABLE(table),combo3,1,2,3,4);
	gtk_widget_set_size_request(combo3,70,-1);
	gtk_combo_box_set_active(GTK_COMBO_BOX( combo3), WMODEDEF);
	gtk_widget_show (combo3);

	combo = gtk_combo_box_new_text();
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo),mode1);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo),mode4);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo),mode3);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo),mode2);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo),mode5);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo),mode8);
	gtk_table_attach_defaults (GTK_TABLE(table),combo,1,2,4,5);
	gtk_widget_set_size_request(combo,120,-1);
	gtk_combo_box_set_active(GTK_COMBO_BOX( combo), MODEDEF);
	gtk_widget_show (combo);

	forcebw_button= gtk_check_button_new();
	gtk_table_attach_defaults (GTK_TABLE(table),forcebw_button,1,2,5,6);
	gtk_widget_set_size_request(forcebw_button,0,25);
	gtk_widget_show (forcebw_button);

	legend_button= gtk_check_button_new();
	gtk_table_attach_defaults (GTK_TABLE(table),legend_button,1,2,6,7);
	gtk_widget_set_size_request(legend_button,0,25);
	gtk_widget_show (legend_button);

	denoising_button= gtk_check_button_new();
	gtk_table_attach_defaults (GTK_TABLE(table),denoising_button,1,2,7,8);
	gtk_widget_set_tooltip_text(denoising_button, "Leave it checked unless you are sure you need raw indexed image. Very usefull for futher operations listed below.");
	gtk_widget_set_size_request(denoising_button,0,40);
	gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (denoising_button   ),TRUE);
	gtk_widget_show (denoising_button);
	  
 	spin_sp_tresh_adj = gtk_adjustment_new (maindata.sptresh, 0,500, 1, 1, 0);
	spin_sp_tresh = gtk_spin_button_new (GTK_ADJUSTMENT (spin_sp_tresh_adj), 1, 0);
	gtk_widget_set_tooltip_text(spin_sp_tresh, "0=disabled, good value in range 20 - 100.");
	gtk_widget_show (spin_sp_tresh);
	gtk_table_attach_defaults (GTK_TABLE(table),spin_sp_tresh,1,2,9,10);
	gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_sp_tresh), TRUE);
	gtk_widget_show (spin_sp_tresh);

	spin_sp_it_adj = gtk_adjustment_new (maindata.spit, 0,5, 1, 1, 0);
	spin_sp_it = gtk_spin_button_new (GTK_ADJUSTMENT (spin_sp_it_adj), 1, 0);
	gtk_widget_set_tooltip_text(spin_sp_it, "0=disabled, 2 is usually enough, if you notice artifacts increase the number.");
	gtk_widget_show (spin_sp_it);
	gtk_table_attach_defaults (GTK_TABLE(table),spin_sp_it,1,2,10,11);
	gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_sp_it), TRUE);
	gtk_widget_show (spin_sp_it);

	spin_erode_it_adj = gtk_adjustment_new (ERODEDEF, 0,200, 1, 1, 0);
	spin_erode_it = gtk_spin_button_new (GTK_ADJUSTMENT (spin_erode_it_adj), 1, 0);
	gtk_widget_set_tooltip_text(spin_erode_it, "Either leave it on default or try very low numbers to soften the effect");
	gtk_widget_show (spin_erode_it);
	gtk_table_attach_defaults (GTK_TABLE(table),spin_erode_it,1,2,12,13);
	gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_erode_it), TRUE);
	gtk_widget_set_sensitive  (spin_erode_it,FALSE);
	gtk_widget_show (spin_erode_it);

	spin_lin_br_tresh_adj = gtk_adjustment_new (LINBRTRESHDEF, 0,1, 0.01, 0.01, 0);
	spin_lin_br_tresh = gtk_spin_button_new (GTK_ADJUSTMENT (spin_lin_br_tresh_adj), 0.1,2);
	gtk_widget_set_tooltip_text(spin_lin_br_tresh, "To generate lines solely based on brightness, set 'Hue treshold' to 0");
	gtk_widget_show (spin_lin_br_tresh);
	gtk_table_attach_defaults (GTK_TABLE(table),spin_lin_br_tresh,1,2,14,15);
	gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_lin_br_tresh), TRUE);
	gtk_widget_set_sensitive  (spin_lin_br_tresh,FALSE);
	gtk_widget_show (spin_lin_br_tresh);

	spin_lin_hue_tresh_adj = gtk_adjustment_new (LINHUETRESHDEF, 0,0.5, 0.01, 0.01, 0);
	spin_lin_hue_tresh = gtk_spin_button_new (GTK_ADJUSTMENT (spin_lin_hue_tresh_adj), 0.1,2);
	gtk_widget_set_tooltip_text(spin_lin_hue_tresh, 
		"To generate lines solely based on hue, set 'Brightness treshold' to 0");
	gtk_widget_show (spin_lin_hue_tresh);
	gtk_table_attach_defaults (GTK_TABLE(table),spin_lin_hue_tresh,1,2,15,16);
	gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_lin_hue_tresh), TRUE);
	gtk_widget_set_sensitive  (spin_lin_hue_tresh,FALSE);
	gtk_widget_show (spin_lin_hue_tresh);

	spin_lin_rem_adj = gtk_adjustment_new (LINREMDEF, 0,1000, 10, 10, 0);
	spin_lin_rem = gtk_spin_button_new (GTK_ADJUSTMENT (spin_lin_rem_adj), 1,0);
	gtk_widget_set_tooltip_text(spin_lin_rem, "0=disabled (no removal)");
	gtk_widget_show (spin_lin_rem);
	gtk_table_attach_defaults (GTK_TABLE(table),spin_lin_rem,1,2,16,17);
	gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_lin_rem), TRUE);
	gtk_widget_set_sensitive  (spin_lin_rem,FALSE);
	gtk_widget_show (spin_lin_rem);

	doerode_button= gtk_check_button_new();
	gtk_table_attach_defaults (GTK_TABLE(table),doerode_button,1,2,11,12);
	gtk_widget_set_size_request(doerode_button,0,40);
	gtk_widget_show (doerode_button);

	dolines_button= gtk_check_button_new();
	gtk_table_attach_defaults (GTK_TABLE(table),dolines_button,1,2,13,14);
	gtk_widget_set_tooltip_text(dolines_button, "Options below are active only if this is checked.");
	gtk_widget_set_size_request(dolines_button,0,40);
	gtk_widget_show (dolines_button);

	combo2 = gtk_combo_box_new_text();
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo2),post1 );
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo2),post2);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo2),post5);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo2),post3);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo2),post4);
	gtk_table_attach_defaults (GTK_TABLE(table),combo2,1,2,17,18);
	//gtk_widget_set_tooltip_text(combo2, "Take this postprocessing options as experimental for now.");
	gtk_widget_set_size_request(combo2,70,-1);
	gtk_combo_box_set_active(GTK_COMBO_BOX( combo2), 0);
	gtk_widget_show (combo2);
	
	exportbutton = gtk_button_new_with_label("Export as new layer");
	gtk_widget_set_tooltip_text(exportbutton, "Plugin window will stay alive with all settings preserved. During export/calculation entire plugin's window is frozen.");
	gtk_table_attach_defaults (GTK_TABLE(table),exportbutton,0,2,18,19);
	gtk_widget_show (exportbutton);

	//sending signal to update preview
	g_signal_connect_swapped (preview			, "invalidated"	,  G_CALLBACK (process),source);
	g_signal_connect_swapped (spin_count_adj	, "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
	g_signal_connect_swapped (spin_weight_adj	, "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
	g_signal_connect_swapped (spin_sp_tresh_adj , "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
	g_signal_connect_swapped (spin_sp_it_adj	, "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
	g_signal_connect_swapped (spin_lin_br_tresh_adj, "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
	g_signal_connect_swapped (spin_lin_hue_tresh_adj, "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
	g_signal_connect_swapped (spin_lin_rem_adj	, "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
	g_signal_connect_swapped (spin_erode_it_adj	, "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
	g_signal_connect_swapped (G_OBJECT( dolines_button), "toggled",G_CALLBACK (gimp_preview_invalidate), preview);
	g_signal_connect_swapped (G_OBJECT( doerode_button), "toggled",G_CALLBACK (gimp_preview_invalidate), preview);
	g_signal_connect_swapped (G_OBJECT( denoising_button), "toggled",G_CALLBACK (gimp_preview_invalidate), preview);
	g_signal_connect_swapped (G_OBJECT( forcebw_button), "toggled",G_CALLBACK (gimp_preview_invalidate), preview);
	g_signal_connect_swapped (G_OBJECT(combo )	, "changed"		, G_CALLBACK (gimp_preview_invalidate), preview);
	g_signal_connect_swapped (G_OBJECT(combo2)	, "changed"		, G_CALLBACK (gimp_preview_invalidate), preview);
	g_signal_connect_swapped (G_OBJECT(combo3)	, "changed"		, G_CALLBACK (gimp_preview_invalidate), preview);
			
	process (source, GIMP_PREVIEW (preview));
	
	//receiving values from sliders and modifying sharpals
	g_signal_connect (spin_count_adj	, "value_changed"	, G_CALLBACK (gimp_int_adjustment_update), &maindata.colors);
	g_signal_connect (spin_weight_adj	, "value_changed"	, G_CALLBACK (gimp_int_adjustment_update), &maindata.weight);
	g_signal_connect (spin_sp_tresh_adj	, "value_changed"	, G_CALLBACK (gimp_int_adjustment_update), &maindata.sptresh);	
	g_signal_connect (spin_sp_it_adj	, "value_changed"	, G_CALLBACK (gimp_int_adjustment_update), &maindata.spit);
	g_signal_connect (spin_lin_br_tresh_adj, "value_changed", G_CALLBACK (gimp_float_adjustment_update), &maindata.linbrtresh);
	g_signal_connect (spin_lin_hue_tresh_adj,"value_changed", G_CALLBACK (gimp_float_adjustment_update), &maindata.linhuetresh);
	g_signal_connect (spin_lin_rem_adj	, "value_changed"	, G_CALLBACK (gimp_int_adjustment_update), &maindata.linesrem);
	g_signal_connect (spin_erode_it_adj	, "value_changed"	, G_CALLBACK (gimp_int_adjustment_update), &maindata.erode);
	g_signal_connect (G_OBJECT(dolines_button), "toggled"	, G_CALLBACK( dolines_changed ), NULL );
	g_signal_connect (G_OBJECT(doerode_button), "toggled"	, G_CALLBACK( doerode_changed ), NULL );	
	g_signal_connect (G_OBJECT(denoising_button), "toggled"	, G_CALLBACK( denoising_changed ), NULL );
	g_signal_connect (G_OBJECT(legend_button), "toggled"	, G_CALLBACK( legend_changed ), NULL );	
	g_signal_connect (G_OBJECT(forcebw_button), "toggled"	, G_CALLBACK( forcebw_changed ), NULL );	
	g_signal_connect_swapped(G_OBJECT(exportbutton),"clicked",G_CALLBACK( exportwrapper ), source );
	g_signal_connect( G_OBJECT( combo )	, "changed"  		, G_CALLBACK( cb_changed ), NULL );
	g_signal_connect( G_OBJECT( combo2)	, "changed"  		, G_CALLBACK( post_changed ), NULL );	
	g_signal_connect( G_OBJECT( combo3)	, "changed"  		, G_CALLBACK( wmode_changed ), NULL );
			
	gtk_widget_show (dialog);
	
	//receiving signals from gimp buttons + "x" (close window button)
	g_signal_connect (dialog, "response",
                    G_CALLBACK (response_callback),
                    NULL);

  gtk_main ();

  if (VERBOSE) printf ("  End of (cartoonizer's) GUI... \n");
  return process_image; //TRUE if image should be processed
}


static void response_callback (GtkWidget *widget,  gint response_id) {
	
  switch (response_id) 	 {
	case RESPONSE_RESET:
	if (VERBOSE)  printf (" Plugin window returned: Resetting... \n");
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_count),COLORSDEF);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_weight),WEIGHTDEF);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_sp_tresh),SPTRESHDEF);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_sp_it),SPITDEF);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_erode_it),ERODEDEF);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_lin_br_tresh),LINBRTRESHDEF);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_lin_hue_tresh),LINHUETRESHDEF);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_lin_rem),LINREMDEF);
	gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (dolines_button  ),FALSE);
	gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (doerode_button  ),FALSE);
	gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (denoising_button),TRUE );
	gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (legend_button   ),FALSE);
	gtk_combo_box_set_active(GTK_COMBO_BOX( combo), MODEDEF);
	gtk_combo_box_set_active(GTK_COMBO_BOX( combo2), 0);
	gtk_combo_box_set_active(GTK_COMBO_BOX( combo3), WMODEDEF);
			
	break;

    case RESPONSE_OK:  //quitting plugin window and applying change
      if (VERBOSE) printf (" Plugin window returned: OK... \n");
      process_image=TRUE; 
      gtk_widget_destroy (widget);
      gtk_main_quit ();
      break;

    default: // if other response - terminate plugin window
      if (VERBOSE) printf (" Plugin window terminated... \n");
      gtk_widget_destroy (widget);
      gtk_main_quit ();
      break;
    };
	
}



