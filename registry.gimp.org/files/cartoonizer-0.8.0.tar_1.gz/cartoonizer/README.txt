COLOR REDUCER and CARTOONIZER, gimp plugin
current version 0.8.0 


HOMEPAGE: http://code.google.com/p/cartooner-color-reducer (see wiki for more info)



WHAT IT DOES:

	This plugin does following:
	- finds best colors to represent original image (few switches to finetune)
	- cleans out standalone pixels
	- remove whole areas of the same color
	- smoothes sharp shapes
	- alternatively generates outlines (outlines can be generated only as separate layer)
	- removes short lines
	- dithering modes avaiable alternatively
	- few "postprocess" modes (color modification)



CURRENT STATUS:

	0.8.x - stable, as by now I do not intend to add another features.



INSTALATION:

  LINUX:

	1. extract the tarbal
	2. 'cd' to directory with cartoonizer.c file
	3. for user-only installation, compile as user:
	    $ gimptool-2.0 --install cartoonizer.c
	   and for system-wide installation (must be root):
	    $ gimptool-2.0 --install-admin cartoonizer.c
	
	
	
	If compilation fails with something like this:
	
	   /usr/bin/ld: /tmp/cctTFG6U.o: undefined reference to symbol 'pow@@GLIBC_2.0'
	   /usr/bin/ld: note: 'pow@@GLIBC_2.0' is defined in DSO /lib/libm.so.6 so try adding it to the linker command line
	   /lib/libm.so.6: could not read symbols: Invalid operation
	   collect2: ld returned 1 exit status
	
	issue this in console and try to compile again:
	
	   export LDFLAGS="$LDFLAGS -lm"
	
	Needed on ArchLinux, not needed on Debian Lenny (my limited experience)
	
	Compilation should complete without any errors (or significant warnings) 
	if you run into critical issue, please contact me somehow (by mail or Issues section). 
	Attach also Gtk version (run: 'pkg-config --modversion gtk+-2.0'),
	list your distribution with version and gimp's version at least. And paste the error, of course.


  WINDOWS:

	I do not prepare windows binaries, but I am willing to host compiled package on the google code.
	
	Beware, windows binaries are not standalone program, must be put to appropriate 
	folder and initiated from within GIMP.
	
	You can also search for windows binaries on registry.gimp.org


  OSX version:
  
	Well, I dont know :)


 UNINSTALL:

	just remove compiled the binary, might be located like:
	/home/tibor/.gimp-2.6/plug-ins/cartoonizer
	if user-only installation. As for system wide installation - 
	well I dont know right directory right now :)



USE:

	To learn more how it works visit the above mentioned wiki and/or read mouse over tips within plugin.
	
	The plugin itself si located: Filters -> Artistic -> Cartoonizer



Published: 5. Dec 2012

feedback: tiborb95 at gmail dot com
or check above wiki for more options
