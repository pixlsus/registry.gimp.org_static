#ifndef __MAPOBJECT_UI_H__
#define __MAPOBJECT_UI_H__

/* Externally visible variables */
/* ============================ */

extern GdkGC     *gc;
extern GtkWidget *previewarea;

/* Externally visible functions */
/* ============================ */

gboolean main_dialog (GimpDrawable *drawable);

#endif  /* __MAPOBJECT_UI_H__ */
