gimp-dds 2.0.2
(C) Copyright 2007 Shawn Kirst <skirst@fuse.net>

To install, extract these files to your GIMP plugins directory.
This directory is usually located at:
C:\Program Files\GIMP-2.0\lib\gimp\2.0\plug-ins
