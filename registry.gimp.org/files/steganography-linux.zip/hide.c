#include<libgimp/gimp.h>
#include<libgimp/gimpui.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<gtk/gtk.h>


static void query (void);
static void run   (const gchar      *name,
                   gint              nparams,
                   const GimpParam  *param,
                   gint             *nreturn_vals,
                   GimpParam       **return_vals);

static gboolean build_ui (GimpDrawable *drawable);
static void write_header(guchar *first_row,gint,gint,gint);
static void get_file_content();
static void get_file_header();
static void get_image_dimension(GimpDrawable *drawable);
static void get_no_of_rows_to_write();
static gint is_feasible();
static void convert_to_binary(int x,int [],int );
static void write_file_to_image(GimpDrawable *drawable);

//~ storage for the data of input file
static unsigned  char file_content[2500000];
static gchar file_path[100], file_type[10];
static gint file_size,img_width,img_height,no_of_rows_to_write, feasible;
static guchar *info;
static int no_of_chars=0, binary[8];

GimpPlugInInfo PLUG_IN_INFO =
{
  NULL,
  NULL,
  query,
  run
};

MAIN()
static void
query (void)
{
  static GimpParamDef args[] =
  {
    {
      GIMP_PDB_INT32,
      "run-mode",
      "Run mode"
    },
    {
      GIMP_PDB_IMAGE,
      "image",
      "Input image"
    },
    {
      GIMP_PDB_DRAWABLE,
      "drawable",
      "Input drawable"
    }
  };

  gimp_install_procedure (
    "plug-in-hide",
    "Hide text/images inside an image",
    "Works on only lossless image formats",
    "Srihari,Suhas,Vidyashree,Zeeshan",
    "2012, Srihari,Suhas,Vidyashree,Zeeshan",
    "Jan 26, 2012",
    "_Hide",
    "RGB*, GRAY*",
    GIMP_PLUGIN,
    G_N_ELEMENTS (args), 0,
    args, NULL);

  gimp_plugin_menu_register ("plug-in-hide",
                             "<Image>/Filters/Steganography");
}

static void
run (const gchar      *name,
     gint              nparams,
     const GimpParam  *param,
     gint             *nreturn_vals,
     GimpParam       **return_vals)
{
  static GimpParam  values[1];
  
  GimpPDBStatusType status = GIMP_PDB_SUCCESS;
  GimpRunMode       run_mode;
  GimpDrawable     *drawable;

  /* Setting mandatory output values */
  *nreturn_vals = 1;
  *return_vals  = values;

  values[0].type = GIMP_PDB_STATUS;
  values[0].data.d_status = status;

  /* Getting run_mode - we won't display a dialog if
   * we are in NONINTERACTIVE mode
   */
  run_mode = param[0].data.d_int32;
  drawable = gimp_drawable_get (param[2].data.d_drawable);
  gimp_progress_init ("Hiding in image...");
  if(! build_ui (drawable))
  	g_message("error");    
  strcpy(file_path,info);

  get_file_header();
  get_file_content();
  get_image_dimension(drawable);
  
  if(is_feasible())
  {
    get_no_of_rows_to_write(); 
  }
  else
  {
    g_message("not feasible;input file size too large");
    return;
  }
  write_file_to_image(drawable);
  gimp_displays_flush ();
  gimp_drawable_detach (drawable);
  return;
}

static void 
get_file_header()
{
  FILE *fp;
  //get file_type
  strcpy(file_type,strstr(file_path,"."));
  if(strlen(file_type)==4)
  {
    file_type[4]=' ';
  }
  //get file size
  fp=fopen(file_path,"rb");
  fseek(fp, 0L, SEEK_END);
  file_size = ftell(fp);
  fseek(fp, 0L, SEEK_SET);
	
}

static void 
get_file_content()
{ 
  FILE *fp;
  int r=0,c=0;
  fp=fopen(file_path,"r");
  if(fp==NULL)
    g_message("can't open file");
  for(c=0;c<file_size;c++)
  {
    file_content[c]=(unsigned char) fgetc (fp);
  }
  fclose(fp);
}

static void 
get_image_dimension(GimpDrawable *drawable)
{
  gint x1, y1, x2, y2;
  gimp_drawable_mask_bounds (drawable->drawable_id,
                             &x1, &y1,
                             &x2, &y2);
  img_width=x2-x1;
  img_height=y2-y1;
}


static gint
is_feasible()
{
  feasible=(file_size*8<img_height*img_width*3);
}

static void
get_no_of_rows_to_write()
{
  no_of_rows_to_write=(gint)ceil(file_size*8/img_width*3);
}


static void
write_file_to_image (GimpDrawable *drawable)
{
  gint         i, j, k, channels;
  gint         x1, y1, x2, y2;
  GimpPixelRgn rgn_in, rgn_out;
  guchar      *row1, *row, *row3;
  int tmp,sum=0,counter=0,file_content_counter=0,lsb=0,binary[8];
  gimp_drawable_mask_bounds (drawable->drawable_id,
                             &x1, &y1,
                             &x2, &y2);
  channels = gimp_drawable_bpp (drawable->drawable_id);

  gimp_pixel_rgn_init (&rgn_in,
                       drawable,
                       x1, y1,
                       x2 - x1, y2 - y1,
                       FALSE, FALSE);
  gimp_pixel_rgn_init (&rgn_out,
                       drawable,
                       x1, y1,
                       x2 - x1, y2 - y1,
                       TRUE, TRUE);

  no_of_chars=file_size;
  row = g_new (guchar, channels * (x2 - x1));
  
  //Prepare and write header
  gimp_pixel_rgn_get_row (&rgn_in,
                              row,
                              x1, y1,
                              x2 - x1);   
   
  gimp_pixel_rgn_get_row (&rgn_in,
                              row,
                              x1, y1,
                              x2 - x1);                              
   
  write_header(&row[0],x1,x2,channels);
  gimp_pixel_rgn_set_row (&rgn_out,
                              row,
                              x1, y1,
                              x2 - x1);
   //finished writing header
  file_content_counter=0;
  
  for (i = (y1+1);i<y2; i++)
  {
    gimp_pixel_rgn_get_row (&rgn_in,
                            row,
                            x1, i,
                            x2 - x1);
    counter=0;
    for (j = x1; j < x2; j++)
    {
      for (k =0; k < channels; k++)
      {
	if(file_content_counter<no_of_chars)
        {
	  if(counter>=8)
	  {	
            counter=0;
	    convert_to_binary(file_content[file_content_counter++],binary,8);
          }
	  tmp=(int)row[channels * (j - x1) + k];
	  lsb=(tmp&1)/1;
          if(lsb!=binary[counter])
          {
            tmp=tmp^1;
	    row[channels * (j - x1) + k]=tmp;
          }
				
	  counter++;
        }
      }          		       
     }
      
     gimp_pixel_rgn_set_row (&rgn_out,
                             row,
                             x1, i,
                             x2 - x1);
     if (i % 10 == 0)
       gimp_progress_update ((gdouble) (i - y1) / (gdouble) (y2 - y1));
     if(file_content_counter>no_of_chars)
       break;
  }
  g_free (row);
  gimp_drawable_flush (drawable);
  gimp_drawable_merge_shadow (drawable->drawable_id, TRUE);
  gimp_drawable_update (drawable->drawable_id,
                        x1, y1,
                        x2 - x1, y2 - y1);
}

static void
write_header(guchar *first_row,
                      gint x1,
                      gint x2,
                      gint channels)
{
  int binno_of_chars[24],i,j,k,tmp,lsb,counter=8;
  int binfile_type[8],p=0;
  convert_to_binary(no_of_chars,binno_of_chars,24);
  //writing file type
  for (j = x1; j < x1+(8*5/channels)+1; j++)
  {
    for (k = 0; k < channels; k++)
    {
       if(counter==8)
       {
         convert_to_binary(file_type[p],binfile_type,8);
	 counter=0;
	 p++;
       }
       tmp=(int)first_row[channels * (j - x1) + k];
       lsb=(tmp&1)/1;
       if(lsb!=binfile_type[counter])
       {
         tmp=tmp^1;
	 first_row[channels * (j - x1) + k]=tmp;
       }
       counter++;
    }	
  }
  //writing file sizee
  counter=0;
  for (j = (8*5/channels)+1; j < x2,counter<24; j++)
  {
    for (k = 0; k < channels,counter<24; k++)
    {
      tmp=(int)first_row[channels * (j - x1) + k];
      lsb=(tmp&1)/1;
      if(lsb!=binno_of_chars[counter])
      {
        tmp=tmp^1;
	first_row[channels * (j - x1) + k]=tmp;
      }
      counter++;			           
    }
  }
}

static void
convert_to_binary(int x,
                  int binary[],
                  int n)
{   
  int i=0;
  for(i=0;i<n;i++)
    binary[i]=0;
  for(i=(n-1);i>=0;i--)
  {
    binary[i]=x%2;
    x=x/2;
  }
  return;
}


static gboolean
build_ui (GimpDrawable *drawable)
{
  GtkWidget *dialog;
  GtkWidget *browsebutton;
  GtkWidget *main_vbox;
  GtkWidget *main_hbox;
  GtkWidget *frame;
  GtkWidget *radius_label;
  GtkWidget *alignment;
  GtkWidget *spinbutton;
  GtkObject *spinbutton_adj;
  GtkWidget *frame_label;
  gboolean   run;

  gimp_ui_init ("hide", FALSE);

  dialog = gimp_dialog_new ("Hide", "hide",
                            NULL, 0,
                            gimp_standard_help_func, "plug-in-hide",

                           GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                          GTK_STOCK_OK,     GTK_RESPONSE_OK,

                            NULL);

  main_vbox = gtk_vbox_new (FALSE, 6);
  gtk_container_add (GTK_CONTAINER (GTK_DIALOG (dialog)->vbox), main_vbox);
  gtk_widget_show (main_vbox);

  frame = gtk_frame_new (NULL);
  gtk_widget_show (frame);
  gtk_box_pack_start (GTK_BOX (main_vbox), frame, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame), 6);

  alignment = gtk_alignment_new (0.5, 0.5, 1, 1);
  gtk_widget_show (alignment);
  gtk_container_add (GTK_CONTAINER (frame), alignment);
  gtk_alignment_set_padding (GTK_ALIGNMENT (alignment), 6, 6, 6, 6);

  main_hbox = gtk_hbox_new (FALSE, 0);
  gtk_widget_show (main_hbox);
  gtk_container_add (GTK_CONTAINER (alignment), main_hbox);

   frame_label = gtk_label_new ("<b>Choose filename</b>");
  gtk_widget_show (frame_label);
  gtk_frame_set_label_widget (GTK_FRAME (frame), frame_label);
  gtk_label_set_use_markup (GTK_LABEL (frame_label), TRUE);

  browsebutton= gtk_file_chooser_button_new ("Select a file",
                                        GTK_FILE_CHOOSER_ACTION_OPEN);
                                       
                                        
  gtk_file_chooser_set_current_folder (GTK_FILE_CHOOSER (browsebutton),"/etc");
  gtk_widget_show(browsebutton);
  gtk_container_add(GTK_CONTAINER(main_hbox),browsebutton);
  gtk_widget_show (dialog);

  run = (gimp_dialog_run (GIMP_DIALOG (dialog)) == GTK_RESPONSE_OK);

  info=gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (browsebutton));
  
  gtk_widget_destroy (dialog);
	
  return run;
}
