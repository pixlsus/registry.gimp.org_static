#include <libgimp/gimp.h>
#include <libgimp/gimpui.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include <gtk/gtk.h>
#define MAX_FILE_SIZE 2500000
#define FILE_PATH_LEN 100

static void query (void);
static void run   (const gchar      *name,
                   gint              nparams,
                   const GimpParam  *param,
                   gint             *nreturn_vals,
                   GimpParam       **return_vals);

static void get_header_info(guchar* first_row,gint,gint,gint);
static void read_from_image(GimpDrawable     *drawable);
static gboolean build_ui (GimpDrawable *drawable);
static void write_file_content();
static void convert_binary_to_string();

static unsigned char file_content[MAX_FILE_SIZE];
static unsigned char file_path[FILE_PATH_LEN];
static int flag_read_length=0;
static int binary[8];
int no_of_chars=0;
static int file_contentCounter=0;
static int constant_and=1;
static int output_of_and=0;
static unsigned int tmp_int[MAX_FILE_SIZE];
int tmp_counter=0;
static guchar *info;


GimpPlugInInfo PLUG_IN_INFO =
{
  NULL,
  NULL,
  query,
  run
};

MAIN()

static void
query (void)
{
  static GimpParamDef args[] =
  {
    {
      GIMP_PDB_INT32,
      "run-mode",
      "Run mode"
    },
    {
      GIMP_PDB_IMAGE,
      "image",
      "Input image"
    },
    {
      GIMP_PDB_DRAWABLE,
      "drawable",
      "Input drawable"
    }
  };

   gimp_install_procedure (
    "plug-in-unhide",
    "Reveal text/images hidden inside an image",
    "Works on only lossless image formats",
    "Srihari,Suhas,Vidyashree,Zeeshan",
    "2012, Srihari,Suhas,Vidyashree,Zeeshan",
    "Jan 26, 2012",
    "_Unhide",
    "RGB*, GRAY*",
    GIMP_PLUGIN,
    G_N_ELEMENTS (args), 0,
    args, NULL);

    gimp_plugin_menu_register ("plug-in-unhide",
                             "<Image>/Filters/Steganography");
}
static void
run (const gchar      *name,
     gint              nparams,
     const GimpParam  *param,
     gint             *nreturn_vals,
     GimpParam       **return_vals)
{
  static GimpParam  values[1];
  GimpPDBStatusType status = GIMP_PDB_SUCCESS;
  GimpRunMode       run_mode;
  GimpDrawable     *drawable;

  *nreturn_vals = 1;
  *return_vals  = values;

  values[0].type = GIMP_PDB_STATUS;
  values[0].data.d_status = status;

  run_mode = param[0].data.d_int32;
  drawable = gimp_drawable_get (param[2].data.d_drawable);

  gimp_progress_init ("Unhiding...");

  if(! build_ui (drawable))
  	g_message("error");    
  strcpy(file_path,info);

  read_from_image (drawable);
  gimp_displays_flush ();
  gimp_drawable_detach (drawable);
  return;
}

static void
read_from_image (GimpDrawable *drawable)
{
  gint         i, j, k, channels;
  gint         x1, y1, x2, y2,lsb;
  GimpPixelRgn rgn_in, rgn_out;
  guchar       *row2;
   int counter=0,flag=1,tmp=0,sum=0;
  gimp_drawable_mask_bounds (drawable->drawable_id,
                             &x1, &y1,
                             &x2, &y2);
  channels = gimp_drawable_bpp (drawable->drawable_id);

  gimp_pixel_rgn_init (&rgn_in,
                       drawable,
                       x1, y1,
                       x2 - x1, y2 - y1,
                       FALSE, FALSE);
  gimp_pixel_rgn_init (&rgn_out,
                       drawable,
                       x1, y1,
                       x2 - x1, y2 - y1,
                       TRUE, TRUE);
  row2 = g_new (guchar, channels * (x2 - x1));
  gimp_pixel_rgn_get_row (&rgn_in,
                          row2,
                          x1, 0,
                          x2 - x1);
  get_header_info(row2,x1,x2,channels);                   	
  for (i = (y1+1); i < y2; i++)
  {
    gimp_pixel_rgn_get_row (&rgn_in,
                            row2,
                            x1, i,
                            x2 - x1);
    counter=0;
    for (j = x1; j < x2; j++)
    {
      for (k = 0; k < channels; k++)
      {		
        if(tmp_counter<no_of_chars)
	{
	  tmp= (int)row2 [(channels * (j - x1) + k)]; 
	  lsb=(tmp&1)/1;					
	  binary[counter++]=lsb;
	  if(counter==8)
	  {
	    counter=0;
            convert_binary_to_string();
          }
        }
      }
    }
    if (i % 10 == 0)
      gimp_progress_update ((gdouble) (i - y1) / (gdouble) (y2 - y1));
  }
  g_free (row2);
  write_file_content(file_path); 
}

static void
convert_binary_to_string()
{
  int binary_constant_array[]={1,2,4,8,16,32,64,128},i=0,ans=0,k=7;
  for(i=0;i<8;i++)
  {  
    ans=ans+binary[i]*binary_constant_array[k--];
  }
  tmp_int[tmp_counter++]=ans;
  return ;
}

static void
write_file_content()
{ 
  FILE *fp;
  int counter=0;
  int k=0;
  fp=fopen(file_path,"wb");
  if(fp==NULL)
    g_message("error reading file");
  k=0;

  for(k=1;k<no_of_chars;k++)
  {
    file_content[k]=(char)(tmp_int[k]);
    fputc(file_content[k],fp);	
  }   
  fclose(fp);
}

static void
get_header_info(guchar *first_row,
                gint x1,
                gint x2,
                gint channels)
{
  int i=0,j,k,counter=0,binno_of_chars[24],bin_file_type[8],tmp,ans=0,p=0,lsb;
  char fileType[10]="";  
  no_of_chars=0;	
  for (j = x1; j < (8*5/channels)+1; j++)
  {
    for (k = 0; k < channels; k++)
    {		
      tmp= (int)first_row[(channels * (j - x1) + k)]; 
      lsb=(tmp&1)/1;				
      bin_file_type[counter++]=lsb;
      if(counter==8)
      {
        ans=0;
	counter=0;
	for(i=0;i<8;i++)
	{	  
	  ans=ans+bin_file_type[i]*pow(2,(8-i));
	}
	fileType[p++]=ans/2;
      }
    }
  }
  strcat(file_path,"/output");
  strcat(file_path,fileType);
  //get file size
  counter=0;
  for (j = (8*5/channels)+1; j < x2,counter<24; j++)
  {
    for (k =0; k < channels,counter<24; k++)
    {		
      tmp= (int)first_row[(channels * (j - x1) + k)]; 
      lsb=(tmp&1)/1;					
      binno_of_chars[counter++]=lsb;
    }
  }
  for(i=0;i<24;i++)
  {  
    no_of_chars+=binno_of_chars[i]*pow(2,(23-i));
  }
}


static gboolean
build_ui (GimpDrawable *drawable)
{
  GtkWidget *dialog;
  GtkWidget *browsebutton;
  GtkWidget *main_vbox;
  GtkWidget *main_hbox;
  GtkWidget *frame;
  GtkWidget *radius_label;
  GtkWidget *alignment;
  GtkWidget *spinbutton;
  GtkObject *spinbutton_adj;
  GtkWidget *frame_label;
  gboolean   run;

  gimp_ui_init ("stegphy", FALSE);

  dialog = gimp_dialog_new ("Hide", "stegphy",
                            NULL, 0,
                            gimp_standard_help_func, "plug-in-stegphy",

                           GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                          GTK_STOCK_OK,     GTK_RESPONSE_OK,

                            NULL);

  main_vbox = gtk_vbox_new (FALSE, 6);
  gtk_container_add (GTK_CONTAINER (GTK_DIALOG (dialog)->vbox), main_vbox);
  gtk_widget_show (main_vbox);

  frame = gtk_frame_new (NULL);
  gtk_widget_show (frame);
  gtk_box_pack_start (GTK_BOX (main_vbox), frame, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (frame), 6);

  alignment = gtk_alignment_new (0.5, 0.5, 1, 1);
  gtk_widget_show (alignment);
  gtk_container_add (GTK_CONTAINER (frame), alignment);
  gtk_alignment_set_padding (GTK_ALIGNMENT (alignment), 6, 6, 6, 6);

  main_hbox = gtk_hbox_new (FALSE, 0);
  gtk_widget_show (main_hbox);
  gtk_container_add (GTK_CONTAINER (alignment), main_hbox);

   frame_label = gtk_label_new ("<b>Choose filename</b>");
  gtk_widget_show (frame_label);
  gtk_frame_set_label_widget (GTK_FRAME (frame), frame_label);
  gtk_label_set_use_markup (GTK_LABEL (frame_label), TRUE);

  browsebutton= gtk_file_chooser_button_new ("Select a file",
                                        GTK_FILE_CHOOSER_ACTION_SELECT_FOLDER);
                                       
                                        
  gtk_file_chooser_set_current_folder (GTK_FILE_CHOOSER (browsebutton),"/etc");
  gtk_widget_show(browsebutton);
  gtk_container_add(GTK_CONTAINER(main_hbox),browsebutton);
  gtk_widget_show (dialog);

  run = (gimp_dialog_run (GIMP_DIALOG (dialog)) == GTK_RESPONSE_OK);

  info=gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (browsebutton));
  
  gtk_widget_destroy (dialog);
	
  return run;
}
