#!/usr/bin/perl

# AUTHOR: Michael K. Nacos
# # LICENSE: GPL (http://www.gnu.org/licenses/gpl.html)
# # DESCRIPTION: perl-fu plugin for gimp which converts a multi-layered
# # image to an html template + corresponding png images
# # DEPENDENCIES: you need gimp, perl (doh!) and the Gimp::Perl module
# # INSTALL: satisfy the above, then place script in ~/.gimp plug-ins dir
# # USAGE: start by creating a new image (e.g. 1024x76 8) and adding all
# # individual decorative elements in individual transparent gimp layers
# # each layer will be converted to a separate png file with the same
# # name as the gimp layer, size cropped to a minimum
# # an appropriate html file with individual div blocks and css positioning
# # will be automatically created
# # KNOWN BUGS: you have to save at least once the layered file (.xcf)
# # before application of this script. images are deposited in the dir
# # you select but html file is deposited in the directory gimp runs in
# # (this is not a problem if you cd to the directory you want before running
# # gimp from the command line. in gimp 2 you may not undo the flatten
# # operation after this script completes.
# # DISCLAIMER: this is an old file. it works for me! please don’t flame.

use Gimp ":auto";
use Gimp::Fu;

local ($IMAGE,$DRAWABLE,$SAVEDIR,$BG_COLOUR,$INCLUDE_BACKGROUND);
local ($FILENAME,$HTML_HEADER,$HTML_FOOTER);
local $CROP = [];

# change names if they contain additional info

# MAIN sub
sub ep_l2i {
    ($IMAGE,$DRAWABLE,$SAVEDIR,$BG_COLOUR,$INCLUDE_BACKGROUND) = @_;
    $FILENAME = gimp_image_get_filename($IMAGE);
    gimp_undo_push_group_start($IMAGE);
    &ep_get_crop_info(&ep_get_layer_objects);
    &ep_html_init();
    &ep_export_css(&ep_get_layer_names);
    &ep_save_all_pngs(&ep_get_layer_names);
    # gimp_message("Point your browser to $FILENAME.html");
    gimp_undo_push_group_end($IMAGE);
    return $img;
}

# LAYER NAMES - for choosing filenames (maybe options too)
# input: none required --- output: ref to list of layer names
sub ep_get_layer_names {
    my $i; my @output;
    my @list = $IMAGE->get_layers;
    my $max = scalar(@list);
    LAYER_NAMES: for($i = 0; $i<$max; $i++) {
	next LAYER_NAMES unless $list[$i]->get_visible; 
# let's turn those spaces in layer names into underscores
	$checked = $list[$i]->get_name;
	$checked =~ s/ /_/g;
	push @output, $checked;
    }
    return \@output;
}

# LAYER OBJECTS
# input: none required --- output: ref to list of layer objects
sub ep_get_layer_objects {
    my $i; my @output;
    my @list = $IMAGE->get_layers;
    my $max = scalar(@list);
    LAYER_OBJS: for($i = 0; $i<$max; $i++) {
	next LAYER_OBJS unless $list[$i]->get_visible;
	push @output, $list[$i];
    }
    return \@output;
}

# GET CROP INFO 
# input: ref to list of layer objects --- 
sub ep_get_crop_info {
    my $obj_list = shift;
    my $max = scalar(@$obj_list); my $i;
    my ($opa,$x1,$x2,$y1,$y2,$n_width,$n_height);
    for($i = 0; $i<$max; $i++) {
# get the coordinates of the selection in the original image
	if (gimp_drawable_has_alpha($$obj_list[$i])) {
	    gimp_selection_layer_alpha($$obj_list[$i]); 
	    gimp_selection_grow($IMAGE, 5); 
	    ($opa, $x1, $y1, $x2, $y2) = gimp_selection_bounds($IMAGE);
	    # gimp_message("$i: lx is $lx - ly is $ly");
	    gimp_selection_clear($IMAGE);
	    $n_width = $x2 - $x1; $n_height = $y2 - $y1;
	    push @$CROP, [$n_width,$n_height,$x1,$y1];
	}
	else { push @$CROP, [$IMAGE->width,$IMAGE->height,0,0]; };
    }
}

# SAVE ALL PNGS
# input: ref to list of layer names --- 
sub ep_save_all_pngs {
    my $name_list = shift; 
    my $max = scalar(@$name_list); my $i;
    my ($tmp,$layer,$sel,$dis,$floating,$n_width,$n_height,$x1,$y1,$our_path);
    my $merged = $IMAGE->merge_visible_layers(CLIP_TO_IMAGE);
    for($i = 0; $i<$max; $i++) {
# create new image w/ alpha layer & transparent BG for each original layer 
	$tmp = gimp_image_new($IMAGE->width,$IMAGE->height,RGB_IMAGE);
	$layer = gimp_layer_new($tmp,$tmp->width,$tmp->height,RGB_IMAGE,"gimp_2_css",100,NORMAL_MODE);
	gimp_layer_add_alpha($layer);
	$tmp->add_layer($layer,0);
	$tmp->set_active_layer($layer);
	$sel = gimp_selection_all($tmp);
	$dis = gimp_display_new($tmp);
	gimp_edit_clear($layer);
# copy - paste - crop operations
    	gimp_edit_copy($merged);
	$floating = gimp_edit_paste($layer,1);
	gimp_floating_sel_anchor($floating);
	$n_width = $$CROP[$i][0];
	$n_height = $$CROP[$i][1];
	$x1 = $$CROP[$i][2];
	$y1 = $$CROP[$i][3];
	gimp_crop($tmp,$n_width,$n_height,$x1,$y1);
# make sure we remove older copy
	$our_path = $SAVEDIR.$$name_list[$i].".png";
	# `rm -f $our_path`;
	file_png_save(RUN_NONINTERACTIVE, $tmp, $layer, $our_path, $$name_list[$i].".png", 0, 6, 0, 0, 0, 0, 0 );
	gimp_display_delete($dis);
    }
}

sub ep_html_init {

    $HTML_HEADER = <<HTML_HEADER_STOP;
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<HTML>
<HEAD>

<TITLE>$FILENAME</TITLE>
<META HTTP-equiv="Content-Type" CONTENT="text/html; CHARSET=iso-8859-7">
<META HTTP-equiv="imagetoolbar" CONTENT="no">
HTML_HEADER_STOP

    $HTML_FOOTER = <<HTML_FOOTER_STOP;
</BODY>

</HTML>
HTML_FOOTER_STOP
}

sub ep_export_css {
    my $name_list = shift;
    my $output = $HTML_HEADER;
    my $max = scalar(@$name_list); my $i; my ($file,$x,$y);
    $output .= "<STYLE>\n";
    $output .= "    img { border-width: 0px; }\n\n";
    for($i=$max-1;$i>=0;$i--) {
	$file = $$name_list[$i];
	$x = $$CROP[$i][2]; $y = $$CROP[$i][3];
	$output .= "    .$file { position: absolute; padding: 0px; top: $y"."px; left: $x"."px; }\n";
    }
    $output .= "\n</STYLE>\n\n</HEAD>\n<BODY BGCOLOR=\"$BG_COLOUR\">\n\n";

    if ($INCLUDE_BACKGROUND) {
	for($i=$max-1;$i>=0;$i--) {
	    $file = $$name_list[$i];
	    $output .= "<DIV CLASS=\"$file\">\n<IMG SRC=\"$file.png\">\n</DIV>\n\n";
	}
    }
    else {
	for($i=$max-2;$i>=0;$i--) {
	    $file = $$name_list[$i];
	    $output .= "<DIV CLASS=\"$file\">\n<IMG SRC=\"$file.png\">\n</DIV>\n\n";
	}
    }

    $output .= $HTML_FOOTER;
    open(FS_EXPORT, ">$FILENAME.html");
    print FS_EXPORT $output;
    close FS_EXPORT;
}

# code which might be useful with transparent gifs
##################################################

# working with original image
	#gimp_layer_set_visible($$obj_list[$i],0);
	#$IMAGE->merge_visible_layers(CLIP_TO_IMAGE);
# what about undo
	#gimp_layer_set_visible($$obj_list[$i],1);
	#$tmp = gimp_image_new($IMAGE->width,$IMAGE->height,RGB_IMAGE);
	#$layer = gimp_layer_new($tmp,$tmp->width,$tmp->height,RGB_IMAGE,"name",100,NORMAL_MODE);
	#gimp_layer_add_alpha($layer);
	#$tmp->add_layer($layer,0);
	#$tmp->set_active_layer($layer);
	#$sel = gimp_selection_all($tmp);
	#$dis = gimp_display_new($tmp);
	#gimp_edit_clear($layer);
## we should change this to crop merged original image at coordinates
    	#gimp_edit_copy($$obj_list[$i]);
	#$floating = gimp_edit_paste($layer,0);
	#gimp_floating_sel_anchor($floating);
	#gimp_selection_layer_alpha($layer);
	#gimp_selection_grow($tmp, 5);


register
     "gimp_2_css", # fill in name
     "Visible layers to images + css", # a small description
     "should hopefully help with layout creation", # a help text
     "Michael K. Nacos", # Your name
     "eurek@! Pliroforiki", # Your copyright
     "2004-06-06", # Date
     "<Image>/gimp-to-css", # menu path
     "*", # Image types
     [
     [PF_FILE, "directory", "please choose dir for images", undef],
     [PF_STRING, "bg_color", "please choose BG color", '#ffffff'],
     [PF_BOOL, "bg", "will the bottom layer be included?", 0]
     ],
     \&ep_l2i;

exit main();


