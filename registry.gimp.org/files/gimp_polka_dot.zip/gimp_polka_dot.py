#!/usr/bin/env python
# -*- coding: utf8 -*-

# *************************************************************************** #
#                                                                             #
#      Version 0.1 - 2011-04-01                                               #
#      Copyright (C) 2011 Marco Crippa                                        #
#                                                                             #
#      This program is free software; you can redistribute it and/or          #
#      modify it under the terms of the GNU General Public License            #
#      as published by the Free Software Foundation; either version 2         #
#      of the License, or (at your option) any later version.                 #
#                                                                             #
#      This program is distributed in the hope that it will be useful,        #
#      but WITHOUT ANY WARRANTY; without even the implied warranty of         #
#      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          #
#      GNU General Public License for more details.                           #
#                                                                             #
#      You should have received a copy of the GNU General Public License      #
#      along with this program; if not, write to the                          #
#      Free Software Foundation, Inc.,                                        #
#      51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA           #
#                                                                             #
# *************************************************************************** #

from gimpfu import *
import math,random


def Do_polka_dot( img, draw, square_a, diameter_a, antialias_a, feather_a, feather_radius_a, col_bkg_a, square_b, diameter_b, antialias_b, feather_b, feather_radius_b, col_bkg_b, alternation ):

    #control dimension
    if square_a<diameter_a:
        square_a=diameter_a
    if square_b<diameter_b:
        square_b=diameter_b
    if square_a>square_b:
        px_w=square_a
    else:
        px_w=square_b
    
    #disable undo
    img.disable_undo()

    #keep current background color
    current_b=pdb.gimp_context_get_background()

    #select the active layer
    draw=pdb.gimp_image_get_active_layer(img)

    #duplicate image and pixelate
    draw_copy=pdb.gimp_layer_new_from_drawable(draw,img)
    pdb.gimp_image_add_layer(img,draw_copy,-1)
    pdb.plug_in_pixelize2(img,draw_copy,px_w,px_w)

    #hide background layer_copy
    pdb.gimp_drawable_set_visible(draw,False)
    pdb.gimp_drawable_set_visible(draw_copy,False)

    #create pattern A
    pdb.gimp_context_set_background(col_bkg_a)
    pattern_a=pdb.gimp_layer_new(img,square_a,square_a,1,"dot_a",100,0)
    pdb.gimp_image_add_layer(img,pattern_a,-1)
    pdb.gimp_image_set_active_layer(img,pattern_a)
    pos_x=(square_a-diameter_a)/2
    pos_y=(square_a-diameter_a)/2
    pdb.gimp_ellipse_select(img,pos_x,pos_y,diameter_a,diameter_a,0,antialias_a,feather_a,feather_radius_a)
    pdb.gimp_selection_invert(img)
    pdb.gimp_edit_fill(pattern_a,1)
    pdb.gimp_selection_clear(img)
    pdb.gimp_drawable_set_visible(pattern_a,False)

    #create pattern B
    pdb.gimp_context_set_background(col_bkg_b)
    pattern_b=pdb.gimp_layer_new(img,square_b,square_b,1,"dot_b",100,0)
    pdb.gimp_image_add_layer(img,pattern_b,-1)
    pdb.gimp_image_set_active_layer(img,pattern_b)
    pos_x=(square_b-diameter_b)/2
    pos_y=(square_b-diameter_b)/2
    pdb.gimp_ellipse_select(img,pos_x,pos_y,diameter_b,diameter_b,0,antialias_b,feather_b,feather_radius_b)
    pdb.gimp_selection_invert(img)
    pdb.gimp_edit_fill(pattern_b,1)
    pdb.gimp_selection_clear(img)
    pdb.gimp_drawable_set_visible(pattern_b,False)

    l_offset_x=0
    l_offset_y=0
    
    #alternation none
    if alternation==0:
        layer_fill=fill_dot(img,pdb.gimp_image_width(img),pdb.gimp_image_height(img),pattern_a,l_offset_x,l_offset_y)
      
    
    #alternation horizontal
    elif alternation==1:
        
        layer_fill01=fill_dot(img,pdb.gimp_image_width(img),square_a,pattern_a,l_offset_x,l_offset_y)
#        l_offset_x=l_offset_x-(square_b/2)
        l_offset_y=square_a
        total_offset=square_a+square_b
        layer_fill02=fill_dot(img,pdb.gimp_image_width(img)+square_b,square_b,pattern_b,l_offset_x,l_offset_y)
        merge_layer=pdb.gimp_image_merge_down(img,layer_fill02,1)

        times=pdb.gimp_image_height(img)/total_offset
        
        for i in xrange(0,int(times)):
            layer_copy=pdb.gimp_layer_copy(merge_layer,True)
            pdb.gimp_image_add_layer(img,layer_copy,-1)
            pdb.gimp_layer_translate(layer_copy,0,total_offset*(i+1))
        
    #alternation vertical
    elif alternation==2:
        
        layer_fill01=fill_dot(img,square_a,pdb.gimp_image_height(img),pattern_a,l_offset_x,l_offset_y)
        l_offset_x=square_a
        total_offset=square_a+square_b
        layer_fill02=fill_dot(img,square_b,pdb.gimp_image_height(img)+square_b,pattern_b,l_offset_x,l_offset_y)
        merge_layer=pdb.gimp_image_merge_down(img,layer_fill02,1)

        times=pdb.gimp_image_width(img)/total_offset
        
        for i in xrange(0,int(times)):
            layer_copy=pdb.gimp_layer_copy(merge_layer,True)
            pdb.gimp_image_add_layer(img,layer_copy,-1)
            pdb.gimp_layer_translate(layer_copy,total_offset*(i+1),0)

    #alternation diagonal
    elif alternation==3:
        layer_fill01=fill_dot(img,pdb.gimp_image_width(img),square_a,pattern_a,l_offset_x,l_offset_y)
        l_offset_x=l_offset_x-(square_b/2)
        l_offset_y=square_a
        total_offset=square_a+square_b
        layer_fill02=fill_dot(img,pdb.gimp_image_width(img)+square_b,square_b,pattern_b,l_offset_x,l_offset_y)
        merge_layer=pdb.gimp_image_merge_down(img,layer_fill02,1)

        times=pdb.gimp_image_height(img)/total_offset
        
        for i in xrange(0,int(times)):
            layer_copy=pdb.gimp_layer_copy(merge_layer,True)
            pdb.gimp_image_add_layer(img,layer_copy,-1)
            pdb.gimp_layer_translate(layer_copy,0,total_offset*(i+1))

    #create layer to fill with pattern
#    l_dot=pdb.gimp_layer_new(img,pdb.gimp_image_width(img),pdb.gimp_image_height(img),1,"fill_dot",100,0)
#    pdb.gimp_image_add_layer(img,l_dot,-1)
#    pdb.gimp_image_set_active_layer(img,l_dot)
#    pdb.gimp_edit_fill(l_dot,4)

    #merge all fill layer_copy
    merge_all=pdb.gimp_image_merge_visible_layers(img,1)

    #remove pattern
    pdb.gimp_drawable_set_visible(pattern_a,True)
    pdb.gimp_drawable_set_visible(pattern_b,True)
    pdb.gimp_image_remove_layer(img,pattern_a)
    pdb.gimp_image_remove_layer(img,pattern_b)

    #unhide background layer_copy
    pdb.gimp_drawable_set_visible(draw,True)
    pdb.gimp_drawable_set_visible(draw_copy,True)

    #enable undo
    img.enable_undo()

    #set the original background color
    pdb.gimp_context_set_background(current_b)
    
def fill_dot(img,width,height,pat,offset_x,offset_y):
    #select pattern
    pdb.gimp_edit_copy(pat)
    pdb.gimp_context_set_pattern("Clipboard")

    #create layer to fill with pattern
    l_dot=pdb.gimp_layer_new(img,width,height,1,"fill_dot",100,0)
    pdb.gimp_image_add_layer(img,l_dot,-1)
    pdb.gimp_image_set_active_layer(img,l_dot)
    pdb.gimp_edit_fill(l_dot,4)
    pdb.gimp_layer_translate(l_dot,offset_x,offset_y)
    
    return l_dot


register( "polka_dot",
  "Polka Dot Effect",
  "Applay Polka Dot effet to a photo",
  "Marco Crippa",
  "(©) 2011 Marco Crippa",
  "2010-04-01",
  "<Image>/Filters/Artistic/Polka Dot Effect",
  'RGB*',
  [ 
		(PF_SPINNER, "square_a", "Square dimension pattern A:", 20, (1, 9999999999, 1)),
		(PF_SPINNER, "diameter_a", "Dot diameter pattern A:", 20, (1, 9999999999, 1)),
		(PF_BOOL,"antialias_a", "Antialias pattern A:", 1),
		(PF_BOOL,"feather_a", "Feather pattern A:", 0),
		(PF_SPINNER, "feather_radius_a", "Feather radius pattern A:", 0, (0, 9999999999, 1)),
		(PF_COLOR, "col_bkg_a", "Background color pattern A:", (0,0,0)),

		(PF_SPINNER, "square_b", "Square dimension pattern B:", 20, (1, 9999999999, 1)),
		(PF_SPINNER, "diameter_b", "Dot diameter pattern B:", 20, (1, 9999999999, 1)),
		(PF_BOOL,"antialias_b", "Antialias pattern B:", 1),
		(PF_BOOL,"feather_b", "Feather pattern B:", 0),
		(PF_SPINNER, "feather_radius_b", "Feather radius pattern B:", 0, (0, 9999999999, 1)),
		(PF_COLOR, "col_bkg_b", "Background color pattern B:", (0,0,0)),
		
		(PF_OPTION, "alternation", "Alternation:",0, ["None", "Horizontal", "Vertical", "Diagonal"])
  ],
  '',
  Do_polka_dot)

main()

