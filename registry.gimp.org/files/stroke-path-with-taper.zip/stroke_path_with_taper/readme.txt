Stroke Path with Taper GIMP plug-in (25/10/2009) v1.0
=====================================================

This is a plugin that allows you to stroke a path with a taper 
(i.e. a changing width from start to end), and is an alternative
to Rob Antonishen's Tapered Stroke plugin. The main difference 
is that there are a variety of line styles available and you can 
use the foreground color or current pattern. It can be slow on 
complicated paths and/or large images.

How to install:
---------------

Linux: Use "gimptool-2.0 --install stroke-path-with-taper.c".
Windows: Move stroke-path-with-taper.exe to your plugins folder.

How to use:
-----------

* Select Path tool, and add your anchor points.
* In the Edit menu, select Stroke Path with Taper...
* Choose your settings and click OK.
* Path is stroked with taper using foreground colour.

Stroke Path with Taper dialog window settings:
----------------------------------------------

1) Start width: The width of the line at the start of the path.
2) End width: The width of the line at the end of the path.
3) Exponent: Determines how rapidly the line width changes.
4) Tolerance: High = Faster, Uglier; Low = Slower, Prettier.
5) Fill style: Either foreground color, or current pattern.
6) Cap style: Either Butt, Round, or Square.
7) Join style: Either Miter, Round, or Bevel.
8) Miter limit: Convert a mitered join to a bevelled join if the
   miter would extend to a distance of more than (miter-limit *
   line_width) from the actual join point.
9) Antialiasing: Specifies whether or not the line is antialiased.

Screenshots:
------------

http://www.ludicity.org/images/taper_demo.png
http://www.ludicity.org/images/taper_settings.png

Author:
-------

Marko Peric (G00g1e em4i1 account name is cragwolf).