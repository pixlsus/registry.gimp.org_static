/*
 *      stroke-path-with-taper.c - Stroke Path with Taper plugin for the GIMP
 *      
 *      Copyright 2009 Marko Peric
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */
#include <libgimp/gimp.h>
#include <libgimp/gimpui.h>
#include <math.h>

#define EPS 1.0E-06
#define PLUG_IN_PROC "plug-in-stroke-path-with-taper"
#define PLUG_IN_BINARY "stroke-path-with-taper"
#define RESPONSE_RESET 1
#define SPIN_BUTTON_WIDTH 60
#define SCALE_WIDTH 125
#define DEF_SW 10.0
#define DEF_EW  2.0
#define DEF_EX  4.0
#define DEF_TO  0.5
#define DEF_FI  0
#define DEF_CA  0
#define DEF_JO  0
#define DEF_ML 10.0 
#define DEF_AA  1

static void query(void);
static void run(const gchar      *name,
                gint              nparams,
                const GimpParam  *param,
                gint             *nreturn_vals,
                GimpParam       **return_vals);

typedef struct {
    gdouble b0_x;
    gdouble b0_y;
    gdouble b1_x;
    gdouble b1_y;
    gdouble b2_x;
    gdouble b2_y;
    gdouble b3_x;
    gdouble b3_y;
    gdouble t0;
    gdouble t1;
} curve;

typedef struct {
    gdouble b0_x;
    gdouble b0_y;
    gdouble b1_x;
    gdouble b1_y;
    gdouble bc_x;
    gdouble bc_y;
    gdouble t0;
    gdouble t1;
} arc;

typedef struct {
    gdouble p_x;
    gdouble p_y;
    gdouble t;
} segment;

typedef struct {
    gdouble width_start;
    gdouble width_end;
    gdouble exponent;
    gdouble tolerance;
    gint    fill;
    gint    cap;
    gint    join;
    gdouble miter_limit;
    gint    antialiased;
} TaperVals;

typedef struct {
    GtkWidget *sw_entry;
    GtkWidget *ew_entry;
    GtkObject *ex_entry;
    GtkObject *to_entry;
    GtkWidget *fi_entry;
    GtkWidget *ca_entry;
    GtkWidget *jo_entry;
    GtkObject *ml_entry;
    GtkWidget *aa_entry;
} entry;

static TaperVals tvals =
{
    DEF_SW,
    DEF_EW,
    DEF_EX,
    DEF_TO,
    DEF_FI,
    DEF_CA,
    DEF_JO,
    DEF_ML,
    DEF_AA
};

GimpPlugInInfo PLUG_IN_INFO =
{
  NULL,
  NULL,
  query,
  run
};

gboolean START;
gint num_strokes;

MAIN()

/*----------------------------------------------------------------------------- 
 *  query  --  called so that the plugin can inform the GIMP about itself 
 *-----------------------------------------------------------------------------
 */
static void query (void)
{
    static GimpParamDef args[] =
    {
        {GIMP_PDB_INT32,    "run-mode",    "Interactive, non-interactive"},
        {GIMP_PDB_IMAGE,    "image",       "Input image"},
        {GIMP_PDB_DRAWABLE, "drawable",    "Input drawable"},
        {GIMP_PDB_FLOAT,    "width_start", "Start width"},
        {GIMP_PDB_FLOAT,    "width_end",   "End width"},
        {GIMP_PDB_FLOAT,    "exponent",    "Exponent"},
        {GIMP_PDB_FLOAT,    "tolerance",   "Tolerance"},
        {GIMP_PDB_INT32,    "fill",        "Fill type"},
        {GIMP_PDB_INT32,    "cap",         "Cap options"},
        {GIMP_PDB_INT32,    "join",        "Join options"},
        {GIMP_PDB_FLOAT,    "miter_limit", "Miter limit"},
        {GIMP_PDB_INT32,    "antialiased", "Antialiased"},
    };

    gimp_install_procedure(
        PLUG_IN_PROC,
        "Stroke Path with Taper",
        "Stroke a path with a taper",
        "Marko Peric",
        "Marko Peric",
        "October 2009",
        "Stroke Path with Taper...",
        "*", GIMP_PLUGIN,
        G_N_ELEMENTS(args), 0,
        args, NULL);

    gimp_plugin_menu_register(PLUG_IN_PROC, "<Image>/Edit");
}

/*----------------------------------------------------------------------------- 
 *  sufficiently_flat_arc  --  Determines if a circular arc is sufficiently 
 *                             flat to be approximated by a straight line
 *-----------------------------------------------------------------------------
 */
gboolean sufficiently_flat_arc(arc a)
{
    gdouble r   = sqrt((a.b0_x - a.bc_x) * (a.b0_x - a.bc_x) +
                       (a.b0_y - a.bc_y) * (a.b0_y - a.bc_y));
    gdouble d2  = (a.b0_x - a.b1_x) * (a.b0_x - a.b1_x) +
                  (a.b0_y - a.b1_y) * (a.b0_y - a.b1_y);
    gdouble del = r - sqrt(r*r - 0.25 * d2);
    return (del <= 0.5 * tvals.tolerance);
}

/*----------------------------------------------------------------------------- 
 *  subdivide_arc  --  subdivides a circular arc 
 *-----------------------------------------------------------------------------
 */
void subdivide_arc(arc a, arc *l, arc *r)
{
    gdouble vx  = a.b0_x + a.b1_x - 2 * a.bc_x;
    gdouble vy  = a.b0_y + a.b1_y - 2 * a.bc_y;
    gdouble fac = sqrt(((a.b0_x - a.bc_x) * (a.b0_x - a.bc_x) +
                        (a.b0_y - a.bc_y) * (a.b0_y - a.bc_y)) 
                          / (vx*vx + vy*vy));
    vx *= fac; vy *= fac;
    l->bc_x = a.bc_x; l->bc_y = a.bc_y; r->bc_x = a.bc_x; r->bc_y = a.bc_y;
    l->b0_x = a.b0_x; l->b0_y = a.b0_y; r->b1_x = a.b1_x; r->b1_y = a.b1_y;
    l->b1_x = a.bc_x + vx; l->b1_y = a.bc_y + vy;
    r->b0_x = l->b1_x; r->b0_y = l->b1_y;
    l->t0   = a.t0; l->t1 = (a.t0 + a.t1) * 0.5;
    r->t0   = l->t1; r->t1 = a.t1;
}

/*----------------------------------------------------------------------------- 
 *  flatten_arc  --  produces a polyline approximation to a circular arc
 *-----------------------------------------------------------------------------
 */
void flatten_arc(arc a, GArray *apa)
{
    if (sufficiently_flat_arc(a)) {
        segment s;
        s.p_x = a.b0_x;
        s.p_y = a.b0_y;
        s.t   = a.t0;
        g_array_append_val(apa, s);
    } else {
        arc l, r;
        subdivide_arc(a, &l, &r);
        flatten_arc(l, apa);
        flatten_arc(r, apa);
    }
}

/*----------------------------------------------------------------------------- 
 *  sufficiently_flat_curve  --  Determines if a Bezier curve is sufficiently 
 *                               flat to be approximated by a straight line
 *-----------------------------------------------------------------------------
 */
gboolean sufficiently_flat_curve(curve c)
{
    gdouble ux = 3.0*c.b1_x - 2.0*c.b0_x - c.b3_x; ux *= ux;
    gdouble uy = 3.0*c.b1_y - 2.0*c.b0_y - c.b3_y; uy *= uy;
    gdouble vx = 3.0*c.b2_x - 2.0*c.b3_x - c.b0_x; vx *= vx;
    gdouble vy = 3.0*c.b2_y - 2.0*c.b3_y - c.b0_y; vy *= vy;
    if (ux < vx) ux = vx;
    if (uy < vy) uy = vy;
    return (ux+uy <= 16*tvals.tolerance*tvals.tolerance);
}

/*----------------------------------------------------------------------------- 
 *  subdivide_curve  --  subdivides a Bezier curve 
 *-----------------------------------------------------------------------------
 */
void subdivide_curve(curve c, curve *l, curve *r)
{
    gdouble mx = (c.b1_x + c.b2_x) * 0.5;
    gdouble my = (c.b1_y + c.b2_y) * 0.5;
    l->b0_x = c.b0_x; l->b0_y = c.b0_y;
    r->b3_x = c.b3_x; r->b3_y = c.b3_y;
    l->b1_x = (c.b0_x + c.b1_x) * 0.5; l->b1_y = (c.b0_y + c.b1_y) * 0.5;
    r->b2_x = (c.b2_x + c.b3_x) * 0.5; r->b2_y = (c.b2_y + c.b3_y) * 0.5;
    l->b2_x = (l->b1_x + mx) * 0.5; l->b2_y = (l->b1_y + my) * 0.5;
    r->b1_x = (mx + r->b2_x) * 0.5; r->b1_y = (my + r->b2_y) * 0.5;
    l->b3_x = (l->b2_x + r->b1_x) * 0.5; l->b3_y = (l->b2_y + r->b1_y) * 0.5;
    r->b0_x = l->b3_x; r->b0_y = l->b3_y;
    l->t0   = c.t0; l->t1 = (c.t0 + c.t1) * 0.5;
    r->t0   = l->t1; r->t1 = c.t1;
}

/*----------------------------------------------------------------------------- 
 *  flatten_curve  --  produces a polyline approximation to a Bezier curve
 *-----------------------------------------------------------------------------
 */
void flatten_curve(curve c, GArray *apc)
{
    if (sufficiently_flat_curve(c)) {
        segment s;
        s.p_x = c.b0_x;
        s.p_y = c.b0_y;
        s.t   = c.t0;
        g_array_append_val(apc, s);
    } else {
        curve l, r;
        subdivide_curve(c, &l, &r);
        flatten_curve(l, apc);
        flatten_curve(r, apc);
    }
}

/*----------------------------------------------------------------------------- 
 *  get_offsets  --  get perpendicular offsets to a point on the stroke
 *-----------------------------------------------------------------------------
 */
void get_offsets(gdouble f, gdouble vx, gdouble vy, 
                 gdouble *delx, gdouble *dely)
{
    gdouble len, temp, ff;
    len = sqrt(vx*vx + vy*vy);
    vx /= len; vy /= len;
    temp = vx; vx = -vy; vy = temp;
    ff = pow(f, tvals.exponent);
    *delx = tvals.width_start * (1.0 - ff) * vx + tvals.width_end * ff * vx;
    *dely = tvals.width_start * (1.0 - ff) * vy + tvals.width_end * ff * vy;
    *delx *= 0.5;
    *dely *= 0.5;
}

/*----------------------------------------------------------------------------- 
 *  vectors_intersect  --  check if two vectors (as points) intersect
 *-----------------------------------------------------------------------------
 */
gboolean vectors_intersect(gdouble p1x, gdouble p1y, gdouble p2x, gdouble p2y, 
                           gdouble q1x, gdouble q1y, gdouble q2x, gdouble q2y,
                           gdouble *ix, gdouble *iy)
{
    gdouble denom = ((q2y - q1y) * (p2x - p1x)) - ((q2x - q1x) * (p2y - p1y));
    gdouble num   = ((q2x - q1x) * (p1y - q1y)) - ((q2y - q1y) * (p1x - q1x));
    
    if (ABS(denom) < EPS) return FALSE;
    
    gdouble u = num / denom;
    
    *ix = p1x + u * (p2x - p1x);
    *iy = p1y + u * (p2y - p1y);
    return TRUE;
}

/*----------------------------------------------------------------------------- 
 *  cross_product  --  returns the 2D cross product of two vectors
 *-----------------------------------------------------------------------------
 */
gdouble cross_product(gdouble v1x, gdouble v1y, gdouble v2x, gdouble v2y)
{
    return (v1x*v2y - v1y*v2x);
}

/*----------------------------------------------------------------------------- 
 *  compare_func  --  compare function for the array sort
 *-----------------------------------------------------------------------------
 */
gint compare_func(gconstpointer a, gconstpointer b)
{
    if (((segment *) a)->t > ((segment *) b)->t) return 1;
    if (((segment *) a)->t < ((segment *) b)->t) return -1;
    return 0;
}

/*----------------------------------------------------------------------------- 
 *  point_close_to_line  --  Determines if a point is close enough to a line
 *-----------------------------------------------------------------------------
 */
gboolean point_close_to_line(gdouble px, gdouble py, gdouble vx, gdouble vy,
                             gdouble qx, gdouble qy)
{
    gdouble u = ((qx - px)*vx + (qy - py)*vy) / (vx*vx + vy*vy);
    gdouble x = px + u*vx;
    gdouble y = py + u*vy;
    return ((x - qx)*(x - qx) + (y - qy)*(y - qy) < 
                                        tvals.tolerance*tvals.tolerance*0.25);
}


/*----------------------------------------------------------------------------- 
 *  remove_points  --  Removes useless points from a polyline
 *-----------------------------------------------------------------------------
 */
void remove_points(GArray *apx, GArray *apy)
{
    gint n;
    gdouble px, py, vx, vy, qx, qy;
    n = 0;
    while (n < apx->len - 2) {
        px = g_array_index(apx, gdouble, n);
        py = g_array_index(apy, gdouble, n);
        vx = g_array_index(apx, gdouble, n+1) - px;
        vy = g_array_index(apy, gdouble, n+1) - py;
        qx = g_array_index(apx, gdouble, n+2);
        qy = g_array_index(apy, gdouble, n+2);
        if (point_close_to_line(px, py, vx, vy, qx, qy)) {
            g_array_remove_index(apx, n+1);
            g_array_remove_index(apy, n+1);
        } else
            n++;
    }
}

/*----------------------------------------------------------------------------- 
 *  stroke_stroke_with_taper  --  strokes the vector stroke with a taper
 *-----------------------------------------------------------------------------
 */
void stroke_stroke_with_taper(gint32 image_id, gint32 vectors_id, 
                              gint stroke_id, gint num)
{
    gint      n, num_coords, m, k;
    gboolean  closed;
    gdouble  *coords;
    gdouble  *seg;
    gdouble   len, f, x, y, px, py;
    gdouble   v1x, v1y, v2x, v2y, del1x, del1y, del2x, del2y, 
              del3x, del3y, del4x, del4y;
    GArray   *apx;
    GArray   *apy;
    GArray   *apr;
    GArray   *apc;
    GArray   *apa;
    curve     c;
    arc       a;
    segment   s;
    GimpChannelOps operation;
    
    /* Extract control points */
    gimp_vectors_stroke_get_points(vectors_id, stroke_id, &num_coords,
                                   &coords, &closed);
                                   
    /* Must have at least 2 anchor points, i.e. 12 array entries */
    if (num_coords < 12) {
        g_free(coords);
        return;
    }
    
    apa = g_array_new(FALSE, TRUE, sizeof(segment));
    apc = g_array_new(FALSE, TRUE, sizeof(segment));
    apx = g_array_new(FALSE, TRUE, sizeof(gdouble));
    apy = g_array_new(FALSE, TRUE, sizeof(gdouble));
    
    /* For each Bezier curve, find a polyline approximation */
    for (n = 2; n < num_coords - 3; n += 6) {
        if (n == num_coords - 4) {
            if (closed) {
                c.b0_x = coords[n];
                c.b0_y = coords[n+1];
                c.b1_x = coords[n+2];
                c.b1_y = coords[n+3];
                c.b2_x = coords[0];
                c.b2_y = coords[1];
                c.b3_x = coords[2];
                c.b3_y = coords[3];
                c.t0   = 0.0;
                c.t1   = 1.0;
                g_array_set_size(apc, 0);
                flatten_curve(c, apc);
                g_array_sort(apc, compare_func);
                for (m = 0; m < apc->len; m++) {
                    s = g_array_index(apc, segment, m);
                    g_array_append_val(apx, s.p_x);
                    g_array_append_val(apy, s.p_y);
                }
            }
        } else {
            c.b0_x = coords[n];
            c.b0_y = coords[n+1];
            c.b1_x = coords[n+2];
            c.b1_y = coords[n+3];
            c.b2_x = coords[n+4];
            c.b2_y = coords[n+5];
            c.b3_x = coords[n+6];
            c.b3_y = coords[n+7];
            c.t0   = 0.0;
            c.t1   = 1.0;
            g_array_set_size(apc, 0);
            flatten_curve(c, apc);
            g_array_sort(apc, compare_func);
            for (m = 0; m < apc->len; m++) {
                s = g_array_index(apc, segment, m);
                g_array_append_val(apx, s.p_x);
                g_array_append_val(apy, s.p_y);
            }
        }
    }
    
    /* Add end points and remove points that are not required */
    if (closed) {
        g_array_append_val(apx, coords[2]);
        g_array_append_val(apy, coords[3]);
    } else {
        g_array_append_val(apx, coords[num_coords - 4]);
        g_array_append_val(apy, coords[num_coords - 3]);
    }
    remove_points(apx, apy);
    
    /* If  square caps then extend the first and last two points */
    if (tvals.cap == 2) {
        v1x = g_array_index(apx, gdouble, 0) - g_array_index(apx, gdouble, 1);
        v1y = g_array_index(apy, gdouble, 0) - g_array_index(apy, gdouble, 1);
        len = sqrt(v1x*v1x + v1y*v1y);
        v1x /= len; 
        v1y /= len;
        v1x *= tvals.width_start * 0.5; 
        v1y *= tvals.width_start * 0.5;
        g_array_index(apx, gdouble, 0) += v1x;
        g_array_index(apy, gdouble, 0) += v1y;
        v1x = g_array_index(apx, gdouble, apx->len-1) - 
              g_array_index(apx, gdouble, apx->len-2);
        v1y = g_array_index(apy, gdouble, apx->len-1) - 
              g_array_index(apy, gdouble, apx->len-2);
        len = sqrt(v1x*v1x + v1y*v1y);
        v1x /= len; 
        v1y /= len;
        v1x *= tvals.width_end * 0.5; 
        v1y *= tvals.width_end * 0.5;
        g_array_index(apx, gdouble, apx->len-1) += v1x;
        g_array_index(apy, gdouble, apx->len-1) += v1y;
    }
    
    
    /* create array of lengths, then make it cummulative ratios */
    len = 0.0;
    apr = g_array_new(FALSE, TRUE, sizeof(gdouble));
    for (n = 0; n < apx->len; n++) {
        if (n == 0) 
          g_array_append_val(apr, len);
        else {
            len += sqrt(SQR(g_array_index(apx, gdouble, n) - 
                            g_array_index(apx, gdouble, n-1)) +
                        SQR(g_array_index(apy, gdouble, n) - 
                            g_array_index(apy, gdouble, n-1)));
            g_array_append_val(apr, len);
        }
    }
    for (n = 0; n < apr->len; n++) 
        g_array_index(apr, gdouble, n) /= len;
    
    /* Now draw the segments */
    seg = g_new(gdouble, 12);
    for (n = 1; n < apx->len - 1; n++) {
        v1x = g_array_index(apx, gdouble, n) - 
              g_array_index(apx, gdouble, n - 1);
        v1y = g_array_index(apy, gdouble, n) - 
              g_array_index(apy, gdouble, n - 1);
        v2x = g_array_index(apx, gdouble, n + 1) - 
              g_array_index(apx, gdouble, n);
        v2y = g_array_index(apy, gdouble, n + 1) - 
              g_array_index(apy, gdouble, n);
        px = g_array_index(apx, gdouble, n);
        py = g_array_index(apy, gdouble, n);
        f = g_array_index(apr, gdouble, n - 1);
        get_offsets(f, v1x, v1y, &del1x, &del1y);
        f = g_array_index(apr, gdouble, n);
        get_offsets(f, v1x, v1y, &del2x, &del2y);
        get_offsets(f, v2x, v2y, &del3x, &del3y);
        f = g_array_index(apr, gdouble, n + 1);
        get_offsets(f, v2x, v2y, &del4x, &del4y);
        
        /* Add join on exterior angle only */
        if (cross_product(v1x, v1y, v2x, v2y) > 0) {
            del1x = -del1x; del1y = -del1y;
            del2x = -del2x; del2y = -del2y;
            del3x = -del3x; del3y = -del3y;
            del4x = -del4x; del4y = -del4y;
        }
        
        /* Set selection operation mode */
        if (START) {
            START = FALSE;
            operation = GIMP_CHANNEL_OP_REPLACE;
        }
        else
            operation = GIMP_CHANNEL_OP_ADD;
        
        /* Add join if angle is large enough, need intersection point */
        if (vectors_intersect(g_array_index(apx, gdouble, n - 1) + del1x, 
                              g_array_index(apy, gdouble, n - 1) + del1y,
                              px + del2x, py + del2y, px + del3x, py + del3y,
                              g_array_index(apx, gdouble, n + 1) + del4x, 
                              g_array_index(apy, gdouble, n + 1) + del4y,
                              &x, &y)) {
            if (tvals.join == 0) {
                seg[0]  = g_array_index(apx, gdouble, n - 1) + del1x;
                seg[1]  = g_array_index(apy, gdouble, n - 1) + del1y;
                if ((px - x)*(px - x) + (py - y)*(py - y) > 
                       tvals.miter_limit * tvals.miter_limit * 
                       (del2x*del2x + del2y*del2y)) {
                    seg[2]  = px + del2x;
                    seg[3]  = py + del2y;
                } else {
                    seg[2] = x;
                    seg[3] = y;
                }
                seg[4]  = px + del3x;
                seg[5]  = py + del3y;
                seg[6]  = px;
                seg[7]  = py;
                seg[8]  = px - del2x;
                seg[9]  = py - del2y;
                seg[10] = g_array_index(apx, gdouble, n - 1) - del1x;
                seg[11] = g_array_index(apy, gdouble, n - 1) - del1y;
                gimp_free_select(image_id, 12, seg, operation, TRUE, FALSE, 0);
            } else if (tvals.join == 2) {
                seg[0]  = g_array_index(apx, gdouble, n - 1) + del1x;
                seg[1]  = g_array_index(apy, gdouble, n - 1) + del1y;
                seg[2]  = px + del2x;
                seg[3]  = py + del2y;
                seg[4]  = px + del3x;
                seg[5]  = py + del3y;
                seg[6]  = px;
                seg[7]  = py;
                seg[8]  = px - del2x;
                seg[9]  = py - del2y;
                seg[10] = g_array_index(apx, gdouble, n - 1) - del1x;
                seg[11] = g_array_index(apy, gdouble, n - 1) - del1y;
                gimp_free_select(image_id, 12, seg, operation, TRUE, FALSE, 0);
            } else {
                a.bc_x = px;
                a.bc_y = py;
                a.b0_x = px + del2x;
                a.b0_y = py + del2y;
                a.b1_x = px + del3x;
                a.b1_y = py + del3y;
                a.t0   = 0.0;
                a.t1   = 1.0;
                g_array_set_size(apa, 0);
                flatten_arc(a, apa);
                g_array_sort(apa, compare_func);
                m = apa->len * 2 + 10;
                seg = g_renew(gdouble, seg, m);
                seg[0]  = g_array_index(apx, gdouble, n - 1) + del1x;
                seg[1]  = g_array_index(apy, gdouble, n - 1) + del1y;
                for (k = 0; k < apa->len; k++) {
                    seg[2*k+2] = g_array_index(apa, segment, k).p_x;
                    seg[2*k+3] = g_array_index(apa, segment, k).p_y;
                }
                seg[m-8] = a.b1_x; seg[m-7] = a.b1_y;
                seg[m-6] = a.bc_x; seg[m-5] = a.bc_y;
                seg[m-4] = px - del2x;
                seg[m-3] = py - del2y;
                seg[m-2] = g_array_index(apx, gdouble, n - 1) - del1x;
                seg[m-1] = g_array_index(apy, gdouble, n - 1) - del1y;
                gimp_free_select(image_id, m, seg, operation, TRUE, FALSE, 0);
            }
        } else {
            seg[0]  = g_array_index(apx, gdouble, n - 1) + del1x;
            seg[1]  = g_array_index(apy, gdouble, n - 1) + del1y;
            seg[2]  = px + del2x;
            seg[3]  = py + del2y;
            seg[4]  = px - del2x;
            seg[5]  = py - del2y;
            seg[6]  = g_array_index(apx, gdouble, n - 1) - del1x;
            seg[7]  = g_array_index(apy, gdouble, n - 1) - del1y;
            gimp_free_select(image_id, 8, seg, operation, TRUE, FALSE, 0);
        }
        operation = GIMP_CHANNEL_OP_ADD;
        if (n == apx->len - 2) {
            seg[0]  = px + del3x;
            seg[1]  = py + del3y;
            seg[2]  = g_array_index(apx, gdouble, n + 1) + del4x;
            seg[3]  = g_array_index(apy, gdouble, n + 1) + del4y;
            seg[4]  = g_array_index(apx, gdouble, n + 1) - del4x;
            seg[5]  = g_array_index(apy, gdouble, n + 1) - del4y;
            seg[6]  = px - del3x;
            seg[7]  = py - del3y;
            gimp_free_select(image_id, 8, seg, operation, TRUE, FALSE, 0);
        }
        x = (gdouble) num + ((gdouble) n / (gdouble) (apx->len - 2));
        gimp_progress_update(x / ((gdouble) num_strokes));
    }
    
    /* This happens if the above loop is skipped, i.e. there are 2 points */
    if (apx->len == 2) {
        v1x = g_array_index(apx, gdouble, n) - 
              g_array_index(apx, gdouble, n - 1);
        v1y = g_array_index(apy, gdouble, n) - 
              g_array_index(apy, gdouble, n - 1);
        v2x = g_array_index(apx, gdouble, n + 1) - 
              g_array_index(apx, gdouble, n);
        v2y = g_array_index(apy, gdouble, n + 1) - 
              g_array_index(apy, gdouble, n);
        px = g_array_index(apx, gdouble, n);
        py = g_array_index(apy, gdouble, n);
        f = g_array_index(apr, gdouble, n - 1);
        get_offsets(f, v1x, v1y, &del1x, &del1y);
        f = g_array_index(apr, gdouble, n);
        get_offsets(f, v1x, v1y, &del2x, &del2y);
        operation = GIMP_CHANNEL_OP_ADD;
        seg[0]  = g_array_index(apx, gdouble, n - 1) + del1x;
        seg[1]  = g_array_index(apy, gdouble, n - 1) + del1y;
        seg[2]  = px + del2x;
        seg[3]  = py + del2y;
        seg[4]  = px - del2x;
        seg[5]  = py - del2y;
        seg[6]  = g_array_index(apx, gdouble, n - 1) - del1x;
        seg[7]  = g_array_index(apy, gdouble, n - 1) - del1y;
        gimp_free_select(image_id, 8, seg, operation, TRUE, FALSE, 0);
    }
    
    /* Add round caps if required */
    if (tvals.cap == 1) {
        operation = GIMP_CHANNEL_OP_ADD;
        /* Start cap */
        v1x = g_array_index(apx, gdouble, 1) - g_array_index(apx, gdouble, 0);
        v1y = g_array_index(apy, gdouble, 1) - g_array_index(apy, gdouble, 0);
        f = g_array_index(apr, gdouble, 0);
        get_offsets(f, v1x, v1y, &del1x, &del1y);
        len = sqrt(v1x*v1x + v1y*v1y);
        v1x *= 2/len; v1y *= 2/len;
        a.bc_x = g_array_index(apx, gdouble, 0) + v1x;
        a.bc_y = g_array_index(apy, gdouble, 0) + v1y;
        a.b0_x = g_array_index(apx, gdouble, 0) + del1x;
        a.b0_y = g_array_index(apy, gdouble, 0) + del1y;
        a.b1_x = g_array_index(apx, gdouble, 0) - del1x;
        a.b1_y = g_array_index(apy, gdouble, 0) - del1y;
        a.t0   = 0.0;
        a.t1   = 1.0;
        g_array_set_size(apa, 0);
        flatten_arc(a, apa);
        g_array_sort(apa, compare_func);
        m = apa->len * 2 + 4;
        seg = g_renew(gdouble, seg, m);
        for (n = 0; n < apa->len; n++) {
            seg[2*n]   = g_array_index(apa, segment, n).p_x;
            seg[2*n+1] = g_array_index(apa, segment, n).p_y;
        }
        seg[m-4] = a.b1_x; seg[m-3] = a.b1_y;
        seg[m-2] = a.bc_x; seg[m-1] = a.bc_y;
        gimp_free_select(image_id, m, seg, operation, TRUE, FALSE, 0);
        /* End cap */
        v1x = g_array_index(apx, gdouble, apx->len-1) - 
              g_array_index(apx, gdouble, apx->len-2);
        v1y = g_array_index(apy, gdouble, apx->len-1) - 
              g_array_index(apy, gdouble, apx->len-2);
        f = g_array_index(apr, gdouble, apx->len-1);
        get_offsets(f, v1x, v1y, &del1x, &del1y);
        len = sqrt(v1x*v1x + v1y*v1y);
        v1x *= 2/len; v1y *= 2/len;
        a.bc_x = g_array_index(apx, gdouble, apx->len-1) - v1x;
        a.bc_y = g_array_index(apy, gdouble, apx->len-1) - v1y;
        a.b0_x = g_array_index(apx, gdouble, apx->len-1) + del1x;
        a.b0_y = g_array_index(apy, gdouble, apx->len-1) + del1y;
        a.b1_x = g_array_index(apx, gdouble, apx->len-1) - del1x;
        a.b1_y = g_array_index(apy, gdouble, apx->len-1) - del1y;
        a.t0   = 0.0;
        a.t1   = 1.0;
        g_array_set_size(apa, 0);
        flatten_arc(a, apa);
        g_array_sort(apa, compare_func);
        m = apa->len * 2 + 4;
        seg = g_renew(gdouble, seg, m);
        for (n = 0; n < apa->len; n++) {
            seg[2*n]   = g_array_index(apa, segment, n).p_x;
            seg[2*n+1] = g_array_index(apa, segment, n).p_y;
        }
        seg[m-4] = a.b1_x; seg[m-3] = a.b1_y;
        seg[m-2] = a.bc_x; seg[m-1] = a.bc_y;
        gimp_free_select(image_id, m, seg, operation, TRUE, FALSE, 0);
    }
    
    g_array_free(apa, TRUE);
    g_array_free(apc, TRUE);
    g_array_free(apx, TRUE);
    g_array_free(apy, TRUE);
    g_array_free(apr, TRUE);
    g_free(seg);
    g_free(coords);
}

/*----------------------------------------------------------------------------- 
 *  stroke_path_with_taper  --  strokes a path with a taper by transforming
 *                              original path to an outline, and then filling
 *                              the outline with the foreground color
 *-----------------------------------------------------------------------------
 */
gboolean stroke_path_with_taper(gint32 drawable_id, gint32 image_id, 
                                gint32 vectors_id)
{
    gint          n;
    gint         *strokes;
    gint32        channel_id;
    gboolean      empty;
    
    gimp_progress_init("Stroking path with taper...");
    
    /* The taper algorithm is applied to each stroke */
    START = TRUE;
    empty = gimp_selection_is_empty(image_id);
    if (!empty) channel_id = gimp_selection_save(image_id);
    strokes = gimp_vectors_get_strokes(vectors_id, &num_strokes);
    for (n = 0; n < num_strokes; n++) 
      stroke_stroke_with_taper(image_id, vectors_id, strokes[n], n);
      
    /* Fill with foreground colour or pattern, sharpen if neccessary */
    if (!tvals.antialiased) gimp_selection_sharpen(image_id);
    if (!empty) gimp_selection_combine(channel_id, GIMP_CHANNEL_OP_INTERSECT);
    if (tvals.fill)
        gimp_edit_fill(drawable_id, GIMP_PATTERN_FILL);
    else
        gimp_edit_fill(drawable_id, GIMP_FOREGROUND_FILL);
    
    if (empty)
        gimp_selection_none(image_id);
    else 
        gimp_selection_load(channel_id);
    
    g_free(strokes);
    
    return TRUE;
}

gboolean run_flag;

/*----------------------------------------------------------------------------- 
 *  response_callback  --  callback function for our main dialog
 *-----------------------------------------------------------------------------
 */
void response_callback(GtkWidget *widget, gint response_id, entry *scale)
{
    switch (response_id) {
        case RESPONSE_RESET:
            gimp_size_entry_set_refval(GIMP_SIZE_ENTRY(scale->sw_entry), 0,
                                       DEF_SW);
            tvals.width_start = DEF_SW;
            gimp_size_entry_set_refval(GIMP_SIZE_ENTRY(scale->ew_entry), 0,
                                       DEF_EW);
            tvals.width_end = DEF_EW;
            gtk_adjustment_set_value(GTK_ADJUSTMENT(scale->to_entry), DEF_TO);
            gtk_adjustment_value_changed(GTK_ADJUSTMENT(scale->to_entry));
            gtk_adjustment_set_value(GTK_ADJUSTMENT(scale->ex_entry), DEF_EX);
            gtk_adjustment_value_changed(GTK_ADJUSTMENT(scale->ex_entry));
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(scale->fi_entry),
                                         TRUE);
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(scale->ca_entry),
                                         TRUE);
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(scale->jo_entry),
                                         TRUE);
            gtk_adjustment_set_value(GTK_ADJUSTMENT(scale->ml_entry), DEF_ML);
            gtk_adjustment_value_changed(GTK_ADJUSTMENT(scale->ml_entry));
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(scale->aa_entry), 
                                         DEF_AA);
            break;

        case GTK_RESPONSE_OK:
            run_flag = TRUE;

        default:
            gtk_widget_destroy(GTK_WIDGET(widget));
            break;
    }
}

/*----------------------------------------------------------------------------- 
 *  entry_callback  --  callback function for our entry widgets
 *-----------------------------------------------------------------------------
 */
void entry_callback(GtkWidget *widget, gpointer data)
{
    gint *n;
    n = (gint *) data;
    switch (*n) {
        case 0:
            tvals.width_start 
              = gimp_size_entry_get_refval(GIMP_SIZE_ENTRY(widget), 0);
            break;
        case 1:
            tvals.width_end 
              = gimp_size_entry_get_refval(GIMP_SIZE_ENTRY(widget), 0);
            break;
        case 2:
            if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget)))
                tvals.cap = 0;
            break;
        case 3:
            if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget)))
                tvals.cap = 1;
            break;
        case 4:
            if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget)))
                tvals.cap = 2;
            break;
        case 5:
            if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget)))
                tvals.join = 0;
            break;
        case 6:
            if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget)))
                tvals.join = 1;
            break;
        case 7:
            if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget)))
                tvals.join = 2;
            break;
        case 8:
            if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget)))
                tvals.fill = 0;
            break;
        case 9:
            if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget)))
                tvals.fill = 1;
            break;
    }
}

/*----------------------------------------------------------------------------- 
 *  taper_dialog  --  dialog that allows user to set some algorithm parameters
 *-----------------------------------------------------------------------------
 */
gboolean taper_dialog(gint32 image_id)
{
    GtkWidget *dialog;
    GtkWidget *vbox;
    GtkWidget *table;
    GtkWidget *table1;
    GtkWidget *spin1;
    GtkWidget *spin2;
    GtkWidget *label1;
    GtkWidget *label2;
    GtkWidget *label3;
    GtkWidget *label4;
    GtkWidget *label5;
    GtkWidget *label6;
    GtkWidget *label7;
    GtkWidget *expand;
    GtkWidget *radio1;
    GtkWidget *radio2;
    GtkWidget *radio3;
    GtkWidget *radio4;
    GtkWidget *radio5;
    GtkWidget *radio6;
    GtkWidget *radio7;
    GtkWidget *radio8;
    GtkWidget *hbox1;
    GtkWidget *hbox2;
    GtkWidget *image;
    GtkWidget *align;
    GtkWidget *temp;
    gint       arr[10];
    gint       n;
    GimpUnit   unit;
    gdouble    xres;
    gdouble    yres;
    entry      scale;
    
    run_flag = FALSE;
    
    gimp_ui_init(PLUG_IN_BINARY, FALSE);
    
    dialog = gimp_dialog_new("Stroke Path with Taper", PLUG_IN_BINARY,
                             NULL, 0,
                             gimp_standard_help_func, PLUG_IN_PROC,
                             GIMP_STOCK_RESET, RESPONSE_RESET,
                             GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                             GTK_STOCK_OK,     GTK_RESPONSE_OK,
                             NULL);
                             
    gtk_dialog_set_alternative_button_order(GTK_DIALOG (dialog),
                                            RESPONSE_RESET,
                                            GTK_RESPONSE_OK,
                                            GTK_RESPONSE_CANCEL,
                                            -1);
                                            
    gtk_window_set_resizable(GTK_WINDOW (dialog), FALSE);
    
    vbox = gtk_vbox_new(FALSE, 12);
    gtk_container_set_border_width(GTK_CONTAINER(vbox), 12);
    gtk_container_add(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), vbox);
    gtk_widget_show(vbox);
    
    for (n = 0; n < 10; n++) arr[n] = n;
                     
    /* Our main table that will hold everything */
    table = gtk_table_new(5, 3, TRUE);
    gtk_table_set_row_spacings(GTK_TABLE(table), 6);
    gtk_table_set_row_spacing(GTK_TABLE(table), 0, 6);
    gtk_table_set_col_spacing(GTK_TABLE(table), 0, 10);
    gtk_box_pack_start(GTK_BOX(vbox), table, FALSE, FALSE, 0);
    gtk_widget_show(table);
    
    /* Do the labels */
    label1 = gtk_label_new_with_mnemonic("_Start width: ");
    gtk_table_attach(GTK_TABLE(table), label1, 0, 1, 0, 1, GTK_FILL,
                     GTK_FILL, 0, 3);
    gtk_misc_set_alignment(GTK_MISC(label1), 0.0, 0.5);
    gtk_widget_show(label1);
    label2 = gtk_label_new_with_mnemonic("_End width: ");
    gtk_table_attach(GTK_TABLE(table), label2, 0, 1, 1, 2, GTK_FILL,
                     GTK_FILL, 0, 3);
    gtk_misc_set_alignment(GTK_MISC(label2), 0.0, 0.5);
    gtk_widget_show(label2);
    label3 = gtk_label_new_with_mnemonic("E_xponent: ");
    gtk_table_attach(GTK_TABLE(table), label3, 0, 1, 2, 3, GTK_FILL,
                     GTK_FILL, 0, 3);
    gtk_misc_set_alignment(GTK_MISC(label3), 0.0, 0.5);
    gtk_widget_show(label3);
    label4 = gtk_label_new_with_mnemonic("_Tolerance: ");
    gtk_table_attach(GTK_TABLE(table), label4, 0, 1, 3, 4, GTK_FILL,
                     GTK_FILL, 0, 3);
    gtk_misc_set_alignment(GTK_MISC(label4), 0.0, 0.5);
    gtk_widget_show(label4);
    label7 = gtk_label_new_with_mnemonic("_Fill Style: ");
    gtk_table_attach(GTK_TABLE(table), label7, 0, 1, 4, 5, GTK_FILL,
                     GTK_FILL, 0, 3);
    gtk_misc_set_alignment(GTK_MISC(label7), 0.0, 0.5);
    gtk_widget_show(label7);
                     
    /*  Get the image resolution and unit  */
    gimp_image_get_resolution(image_id, &xres, &yres);
    unit = gimp_image_get_unit(image_id);
                     
    /* Start width entry widget */
    scale.sw_entry = gimp_size_entry_new(1, unit, "%a", TRUE, FALSE, FALSE,
                                         SPIN_BUTTON_WIDTH,
                                         GIMP_SIZE_ENTRY_UPDATE_SIZE);
    gimp_size_entry_set_unit(GIMP_SIZE_ENTRY(scale.sw_entry), GIMP_UNIT_PIXEL);
    gimp_size_entry_set_resolution(GIMP_SIZE_ENTRY(scale.sw_entry), 0, xres, 
                                   TRUE);
    gimp_size_entry_set_refval_boundaries(GIMP_SIZE_ENTRY(scale.sw_entry), 0,
                                          0.0, 200.0);
    gimp_size_entry_set_refval(GIMP_SIZE_ENTRY(scale.sw_entry), 0,
                               tvals.width_start);
    gimp_size_entry_set_refval_digits(GIMP_SIZE_ENTRY(scale.sw_entry), 0, 1);
    g_signal_connect(scale.sw_entry, "value-changed",
                     G_CALLBACK(entry_callback),
                     &arr[0]);
    gtk_table_attach(GTK_TABLE(table), scale.sw_entry, 1, 3, 0, 1, GTK_FILL,
                     GTK_FILL, 0, 0);
    gtk_widget_show(scale.sw_entry);
    temp = gimp_size_entry_get_help_widget(GIMP_SIZE_ENTRY(scale.sw_entry), 0);
    gtk_label_set_mnemonic_widget(GTK_LABEL(label1), temp);
    
    /*  End width entry widget*/
    scale.ew_entry = gimp_size_entry_new(1, unit, "%a", TRUE, FALSE, FALSE,
                                         SPIN_BUTTON_WIDTH,
                                         GIMP_SIZE_ENTRY_UPDATE_SIZE);
    gimp_size_entry_set_unit(GIMP_SIZE_ENTRY(scale.ew_entry), GIMP_UNIT_PIXEL);
    gimp_size_entry_set_resolution(GIMP_SIZE_ENTRY(scale.ew_entry), 0, xres, 
                                   TRUE);
    gimp_size_entry_set_refval_boundaries(GIMP_SIZE_ENTRY(scale.ew_entry), 0,
                                          0.0, 200.0);
    gimp_size_entry_set_refval(GIMP_SIZE_ENTRY(scale.ew_entry), 0,
                               tvals.width_end);
    gimp_size_entry_set_refval_digits(GIMP_SIZE_ENTRY(scale.ew_entry), 0, 1);
    g_signal_connect(scale.ew_entry, "value-changed",
                     G_CALLBACK(entry_callback),
                     &arr[1]);
    gtk_table_attach(GTK_TABLE(table), scale.ew_entry, 1, 3, 1, 2, GTK_FILL,
                     GTK_FILL, 0, 0);
    gtk_widget_show(scale.ew_entry);
    temp = gimp_size_entry_get_help_widget(GIMP_SIZE_ENTRY(scale.ew_entry), 0);
    gtk_label_set_mnemonic_widget(GTK_LABEL(label2), temp);
    
    /* Tolerance entry widget */
    spin1 = gimp_spin_button_new(&scale.to_entry, tvals.tolerance, 0.05, 5.0,
                                 0.05, 0.5, 0.0, 1.0, 2);
    g_signal_connect(scale.to_entry, "value-changed",
                     G_CALLBACK(gimp_double_adjustment_update),
                     &tvals.tolerance);
    gtk_table_attach(GTK_TABLE(table), spin1, 1, 2, 3, 4, GTK_FILL,
                     GTK_FILL, 0, 3);
    gtk_widget_show(spin1);
    gtk_label_set_mnemonic_widget(GTK_LABEL(label4), spin1);
                     
    /* Exponent entry widget */
    spin2 = gimp_spin_button_new(&scale.ex_entry, tvals.exponent, 0.1, 20.0,
                                 0.1, 1.0, 0.0, 1.0, 2);
    g_signal_connect(scale.ex_entry, "value-changed",
                     G_CALLBACK(gimp_double_adjustment_update),
                     &tvals.exponent);
    gtk_table_attach(GTK_TABLE(table), spin2, 1, 2, 2, 3, GTK_FILL,
                     GTK_FILL, 0, 3);
    gtk_widget_show(spin2);
    gtk_label_set_mnemonic_widget(GTK_LABEL(label3), spin2);
    
    /* Fill style radio buttons */
    radio7 = gtk_radio_button_new_with_label(NULL, "Color");
    gtk_table_attach(GTK_TABLE(table), radio7, 1, 2, 4, 5, GTK_FILL,
                     GTK_FILL, 0, 3);
    g_signal_connect(radio7, "toggled", G_CALLBACK(entry_callback), &arr[8]);
    gtk_widget_show(radio7);
    scale.fi_entry = radio7;
    gtk_label_set_mnemonic_widget(GTK_LABEL(label7), radio7);
    
    radio8 
      = gtk_radio_button_new_with_label_from_widget(GTK_RADIO_BUTTON(radio7),
                                                    "Pattern");
    gtk_table_attach(GTK_TABLE(table), radio8, 2, 3, 4, 5, GTK_FILL,
                     GTK_FILL, 0, 3);
    g_signal_connect(radio8, "toggled", G_CALLBACK(entry_callback), &arr[9]);
    gtk_widget_show(radio8);
    
    /* Expander, holds the cap/join options */
    expand = gtk_expander_new_with_mnemonic("_Line Style");
    gtk_box_pack_start(GTK_BOX(vbox), expand, FALSE, FALSE, 0);
    gtk_expander_set_spacing(GTK_EXPANDER(expand), 13);
    gtk_widget_show(expand);
    
    /* Alignment container */
    align = gtk_alignment_new(0, 0, 0, 0);
    gtk_alignment_set_padding(GTK_ALIGNMENT(align), 0, 0, 16, 0);
    gtk_container_add(GTK_CONTAINER(expand), align);
    gtk_widget_show(align);
    
    /* Table to hold cap/join options */
    table1 = gtk_table_new(2, 4, FALSE);
    gtk_table_set_row_spacings(GTK_TABLE(table1), 3);
    gtk_table_set_col_spacing(GTK_TABLE(table1), 0, 6);
    gtk_container_add(GTK_CONTAINER(align), table1);
    gtk_widget_show(table1);
    
    /* Labels */
    label5 = gtk_label_new_with_mnemonic("_Cap style: ");
    gtk_misc_set_alignment(GTK_MISC(label5),0.0,0.5);
    gtk_table_attach(GTK_TABLE(table1), label5, 0, 1, 0, 1, GTK_FILL,
                     GTK_FILL, 0, 0);
    gtk_widget_show(label5);
    label6 = gtk_label_new_with_mnemonic("_Join style: ");
    gtk_misc_set_alignment(GTK_MISC(label6),0.0,0.5);
    gtk_table_attach(GTK_TABLE(table1), label6, 0, 1, 1, 2, GTK_FILL,
                     GTK_FILL, 0, 0);
    gtk_widget_show(label6);
    
    /* HBox */
    hbox1 = gtk_hbox_new(FALSE, 0);
    align = gtk_alignment_new(0.0, 0.5, 0.0, 0.0);
    gtk_container_add(GTK_CONTAINER(align), hbox1);
    gtk_table_attach(GTK_TABLE(table1), align, 1, 2, 0, 1, GTK_FILL,
                     GTK_FILL, 0, 0);
    gtk_widget_show(hbox1);
    gtk_widget_show(align);
    hbox2 = gtk_hbox_new(FALSE, 0);
    align = gtk_alignment_new(0.0, 0.5, 0.0, 0.0);
    gtk_container_add(GTK_CONTAINER(align), hbox2);
    gtk_table_attach(GTK_TABLE(table1), align, 1, 2, 1, 2, GTK_FILL,
                     GTK_FILL, 0, 0);
    gtk_widget_show(hbox2);
    gtk_widget_show(align);
    
    /* Toggle buttons */
    radio1 = gtk_radio_button_new(NULL);
    gtk_container_add(GTK_CONTAINER(hbox1), radio1);
    gtk_toggle_button_set_mode(GTK_TOGGLE_BUTTON(radio1), FALSE);
    image = gtk_image_new_from_stock(GIMP_STOCK_CAP_BUTT, GTK_ICON_SIZE_MENU);
    gtk_container_add(GTK_CONTAINER(radio1), image);
    gtk_widget_show(image);
    gtk_button_set_relief(GTK_BUTTON(radio1), GTK_RELIEF_NONE);
    g_signal_connect(radio1, "toggled", G_CALLBACK(entry_callback), &arr[2]);
    gtk_widget_show(radio1);
    scale.ca_entry = radio1;
    gtk_label_set_mnemonic_widget(GTK_LABEL(label5), radio1);
    
    radio2 = gtk_radio_button_new_from_widget(GTK_RADIO_BUTTON(radio1));
    gtk_container_add(GTK_CONTAINER(hbox1), radio2);
    gtk_toggle_button_set_mode(GTK_TOGGLE_BUTTON(radio2), FALSE);
    image = gtk_image_new_from_stock(GIMP_STOCK_CAP_ROUND, GTK_ICON_SIZE_MENU);
    gtk_container_add(GTK_CONTAINER(radio2), image);
    gtk_widget_show(image);
    gtk_button_set_relief(GTK_BUTTON(radio2), GTK_RELIEF_NONE);
    g_signal_connect(radio2, "toggled", G_CALLBACK(entry_callback), &arr[3]);
    gtk_widget_show(radio2);
    
    radio3 = gtk_radio_button_new_from_widget(GTK_RADIO_BUTTON(radio1));
    gtk_container_add(GTK_CONTAINER(hbox1), radio3);
    gtk_toggle_button_set_mode(GTK_TOGGLE_BUTTON(radio3), FALSE);
    image = gtk_image_new_from_stock(GIMP_STOCK_CAP_SQUARE,GTK_ICON_SIZE_MENU);
    gtk_container_add(GTK_CONTAINER(radio3), image);
    gtk_widget_show(image);
    gtk_button_set_relief(GTK_BUTTON(radio3), GTK_RELIEF_NONE);
    g_signal_connect(radio3, "toggled", G_CALLBACK(entry_callback), &arr[4]);
    gtk_widget_show(radio3);
    
    radio4 = gtk_radio_button_new(NULL);
    gtk_container_add(GTK_CONTAINER(hbox2), radio4);
    gtk_toggle_button_set_mode(GTK_TOGGLE_BUTTON(radio4), FALSE);
    image = gtk_image_new_from_stock(GIMP_STOCK_JOIN_MITER,GTK_ICON_SIZE_MENU);
    gtk_container_add(GTK_CONTAINER(radio4), image);
    gtk_widget_show(image);
    gtk_button_set_relief(GTK_BUTTON(radio4), GTK_RELIEF_NONE);
    g_signal_connect(radio4, "toggled", G_CALLBACK(entry_callback), &arr[5]);
    gtk_widget_show(radio4);
    scale.jo_entry = radio4;
    gtk_label_set_mnemonic_widget(GTK_LABEL(label6), radio4);
    
    radio5 = gtk_radio_button_new_from_widget(GTK_RADIO_BUTTON(radio4));
    gtk_container_add(GTK_CONTAINER(hbox2), radio5);
    gtk_toggle_button_set_mode(GTK_TOGGLE_BUTTON(radio5), FALSE);
    image = gtk_image_new_from_stock(GIMP_STOCK_JOIN_ROUND,GTK_ICON_SIZE_MENU);
    gtk_container_add(GTK_CONTAINER(radio5), image);
    gtk_widget_show(image);
    gtk_button_set_relief(GTK_BUTTON(radio5), GTK_RELIEF_NONE);
    g_signal_connect(radio5, "toggled", G_CALLBACK(entry_callback), &arr[6]);
    gtk_widget_show(radio5);
    
    radio6 = gtk_radio_button_new_from_widget(GTK_RADIO_BUTTON(radio4));
    gtk_container_add(GTK_CONTAINER(hbox2), radio6);
    gtk_toggle_button_set_mode(GTK_TOGGLE_BUTTON(radio6), FALSE);
    image = gtk_image_new_from_stock(GIMP_STOCK_JOIN_BEVEL,GTK_ICON_SIZE_MENU);
    gtk_container_add(GTK_CONTAINER(radio6), image);
    gtk_widget_show(image);
    gtk_button_set_relief(GTK_BUTTON(radio6), GTK_RELIEF_NONE);
    g_signal_connect(radio6, "toggled", G_CALLBACK(entry_callback), &arr[7]);
    gtk_widget_show(radio6);
    
    switch (tvals.cap) {
        case 0:
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radio1), TRUE);
            break;
        case 1:
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radio2), TRUE);
            break;
        case 2:
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radio3), TRUE);
            break;
    }
    
    switch (tvals.join) {
        case 0:
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radio4), TRUE);
            break;
        case 1:
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radio5), TRUE);
            break;
        case 2:
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radio6), TRUE);
            break;
    }
    
    /* Miter limit scale entry */
    scale.ml_entry = gimp_scale_entry_new(GTK_TABLE(table1), 0, 2,
                                          "_Miter limit:", SCALE_WIDTH, 6,
                                          tvals.miter_limit, 0.0, 100.0, 1.0, 
                                          1.0, 2, TRUE, 0, 0, NULL, NULL);
    g_signal_connect(scale.ml_entry, "value-changed",
                     G_CALLBACK(gimp_double_adjustment_update),
                     &tvals.miter_limit);
                     
    /* Antialiasing checkbox */
    scale.aa_entry = gtk_check_button_new_with_mnemonic("_Antialiasing");
    gtk_misc_set_alignment(GTK_MISC(scale.aa_entry),0.0,0.5);
    gtk_table_attach(GTK_TABLE(table1), scale.aa_entry, 0, 1, 3, 4, GTK_FILL,
                     GTK_FILL, 0, 0);
    gtk_widget_show(scale.aa_entry);
    g_signal_connect(scale.aa_entry, "toggled",
                     G_CALLBACK(gimp_toggle_button_update),
                     &tvals.antialiased);
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(scale.aa_entry),
                                 tvals.antialiased);

    /* Dialog callbacks */
    g_signal_connect(dialog, "response",
                     G_CALLBACK(response_callback),
                     &scale);
    g_signal_connect(dialog, "destroy",
                     G_CALLBACK(gtk_main_quit),
                     NULL);
                     
    gtk_widget_show(dialog);
    
    gtk_main();

    return run_flag;
}

/*----------------------------------------------------------------------------- 
 *  run  --  code that gets called when the plugin is asked to run
 *-----------------------------------------------------------------------------
 */
static void run(const gchar      *name,
                gint              nparams,
                const GimpParam  *param,
                gint             *nreturn_vals,
                GimpParam       **return_vals)
{
    static GimpParam  values[1];
    GimpPDBStatusType status = GIMP_PDB_SUCCESS;
    GimpRunMode       run_mode;
    gint32            drawable_id, image_id, vectors_id;

    /* Setting mandatory output values */
    *nreturn_vals = 1;
    *return_vals  = values;
    values[0].type = GIMP_PDB_STATUS;
    values[0].data.d_status = status;
    
    run_mode = param[0].data.d_int32;
    image_id = param[1].data.d_image;
    drawable_id = param[2].data.d_drawable;
    vectors_id = gimp_image_get_active_vectors(image_id);
    
    
    switch (run_mode) {
        case GIMP_RUN_INTERACTIVE:
            /* Get options last values if needed */
            gimp_get_data(PLUG_IN_PROC, &tvals);
            /* Display the dialog */
            if (!taper_dialog(image_id))
                return;
            break;
        case GIMP_RUN_NONINTERACTIVE:
            if (nparams != 12)
                status = GIMP_PDB_CALLING_ERROR;
            if (status == GIMP_PDB_SUCCESS) {
                tvals.width_start = param[3].data.d_float;
                tvals.width_end   = param[4].data.d_float;
                tvals.exponent    = param[5].data.d_float;
                tvals.tolerance   = param[6].data.d_float;
                tvals.fill        = param[7].data.d_int32;
                tvals.cap         = param[8].data.d_int32;
                tvals.join        = param[9].data.d_int32;
                tvals.miter_limit = param[10].data.d_float;
                tvals.antialiased = param[11].data.d_int32;
            }
            break;
        case GIMP_RUN_WITH_LAST_VALS:
            /*  Get options last values if needed  */
            gimp_get_data(PLUG_IN_PROC, &tvals);
            break;
        default:
            break;
    }
    
    if (status == GIMP_PDB_SUCCESS) {
        /* Bundle the taper_path code inside an undo group */
        gimp_image_undo_group_start(image_id);
        stroke_path_with_taper(drawable_id, image_id, vectors_id);
        gimp_image_undo_group_end(image_id);
      
        /* Refresh and clean up */
        if (run_mode != GIMP_RUN_NONINTERACTIVE)
            gimp_displays_flush();

        /*  Finally, set options in the core  */
        if (run_mode == GIMP_RUN_INTERACTIVE)
              gimp_set_data(PLUG_IN_PROC, &tvals, sizeof(TaperVals));
    } else
        status = GIMP_PDB_EXECUTION_ERROR;
    
    values[0].data.d_status = status;
}
