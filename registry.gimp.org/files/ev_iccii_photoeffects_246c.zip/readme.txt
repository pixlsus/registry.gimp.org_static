This is a compilation some usefull scripts of Iccii and some other scripts I 've made myself, all brought together is one script-fu file.
In my own scripts I've made use of some my Gimpressionist presets.  They should also be installed.

Put the script in :

    * C:\Documents and Settings\yourname\.gimp-2.x\scripts   (Windows)
    * /home/yourname/.gimp-2.x/scripts    (Linux)

Put the Gimpressionist presets in :

    * C:\Documents and Settings\yourname\.gimp-2.x\gimpressionist\presets  (Windows)
    * /home/yourname/.gimp-2.x/gimpressionist/presets (Linux)


Find more information on 
http://users.telenet.be/ev1/gimpcursus/effecten/gimpphotoeffects_en.html


Enjoy

Eddy_verlinden at hotmail.com