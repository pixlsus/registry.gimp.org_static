#ifndef __LIGHTING_APPLY_H__
#define __LIGHTING_APPLY_H__

void init_compute  (void);
void compute_image (void);

#endif  /* __LIGHTING_APPLY_H__ */
