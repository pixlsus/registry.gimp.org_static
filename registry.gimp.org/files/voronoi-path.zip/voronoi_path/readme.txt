Voronoi Path GIMP plug-in (05/10/2009) v1.0
===========================================

Using the Path tool specify a collection of points from which this
plugin will generate a new Path in the form of a Voronoi diagram. 
You have the option of preserving the original points as explained 
below. This plugin uses the algorithm described by Stephen Fortune:

http://www.skynet.ie/~sos/mapviewer/docs/Voronoi_Diagram_Notes_1.pdf

How to install:
---------------

Linux: At the command-line use "gimptool-2.0 --install voronoi-path.c".
Windows: Move the included voronoi-path.exe file to your plugins folder.

How to use:
-----------

* Select Path tool, and add your anchor points. It is best to use 
  Shift-Click when adding points because then there are no distracting 
  lines connecting your points.
* In the Paths dialog, choose right-click menu option, Voronoi Path...
* In the Voronoi Path dialog window choose your settings and click OK.
* Voronoi diagram is generated as a new Path.

Voronoi Path dialog window settings:
------------------------------------

* Preserve original path [On/Off]: If On then the original points that
  you added will be preserved as a new Path. For your convenience, they 
  can be stroked, assuming you use the Round or Square Cap option. 
  This is done by converting each original point into two points, 
  separated by a tiny distance unnoticeable to the human eye. The GIMP 
  will not stroke a single point, but will stroke two seperate points.

Screenshot:
------------

http://www.ludicity.org/images/voronoi_demo.png

Author:
-------

Marko Peric (G00g1e em4i1 account name is cragwolf).
