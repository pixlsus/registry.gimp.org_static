/*  ShapeFS Horn Algorithm Class Source File.
	A GIMP Plug-in to render shape from shading.
	(c) 2003, Alfred P. Reaud
	Created: April 17, 2003
	Current: October 20, 2005
	Version: 1.2.0.0

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

	Reference works on Shape From Shading are available on the internet at:
		"308-558B: Fundamentals of Computer Vision Shape from Shading"
		by Mani Ghasemlou,
	http://www.cs.mcgill.ca/~mghase/shading/shading.html

		"Shape From Shading" by Mark J. Carlotto,
	http://www.newfrontiersinscience.com/martianenigmas/Articles/SFS/sfs.html

		"Photometric Stereo"
	http://kate.snu.ac.kr/research/a2.pdf

		"Shape From Shading" by Tai sing Lee,
	http://www-2.cs.cmu.edu/afs/andrew/scs/cs/15-385/www/handouts/lecture5_shading.pdf

	Search for "shape from shading" and "shape from shading powerpoint"
*/

#include "shapefs.h"
#include <algorithm>

HORN_ALGORITHM horn;			// Horm algorithm coding.

extern COMMON_ALGORITHM common;	// Common algorithms.
extern MATRIX matrix;
extern MESSAGES text;	// Declare text static so that all portions can use it.

// Global semaphore structures.
extern SFSControls SFSctrl;
extern SFSSemaphore SFSint;
extern SFSMemory SFSMem;
extern SFSValues SFSVal;

static gint check_events = CHECK_COUNT;
static Vertex			*vector_map;			// Pointer to vector map array.

// -----------------------------------------------------------------------------
HORN_ALGORITHM::HORN_ALGORITHM ()
/*
  Name: Horn Algorithm Class Constructor.
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 28/09/05 18:11
  Description:  Constructs the Horn Algorithm class.
*/
{
	// Dummy constructor for future need.
}

// -----------------------------------------------------------------------------
HORN_ALGORITHM::~HORN_ALGORITHM ()
/*
  Name: Horn Algorithm Class Destructor
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 28/09/05 18:21
  Description:  Dummy call to a class destructor.
*/
{   // Insure that memory is returned for the static array.
	if (vector_map_local) delete[] vector_map_local;
}

// -----------------------------------------------------------------------------
gint HORN_ALGORITHM::SFS_Horn (GimpDrawable *drawable)
/*
  Name: Shape From Shading Horn Algorithm Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 28/09/05 18:15
  Description:  This is the main module for performing the simplified Horn
				shape from shading algorithm.  See:
	"Shape From Shading" by Dr. Mark J. Carlotto,
	http://www.newfrontiersinscience.com/martianenigmas/Articles/SFS/sfs.html
*/
{
#ifdef DEBUG_AP
#define DEBUG_AP_REFLECTANCE
#define DEBUG_AP_ELEVATION
// Debug variables.
 #ifdef DEBUG_AP_REFLECTANCE
	gdouble *debug_print_object_ref = NULL;
	SFSRef_XY	*r_ptr = NULL;
 #endif
 #ifdef DEBUG_AP_ELEVATION
	gdouble *debug_print_object_elev = NULL;
	SFSElev_XY 	*e_ptr = NULL;
 #endif
#endif


	// Formula selection.
	static gboolean formula = false;
	gboolean		recompute = false;
	// Loop variables.
	gint	i = 0, x = 0, y = 0, y_max = 0;
	const gint	d_height = drawable->height;
	const gint	d_width = drawable->width;
	const gint	d_wth = d_width * d_height;
	guchar	*src = NULL;
	guchar	*guc_ptr = NULL;
	gpointer		pr = NULL;
	GimpPixelRgn	source;

	/* Angle conversions.  Azimuth is negative because of the way we want the
							rotation to occur.  We want to place the image x-axis
							on the sun vector x-z plane, which means we always
							rotate towards image x-axis.
	*/
	const gdouble	azimuth = gimp_deg_to_rad ( -SFSVal.Sun_Azimuth );
	const gdouble	s = gimp_deg_to_rad (SFSVal.Phase_Angle);

	// Mathematical constants.
	const gdouble cos_s = cos(s);
	const gdouble sin_s = sin(s);
	const gdouble sin_a = sin(azimuth);

	// Average image brightness definitions.
	const gint	wth = d_width * d_height;
	gdouble		a = 0.0;  // Estimated scale factor in i(x,y) ~ a [sin(s) p(x,y) + cos(s)]
	gdouble		ei = 0.0; // Average image brightness.
//	GimpDrawable	*rotated = NULL;

	// Reflectance map definitions.
	gint		offset = 0, tile_x, tile_y = 0, y_locator = 0;
	gint		xcoord = 0, ycoord = 0;
	gint		xcoord_ref = 0, ycoord_ref = 0;
	SFSElev_XY  *emp_0 = NULL, *emp_m1 = NULL, *emp_p1 = NULL;
	SFSRef_XY	*ref_map_ptr = NULL;
	SFSRef_XY	*ref_map_row_start = NULL;
	
	// Tile mapping definitions.
	gint		alpha_offset = 0, mult = 0;
	gint		d_tile_map_count = 0, drawable_type = 0;
	SFSRef_Tiled		*tiled_ref_map_ptr = NULL;

	// Elevation and vector map definitions.
	static gint	nd_width = 0;
	static gint	nd_height = 0;
	gint		nd_width_m1 = 0;
	gint		nd_wth = 0, nd_offset = 0, nd_axis_offset = 0;
	gint		offset_y = 0, offset_x = 0;
	gint		x_axis_row = 0, y_axis_col = 0;
	gint		x_label_addr = 0, y_label_col = 0, y_label_row = 0;
	gint		row_point_counter = 0;
	gint		row_point_count_max = 0;
	gdouble		a_cos_s = 0.0, a_sin_s = 0.0, row_avg = 0.0;
	gdouble		row_temp_elev = 0.0;
	gdouble		min_elevation = 0.0;
	gdouble		max_elevation = 0.0;
	gdouble		surface_angle = 0.0;
	gdouble		temp_y = 0.0;
	gdouble	 	y_axis_rotation = 0.0;
	SFSElev_XY	*elev_map_ptr = NULL;
	SFSElev_XY	*elev_row_start_ptr = NULL;
	SFSElev_XY	*row_ptr = NULL;
	SFSElev_XY	*pre_pointer = NULL;
	Vertex		*vect_map_ptr = NULL;
	
	// Height map save definitions.
	gboolean   	hm_line_write = false;
	gdouble 	cos_sa = 0.0, sin_sa = 0.0;
	gdouble		*hm_save_array = NULL;
	gdouble		*hms_array_ptr = NULL;

	// Axis drawing definitions.
	gint	target_x_start_index = 0;
	gint	target_x_end_index = 0;
	gint	target_y_start_index = 0;
	gint	target_y_end_index = 0;
	gdouble target_x_start_height = 0.0;
	gdouble target_x_end_height = 0.0;
	gdouble target_y_start_height = 0.0;
	gdouble target_y_end_height = 0.0;

	if (!SFSint.movie)
	{   // Indicate correct status if not in movie mode.
		common.update_status("Starting Horn algorithm...");
		if (SFSint.cancel) return false;
	}
	// Check for pending events. Don't move these around, they
	// generate errors.
	while (gtk_events_pending()) gtk_main_iteration();
	// Insure that processing occurs correctly if we change the state of the
	// auto-correct toggle button.
	if ( !SFSint.app_button[AUTO_CORRECT] && SFSint.already_corrected )
	{   // Recompute if state of auto-correct button changes.
		SFSint.elev_done = false;
		SFSint.already_corrected = false;
	}
	if (SFSint.app_button[FORMULA] != formula)
	{   // Recompute due to formula selection change.
		formula = SFSint.app_button[FORMULA];
		recompute = true;
	}
	
/* Branch past everything until after elevation as it's already been computed.
   This should save about 1/3 of the processing time between user inputs.
   Make exceptions when the user has selected the write height map option or
   when the state of the auto-correct button changes.
							*/
if ( recompute || !SFSint.elev_done ||
	(SFSint.app_button[WRITE_MAP] && !SFSint.height_map_saved) ||
	(!SFSint.already_corrected && SFSint.app_button[AUTO_CORRECT]) )
{
	if (vector_map_local)
	{	// Release main memory array if declared.
		delete[] vector_map_local;
		vector_map_local = NULL;
	}
	// Check that parameters are valid.
	if ( !common.check_parameters() ) return false;
	
/* ---------------- Compute average image brightness a. (HORN)------------------
		We could also use the gimp_histogram function, but maybe I'm faster?
	*/
	gimp_pixel_rgn_init ( &source, drawable,
						0, 0, d_width, d_height, false, false );
	// Loop through the tiles.
	for (pr = gimp_pixel_rgns_register (1, &source);
			pr != NULL; pr = gimp_pixel_rgns_process (pr))
	{
		src = source.data;
		y_max = source.h * source.w;
		for (y = 0; y != y_max; y += source.w)
		{	// Loop through the rows.
			for (x = 0; x != (int)source.w; x++)
			{	// Loop through the columns.
				// Add the pixel brightness to the sum.
				ei += (double)*(src + x + y);
				if (check_events-- == 0)
				{   // Check for events only on countdown.
					while (gtk_events_pending()) gtk_main_iteration();
					check_events = CHECK_COUNT;
				}
			}
		}
	}
	ei = ei / (double)wth; // Compute average.
#ifdef NEW_ALGO
	a = ei / (cos_s * sin_a);
#else
	a = ei / cos_s;
#endif
	common.update_progress(" Avg. brightness done. Tileing reflectance map...");
	if (SFSint.cancel) return false;

// ---------------- Compute tile'd reflectance map, i(x,y). (HORN)--------------  
	d_tile_map_count = drawable->ntile_rows * drawable->ntile_cols;
	if ( (common.d_tile_map = new SFSTileSize [d_tile_map_count]) != NULL )
		SFSMem.d_tile_map = true;
	else
	{   // Flag user on critical error and leave.
		text.new_error ("UNABLE TO CREATE drawable IMAGE TILE MAP:\n", d_tile_map_count);
		common.error_status (SFS_MEMERROR);
		return false;
	}
	// Next generate the drawable tile map.
	common.sfs_tile_map (common.d_tile_map, drawable);

	if ( (common.tiled_ref_map = new SFSRef_Tiled [d_wth]) != NULL )
	{	// Create array to save information in.
		SFSMem.tiled_ref_map = true;
	}
	else
	{   // Flag user on critical error and leave.
		text.new_error ("UNABLE TO CREATE TILE'D REFLECTANCE MAP:\n", d_wth);
		common.error_status (SFS_MEMERROR);
		return false;
	}

	// Initialize variables that track progress.
	tiled_ref_map_ptr = common.tiled_ref_map;
	tile_x = tile_y = 0;
	drawable_type = gimp_drawable_type (drawable->drawable_id);
	if ( (drawable_type != GIMP_GRAY_IMAGE) && (drawable_type != GIMP_GRAYA_IMAGE) )
	{
		gimp_message ("INCOMPATIBLE drawable IMAGE TYPE IN \nREFLECTANCE MAP INITILIZATION");
		common.error_status (SFS_IMGERROR);
		return false;
	}
	if ( drawable->bpp > 1)
	{
		mult = 2;
		alpha_offset = 1;
	}
	else
	{
		mult = 1;
		alpha_offset = 0;
	}

	// Loop throught the tiles.
	gimp_pixel_rgn_init ( &source, drawable,
						0, 0, d_width, d_height, false, false );
	for (pr = gimp_pixel_rgns_register (1, &source);
			pr != NULL; pr = gimp_pixel_rgns_process (pr))
	{
		if (tile_x >= (int)drawable->ntile_cols)
		{
			tile_x = 0;
			tile_y++;
		}
		// Compute reference offsets.
		xcoord_ref = ycoord_ref = 0;
		for (y = 0; y < tile_y; y++)
		{
			ycoord_ref += common.d_tile_map[tile_x + y * drawable->ntile_cols].h;
		}
		for (x = 0; x < tile_x; x++)
		{
			xcoord_ref += common.d_tile_map[x + tile_y * drawable->ntile_cols].w;
		}
		// Initialize variables.
		src = source.data;
		y_max = source.h * source.w;
		ycoord = ycoord_ref;
		xcoord = xcoord_ref;
		for (y = 0; y != y_max; y += source.w)
		{	// Loop through the rows.
			y_locator = y / source.w;
			for (x = 0; x != (int)source.w; x++)
			{	// Loop through the columns.
				offset = (x + y) * mult;
				guc_ptr = src + offset;
				// Correct for alpha channel if it occurs.
				if ( (*(guc_ptr + alpha_offset) == '\0') && (alpha_offset != 0) )
				{   // Don't use a point that has a 0 value for the alpha channel.
					tiled_ref_map_ptr->value = 0;
					tiled_ref_map_ptr->ref = 0.0;
					tiled_ref_map_ptr->dont_process = true;
				}
				else
				{   // Use the point otherwise.
					tiled_ref_map_ptr->value = *guc_ptr;
					// Compute the reflectance value using the formula in
					// www.newfrontiersinscience.com/martianenigmas/Articles/SFS/sfs.html
					tiled_ref_map_ptr->ref = a * (sin_s * sin_a *
						(double)tiled_ref_map_ptr->value / 255.0 + cos_s * sin_a);
					tiled_ref_map_ptr->dont_process = false;
				}
				tiled_ref_map_ptr->image_data.x = xcoord++;
				tiled_ref_map_ptr->image_data.y = ycoord;
#ifdef DEBUG
				tiled_ref_map_ptr->tile_data.x = x;
				tiled_ref_map_ptr->tile_data.y = y_locator;
				tiled_ref_map_ptr->tile_data.tile_x = tile_x;
				tiled_ref_map_ptr->tile_data.tile_y = tile_y;
#endif
				tiled_ref_map_ptr++;
				if (check_events-- == 0)
				{   // Check for events only on countdown.
					while (gtk_events_pending()) gtk_main_iteration();
					check_events = CHECK_COUNT;
				}
			}
			xcoord = xcoord_ref;
			ycoord++;
		}
		tile_x++;
	}
	common.update_progress(" Tiled reflectance map done. Clearing X-Y map array...");
	if ( SFSMem.d_tile_map )
	{	// Free drawable tile map.
		delete[] common.d_tile_map;
		common.d_tile_map = NULL;
		SFSMem.d_tile_map = false;
	}
	if (SFSint.cancel) return false;

/* --- Remap reflectance map to X-Y form from Tile array form. (HORN)-----------
	   Verified with Excel on a 200x200 image. 10/13/2005, apr.
*/
	// Account for axis display.
	if (SFSint.app_button[DRAW_AXES])
	{   // Axis display
		nd_axis_offset = 16;
		nd_width = d_width + nd_axis_offset;
		nd_height = d_height + nd_axis_offset;
		nd_wth = nd_width * nd_height;
		nd_offset = 8;
	}
	else
	{   // No axis display.
		nd_axis_offset = 0;
		nd_width = d_width;
		nd_height = d_height;
		nd_wth = nd_width * nd_height;
		nd_offset = 0;
	}
	if ( (common.ref_map = new SFSRef_XY [nd_wth]) != NULL )
	{
		SFSMem.ref_map = true;
	}
	else
	{   // Error out at a critical point.
		text.new_error ("UNABLE TO CREATE X-Y REFLECTANCE MAP:\n", nd_wth);
		common.error_status (SFS_MEMERROR);
		return false;
	}
	
	ref_map_ptr = common.ref_map;
	for (i = 0; i != nd_wth; i++)
	{   // Clear out array!
		ref_map_ptr->dont_process = true;
		ref_map_ptr->ref = 0.0;
		ref_map_ptr->value = 0;
#ifdef DEBUG
		ref_map_ptr->image_data.x = 0;
		ref_map_ptr->image_data.y = 0;
		ref_map_ptr->image_data.iter = 0;
		ref_map_ptr->tile_data.x = 0;
		ref_map_ptr->tile_data.y = 0;
		ref_map_ptr->tile_data.tile_x = 0;
		ref_map_ptr->tile_data.tile_y = 0;
#endif
		ref_map_ptr++;
	}
	
	common.update_progress(" X-Y map array clear done. Maping to x-y array...");
	if (SFSint.cancel) return false;

	tiled_ref_map_ptr = common.tiled_ref_map;
	for (i = 0; i != d_wth; i++)
	{	// Loop through the whole array and remap.
		x = tiled_ref_map_ptr->image_data.x + nd_offset;
		y = (tiled_ref_map_ptr->image_data.y + nd_offset) * nd_width;// + nd_offset;
		offset = x + y;
		common.ref_map[offset].dont_process = false;
		common.ref_map[offset].value = tiled_ref_map_ptr->value;
		common.ref_map[offset].ref = tiled_ref_map_ptr->ref;
#ifdef DEBUG 
		common.ref_map[offset].image_data = tiled_ref_map_ptr->image_data;
		common.ref_map[offset].tile_data = tiled_ref_map_ptr->tile_data;
#endif
		tiled_ref_map_ptr++;
		if (check_events-- == 0)
		{   // Check for events only on countdown.
			while (gtk_events_pending()) gtk_main_iteration();
			check_events = CHECK_COUNT;
		}
	}

	common.update_progress(" X-Y array mapping done. Height map starting...");
	if ( SFSMem.tiled_ref_map )
	{	// Free tiled reflectance map.
		delete[] common.tiled_ref_map;
		common.tiled_ref_map = NULL;
		SFSMem.tiled_ref_map = false;
	}
	if (SFSint.cancel) return false;
#ifdef DEBUG_AP_REFLECTANCE
			debug_print_object_ref = new gdouble[nd_wth];
			r_ptr = common.ref_map;
			for (i = 0; i != nd_wth; i++)
			{
				debug_print_object_ref[i] = r_ptr->ref;
				r_ptr++;
			}
			text.debug_array_print(debug_print_object_ref, nd_width, nd_wth,
							"reflection x-y map", "d:\\ref_xy_map.txt");
			delete[] debug_print_object_ref;
#endif

// ---------------- Compute height map, z(x,y). (HORN)--------------------------
	// Create array to save information in.
	if ( (elevation_map = new SFSElev_XY [nd_wth]) != NULL )
	{   // Allocation ok!
		SFSMem.elevation_map = true;
	}
	else
	{   // Error out at a critical juncture.
		text.new_error ("UNABLE TO CREATE ELEVATION MAP:\n", d_wth);
		common.error_status (SFS_MEMERROR);
		return false;
	}
	// Initialize variables that point.
	elev_map_ptr = elevation_map;
	ref_map_ptr = common.ref_map;
	// Take the constants out of the loops.
	a_sin_s = a * sin_s * sin_a;
	a_cos_s = a * cos_s * sin_a;
	// Loop for the image rows.
	for (y = 0; y != nd_height; y++)
	{	// Loop through the image columns.
		elev_row_start_ptr = elev_map_ptr;
		ref_map_row_start = ref_map_ptr;
		row_point_counter = 0;
		for (x = 0; x != nd_width; x++)
		{   // Process the rows.  Continue if not an actal pixel point.
			if (ref_map_ptr->dont_process)
			{   // Insure that everything is correct.
				elev_map_ptr->dont_process = true;
				elev_map_ptr->value = ref_map_ptr->value;
				elev_map_ptr->elev = 0.0;
				elev_map_ptr++;
				ref_map_ptr++;
				continue;
			}
			elev_map_ptr->dont_process = false;
			// Insure that we don't go past the edge boundary.
			if (x != 0)
			{   // Not the leftmost column.
				pre_pointer = elev_map_ptr - 1;
				if (SFSint.formula)
				{
					elev_map_ptr->elev = pre_pointer->elev
									+ (ref_map_ptr->ref - a_cos_s ) / a * sin_s * sin_a;
				}
				else
				{
					elev_map_ptr->elev = pre_pointer->elev
									+ (ref_map_ptr->ref - a_cos_s ) / a_sin_s;
				}
			}
			else
			{	// This is the leftmost column in the image.
				if (SFSint.formula)
				{
					elev_map_ptr->elev = (ref_map_ptr->ref - a_cos_s ) / a
															* sin_s * sin_a;
				}
				else
				{
					elev_map_ptr->elev = (ref_map_ptr->ref - a_cos_s ) / a_sin_s;
				}
			}
			elev_map_ptr->value = ref_map_ptr->value;
#ifdef DEBUG
			elev_map_ptr->ref = ref_map_ptr->ref;
			elev_map_ptr->image_data = ref_map_ptr->image_data;
			elev_map_ptr->tile_data = ref_map_ptr->tile_data;
#endif
			elev_map_ptr++;
			ref_map_ptr++;
			row_point_counter++;
			if (check_events-- == 0)
			{   // Check for events only on countdown.
				while (gtk_events_pending()) gtk_main_iteration();
				check_events = CHECK_COUNT;
			}
		}
		// Compute elevation row average.
		if (row_point_counter != 0)
		{   // Process only if we have an actual row point count otherwise
			// division by 0 occurs.
			if (row_point_counter > row_point_count_max)
								row_point_count_max = row_point_counter;
			row_avg = 0.0;
			row_ptr = elev_row_start_ptr;
			row_point_counter = 0;
			for (i = 0; i != nd_width; i++)
			{   // Only average those elements that don't count.
				if (!row_ptr->dont_process)
				{  // Add element to row sum.
					row_avg += row_ptr->elev;
					row_point_counter++;
				}
				row_ptr++;
				if (check_events-- == 0)
				{   // Check for events only on countdown.
					while (gtk_events_pending()) gtk_main_iteration();
					check_events = CHECK_COUNT;
				}
			}
			if (row_point_counter != 0) row_avg = row_avg / (double)row_point_counter;
			else row_avg = 0.0;
			// Subtract out the elevation row average.
			row_ptr = elev_row_start_ptr;
			for (i = 0; i != nd_width; i++)
			{   // Only subtract from actual row pixels.
				if (row_ptr->dont_process)
				{   // Correct the row pointer.
					row_ptr++;
					continue;
				}
				row_temp_elev = (row_ptr->elev -= row_avg);
				// Get the minimum and maximum row elevations.
				if ( row_temp_elev < min_elevation) min_elevation = row_temp_elev;
				else if ( row_temp_elev > max_elevation) max_elevation = row_temp_elev;
				row_ptr++;
				if (check_events-- == 0)
				{   // Check for events only on countdown.
					while (gtk_events_pending()) gtk_main_iteration();
					check_events = CHECK_COUNT;
				}
			}
		}
	}
	if ( SFSMem.ref_map )
	{	// Free reflectance map.
		delete[] common.ref_map;
		common.ref_map = NULL;
		SFSMem.ref_map = false;
	}

#ifdef DEBUG_AP_ELEVATION
	debug_print_object_elev = new gdouble[nd_wth];
	e_ptr = elevation_map;
	for (i = 0; i != nd_wth; i++)
	{
		debug_print_object_elev[i] = e_ptr->elev;
		e_ptr++;
	}
	text.debug_array_print(debug_print_object_elev, nd_width, nd_wth,
					"elevation map", "d:\\elevation_map.txt");
	delete[] debug_print_object_elev;
#endif

	// Now eliminate interior row 0 values by interpolation.
	elev_map_ptr = elevation_map;
	nd_width_m1 = nd_width - 1;
	for (y = 0; y != nd_height; y++)
	{   // Scan the rows.
		offset_y = y * nd_width;
		for (x = 1; x != nd_width_m1; x++)
		{   // Scan the columns from the second column to the next to last.
			offset = x + offset_y;
			emp_0 = &elev_map_ptr[offset];
			if ( FP_EQ(emp_0->elev, 0.0) )
			{   // Do on a value of zero
				emp_m1 = &elev_map_ptr[offset-1];
				emp_p1 = &elev_map_ptr[offset+1];
				if ( FP_NEQ(emp_m1->elev, 0.0) && FP_NEQ(emp_p1->elev, 0.0) )
				{   // Only interpolate if it's a 0 value surrounded by non-
					// zero values.
					emp_0->elev =
						(emp_m1->elev + emp_p1->elev) / 2.0;
				}
			}
			if (check_events-- == 0)
			{   // Check for events only on countdown.
				while (gtk_events_pending()) gtk_main_iteration();
				check_events = CHECK_COUNT;
			}
		}
	}

	// Compute the y-axis tilt just in case we will need it.
	while (gtk_events_pending()) gtk_main_iteration();
	surface_angle = atan( (max_elevation - min_elevation) / (gdouble)row_point_count_max );
	if ( SFSint.app_button[AUTO_CORRECT] )
	{   // Auto correct the viewer y-axis value to create a flat rendering, compensating
		// for the y-axis tilt.
		SFSint.already_corrected = true;
//		y_axis_rotation = 180.0 / PI * surface_angle;
		y_axis_rotation = gimp_rad_to_deg(surface_angle);
		if ( SFSint.movie )
		{
			if (SFSint.movie_axis != YAXIS)
			{
				SFSVal.Viewer_Yaxis = y_axis_rotation;
				gtk_adjustment_set_value ( GTK_ADJUSTMENT(SFSctrl.Viewer_Yaxis),
									SFSVal.Viewer_Yaxis);
			}
			else
			{
				SFSint.orig_axis_value.y = y_axis_rotation;
			}
		}
		else
		{
				SFSVal.Viewer_Yaxis = y_axis_rotation;
				gtk_adjustment_set_value ( GTK_ADJUSTMENT(SFSctrl.Viewer_Yaxis),
									SFSVal.Viewer_Yaxis);
		}
	}
	else SFSint.already_corrected = false;

	common.update_progress(" Height map done. Vectorizing...");
	if (SFSint.cancel) return false;

	/* Vectors are required to project the elevation map in a 3D
		viewer perspective.  The form of the vector is (x,y,z,w) where
		x, y, and z are the actual physical coordinates and w is an extra coordinate
		used to allow for homegeneous coordinates.
	*/
	if ( (vector_map_local = new Vertex [nd_wth]) == NULL )
	{   // Drop out on critical error.
		text.new_error ("UNABLE TO CREATE VECTOR MAP:\n", nd_wth);
		common.error_status (SFS_MEMERROR);
		return false;
	}
	vector_map = vector_map_local;
	// Initialize variables that point.
	elev_map_ptr = elevation_map;
	vect_map_ptr = vector_map;
	for (y = 0; y != nd_height; y++)
	{	// Do the conversion to a vector array.
		temp_y = (double)y;
		for (x = 0; x != nd_width; x++)
		{
			vect_map_ptr->dont_process = elev_map_ptr->dont_process;
			vect_map_ptr->is_axis = false;
			vect_map_ptr->value = elev_map_ptr->value;
			// Generate homogeneous coordinates.
			vect_map_ptr->Local.x = (double)x;
			vect_map_ptr->Local.y = temp_y;
			vect_map_ptr->Local.z = elev_map_ptr->elev;
			vect_map_ptr->Local.w = 1.0;
			// Increment the pointers.
			elev_map_ptr++;
			vect_map_ptr++;
			if (check_events-- == 0)
			{   // Check for events only on countdown.
				while (gtk_events_pending()) gtk_main_iteration();
				check_events = CHECK_COUNT;
			}
		}
	}
	
	if (SFSMem.elevation_map)
	{	// Free elevation map.
		delete[] elevation_map;
		elevation_map = NULL;
		SFSMem.elevation_map = false;
	}

	common.update_progress(" Vector map done.");
	if (SFSint.cancel) return false;

	if ( SFSint.app_button[WRITE_MAP] )
	{	// Open stream for outtputing values.
		std::ofstream heightmap(SFSint.heightmap_filename);
		if (!heightmap)
		{	// An error occurred, message user!
			char *message_text = "Unable to open file ";
			strcat (message_text, SFSint.heightmap_filename);
			strcat (message_text, " for writing!");
			text.dialog_message(message_text, GTK_MESSAGE_WARNING);
		}
		else
		{   // Write the height map.
			char *message_text;
			message_text = new char[512];
			strcpy (message_text, "Writing height map to ");
			strcat (message_text, SFSint.heightmap_filename);
			common.update_status(message_text);
			while ( gtk_events_pending() ) gtk_main_iteration();
			delete[] message_text;
			// Create a properly oriented height map.
			if ( (hm_save_array = new gdouble[nd_wth]) == NULL )
			{   // Drop out on critical error.
				text.new_error ("UNABLE TO CREATE HEIGHT MAP SAVE ARRAY:\n", nd_wth);
				common.error_status (SFS_MEMERROR);
				return false;
			}
			hms_array_ptr = hm_save_array;
			for (i = 0; i != nd_wth; i++)
			{   // Clear the array!
				*hms_array_ptr = 0.0;
				hms_array_ptr++;
			}
			// Do the transformation.
			hms_array_ptr = hm_save_array;
			vect_map_ptr = vector_map;
			cos_sa = cos(surface_angle);
			sin_sa = sin(surface_angle);
			for (i = 0; i != nd_wth; i++)
			{	// Loop through the vector map.
				if (!vect_map_ptr->dont_process)
				{
/*  From Transformations in 3D by Thomas M�lhave. See:
	http://home10.inet.tele.dk/moelhave/tutors/3d/transformations/transformations.html
	This is not an affine transformation and just maps the z-axis values to
	flatten them to a common reference that account for the x-axis tilt.
*/					*hms_array_ptr = -(vect_map_ptr->Local.z * cos_sa
							- vect_map_ptr->Local.x * sin_sa)
							* SFSVal.Pixel_Width;
				}
				hms_array_ptr++;
				vect_map_ptr++;
				if (check_events-- == 0)
				{   // Check for events only on countdown.
					while (gtk_events_pending()) gtk_main_iteration();
					check_events = CHECK_COUNT;
				}
			}
			// Print it out!
			hms_array_ptr = hm_save_array;
			vect_map_ptr = vector_map;
			i = 0;
			for (y = 0; y != nd_height; y++)
			{	// Loop through the image rows.
				if ( SFSint.app_button[HM_TYPE] )
				{   // Excel type map.
					hm_line_write = false;
					for (x = 0; x != nd_width; x++)
					{   // Loop through the image columns.
						if (!vect_map_ptr->dont_process)
						{   // Only output if a processable element.
							heightmap << *hms_array_ptr << ",";
							hm_line_write = true;
						}
						hms_array_ptr++;
						vect_map_ptr++;
						if (check_events-- == 0)
						{   // Check for events only on countdown.
							while (gtk_events_pending()) gtk_main_iteration();
							check_events = CHECK_COUNT;
						}
					}
					if (hm_line_write) heightmap << std::endl;
				}
				else
				{   // Sequential text style map.
					for (x = 0; x != nd_width; x++)
					{   // Loop trough the columns.
						if (!vect_map_ptr->dont_process)
						{   // Only output if a processable element.
							heightmap << x << "," << i << ","
								<< *hms_array_ptr << std::endl;
						}
						hms_array_ptr++;
						vect_map_ptr++;
						if (check_events-- == 0)
						{   // Check for events only on countdown.
							while (gtk_events_pending()) gtk_main_iteration();
							check_events = CHECK_COUNT;
						}
					}
					i++;
				}
				if (check_events-- == 0)
				{   // Check for events only on countdown.
					while (gtk_events_pending()) gtk_main_iteration();
					check_events = CHECK_COUNT;
				}
			}
			// Finish up and exit cleanly.
			heightmap.flush();
			heightmap.close();
			SFSint.height_map_saved = true;
			delete[] hm_save_array;
			common.update_status("Height map save done!");
			while ( gtk_events_pending() ) gtk_main_iteration();
			if (SFSint.cancel) return false;
		}
	}
	
	// Create coordinate axes on vector map.
	if (SFSint.app_button[DRAW_AXES])
	{  // Compte memory offsets.
		y_axis_col = nd_width / 2;
		x_axis_row = (nd_height / 2) * nd_width;// + 3;
		// Y-axis drawing computations.
		for (i = 0; i != nd_height; i++)
		{	// Scan the row fowards for the first non-zero height.
			offset = y_axis_col + i * nd_width;
			if ( vector_map[offset].dont_process ) continue;
			target_y_start_height = vector_map[offset].Local.z;
			target_y_start_index = i;
			break;
		}
		for (i = nd_height - 1; i != target_y_start_index; i--)
		{	// Scan the row backwards for the first non-zero height.
			offset = y_axis_col + i * nd_width;
			if ( vector_map[offset].dont_process ) continue;
			target_y_end_height = vector_map[offset].Local.z;
			target_y_end_index = i;
			break;
		}
		for (i = 0; i != nd_height; i++)
		{	// Draw the y-axis via bit mapping.
			offset = y_axis_col + i * nd_width;
			if (i < target_y_start_index) vector_map[offset].Local.z
														= target_y_start_height;
			else if (i > target_y_end_index) vector_map[offset].Local.z
																	= target_y_end_height;
			vector_map[offset].value = AXIS;
			vector_map[offset].is_axis = true;
			vector_map[offset].dont_process = false;
		}
		// X-axis drawing computations.
		for (i = 0; i != nd_width; i++)
		{	// Scan the column fowards for the first non-zero height.
			offset = x_axis_row + i;
			if ( vector_map[offset].dont_process ) continue;
			target_x_start_height = vector_map[offset].Local.z;
			target_x_start_index = i;
			break;
		}
		for (i = nd_width_m1; i != target_x_start_index; i--)
		{	// Scan the column fowards for the first non-zero height.
			offset = x_axis_row + i;
			if ( vector_map[offset].dont_process ) continue;
			target_x_end_height = vector_map[offset].Local.z;
			target_x_end_index = i;
			break;
		}
		for (i = 0; i != nd_width; i++)
		{	// Draw the x-axis via bit mapping.
			offset = x_axis_row + i;
			if (i < target_x_start_index) vector_map[offset].Local.z
														= target_x_start_height;
			else if (i > target_x_end_index) vector_map[offset].Local.z
																	= target_x_end_height;
			vector_map[offset].value = AXIS;
			vector_map[offset].is_axis = true;
			vector_map[offset].dont_process = false;
		}

/* TODO (20051017#1#): Debug errors due to changes done on 10/17 to
					   algorithm. */
		// Draw x-axis indicator via bit mapping.
		x_label_addr = x_axis_row
						- (BITMAP_SIZE + 3) * nd_width - (2 * BITMAP_SIZE);
		for (y = 0; y != BITMAP_SIZE; y++)
		{   // Do the indicator rows.
			for (x = 0; x != BITMAP_SIZE; x++)
			{   // Do the indicator columns.
				if (bitmap_x[y][x] != '\0')
				{  // Plot only if necessary.
					offset = x_label_addr + x + 11;
					vector_map[offset].Local.z = target_x_end_height;
					vector_map[offset].value = bitmap_x[y][x];
					vector_map[offset].is_axis = true;
					vector_map[offset].dont_process = false;
				}
			}
			x_label_addr += nd_width;
		}

		// Draw y-axis indicator via bit mapping.
		y_label_row = nd_width;
		y_label_col = y_axis_col - (BITMAP_SIZE + 5);
		for (y = 0; y != BITMAP_SIZE; y++)
		{   // Do the indicator rows.
			offset = y_label_row + y_label_col;
			for (x = 0; x != BITMAP_SIZE; x++)
			{   // Do the indicator column.
				if (bitmap_y[y][x] != '\0')
				{  // Only plot if necessary.
					offset_x = offset + x;
					vector_map[offset_x].Local.z = target_y_start_height;
					vector_map[offset_x].value = bitmap_y[y][x];
					vector_map[offset_x].is_axis = true;
					vector_map[offset_x].dont_process = false;
				}
			}
			y_label_row += nd_width;
		}
	}
#ifdef DEBUG
	// Free drawable image display.
	if (SFSMem.debug_display_id != -1 ) {
		gimp_display_delete (SFSMem.debug_display_id);
		SFSMem.debug_display_id = -1;
	}
#endif
	SFSint.elev_done = true;	// Flag that we have elevation.
}
else
{
	// Update the process count to the correct point.
	if (!SFSint.movie) SFSint.progress_value = HORN_ELEV_DONE_PROCESS_COUNT
						/ (HORN_PROCESS_COUNT - 1.0);
}	
	common.update_progress(" Horn - Done! World coordinates...");
	if (SFSint.cancel) return false;

	// --------- Generate 3D drawing from d_height map. ------------------------
	// Process any pending events to keep the UI clean!
	if (!SFSint.movie) common.update_status("Computing 3D rendering!");
	if (SFSint.cancel) return false;

	// Check for pending events. Don't move these around, they
	// generate errors.
	while (gtk_events_pending()) gtk_main_iteration();

	if ( !common.render_3D (&SS, vector_map, nd_width, nd_height) ) return false;
	
	// ---------------- Finish up and leave. -----------------------------------
	if (!SFSint.movie) common.update_status("Horn algorithm done!");
	if (SFSint.cancel) return false;
	return true;
}
