/*  ShapeFS Header File.
	A GIMP Plug-in to render shape from shading.
	(c) 2003, Alfred P. Reaud
	Created: April 17, 2003
	Current: October 20, 2005
	Version: 1.2.0.0

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
 
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

	Compiler Notes for GIMP 2.2.8:

	The full GIMP application install is available at:
		http://gimp-win.sourceforge.net/stable.html
	Remember to also download and install the compatible version of GTK+
	first.
	
	GTK+ and other developer files are available at:
		http://www.gimp.org/~tml/gimp/win32/downloads.html

	See the included ShapeFS_Dev.bat for an example of the proper installation
	paths and what needs to be moved. The developer packages necessary are
	(for Windows):
	atk-dev-1.9.0.zip   ftp://ftp.gtk.org/pub/gtk/v2.6/win32/atk-dev-1.9.0.zip
	glib-dev-2.6.6.zip  ftp://ftp.gtk.org/pub/gtk/v2.6/win32/glib-dev-2.6.6.zip
	gimp-dev-2.2.7.zip  http://www.gimp.org/win32/gimp-dev-2.2.7.zip
	gtk+-dev-2.6.9.zip  ftp://ftp.gtk.org/pub/gtk/v2.6/win32/gtk+-dev-2.6.9.zip
	pango-dev-1.8.2.zip ftp://ftp.gtk.org/pub/gtk/v2.6/win32/pango-dev-1.8.2.zip

	d:\Dev-Cpp in the following may be replaced by the proper paths in your system
	configuration.  The important thing to remember is that relative paths is
	what counts, such as the lib paths from the root of the Dev-C++
	installation.

	Necessary header file folder locations are (Add to Project Options ->
	Directories -> Include Directories):
		d:\Dev-Cpp\lib\glib-2.0\include"
		d:\Dev-Cpp\lib\gtk-2.0\include"

	The pertinent libraries are (Add to Project Options -> Parameters ->
	Linker):
		-lgimp-2.0
		-lgtk-win32-2.0
		-lgobject-2.0
		-lgdk-win32-2.0
		-lgimpwidgets-2.0
		-lgimpui-2.0
		-lglib-2.0
		-lgcov (for coverage checking only.)

		Please be aware of differences in duplicate libraries.  Any unresolved
		references are probably caused by using the incorrect library set.
		
	The following compiler parameters (in Project Options -> Parameters ->
	C++ Compiler) are for profile and coverage checking only:
		-ggdb
		-pg
		-fprofile-arcs
		-ftest-coverage

	Site for Windows GIMP itself:
	http://www2.arnes.si/~sopjsimo/gimp/

	Site for GIMP Developement packages:
	http://www.gimp.org/~tml/gimp/win32/downloads.html

	Tutorial site for GIMP plugins:
	http://gimp-plug-ins.sourceforge.net/doc/Writing/html/chapt-intro.html

	Sample plugin:
	http://www.home.unix-ag.org/simon/gimp/guadec2002/gimp-plugin/html/sample_plugin.html

	Run gdb or insight from D:\GIMP-2.0\lib\gimp\2.0\plug-ins
	Debug command from the command line is(DOS):
		gdb --command=d:\shapefs\gdb_cmd.txt shapefs.exe
		insight --command=d:\shapefs\gdb_cmd.txt shapefs.exe
	Under an rxvt terminal (MSYS) the debug command is:
		gdb --command=/d/shapefs/gdb_cmd.txt shapefs.exe
		insight --command=/d/shapefs/gdb_cmd.txt shapefs.exe &

*/

/* DONE (20051012#3#): Figure out what's causing the little flying blip in y-axis
						movies.  It appears to be related to the axes maybe?
						Goes clockwise as the terrain goes counterclockwise!
	Results:  Isolated the problem to gimp_image_merge_down and that's as far
	as it went.  Tried different merge types to no avail, so we're stuck with
	layer by layer editing of the movie to remove these pixel blips.
*/
/* TODO (20051014#5#): Clean up prior to re-release. */
/* TODO (20051016#5#): Perform max memory size and speed analysis on different files
			from 100x100 to 1500x1500 in 100 pixel intervals. */

// Uncomment following line to allow debugging entry point in GDB.
//#define DEBUG
// Uncomment following line to allow for printing of arrays in when in debug
// mode.
//#define DEBUG_AP
// Uncomment following line to allow for memory leak checking using LeakTracer.
//#define MEM_LEAK_CHECK
// Disable assert testing and GTK/GLIB parameter checking if not in debug mode.
#ifndef DEBUG
#define G_DISABLE_CHECKS
#endif

#ifndef MEM_LEAK_CHECK
using namespace std;
#endif

// Comment the following line for Linux/Unix or other OS.
#define G_OS_WIN32

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#ifndef MEM_LEAK_CHECK
#include <new>
#endif
#include <fstream>

#include <gtk/gtk.h>
#include <glib.h>

#include <libgimp/gimp.h>
#include <libgimp/gimpui.h>
#include <libgimpmath/gimpmatrix.h>

#ifdef G_OS_WIN32
#include <windows.h>	/* For Call to SetTimer, which is outside of GIMP & GTK!
								This should be modified to something using cron or at
								in Unix/Linux target systems.
						*/
#endif

// Local definitions. ----------------------------------------------------------
// Buffers
#define FILENAME_BUFF_SIZE	267		// Filename buffer size.
#define MSG_BUFF_SIZE		1024	// Message buffer size.
#define NUMB_BUFF_SIZE		26		// Number conversion buffer size.
// Button control
#define ALGO_BUTTONS		3		// Number of buttons in each class.
#define APP_BUTTONS			9
#define MOVIE_BUTTONS		3
// File control.
#define INIT_FILENAME		"shapefs.ini"
// Floating point operations.
#define EPSILON 1.0E-009	// Number limit for floating point equality comparisons
							// which may be lowered for better accuracy.
#define KRONECKER_LIMIT		1.0E-010
#define SMALL_NUMB			0.0005
#define FP_EQ(a,b) (((b - EPSILON) < a) && (a < ( b + EPSILON)))
#define FP_NEQ(a,b) !( FP_EQ(a,b) )
// Image generation.
#define AXIS				255
#define BITMAP_SIZE			15
#define CHECK_COUNT		 	32
#define SCALE_WIDTH			128
// Progress bar parameters.
#define HORN_PROCESS_COUNT	15.0
#define HORN_ELEV_DONE_PROCESS_COUNT	5.0
#define HORN_MOVIE_PROCESS_COUNT 7.0
#define MOVIE_PROCESS_COUNT 8.0
#define PULSE_BAR_TIMEOUT	100

// ENUMERATES:------------------------------------------------------------------
typedef enum {	// Algorithm selection enumeration.
	HORN,	   // Horn algorithm method.
	GHASEMLOU,  // Ghasemlou algorithm method, not implemented yet.
	LEE		 // Lee algorithm method, not implemented yet.
} SFSAlgorithms;	

typedef enum {	// Dialog control buttons.
	CANCEL_BUTTON,
	START_BUTTON,
	DONE_BUTTON
} SFSDialog_Buttons;			


typedef enum {	// Application button enumeration.
	DELETE_IMAGES,	// Delete prior rendered images.
	IGNORE_MATRIX,	// Ignore matrix warnings.
	IGNORE_MEMORY,	// Ignore memory warnings.
	DRAW_AXES,		// Draw x & y axis.
	GEN_MOVIE,		// Generate a movie.
	WRITE_MAP,		// Write a height map file.
	HM_TYPE,		// Height map type, either sequential or array.
	AUTO_CORRECT,	// Auto correct x-axis tilt towards light source.
	FORMULA			// Alternate formulas switch.
} SFSApplication;	

typedef enum {	// Movie control buttons.
	ZAXIS,	// Z-Axis roll movie.
	YAXIS,	// Y-Axis roll movie.
	XAXIS,	// Z-Axis roll movie.
} SFSMovie;			

typedef enum {	// Horn algorithm result enumeration.
	SFS_UNKNOWN,
	SFS_CANCEL,
	SFS_OK,
	SFS_SUN_AZIMUTH_INVALID,
	SFS_PHASE_ANGLE_INVALID,
	SFS_PIXEL_SIZE_INVALID,
	SFS_MEMERROR,
	SFS_IMGERROR,
	SFS_DET0,
	SFS_ILLCOND,
	SFS_MOVIE_FAILED
} SFSResult;		


// STRUCTURES:------------------------------------------------------------------
typedef struct {	// Movie anti-bounce prevention.

	gint 	row_adj;		// Current row adjustment value for centering.
	gint 	col_adj;		// Current column adjustment value for centering.
} SFSAntiBounce; 

typedef struct {	// 3D Vector
	gdouble		x;	// X axis value.
	gdouble		y;	// Y Axis value.
	gdouble		z;	// Z Axis value.
} SFS3Vector;
	
typedef struct {	// Boolean's assert true!
	// Button control arrays.
	gboolean		draw_axes_state;		// Saves state of draw axes button.
	gboolean		cancel;					// Terminate loops on cancel.
	gboolean		done;					// Terminate loops on done.
	gboolean		algo_button[ALGO_BUTTONS];	// Algorithm control buttons.
	gboolean		app_button[APP_BUTTONS];	// Application control buttons.
	gboolean		movie_button[MOVIE_BUTTONS];	// Movie control buttons.
	// Window control variables.
	gboolean		watchdog_awake;		// Watchdog is active.
	gboolean		init_file_found;	// Initialization file found.
	guint			watchdog;			// Watchdog id.
	gulong			destroy_handler_id;	// Destroy event handler id.
	gulong			delete_handler_id;	// Delete event handler id.
	gulong			start_button_handler;	// Start button handler id.
	gulong			done_button_handler;	// Done button handler id.
	gulong			cancel_button_handler;	// Cancel event handler id.
	GtkWidget		*top_window;	// Top window of plug-in.
	GtkWidget		*SFSdialog;		// Dialog window widget pointer.
	GtkWidget		*SFScancel;		//  Cancel button window pointer.
	// Height map variables.
	gboolean		already_corrected;	// X-axis bias corrected.
	gboolean		formula;			// Use alternate formula.
	gboolean        height_map_saved;   // Height map already saved.
	gchar			*heightmap_filename;	// Heightmap filename pointer.
	GtkWidget		*save_height_map_widget;	// Height map filename box widget.
	// Progress and status variables.
	gdouble			progress_value;	// Progress bar current value.
	gdouble			progress_delta;	// Progress bar incremental change.
	guint			status_bar_context;	// Context of status bar text.
	SFSResult		status;			// Plug-in completion status.
	GtkWidget		*status_bar;	// Status bar text widget.
	GtkWidget		*status_messages;	// Widget for status messages.
	GtkWidget		*pulse_bar;			// Widget for pulse bar.
	GtkWidget		*pulse_bar_table;	// Table for pulse bar.
	gboolean		pulse_bar_enable;	// Pulse bar is enabled.
	gboolean		pulse_bar_defined;	// Pulse bar widget is defined.
	// Movie variables.
	gboolean		movie;					// In movie mode.
	gboolean		not_first_movie_pass;	// Not first movie pass.
	gint			movie_axis;			// Movie axis selection index.
	gint32			movie_image;		// Movie image id.
	SFS3Vector		orig_axis_value;	// Original movie axis start value/.
	GimpDrawable	*movie_drawable;	// Movie drawable structure.
	// Algorithim and image control variables.
	gboolean		elev_done;			// Elevation array is computed.
	gboolean		not_first_pass;		// Not first pass through algorithm.
	gint32			output_image;		// Output image id.
	gint32			output_display;		// Output display id.
	GimpDrawable	*output_drawable;	// Output drawable structure.
	// Debugging assistance.
#ifdef DEBUG
	gint			process_count_calls;	// Register for process count determination.
	gint			render_count_calls;		// Register for render call determination.
#endif
} SFSSemaphore;		// Structure for UI control.

typedef struct {	// Object structure for user interface widgets.
  GtkWidget *Sun_Azimuth;
  GtkWidget *Emission_Angle;
  GtkWidget *Incidence_Angle;
  GtkWidget *Phase_Angle;
  GtkWidget *Pixel_Width;
  GtkWidget *Pixel_Aspect_Ratio;
  GtkWidget *Slant_Distance;
  GtkObject *Algorithm;
  GtkObject *Scale;
  GtkObject	*Viewer_Xaxis;
  GtkObject *Viewer_Yaxis;
  GtkObject *Viewer_Zaxis;
  GtkObject *Focal_Distance;
  GtkObject *Output_Size;
  GtkObject *Movie_Start;
  GtkObject *Movie_End;
  GtkObject *Movie_Frame_Count;
  GtkWidget *progress;
} SFSControls;

typedef struct {	// Actual double presicion variables of user interface widgets.
  gdouble Sun_Azimuth;
  gdouble Emission_Angle;
  gdouble Incidence_Angle;
  gdouble Phase_Angle;
  gdouble Pixel_Width;
  gdouble Pixel_Aspect_Ratio;
  gdouble Slant_Distance;
  gdouble Scale;
  gdouble Viewer_Xaxis;
  gdouble Viewer_Yaxis;
  gdouble Viewer_Zaxis;
  gdouble Focal_Distance;
  gdouble Output_Size;
  gdouble Movie_Start;
  gdouble Movie_End;
  gdouble Movie_Frame_Count;
  SFSAlgorithms Algorithm;
} SFSValues;		

typedef struct {	// Structure for determining an image size.
	gdouble x_min;	// Minimum x axis value.
	gdouble x_max;	// Maximum x axis value.
	gdouble y_min;	// Minimum y axis value.
	gdouble y_max;	// Maximum y axis value.
	gint width;		// Image display width in pixels.
	gint xoffset;	// Pastable layer x-axis offset in pixels.
	gint height;	// Image display height in pixels.
	gint yoffset;	// Pastable layer y-axis offset in pixels.
	gint wth;		// Image display size in pixels.
} SFSScreenSize;	

typedef struct {	// Structure to track memory allocations.
	gboolean tile_map;			// If any of these are true then the respective
	gboolean d_tile_map;		// array has been allocated.
	gboolean tiled_ref_map;
	gboolean ref_map;
	gboolean elevation_map;
	gboolean sorted_vect_map;
	gboolean screen_tile_map;
	gboolean tiled_vect_map;
	// If any value other than -1, there is a deletable image present.
	gint32 debug_display_id;
} SFSMemory;		

typedef struct {	// Tile size information structure.
	gint tile_x;	// Tile x index.
	gint tile_y;	// Tile y index.
	gint w;			// Tile width.  Saved as this varies in the lowest row and
	gint h;			// Tile height. rightmost column.
} SFSTileSize;		

typedef struct {	// Tile coordinate information structure.
	gint tile_x;	// Tile x index.
	gint tile_y;	// Tile y index.
	gint x;			// x coordinate in tile.
	gint y;			// y coordinate in tile.
} SFSTileLocator;	

typedef struct {	// Coordinate information structure.
	gint x;			// Image x coordinate.
	gint y;			// Image y coordinate.
	gint iter;		// Iteration position.
} SFSLocation;		

typedef struct {	// Reflectance, and tracking of image/tile coordinates.
	gboolean	dont_process;	// Don't process this element.
	guchar		value;	// The image value at that location.
	gdouble		ref;	// Reflectance at coordinate.
	SFSLocation	image_data;		// Location in image.
#ifdef DEBUG
	SFSTileLocator tile_data;	// Location in tiles.
#endif
} SFSRef_Tiled;

typedef struct {	// Reflectance and tracking of tile coordinates.
	gboolean	dont_process;	// Don't process this element.
	guchar		value;	// Actual pixel value.
	gdouble		ref;	// Computed pixel reflectance.
#ifdef DEBUG
	SFSLocation		image_data;	// Location in image.
	SFSTileLocator	tile_data;	// Location in tiles.
#endif
} SFSRef_XY;

typedef struct {	// Elevation and tracking of tile coordinates.
					// Image coordinate is implied by offset into array.
	gboolean	dont_process;	// Don't process this element.
	guchar		value;	// The image value at that location.
	gdouble		elev;	// Elevation at coordinate.
#ifdef DEBUG
	gdouble	ref;			// Computed pixel reflectance.
	SFSLocation	image_data;	// Location in image.
	SFSTileLocator tile_data;	// Location in tiles.
#endif
} SFSElev_XY;

typedef struct {	// Structure for vertex projection.
	gboolean is_axis;	// Flag to indicate that this pixel is part of axis.
	gboolean dont_process;	//Indicate that this element is not part of image.
	guchar value;		// The image value at that location.
	GimpVector4 Local;	// Coordinates as converted from elevation map.
	GimpVector4 World;	// Coordinates after scaling.
	GimpVector4 Aligned;	// Coordinates after viewer rotation.
	GimpVector4 Screen;	// Coordinates after perspective.
} Vertex;

typedef struct {	// Sorted vector structure.
	guchar		value;		// Pixel intensity value.
	gint		hit_count;	// Number of times pixel address has been hit.
	gint		x;		// X-axis coordinate.
	gint		y;		// Y-axis coordinate.
	gdouble		depth;	// Depth for hidden element removal purposes.
	gdouble		z;		// Z-azis value for hidden surface removal.
#ifdef DEBUG
	SFSLocation image_data;	// Location in image.
#endif
} Vector_XY;

// -----------------------------------------------------------------------------
class GIMP_SFS {	// GIMP_SFS class declarations.
		// Algorithm not implemented error message.
		void SFS_not_implemented (gchar *);
		// New frame widget constructor.
		GtkWidget* SFS_frame_new_in_box ( const gchar *, GtkWidget *,
			const gboolean, const gboolean
		);
		// New table widget constructor.
		GtkWidget* SFS_table_new_in_frame (const gint cols, const gint rows,
			GtkWidget *frame
		);
		// New scale widget constructor.
		GtkObject* SFS_scale_entry_new_double(
			const gchar *, const gchar *, GtkWidget *, const gint, gdouble *,
			const double, const double, const double,  const double,
			const gint
		);
		// New spin button.
		GtkWidget* SFS_spin_button_new_in_table
		(
			GtkWidget *, GtkObject *, GtkWidget *, const gdouble,
			const guint digits, const gint, const gint col_end,
			const gint row_start, const gint row_end, GtkTooltips *tips_list,
			const gchar *tip
		);
		// New radio button widget constructor.
		GSList* SFS_radio_button_new_in_table
		(
			const gchar *, GSList *group, const GtkWidget *, const gint,
			const gint, const gint, const gint, gint *, gboolean, GtkTooltips *,
			const gchar *
		);
		// New toggle button widget constructor.
		GtkWidget* SFS_toggle_button_new_in_table (
			const gchar *,
			const GtkWidget *,
			const gint, const gint,
			const gint, const gint,
			gint *, gboolean,
			GtkTooltips *, const gchar *
		);
		// New entry box widget constructor.
		GtkWidget* GIMP_SFS::SFS_text_entry_new_in_table (
			const GtkWidget *, const gchar *,
			const gint, const gint,
			const gint, const gint,
			GtkTooltips *, const gchar *
		);


	public:
		GimpDrawable *drawable;	// Source drawable pointer.
#ifdef DEBUG
		void d_c (void);				// Debug call for use with GDB.
#endif
		void movie_error (gchar *);		// Error occured during generation of movie.
		void Plugin_Dialog (gchar *);	// User dialog routine.
		gint SFS_Do (GimpDrawable *);	// Call to determine algorithm.
};

// -----------------------------------------------------------------------------
class COMMON_ALGORITHM {	// COMMON ALGORITHM class declarations.

	public:
		// Global array pointers.
		guchar			*tiled_vect_map;	// Pointer to tiled vector map.
		SFSRef_Tiled	*tiled_ref_map;		// Pointer to tiled reflectance map data array.
		SFSRef_XY		*ref_map;			// Pointer to x-y reflectance map array.
		SFSTileSize		*tile_map;			// Pointer to source tile map.
		SFSTileSize		*d_tile_map;		// Pointer to rotated tile map.
		SFSTileSize		*screen_tile_map;	// Pointer to screen tile map.
		Vector_XY		*sorted_vect_map;	// Pointer to sorted vector map.
		// Global functions.
		COMMON_ALGORITHM (void);			// Constructor.
		gboolean check_parameters (void);	// Parameter checking.
		// Memory return, using C++ "delete".
		void cleanup (void);
		// Clears out Vector_XY array of given size.
		void clear_array ( Vector_XY *, const gint );
		// Error pre-exit.
		void error_status ( SFSResult );
		// Main rendering method.
		gboolean render_3D ( SFSScreenSize *, Vertex *, const gint, const gint );
		// Screen sizing functions.
		void screen_size ( SFSScreenSize *);
		void screen_size ( Vertex *, SFSScreenSize *, gint );
		// Tile mapping function.
		void sfs_tile_map ( SFSTileSize *, GimpDrawable * );
		// Updates the Gimp progress bar.
		void update_progress ( gchar * );
		// Updates the status widget.
		void update_status ( gchar * );
};

// -----------------------------------------------------------------------------
class HORN_ALGORITHM {		// HORN ALGORITHM class declarations.

	private:
		SFSScreenSize RDS, SS;		// Screen sizing structures.

	public:
		SFSElev_XY	*elevation_map;	 // Elevation map pointer.
		Vertex  	*vector_map_local;	// Vector map pointer.
		Vector_XY	*sorted_vect_map;	// Sorted vector map pointer.

		HORN_ALGORITHM (void);	// Class constructor.
		~HORN_ALGORITHM (void); // Class destructor.
		gint SFS_Horn (GimpDrawable *);	// Main class entry.
};

// -----------------------------------------------------------------------------
class MATRIX {	// Matrix Class declaration.

		// Scope vector variables.
		gdouble b_vect[4];
		gdouble result_v[4];
		gdouble temp_v[4];
		// Scope matrix variables.
		gdouble temp_m[4][4];
		gdouble temp_mat_1[4][4];
		gdouble temp_mat_2[4][4];
		// Scope private functions.
		void copy (gdouble [4][4], gdouble [4][4]);	// Copy matrix source to destination.
		void check_det_text (gdouble, gchar *);		// Common check determinant text function.
		gdouble det_3x3 (gdouble *);		// Returns determinant of a 3x3 matrix.
		gdouble det_4x4 (gdouble *);		// Returns determinant of a 4x4 matrix.
		gdouble k_delta (gint, gint);		// Returns Kronecker delta function value.
		// Multiplies 2 matricies., A*B->C.
		void multiply(gdouble [4][4], gdouble [4][4], gdouble [4][4]);
		gdouble sigma (gint);	// Returns sigma function.

	public:
		// Check determinant at labeled code area.
		gdouble check_det (gdouble *, gchar *);		
		// Generates 4x4 identity matrix.
		void identity (gdouble [4][4]);				
		// Checks 4x4 matrix for orthoganality.
		gboolean ortho_check (gdouble [4][4], gchar *);
		// Genetates perspective matrix.
		void perspective (gdouble [4][4], const gdouble);	
		// Generates 3D rotation matrix.
		void rotate_3D (double [4][4], double, double, double);
		// Generates scaling matrix.
		void scale (gdouble [4][4], gdouble, gdouble, gdouble);
		// Generates result of multiplication of vector and matrix.
		void vect_mult (GimpVector4 *, gdouble [4][4], GimpVector4 *);
};

// -----------------------------------------------------------------------------
class MESSAGES {	// Messages class.
	/*	I tried using the C++ string class to no avail.  Not only didn't it work
		correctly, but it also increased the executable size by 4x!  Therefore,
		I've left it as C coding using strcpy, strcat, etc. 5/11/2003, apr.
	*/
	private:
		gboolean	stop_print;		// Stop output printing.
		gint		check_events;	// Event check downcounter.

	public:
		// Message variables.
		gchar number_buffer[NUMB_BUFF_SIZE];	// Number conversion buffer.
		gchar message_buffer[MSG_BUFF_SIZE];	// Text store buffer.
		gchar	*message;		// Pointer to message buffer.
		gchar	*number_ptr;	// Pointer to number conversion buffer.
		gint	sort_error_count;
		
		MESSAGES (void);	// Constructor.
		
		// Message routines. ---------------------------------------------------
		// Attach a formatted number to a string.
		void attach_number (const gchar *, const gint);		
		void attach_number (const gchar *, const gdouble);
		// Generate dialog message method.
		void dialog_message (const gchar *, const GtkMessageType);
		// Error using C++ "new" declaration.
		void new_error ( gchar *, gint );	
		// Sorting error warning.
		void sort_error ( gint, gint, gint, gint, gint, gint,
							gdouble, gdouble, gdouble, gdouble );
		// Right trim string of spaces.
		void rtrim (gchar *);
		// Wait for the number of seconds passed.
		void wait_seconds (const gdouble);	
#ifdef DEBUG_AP
		// Prints out array for debugging purposes
		void debug_array_print (const gdouble *, const gint, const gint,
								const char *, const char *);
		void debug_array_print (const GimpVector4 *array, const gint,
								const char *, const char *);
#endif
};

// -----------------------------------------------------------------------------
static const guchar bitmap_x [BITMAP_SIZE][BITMAP_SIZE] = {
	{ 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255 },
	{ 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255 },
	{ 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0 },
	{ 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0 },
	{ 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 255, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 0, 255, 255, 255, 0, 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 0, 255, 0, 255, 255, 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 255, 0, 0, 0, 255, 255, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0 },
	{ 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0 },
	{ 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0 },
	{ 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255 },
	{ 255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255 }
};

static const guchar bitmap_y [BITMAP_SIZE][BITMAP_SIZE] = {
	{ 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255 },
	{ 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255 },
	{ 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0 },
	{ 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0 },
	{ 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 255, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 255, 255, 0, 0, 255, 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 0, 255, 255, 255, 0, 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0 },
	{ 0, 0, 0, 0, 0, 0, 255, 255, 255, 255, 0, 0, 0, 0, 0 }
};
