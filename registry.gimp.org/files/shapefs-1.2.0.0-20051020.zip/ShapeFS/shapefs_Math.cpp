/*  ShapeFS Mathematics Source File.
	A GIMP Plug-in to render shape from shading.
	(c) 2003, Alfred P. Reaud
	Created: April 24, 2003
	Current: October 20, 2005
	Version: 1.2.0.0

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "shapefs.h"
MATRIX 	matrix;	// Common matrix functions.

extern MESSAGES text;	// Declare text static so that all portions can use it.

extern SFSSemaphore SFSint;

// -----------------------------------------------------------------------------
void MATRIX::copy (gdouble source[4][4], gdouble dest[4][4])
/*
  Name: Matrix Copy Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:28
  Description: Copies a 4x4 matrix from the source to the destination.
*/
{	// Copies source matrix to destination matrix.
	int i, j;

	for(i = 0; i != 4; i++)
		for(j = 0; j != 4; j++)
			dest[i][j] = source[i][j];
}

// -----------------------------------------------------------------------------
gdouble MATRIX::det_3x3 (gdouble *mat)
/*
  Name: 3x3 Matrix Determinant Method.
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:29
  Description: Generates the determinant of a 3x3 matrix. From Mathworld,
  Determinant, Formula 10, at:
			http://mathworld.wolfram.com/Determinant.html
*/
{
	gdouble sumpos, sumneg;
	
	sumpos = mat[0] * mat[4] * mat[8] + mat[1] * mat[5] * mat[6]
				+ mat[2] * mat[3] * mat[7];
	sumneg = mat[2] * mat[4] * mat[6] + mat[0] * mat[5] * mat[7]
				+ mat[1] * mat[3] * mat[8];

	return (sumpos - sumneg);
}

// -----------------------------------------------------------------------------
gdouble MATRIX::det_4x4 (gdouble *mat)
/*
  Name: 4x4 Matrix Determinant Method.
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:29
  Description: Generates the determinant of a 3x3 matrix. From Mathworld,
  Determinant, Formulas 8 and 9, at:
			http://mathworld.wolfram.com/Determinant.html
			Algorithim ported from QBasic implementation Rev: 1.01 - 9/25/1999 15:39
			Handbook of Engineering Fundamentals, Esbach, Wiley & Sons, 1975
			pg. 230, Definition 10.
*/
{
	gint row, col, col_offset;
	gint i, j, j_offset, k;
	gdouble sum = 0.0;
	gdouble temp[9] = { 0.0 };
	
	for (i = 0; i != 4; i++)
	{
		col = 0;
		for (j = 1; j != 4; j++)
		{
			row = 0;
			col_offset = col * 3;
			j_offset = j * 4;
			for (k = 0; k != 4; k++)
			{
				if (k != i) temp[(row++) + col_offset] = mat[j_offset + k];
			}
			col++;
		}
		sum += sigma(i) * mat[i] * det_3x3(temp);
	}
	return sum;
}

// -----------------------------------------------------------------------------
void MATRIX::identity (gdouble mat[4][4])
/*
  Name: 4x4 Matrix Identity Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:32
  Description: Creates a 4x4 identity matrix.
*/
{
	gint i, j;
	
	for (i = 0; i != 4; i++)
	{
		for (j = 0; j != 4; j++) (i == j) ? mat[i][j] = 1.0 : mat [i][j] = 0.0;
	}
}

// -----------------------------------------------------------------------------
gdouble MATRIX::k_delta (gint i, gint j)
/*
  Name: Kronecker Delta Function Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:32
  Description: Generates the Kronecker delta function.
			See: http://mathworld.wolfram.com/KroneckerDelta.html
*/
{
	gdouble test_result;
	(i == j) ? test_result = 1.0 : test_result = 0.0;
	return test_result;
}

// -----------------------------------------------------------------------------
void MATRIX::multiply(gdouble mat_1[4][4], gdouble mat_2[4][4], gdouble dest[4][4])
/*
  Name: 4x4 Matrix Multiply Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:32
  Description: Multiplies 2 4x4 matricies. See: Formula (12)
		http://mathworld.wolfram.com/MatrixMultiplication.html
*/
{
	gint n, p;

	for(n = 0; n != 4; n++)
		for(p = 0; p != 4; p++)
			dest[n][p] =
					mat_1[n][0] * mat_2[0][p] +
					mat_1[n][1] * mat_2[1][p] +
					mat_1[n][2] * mat_2[2][p] +
					mat_1[n][3] * mat_2[3][p];
}

// -----------------------------------------------------------------------------
gboolean MATRIX::ortho_check (gdouble a[4][4], gchar *label)
/*
  Name: 4x4 Orthogonal Matrix Check Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:32
  Description: Checks that the passed matrix is orthogonal.
			   See http://mathworld.wolfram.com/RotationMatrix.html
			   Formula 13.
*/
{
	gint i, j, k;
	gdouble difference, kronecker, sum;
	
	if (!SFSint.app_button[IGNORE_MATRIX]) return true;

		for (j = 0; j != 4; j++)
		{
			for (k = 0; k != 4; k++)
			{
				sum = 0.0;
				for (i = 0; i != 4; i++) sum += a[i][j] * a[i][k];
				kronecker = k_delta (j, k);
				difference = kronecker - sum;
				if ( fabs(difference) >= KRONECKER_LIMIT )
				{
					strcpy (text.message, label);
					strcat (text.message, " inconsistent with an orthogonal transformation.\n");
					strcat (text.message, "Try to change viewer x, y, or z angles to correct.\n");
					strcat (text.message, "Determinant value is ");	
					text.attach_number("%-6G", ( det_4x4((gdouble *)a) ));
					strcat (text.message, "!\n");
					strcat (text.message, "Test data (j, k, difference,  Kronecker delta)\n(");	
					text.attach_number("%-6G", j);
					strcat (text.message, ", ");
					text.attach_number("%-6G", k);
					strcat (text.message, ", ");
					text.attach_number("%-16G", difference);
					strcat (text.message, ", ");
					text.attach_number("%-6G", kronecker);
					strcat (text.message, ")!");
					gimp_message (text.message);
					return false;
				}
			}
		}
	return true;
}

// -----------------------------------------------------------------------------
void MATRIX::perspective (gdouble mat[4][4], const gdouble distance)
/*
  Name: Perspective Matrix Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:38
  Description: Generates a perspective matrix for image manipulation.
 					See: http://www.toulouse.ca/index.php4?/CamModel/
*/
{
	mat[0][0] = distance;
	mat[0][2] = 1.0;
	mat[1][1] = distance;
	mat[1][2] = 1.0;
}

// -----------------------------------------------------------------------------
void MATRIX::rotate_3D (double mat[4][4], double ax, double ay, double az)
/*
  Name: Coordinate 3D Rotation Matrix Creation Method.
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:40
  Description: Generates a rotation matrix from the passed arguments.
			From CRC Standard Mathematical Tables and Formulae, 30th. Ed.,
			Zwillinger, CRC Press, 1996, pages 300 and 302, section 4.10.1 and
			4.10.2.  NOTE: There is a difference between the z-axis matrix and
			that represented in MathWorld.  I'm going with the CRC value as
			it computes out correctly for a unit z-axis vector.
			See http://mathworld.wolfram.com/RotationMatrix.html
			Also see CRC Standard Mathematical Table and Formulae, 31st. Ed.
			Daniel Zwillinger, pg. 349, formula (4.9.2), for pertinent
			modifications with respect to the sign of a given sin function.
			Generated with an HP48GX and (4.9.2).

From: 3D Matrix Math Demystified by Seumas McNally, at
			http://www.gamedev.net/reference/articles/article695.asp

			   [1, 0, 0]  <- X Components of Axis Vectors
	identity = [0, 1, 0]  <- Y Components of Axis Vectors
			   [0, 0, 1]  <- Z Components of Axis Vectors
				^  ^  ^- Z Axis Vector
				|  |---- Y Axis Vector
				|------- X Axis Vector

							All angles in radians.
*/
{
	double xaxis[4][4], yaxis[4][4], zaxis[4][4];

	identity (xaxis);	// x-axis vector is (1, 0, 0).
	xaxis[1][1]= cos(ax);	// CCW around x-axis.
	xaxis[1][2]= -sin(ax);
	xaxis[2][1]= sin(ax);
	xaxis[2][2]= cos(ax);

	identity (yaxis);	// y-axis vector is (0, 1, 0).
	yaxis[0][0]= cos(ay);	// CCW around y-axis.
	yaxis[0][2]= sin(ay);
	yaxis[2][0]= -sin(ay);
	yaxis[2][2]= cos(ay);

	identity (zaxis);	// z-axis vector is (0, 0, 1).
	zaxis[0][0]= cos(az);	// CCW around z-axis.
	zaxis[0][1]= -sin(az);
	zaxis[1][0]= sin(az);
	zaxis[1][1]= cos(az);

	// The order of these definitly matters, as in matricies A(BC) != (AB)C.
	multiply (mat, xaxis, temp_mat_1);
	multiply (temp_mat_1, zaxis, temp_mat_2);
	multiply (temp_mat_2, yaxis, mat);
}

// -----------------------------------------------------------------------------
void MATRIX::scale(gdouble mat[4][4], gdouble sx, gdouble sy, gdouble sz)
/*
  Name: Scale Matrix Creation Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:42
  Description: Generates a scaling matrix from the passed ratios.
			See CRC Standard Mathematical Table and Formulae, 31st. Ed.
			Daniel Zwillinger, pg. 352, formula (4.10.3),
*/
{
	identity (temp_m);
	temp_m[0][0] = sx;
	temp_m[1][1] = sy;
	temp_m[2][2] = sz;
	multiply (mat, temp_m, temp_mat_1);
	copy (temp_mat_1, mat);
}

// -----------------------------------------------------------------------------
gdouble MATRIX::sigma (gint value)
/*
  Name: Sigma Value Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:42
  Description:	Computes the sigma value from the number of iterations, where
 				value is the number of iterations.  From Mathworld :
 				Determinant, Formula 9, at:
			http://mathworld.wolfram.com/Determinant.html
*/
{
	gint i, p, result;
	const gint limit = value + 1;
	p = result = -1;
	for (i = 0; i != limit; i++) result *= p;
	return (gdouble)result;
}

// -----------------------------------------------------------------------------
void MATRIX::vect_mult(GimpVector4 *Source, gdouble mat[4][4], GimpVector4 *Dest)
/*
  Name: Vector by Matrix Multiplication Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:44
  Description: Multiplies a GIMP 4-vector by a 4x4 matrix. Optimized for speed
	via gprof.
*/
{
	gint i, j;	 // Iteration variables.
	gdouble sum = 0.0;	  // Dot product summmation register.
	// Copy Gimpvector4 into gdouble array.
	b_vect[0] = Source->x;
	b_vect[1] = Source->y;
	b_vect[2] = Source->z;
	b_vect[3] = Source->w;
	// Do the multiplication.
	for (i = 0; i != 4; i++)
	{	// Form vector dot product.
		for (j = 0; j != 4; j++) sum += mat[i][j] * b_vect[j];
		result_v[i] = sum;
		sum = 0.0;
	}
	// Copy gdouble array into GimpVector4.
	Dest->x = result_v[0];
	Dest->y = result_v[1];
	Dest->z = result_v[2];
	Dest->w = result_v[3];
}

// -----------------------------------------------------------------------------
gdouble MATRIX::check_det (gdouble *mat, gchar *label)
/*
  Name: Check Matrix Determinant Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:44
  Description: Generates and checks a 4x4 matrix determinant, and flags the user
 					if the matrix is singular or ill conditioned.
*/
{
	gdouble result;

	result = det_4x4 (mat);
	// Pop out if user has selected to ignore MATRIX errors.
	if (!SFSint.app_button[IGNORE_MATRIX]) return result;
	// Check for singular and ill conditioned matricies.
	if ( FP_EQ(result, 0.0) )
	{
		strcpy (text.message, "SINGULAR MATRIX IN ");
		check_det_text (result, label);
	}
	else
	{
		if ( fabs(result) <= (gdouble)SMALL_NUMB )
		{
			strcpy (text.message, "Ill conditioned MATRIX in ");
			check_det_text (result, label);
		}
	}
	return result;
}

// -----------------------------------------------------------------------------
void MATRIX::check_det_text (gdouble result, gchar *label)
/*
  Name: Check Determinant Result Message Method.
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:48
  Description: Messages the user on the results of checking the determinant
			   of a matrix.
*/
{	// Displays the result of determinant checking.
	strcat (text.message, label);
	strcat (text.message, "!\n");
	strcat (text.message, "Determinant value is ");	
	text.attach_number("%-8G", result);
	strcat (text.message, "!");
	gimp_message (text.message);
}
