#!/usr/bin/python
import math

import gimp
import xml
import xml.dom
import xml.dom.minidom

from gimpfu import *


#########################
# Support Functions
##########################

def make_layer(image, name, copy_active):
	"""Function to add a new, named layer of specified dimensions and offset."""
	gimp.pdb.gimp_image_undo_group_start(image)
	new_layer = None
	if copy_active:
		new_layer = image.active_layer.copy()
		new_layer.name = name
	else:
		new_layer = gimp.pdb.gimp_layer_new(image, image.width, image.height, 1, name, 100, 0)
		new_layer.set_offsets(0, 0)
		
	if new_layer:
		image.add_layer(new_layer, -1)
	
	if not copy_active:
		gimp.pdb.gimp_edit_clear(new_layer)
	gimp.pdb.gimp_image_undo_group_end(image)
	
	return new_layer != None

def make_button_path(image, name, x1, y1, w, h):
	""" function to make a button path, based on the specified coord params. """
	x2 = x1 + w
	y2 = y1 + h

	A = 1.0
	C = 2.0

	# ACCACCACCACC - an array of 12 triplets
	points = [
		x1, y1, A,
		x1, y1, C,
		x2, y1, C,
		x2, y1, A,
		x2, y1, C,
		x2, y2, C,
		x2, y2, A,
		x2, y2, C,
		x1, y2, C,
		x1, y2, A,
		x1, y2, C,
		x1, y1, C
		]
	gimp.pdb.gimp_path_set_points(image, name, 1, 36, points)

def _get_logo():
    import gtk, gobject
    import os.path
    logofile = os.path.join(os.path.dirname(__file__), 'dablogo.png')
    try:
        pixbuf = gtk.gdk.pixbuf_new_from_file(logofile)
    except gobject.GError, e:
        return None
    image = gtk.Image()
    image.set_from_pixbuf(pixbuf)
    return image

def getButtonNode(buttonName, xmlDOM):
	nodeList = xmlDOM.getElementsByTagName("button")
	for i in range(nodeList.length):
		node = nodeList.item(i)
		if (node.getAttribute("name") == buttonName):
			return node
	return None	

####################################
# Visible functions
####################################
	
def add_button_layers(img, 
		      drawable,
		      include_image=True,
		      include_highlight=True,
		      include_select=True,
		      copy_active=False):
	gimp.pdb.gimp_image_undo_group_start(img)
	active = img.active_layer
	
	ok = True
	if include_image:
		ok = ok and make_layer(img, 'image_bl', copy_active)
	if include_highlight:
		ok = ok and make_layer(img, 'highlight_bl', copy_active)
	if include_select:
		ok = ok and make_layer(img, 'select_bl', copy_active)
	if not ok:
		gimp.pdb.gimp_message("An error occurred while adding layers... sorry.")
	gimp.pdb.gimp_image_undo_group_end(img)

register("dvdauthorbuttons_add_button_layers",
         "Add button layers, to draw buttons into.",
         "Add new layers to existing image, named image_bl, highlight_bl, and select_bl.",
         "Jamie Strachan<frostfreek@yahoo.com>",
         "Jamie Strachan",
         "2008-01-24",
         "<Image>/Python-Fu/DvdAuthor-Buttons/Add button layers...",
         "RGB*",
         [
            (PF_TOGGLE, 'include_image',     "Include 'image'", True),
            (PF_TOGGLE, 'include_highlight', "Include 'highlight'", True),
            (PF_TOGGLE, 'include_select',    "Include 'select'", True),
            (PF_TOGGLE, 'copy_active', "Copy active layer?", False)
         ],
         [],
         add_button_layers
)

def define_button_selection(image, drawable, button_name):
	dims = gimp.pdb.gimp_selection_bounds(image)
		
	x1 = dims[1]
	y1 = dims[2]
	width = dims[3] - x1
	height = dims[4] - y1
	
	if dims[0] == 0:
		gimp.pdb.gimp_message("Invalid selection!")
	else:
		define_button(image, drawable, button_name, x1, y1, width, height)

register("dvdauthorbuttons_define_button_selection",
		"Define a button's name and path-outline, using the selection for dimensions",
		"Define a button's name and path-outline, using the selection for dimensions",
		"Jamie Strachan<frostfreek@yahoo.com>",
		"Jamie Strachan",
		"2008-01-24",
		"<Image>/Python-Fu/DvdAuthor-Buttons/Define a button, using selection...",
		"RGB*",
		[
			(PF_STRING, 'button_name', "Button Name", 'MyButt')
		],
		[],
		define_button_selection
)

def define_button(image, drawable, button_name, x1, y1, w, h):
	if (w < 2) or (h < 2):
		gimp.pdb.gimp_message("invalid input dimensions.")
	else:
		make_button_path(image, 'button-' + button_name, x1, y1, w, h)
		
register("dvdauthorbuttons_define_button",
		"Define a button's name and extents",
		"Define a button's name and extents",
		"Jamie Strachan<frostfreek@yahoo.com>",
		"Jamie Strachan",
		"2005-07-20",
		"<Image>/Python-Fu/DvdAuthor-Buttons/Define button...",
		"RGB*",
		[
			(PF_STRING, 'button_name',   'Button Name', 'MyButt'),
			(PF_ADJUSTMENT, 'offset_x1', "Offset X1", 0, (0, 718, 1)),
			(PF_ADJUSTMENT, 'offset_y1', "Offset Y1", 0, (0, 574, 1)),
			(PF_ADJUSTMENT, 'width',     "Width",     2, (2, 718, 1)),
			(PF_ADJUSTMENT, 'height',    "Height",    2, (2, 574, 1))
		],
		[],
		define_button
)

def editButtonDirections(image, drawable):
	import pygtk
	pygtk.require('2.0')
	import gtk
	import gimpui
	gtk.rc_parse(gimp.gtkrc())
	
	# Read any existing button directions...
	parasite = image.parasite_find('dvdauthor_buttons')
	actionXML = None
	if parasite:
		actionXML = xml.dom.minidom.parseString(parasite.data)
	
	# Find the name of all buttons.
	buttons = []
	num, pathlist = gimp.pdb.gimp_path_list(image)
	for pathname in pathlist:
		if "button-" == pathname[:7]:
			buttons.append(pathname[7:])
	
	dialog = gtk.Dialog('Edit Button Actions', None, 0,
                        (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL,
                        gtk.STOCK_OK, gtk.RESPONSE_OK))
	
	hbox = gtk.HBox(False, 1) # 5
	hbox.set_border_width(2) # 5
	dialog.vbox.pack_start(hbox, expand=False)
	hbox.show()
	
	frame = gtk.Frame()
	table = gtk.Table(1 + len(buttons)*2, 4, False)
	table.set_border_width(2)
	table.set_row_spacings(2)
	table.set_col_spacings(4)
	table.show()
	frame.add(table)
	frame.show()
	hbox.pack_end(frame, expand=False)
		
	pix = _get_logo()
	if pix:
		vbox = gtk.VBox(False, 3)
		hbox.pack_start(vbox, expand=False)
		vbox.show()
		vbox.pack_start(pix, expand=False)
		pix.show()
	
	headers=['Button', 'Left', ' Up\nDown', 'Right']
	for i in range(len(headers)):
		label = gtk.Label('<b>' + headers[i] + '</b>')
		label.set_use_markup(True)
		label.set_alignment(0.5, 0.5)
		table.attach(label, i, i+1, 0, 1, xoptions=gtk.FILL)
		label.show()
	
	combos = {}
	for i in range(len(buttons)):
		button = buttons[i]
		label = gtk.Label(button)
		label.set_alignment(1.0, 0.5)
		table.attach(label, 0, 1, i*2+1,i*2+3, xoptions=gtk.FILL)
		label.show()
		combos[button] = {}
		
		buttonConfigNode = None
		if actionXML:
			buttonConfigNode = getButtonNode( button, actionXML)
		
		
		attnames = ['left', 'up', 'down', 'right']
		combos[button][attnames[0]] = gtk.combo_box_new_text()
		combo = combos[button][attnames[0]]
		table.attach(combo, 1, 2, i*2+1, i*2+3, xoptions=gtk.FILL,yoptions=0)
		combo.show()
		
		combos[button][attnames[1]] = gtk.combo_box_new_text()
		combo = combos[button][attnames[1]]
		table.attach(combo, 2, 3, i*2+1, i*2+2, xoptions=gtk.FILL)
		combo.show()
		
		combos[button][attnames[2]] = gtk.combo_box_new_text()
		combo = combos[button][attnames[2]]
		table.attach(combo, 2, 3, i*2+2, i*2+3, xoptions=gtk.FILL)
		combo.show()
		
		combos[button][attnames[3]] = gtk.combo_box_new_text()
		combo = combos[button][attnames[3]]
		table.attach(combo, 3, 4, i*2+1, i*2+3, xoptions=gtk.FILL, yoptions=0)
		combo.show()
		
		for j in range(len(attnames)):
			actionTarget = ''
			if buttonConfigNode:
				actionTarget = buttonConfigNode.getAttribute(attnames[j])
			combo = combos[button][attnames[j]]
			combo.append_text('')
			for k in range(len(buttons)):
				button2 = buttons[k]
				combo.append_text(button2)
				if button2 == actionTarget:
					combo.set_active(k + 1)
		
	def response(dlg, id, combos, buttons):
		if id == gtk.RESPONSE_OK:
			# Recreate the 'parasite' button directions, as an XML document.
			actionXML = xml.dom.minidom.parseString('<dvdauthorbuttons/>')
			
			for button in combos.keys():
				node = actionXML.createElement('button')
				actionXML.documentElement.appendChild(node)
				node.setAttribute('name', button)
				for action in combos[button].keys():
					active = combos[button][action].get_active()
					if active > 0:
						node.setAttribute(action, buttons[active-1])
			
			# Create a new parasite object, and attach it to the image.
			p = gimp.Parasite('dvdauthor_buttons', True, actionXML.toxml())
			image.parasite_attach(p)
			gtk.main_quit()

	dialog.connect("response", response, combos, buttons)
	
	dialog.show()
	gtk.main()
	if hasattr(dialog, 'res'):
		res = dialog.res
		dialog.destroy()
		return res
	else:
		dialog.destroy()
		raise CancelError

register("dvdauthorbuttons_edit_button_actions",
	 "Edit which button to jump to for up,down,left, & right",
	 "Edit which button to jump to for up,down,left, & right",
	 "Jamie Strachan<frostfreek@yahoo.com>",
	 "Jamie Strachan",
	 "2008-01-24",
	 "<Image>/Python-Fu/DvdAuthor-Buttons/Edit Button Actions...",
	 "RGB*",
	 [],
	 [],
	 editButtonDirections
	)

def check_and_export(image, drawable, backwardsCompat):
	# start by getting the image's filename.
	fullname = image.filename
	shortname = image.name

	if not fullname:
		gimp.message("You must save the image file (must be an XCF!) first!")
	else:
		# Strip the ".XCF" off the fullname
		fullbase = fullname[:len(fullname)-4]
		shortbase = shortname[:len(shortname)-4]

		if backwardsCompat:
			useLabelNotName = True
		else:
			useLabelNotName = False
		internal_export(image, drawable, fullbase, shortbase, useLabelNotName)

register("dvdauthorbuttons_export",
	 "Export Button PNG images, and SPUMUX XML, into same location as XCF file.  ",
	 "Export Button PNG images, and SPUMUX XML, into same location as XCF file.  " + \
	 "Click the checkmark if you have dvdauthor version 0.6.9 (or earlier) installed. This means 'label' " + \
	 "will be used instead of 'name' in the generated XML.",
	 "Jamie Strachan<frostfreek@yahoo.com>",
	 "Jamie Strachan",
	 "2005-07-30",
	 "<Image>/Python-Fu/DvdAuthor-Buttons/Export...",
	 "RGB*",
	 [
		(PF_TOGGLE, 'backwardsCompat', "Compatible with DVDAuthor 0.6.9 and earlier?", False)
	 ],
	 [],
	 check_and_export
	)

	
	
###########################################
# Export functions
###########################################
def internal_export(orig_image, drawable, fullbase, shortbase, useLabelNotName):
	image = orig_image.duplicate()
	image.disable_undo()
	
	# Read any existing button directions...
	parasite = image.parasite_find('dvdauthor_buttons')
	actionXML = None
	if parasite:
		actionXML = xml.dom.minidom.parseString(parasite.data)

	# export the button png images
	img_filename = export_png(image, "image_bl", fullbase, shortbase)
	hi_filename = export_png(image, "highlight_bl", fullbase, shortbase)
	sel_filename = export_png(image, "select_bl", fullbase, shortbase)

	# export the spumux xml
	doc = xml.dom.minidom.getDOMImplementation().createDocument(None, 'subpictures', None)
	stream = doc.createElement('stream')
	spu = doc.createElement('spu')
	spu.setAttribute('force', 'yes')
	spu.setAttribute('start','00:00:00.00')

	if img_filename:
		spu.setAttribute('image', img_filename)
	if hi_filename:
		spu.setAttribute('highlight', hi_filename)
	if sel_filename:
		spu.setAttribute('select', sel_filename)

	stream.appendChild(spu)
	doc.documentElement.appendChild(stream)
	
	# Now add the button definitions.
	num, pathlist = gimp.pdb.gimp_path_list(image)
	
	attnames = ['left', 'up', 'down', 'right']
	for pathname in pathlist:
		if "button-" == pathname[:7]:
			# Activate the path
			gimp.pdb.gimp_path_set_current(image, pathname)

			# Get the button's name, and replace # with _
			bname = pathname[7:]
			bname.replace('#','_')
			
			# get the path's coordinates.
			gimp.pdb.gimp_selection_clear(image)
			gimp.pdb.gimp_path_to_selection(image, pathname, 0, 0, 0, 0, 0)
			bounds = gimp.pdb.gimp_selection_bounds(image)
			x1 = bounds[1]
			y1 = bounds[2]
			x2 = bounds[3]
			y2 = bounds[4]

			button = doc.createElement('button')
			if useLabelNotName:
				button.setAttribute('label', bname)
			else:
				button.setAttribute('name', bname)
			button.setAttribute('x0', str(bounds[1]))
			button.setAttribute('y0', str(bounds[2]))
			button.setAttribute('x1', str(bounds[3]))
			button.setAttribute('y1', str(bounds[4]))
			
			buttonConfigNode = None
			if actionXML:
				buttonConfigNode = getButtonNode(bname, actionXML)
				if buttonConfigNode:
					for j in range(len(attnames)):
						if buttonConfigNode.hasAttribute(attnames[j]):
							actionTarget = buttonConfigNode.getAttribute(attnames[j])
							button.setAttribute(attnames[j], actionTarget)
			
			spu.appendChild(button)

	# Now write out the XML document.
	f = open(fullbase + "_spu.xml", 'w')
	doc.writexml(f)
	f.close()

	# All done with our image copy, so delete it.
	gimp.delete(image)

def export_png(image, layername, fullbase, shortbase):
	shortname = "%s_%s.png" % (shortbase, layername)
	filename = "%s_%s.png" % (fullbase,  layername)

	dupe = image.duplicate()
	dupe.disable_undo()
	layer = gimp_image_activate_named_layer_delete_others(dupe, layername)
	if layer:
		# convert to 3 colours plus transparent.
		gimp.pdb.gimp_image_convert_indexed(dupe, 0, 0, 3, 0, 0, "")
		### For some reason, the first parameter 'INTERACTIVE', is no longer
		### Accepted.  Discovered by accident...
		# gimp.pdb.file_png_save_defaults(1, dupe, layer, filename, "")
		gimp.pdb.file_png_save_defaults(dupe, layer, filename, "")
	else:
		shortname = None
	gimp.delete(dupe)
	return shortname

def gimp_image_activate_named_layer_delete_others(image, name):
	found = None
	for layer in image.layers:
		if layer.name == name:
			image.active_layer = layer
			layer.visible = 1
			found = layer
		else:
			image.remove_layer(layer)
	return found

		
###########################################
# End of Export functions
###########################################
	
		
main()
