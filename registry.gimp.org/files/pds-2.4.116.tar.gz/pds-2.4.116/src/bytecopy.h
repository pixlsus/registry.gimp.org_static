#ifndef _BYTECOPY_H
#define _BYTECOPY_H

void bytecopy(char* from, char* to, int n);
void bytezero(char *to, int n);

#endif
