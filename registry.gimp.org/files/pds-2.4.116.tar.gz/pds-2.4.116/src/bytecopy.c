void bytecopy(char* from, char* to, int n) {
	while(n--) *to++ = *from++;
}

void bytezero(char *to, int n) {
	while(n--) *to++ = 0;
}
