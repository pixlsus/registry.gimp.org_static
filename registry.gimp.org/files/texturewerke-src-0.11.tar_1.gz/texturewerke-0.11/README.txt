Texturewerke

A texturing plugin for GIMP.

Author: Lauris Kaplinski <lauris@kaplinski.com>
Levmar library by Manolis Lourakis
Webpage: http://khayyam.kaplinski.com/
Released under GNU GPL version 3.0 (or any later version).


Overview

At moment it has two operating modes - color adjustment and highpass filter.

Color adjustment

Takes two (optionally masked) layers and tries to adjust the overall color of work
layer (selected layer) with another (template layer). If either layer has
masks, only the colors of visible areas are used to build color profile, (but
still the whole layer is changed).
Internally it works channel by channel by creating cumulative histograms of both
layers and finding the best transfer function that translates the values with one
distribution function to another.
Optionally both layers can be (internally) blurred before adjustment. It may
help or disturb the adjustment, depending on the actual distribution of
values over channel.

Highpass filter

It removes low frequencies from image, making it suitable for texturing.
Common uses of highpass filter are the creation of seamless texture, or
removing shading gradient form uniformly coloured things like walls,
whiteboards and so on.

It has two submodes:

Blur - simply subtracts blurred image from the original (and adds back
average). It is mostly useful for creating seamless textures, where you only
want to keep relatively high frequencies. It does not support masking.

Polynome - find the best approxaimation of image by two-dimensional polynomic
function of user specified degree (up to 4 in either direction) and
substracts it from the original image (and adds back average).
It supports masking - in that case only unmasked areas are used for
approximation (but it is still applied to the whole layer). It is good for
removing shading gradient from surfaces like walls, while ignoring certain
details (like picture hanging on wall).
Beware that higher order polynomes tend to oscillate heavily and thus you
probably will not get desired result if the borders of the image are masked.


Changelog

2011/18/12 - Version 0.11
Removed polynome fitting from color matching regime, use direct transfer function
instead. The result is much better, if channels have highly constrained ranges.

Lauris Kaplinski

