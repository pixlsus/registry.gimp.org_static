﻿
save_as_windows.py
plugin for GIMP 
---------------------

THIS IS STILL WORK IN PROGRESS.
DON'T EXPECT IT TO BE EASY TO INSTALL

rationale:
----------
Instead of the non-standard, non-compatible, often annoying GTK window,
this plugin shows a Windows standard/native save/open dialog.

GTK dialog has nice features, but it still annoys me very much. I'm sure that windows users, esp. beginners and power users will find this dialog useful. 

Also,
I really don't like to have 2 separate menus for SAVE and EXPORT.  
Since i know enough about graphics and formats, I can actively decide when and why to choose XCF or JPG each time I see a "save" dialog...  
So this plugin has 1 menu entry for both XCF and other types, as it used to be several years ago.



NOTE:
-----
The plugin depends on external library (either pywin32, wxpython, or tkinter)
 - wxPython (best, cross-platform, but 30MB is not shippable, i cant attach here even wx.7z file)
 - tk (cross-platform, but I couldn't make it work)
 - win32 (only on windows, 7mb, not easy to install?)
 - kde (i didn't try, but they have a very usable dialog with similar look and feel)

(i implemented both, because i don't mind the extra MBs, and because i have both windows and linux)


Bugs:
-------
see "questions" below 


Installation:
-------------
1. INSTALLATION IS NOT ORGANIZED, AND IS NOT EASY.
2. it's just quick-and-dirty, certainly not the correct way of installing python plugins
3. this plugin was not (yet) developed for linux. it might even work out of the box (without the next steps)

4. choose if you're going to use pywin32, wx, or tkiner(incomplete!). I recommend on wxpython.
5. find out which python version, and architecture (32bit/64bit)
in my portable-gimp, i found "python.exe", double-click it, and it printed the version. 
in my case it was "Python 2.7.5 (May 15 2013, 22:43:36) [MSC v.1500 32 bit (Intel)]"
which means i have a python version 2.7, 32bit. 

6. copy save-as-windows.py to your plug-ins folder

7. once you (re)start Gimp, There are 2 new menu items:
File > Open as windows, File > Save as windows

8. you might want to change save/keyboard bindings to this plugin.



installing pywin32  (for Windows only):
-----------------------------------------
1. download pywin32 for python 2.7 (depends on your gimp version), must be 32 bit
2. extract its contents (using total commander or 7zip or something)
3. create a sub-folder in gimp's \plug-ins\  called   "win32"
4. copy some* files from pywin32 package to your \plug-ins\win32\    it looks like:
gimp\plug-ins\win32\*.py
gimp\plug-ins\win32\*.pyd
gimp\plug-ins\win32\lib\(...)
gimp\plug-ins\win32\pywin32_system32\(*.dll)
gimp\plug-ins\win32\win32com\client\(...)
gimp\plug-ins\win32\win32com\(...)
gimp\plug-ins\win32\win32comext\(...)

But this is WRONG:   .gimp-2.8/plug-ins/win32/win32/*.py

installing wx:
1. download wxPython for python 2.7 (depends on your gimp version), 32 bit
2. copy the wxPython's library "wx" directory to the plug-ins\ dir* 
so you see something like:
gimp\plug-ins\wx\*.py
gimp\plug-ins\wx\*.pyd
gimp\plug-ins\wx\py\*.py

* most of them are NOT necessary, but i haven't checked which.

Questions
---------
1. ANSWERED: can i replace gimp's default menu entries?
2. ANSWERED: f I run the plugin while there's no image opened in Gimp, gimp shows me a parameters dialog.
3. ANSWERED: why the image is not shown
4. ANSWERED: how to combine 2 menu entries in 1 plugin 
5. ANSWERED: when saving the image, the window's title doesn't change according to the new name. 
6. How to add my recently saved file to the "File > Open Recent" list?

Full answers (with help from ofnuts):
2. the menu label must also be defined as "<Toolbox>".  If it is defined as <Image>, gimp passes automagically 2 parameters (img, drawable) to my function, and shows a dialog
4. nothing is "simple";)  you have to know which menu prefix (as above) to use, and to use very particular value to "imagetypes".  See my code for very ilustraded call to "register()"
5. pdb.gimp_image_set_filename(active_image, f)

Ideally,
--------
There should be system-wide GTK flag that chooses between native and gtk dialog.
This is probably will never happen, so GTK recommend using the same method for native dialogs
http://faq.pygtk.org/index.py?req=edit& ... 21.013.htp

Todo:
------
- on open, add preview (i am not going to implement it on my own)
- remember directory or use current image's directory
- create a list or zip of the depedencies (wx or win32) with only the necessary files
- add a filter with possible extensions (i use almost always gif, jpg, png and xcf, so i don't need this feature)


initial version:  2014-03-22  
latest version:  2014-03-23  
