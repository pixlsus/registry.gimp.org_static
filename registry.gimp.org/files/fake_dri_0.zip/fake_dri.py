#
# fake_dri.py - 2009 by Christian Nielebock (ravetracer@yahoo.de)
#
# This script allows you to make some kind of DRI effect with one single picture. It doesn't work on all images, but on many ;-).
# Just copy it under your home directory in .gimp-2.x/plugins (works with >=2.4) and chmod it for execution.
#
# This script is licensed under the CC-BY-SA Creative Commons License Version 3.0 !
# You can read about the license terms under:
#       (German) http://creativecommons.org/licenses/by-sa/3.0/deed.de
#       (English) http://creativecommons.org/licenses/by-sa/3.0/
#
# In case of modifications you have to leave the original author name an email address in this header information and the source code!
#
# history:
#
# 08.06.2009:
#       - initial release
#

import gimp
import gimpplugin
from gimpenums import *
pdb = gimp.pdb

import re

class fake_dri(gimpplugin.plugin):

    def query(self):
        gimp.install_procedure("fake_dri",
                               "This plugin fakes some kind of DRI effect...",
                               "", "Christian Nielebock", "Christian Nielebock",
                   "2008", "<Image>/Filters/Fake-DRI", "", PLUGIN,
                   [(PDB_INT32, "run_mode", "Run mode"),(PDB_IMAGE,"image","Image"),(PDB_DRAWABLE,"drawable","Drawable")], [])

    def __init__(self):
	self.radius = 50;
	self.amount = 0.4;
	self.threshold = 0;

    def fake_dri(self,run_mode,image,drawable):
	actLayer = pdb.gimp_image_get_active_layer(image)
	newLayer = actLayer.copy()
	newLayer2 = actLayer.copy()
	#pdb.gimp_drawable_set_visible(actLayer,0)
	
	pdb.gimp_image_add_layer(image,newLayer2,-1)
	pdb.gimp_image_add_layer(image,newLayer,-1)
		
	pdb.gimp_desaturate_full(newLayer,2)
	pdb.gimp_invert(newLayer)
	pdb.gimp_layer_set_mode(newLayer,19)
	pdb.gimp_image_merge_down(image,newLayer,0)
	drawable = pdb.gimp_image_get_active_layer(image)
	pdb.plug_in_unsharp_mask(image, drawable, 80, 0.4, 0)
	gimp.displays_flush()
	
if __name__ == "__main__":
    fake_dri().start()
