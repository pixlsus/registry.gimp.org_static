Save for Web plug-in for The Gimp 2.6 using RIOT (Radical Image Optimization Tool)
*************************************************************************************

******* The RIOT DLL package is required. *********
******* freely available at http://luci.criosweb.ro/riot/ **********


Radical Image Optimization Tool is a free image optimizer that will let you visually adjust compression parameters while keeping minimum filesize.

It uses a side by side (dual view) or single view interface to compare the original with the optimized image in real time.

It has a simple and easy to use interface where you will be able to control compression, number of colors, metadata settings and much more, and select image format (JPG, GIF or PNG) for your output file.

This plug-in calls RIOT for the selected area/layer.

*********************
*** Main features ***
*********************

- open multiple graphic file formats by looking first at the magic number (it does not need file extension to recognize format)including support for uncommon images types (up to 128 BPP, integer and floating point. EX: hdr images, 16 bit grayscale, etc). Adaptive logarithmic tone mapping algorithm (Drago) used for HDR images

- save and optimize JPEG, GIF and PNG with a simple, clean user interface

- works in dual view: (original - optimized image) or single view (optimized image). 
utomatic preview of resulting image

- in-place compare function (alternativelly display the original image over the optimized image to notice small pixel changes)

- compress files to desired filesize threshold

- fast processing (all is done in memory); see instant results including resulting filesize

- decide if you want to keep metadata (comments, IPTC, Adobe XMP, EXIF profiles, ICC profiles). Unsupported metadata is removed

- transfer metadata between image formats (destination format must support them)

- common tools: pan and zoom, rotate, flip

-resize image by using well known resample filters (ex: Lanczos3, Catmull Rom, Bicubic, and others)

- the compression and the results are comparable to those of commercial products.

*************************
*** Input image types ***
*************************

- common bitmap images as well as Adobe Photoshop PSD files.


********************
*** Requirements ***
********************

Microsoft Windows 2000, XP or later
The Gimp version 2.4 or later. (tested only on 2.6)

********************
*** Installation ***
********************

1) Copy riot.exe (actual GIMP plugin) to your personal plug-ins folder:

C:\Documents and Settings\<username>\.gimp-2.6\plug-ins

(Here <username> - name of your user account).

2) Download the RIOT DLL package from http://luci.criosweb.ro/riot/download/

3) Extract these files. A folder named Riot_dll will be created after extraction.

4) Copy Riot_dll\Riot.dll and Riot_dll\FreeImage.dll to your personal plug-ins folder


********************
*** Source code  ***
********************

If you want to change the program and get the source code, you can download it from http://registry.gimp.org (from the same page where you found this package).