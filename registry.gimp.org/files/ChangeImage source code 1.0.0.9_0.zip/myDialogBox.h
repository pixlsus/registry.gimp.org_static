#ifndef MYDIALOGBOX_H
#define	MYDIALOGBOX_H

#include "Document.h"


#endif