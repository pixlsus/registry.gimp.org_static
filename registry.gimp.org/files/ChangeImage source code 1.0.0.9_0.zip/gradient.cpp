#include "gradient.h"

extern HBRUSH	brBlue;
extern HBRUSH	brRed;

extern HPEN		pnRed;

gradient::gradient(void): width(1000), transparent(1000, HEIGHT), gr(1000, HEIGHT)
{
	for(UINT i = 0; i < width; i++){
		gTable.push_back(0);
		gTable.push_back(0);
		gTable.push_back(0);

		gATable.push_back(1);
	}
}

void gradient::SetGradient(std::vector<float> &v){
	if((v.size()>=2*4) && (v.size() % 4 == 0)){
		this->tSegment.clear();
		float dx = 1.f / (v.size() / 4 - 1);
		for(UINT i = 0; i < v.size() / 4 - 1; i++){
			tSegment.push_back(segment(sColor( v[i * 4], v[i * 4 + 1], v[i * 4 + 2], v[i * 4 + 3], i * dx), 
				sColor( v[(i + 1) * 4], v[(i + 1) * 4 + 1], v[(i + 1) * 4 + 2], v[(i + 1) * 4 + 3], (i + 1) * dx)));
		}
		CreateGradientVector();
	}
}

gradient::~gradient(void)
{
}

void gradient::SetWidth(UINT width){
	width = width;// - (width % 4);
	this->width = min(max(width,100),2000);

	transparent.SetWidth(this->width, HEIGHT);
	gr.SetWidth(this->width, HEIGHT);

	gTable.clear();
	gATable.clear();

	for(UINT i = 0; i < this->width; i++){
		gTable.push_back(0);
		gTable.push_back(0);
		gTable.push_back(0);

		gATable.push_back(1);
	}

	CreateGradientVector();
}

void gradient::CreateGradientVector(){
	float dk = 1.f / (width - 1);
	float p = 0;

	std::vector<BYTE>::iterator pt = gTable.begin();
	std::vector<float>::iterator pta = gATable.begin();
	
	for(std::vector<segment>::iterator i = tSegment.begin(); i < tSegment.end(); i++){
		i->CreateGradientVector(p, dk, pt, pta);
	}

	int dw = gr.bmih.biWidth % 4;

	for(int i = 0; i < this->gr.bmih.biWidth; i++){
		for(int j = 0; j < this->gr.bmih.biHeight; j++){
			gr.pBits[(i + j * gr.bmih.biWidth) * 3 + j * dw] =		BYTE(this->gTable[i * 3] * gATable[i] + this->transparent.pBits[(i + j * gr.bmih.biWidth) * 3 + j * dw] * (1. - gATable[i]));
			gr.pBits[(i + j * gr.bmih.biWidth) * 3 + 1 + j * dw] =	BYTE(this->gTable[i * 3 + 1] * gATable[i] + this->transparent.pBits[(i + j * gr.bmih.biWidth) * 3 + 1 + j * dw] * (1. - gATable[i]));
			gr.pBits[(i + j * gr.bmih.biWidth) * 3 + 2 + j * dw] =	BYTE(this->gTable[i * 3 + 2] * gATable[i] + this->transparent.pBits[(i + j * gr.bmih.biWidth) * 3 + 2 + j * dw] * (1. - gATable[i]));
		}
	}
}

void gradient::LoadFile(HINSTANCE hInst){
	dlgOpenSaveFileName o(hInst, "pliki *.ggr\0*.ggr\0\0");
	if(o.ShowOpenFileName()){
		std::fstream file(o.GetFileName(),std::ios_base::in);
        std::string s;
		if(file.fail())
			return ;
		std::getline(file, gname);
		
		if(gname.compare("GIMP Gradient")){
			file.close();
			return ;
		}
		if(file.fail())
			return ;
		std::getline(file, gname);
		
		if(gname.size() > 6u)
			gname.erase(0u, 6u);

		if(file.fail())
			return ;
		
		std::getline(file, s);

		int r = atol(s.c_str());

		for(int i = 0; i < r; i++){
			if(file.fail())
				return ;
			std::getline(file, s);
			tSegment.push_back(segment(s));
		}

		CreateGradientVector();		

		file.close();
	}
}

void gradient::LoadFile(std::string path){
	std::fstream file(path.c_str(),std::ios_base::in);
    std::string s;
	if(file.fail())
		return ;
	std::getline(file, gname);
	
	if(gname.compare("GIMP Gradient")){
		file.close();
		return ;
	}
	if(file.fail())
		return ;
	std::getline(file, gname);
	
	if(gname.size() > 6u)
		gname.erase(0u, 6u);

	if(file.fail())
		return ;
	
	std::getline(file, s);

	int r = atol(s.c_str());

	for(int i = 0; i < r; i++){
		if(file.fail())
			return ;
		std::getline(file, s);
		tSegment.push_back(segment(s));
	}

	CreateGradientVector();		

	file.close();
}

void gradient::GetPointColor(int index, float &rl, float &gl, float &bl, float &al, float &rr, float &gr, float &br, float &ar){
	if(index > -1 && index <= (int)tSegment.size()){
		if(index == 0){
			tSegment[0].GetLeftColorRGB(rl, gl, bl, al);
			rr = rl; gr = gl; br = bl; ar = al;
		}else if(index == (int)tSegment.size()){
			(tSegment.end()-1)->GetRightColorRGB(rr, gr, br, ar);
			rl = rr; gl = gr; bl = br; al = ar;
		}else{
			tSegment[index].GetLeftColorRGB(rr, gr, br, ar);
			tSegment[index - 1].GetRightColorRGB(rl, gl, bl, al);
		}
	}
}

void gradient::DrawGradientPt(HDC &hdc, POINT fp, POINT lp){
	POINT pt;
	POINT dp = lp - fp;
	for(std::vector<segment>::iterator i = tSegment.begin(); i < tSegment.end() - 1; i++){
		pt = i->SegmentOnScreen(fp,dp);
		Ellipse(hdc,pt.x - H_SIZE,pt.y - H_SIZE,pt.x + H_SIZE,pt.y + H_SIZE);
	}
}

void gradient::DrawGrPt(HDC &hdc, UINT width, UINT height,int grPtInd,int grSgInd){
	if(tSegment.size()){
		POINT pt;
		pt.y = height / 2;
		if(grSgInd > -1 && grSgInd < (int)tSegment.size() && grPtInd == -1){
			RECT r;
			SetRect(&r, int(tSegment[grSgInd].left.pos * width), 0, int(tSegment[grSgInd].right.pos * width), height);
			FillRect(hdc, &r, grSgInd == 0 ? brRed : (grSgInd == tSegment.size() - 1 ? brRed : brBlue));
		}
		for(std::vector<segment>::iterator i = tSegment.begin(); i < tSegment.end(); i++){
			pt.x = i->SegmentOnScreen(width);
			Ellipse(hdc, pt.x - H_SIZE,pt.y - H_SIZE, pt.x + H_SIZE,pt.y + H_SIZE);
			if(i == tSegment.begin()){
				Ellipse(hdc, - H_SIZE,pt.y - H_SIZE, H_SIZE,pt.y + H_SIZE);
			}
		}
		if(grPtInd > -1 && grPtInd < (int)tSegment.size() - 1){
			int x =  tSegment[grPtInd].SegmentOnScreen(width);
			SelectObject(hdc, pnRed);
			Ellipse(hdc, x - H_SIZE, pt.y - H_SIZE, x + H_SIZE, pt.y + H_SIZE);
		}
	}
}

void gradient::AddPoint(float r,float g,float b,float a,float pos){
	for(std::vector<segment>::iterator i = tSegment.begin(); i < tSegment.end(); i++){
		if(i->left.pos < pos && i->right.pos > pos){
			segment s(i->left,sColor(r, g, b, a, pos));
			*i = segment(s.right, i->right);
			tSegment.insert(i,s);
			CreateGradientVector();
			break;
		}
	}
}

void gradient::SetGradientColors(POINT fp, POINT dp, BYTE* table, int pitch){
	POINT p1;
	POINT p2;
	for(std::vector<segment>::iterator i = tSegment.begin(); i < tSegment.end(); i++){
		p1 = fp + dp * i->left.pos;
		p2 = fp + dp * i->right.pos;
		*i = segment(sColor( (float)table[p1.x * 3 + p1.y * pitch + 2] / 255.f, (float)table[p1.x * 3 + p1.y * pitch + 1] / 255.f, (float)table[p1.x * 3 + p1.y * pitch] / 255.f,1.f,i->left.pos),
				sColor( (float)table[p2.x * 3 + p2.y * pitch + 2] / 255.f, (float)table[p2.x * 3 + p2.y * pitch + 1] / 255.f, (float) table[p2.x * 3 + p2.y * pitch] / 255.f,1.f,i->right.pos));
	}
	CreateGradientVector();
}

void gradient::SetGradientColors32(POINT fp, POINT dp, BYTE* table, int pitch){
	POINT p1;
	POINT p2;
	for(std::vector<segment>::iterator i = tSegment.begin(); i < tSegment.end(); i++){
		p1 = fp + dp * i->left.pos;
		p2 = fp + dp * i->right.pos;
		*i = segment(sColor( (float)table[p1.x * 4 + p1.y * pitch + 2] / 255.f, (float)table[p1.x * 4 + p1.y * pitch + 1] / 255.f, (float)table[p1.x * 4 + p1.y * pitch] / 255.f,(float) table[p1.x * 4 + p1.y * pitch + 3] / 255.f,i->left.pos),
				sColor( (float)table[p2.x * 4 + p2.y * pitch + 2] / 255.f, (float)table[p2.x * 4 + p2.y * pitch + 1] / 255.f, (float) table[p2.x * 4 + p2.y * pitch] / 255.f,(float) table[p2.x * 4 + p2.y * pitch + 3] / 255.f,i->right.pos));
	}
	CreateGradientVector();
}

int gradient::MouseInPt(POINT mp,POINT fp,POINT dp, double scale){
	POINT p1;
	POINT p2;
	scale = H_SIZE * H_SIZE / scale;
	for(std::vector<segment>::iterator i = tSegment.begin(); i < tSegment.end(); i++){
		p1 = fp + dp * i->left.pos;
		p2 = fp + dp * i->right.pos;
		if((p1 - mp) * (p1 - mp) <= scale){
			return (int)(i - tSegment.begin());
		}
		if((p2 - mp) * (p2 - mp) <= scale){
			return (int)(i - tSegment.begin()) + 1;
		}
	}
	return -1;
}

void gradient::FindGrPtAndSegmentIndex(int &grPtInd, int &grSgInd,int x,int width,int ray){
	grSgInd = grPtInd = -1;
	if(grSgInd == -1 && tSegment.size()){
		std::vector<segment>::iterator i = tSegment.begin();
		if(i->left.pos * width - ray < x && i->left.pos * width + ray > x){
			grPtInd = -2;
			return ;
		}
		i = tSegment.end() - 1;
		if(i->right.pos * width - ray < x && i->right.pos * width + ray > x){
			grPtInd = -3;
			return ;
		}
	}
	for(std::vector<segment>::iterator i = tSegment.begin(); i < tSegment.end(); i++){
		if(i->right.pos * width > x && x > i->left.pos * width){
			grSgInd = (int)(i - tSegment.begin());
			if(grPtInd != -1)
				return;
		}
		if(i->right.pos * width - ray < x && i->right.pos * width + ray > x && i != tSegment.end() - 1){
			grPtInd = (int)(i - tSegment.begin());
			if(grSgInd != -1)
				return;
		}
	}
}

void gradient::DeletePoint(int selPt){
	if(selPt && selPt < (int)tSegment.size()){
		tSegment[selPt - 1] = segment(tSegment[selPt - 1].left, tSegment[selPt].right);
		tSegment.erase(tSegment.begin() + selPt);
		CreateGradientVector();
	}
}

std::string gradient::GradientToString(){
	std::string s;
	for(std::vector<segment>::iterator i = tSegment.begin(); i < tSegment.end(); i++){
		s += i->SegmentToString(i == tSegment.end() - 1 ? true:false);
	}
	return s;
}

std::string RemSign(std::string s, const char* sign){
	std::basic_string <char>::size_type i = s.find_first_of(sign, 0);
	while(i != std::string::npos){
		s.erase(i, 1);
		i = s.find_first_of(sign, 0);
	}
	return s;
}

std::string gradient::GetSvgGradientString(std::string idS){
	std::string s;
	s = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<!-- Created with Inkscape (http://www.inkscape.org/) -->\n\n";
	s += "<svg";
	s += char(10);
	s += "xmlns:dc=\"http://purl.org/dc/elements/1.1/\"";
	s += char(10);
	s += "xmlns:cc=\"http://creativecommons.org/ns#\"";
	s += char(10);
	s += "xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"";
	s += char(10);
	s += "xmlns:svg=\"http://www.w3.org/2000/svg\"";
	s += char(10);
	s += "xmlns=\"http://www.w3.org/2000/svg\"";
	s += char(10);
	s += "xmlns:xlink=\"http://www.w3.org/1999/xlink\"";
	s += char(10);
	s += "xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\"";
	s += char(10);
	s += "xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"";
	s += char(10);
	s += "width=\"744.09448819\"";
	s += char(10);
	s += "height=\"1052.3622047\"";
	s += char(10);
	s += "id=\"svg2\"";
	s += char(10);
	s += "version=\"1.1\"";
	s += char(10);
	s += "inkscape:version=\"0.48.0 r9654\"";
	s += char(10);
	s += "sodipodi:docname=\"Nowy dokument 1\">";
	s += "<defs";
	s += char(10);
	s += "id=\"defs4\">";
	s += char(10);

	s += "<linearGradient";
	s += char(10);
	s += "inkscape:collect=\"always\"";
	s += char(10);
	s += "id=\"";
	s += this->gname.size() ? RemSign(gname," #") : RemSign(idS," #");
	s += "\">";
	s += char(10);

	int id = 0;

	s += tSegment[0].left.GetSvgString(id);
	for(int i = 0; i < tSegment.size() - 1; i++){
		s += tSegment[i].right.GetSvgString(id);
		if(!(tSegment[i].right == tSegment[i + 1].left)){
			s += tSegment[i + 1].left.GetSvgString(id);
		}
	}
	s += (tSegment.end()-1)->right.GetSvgString(id);

	s += "</linearGradient>";
	s += char(10);

	s += char(10);
	s += "</defs>";
	s += char(10);

	s += "<sodipodi:namedview";
	s += char(10);
	s += "id=\"base\"";
	s += char(10);
	s += "pagecolor=\"#ffffff\"";
	s += char(10);
	s += "bordercolor=\"#666666\"";
	s += char(10);
	s += "borderopacity=\"1.0\"";
	s += char(10);
	s += "inkscape:pageopacity=\"0.0\"";
	s += char(10);
	s += "inkscape:pageshadow=\"2\"";
	s += char(10);
	s += "inkscape:zoom=\"0.98994949\"";
	s += char(10);
	s += "inkscape:cx=\"210.46193\"";
	s += char(10);
	s += "inkscape:cy=\"780.98887\"";
	s += char(10);
	s += "inkscape:document-units=\"px\"";
	s += char(10);
	s += "inkscape:current-layer=\"layer1\"";
	s += char(10);
	s += "showgrid=\"false\"";
	s += char(10);
	s += "inkscape:window-width=\"1440\"";
	s += char(10);
	s += "inkscape:window-height=\"820\"";
	s += char(10);
	s += "inkscape:window-x=\"-8\"";
	s += char(10);
	s += "inkscape:window-y=\"-8\"";
	s += char(10);
	s += "inkscape:window-maximized=\"1\" />";
	s += char(10);

	s += "<metadata";
	s += char(10);
	s += "id=\"metadata7\">";

	s += "<rdf:RDF>";
	s += "<cc:Work rdf:about=\"\">";
    s += "<dc:format>image/svg+xml</dc:format>";
    s += "<dc:type rdf:resource=\"http://purl.org/dc/dcmitype/StillImage\" />";
	s += "<dc:title />";
	s += "</cc:Work>";
    s += "</rdf:RDF>";
	s += "</metadata>";
	s += "<g inkscape:label=\"Layer 1\" inkscape:groupmode=\"layer\" id=\"layer1\">";
	s += "<rect style=\"color:#000000;fill:url(#";
	s += this->gname.size() ? RemSign(gname," #") : RemSign(idS," #");
	s += ");fill-opacity:1;fill-rule:nonzero;stroke:none;stroke-width:2;marker:none;visibility:visible;display:inline;overflow:visible;enable-background:accumulate\" id=\"rect2985\" width=\"100\" height=\"100\" x=\"0\" y=\"0\" />";
	s += "</g>";
	s += "</svg>";

	return s;
}

std::string gradient::GetSvgGradientDefinition(std::string idS){
	std::string s;

	s = "<linearGradient";
	s += char(10);
	s += "inkscape:collect=\"always\"";
	s += char(10);
	s += "id=\"";
	s += this->gname.size() ? RemSign(gname," #") : RemSign(idS," #");
	s += "\">";
	s += char(10);

	int id = 0;

	s += tSegment[0].left.GetSvgString(id);
	for(int i = 0; i < tSegment.size() - 1; i++){
		s += tSegment[i].right.GetSvgString(id);
		if(!(tSegment[i].right == tSegment[i + 1].left)){
			s += tSegment[i + 1].left.GetSvgString(id);
		}
	}
	s += (tSegment.end()-1)->right.GetSvgString(id);

	s += "</linearGradient>";
	s += char(10);

	return s;
}

std::string gradient::GetSvgGradientObject(std::string idS, int idR, int x, int y, int height, int width){
	std::string s;

	char c[100];

	sprintf(c, "%i", idR);

	s = "<rect style=\"color:#000000;fill:url(#";
	s += this->gname.size() ? RemSign(gname," #") : RemSign(idS," #");
	s += ");fill-opacity:1;fill-rule:nonzero;stroke:none;stroke-width:2;marker:none;visibility:visible;display:inline;overflow:visible;enable-background:accumulate\" id=\"rect";
	s += c;
	s += "\" width=\"";
	sprintf(c, "%i", width);
	s += c;
	s += "\" height=\"";
	sprintf(c, "%i", height);
	s += c;
	s += "\" x=\"";
	sprintf(c, "%i", x);
	s += c;
	s += "\" y=\"";
	sprintf(c, "%i", y);
	s += c;
	s += "\" />";
	s += char(10);

	return s;
}

void gradient::MoveSegment(float dx,int index){
	if(index < 1 || index > (int)tSegment.size() - 1)
		return;
	if(dx > 0){
		dx = min(tSegment[index + 1].right.pos - tSegment[index].right.pos, dx);
	}else if(dx < 0){
		dx = max(tSegment[index - 1].left.pos -  tSegment[index].left.pos, dx);
	}
	tSegment[index].left.pos += dx;
	tSegment[index].center.pos += dx;
	tSegment[index].right.pos += dx;
	tSegment[index + 1].SetLeftPos(tSegment[index + 1].left.pos + dx);
	tSegment[index - 1].SetRightPos(tSegment[index - 1].right.pos + dx);
}