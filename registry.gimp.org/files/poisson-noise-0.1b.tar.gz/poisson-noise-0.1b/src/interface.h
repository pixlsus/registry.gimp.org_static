/* 
 * Poisson noise GIMP plugin
 * 
 * interface.h
 * Copyright 2008 by Marco Rossini
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2+
 * as published by the Free Software Foundation.
 */

#include "plugin.h"

/* declare all widgets global to make things a lot easier */

/* colour mode frame */
GtkWidget *lum_toggle;

/* amount/radius frame */
GtkWidget *photon_label, *photon_spin;
GtkWidget *photon_hbox, *photon_vbox, *photon_scale;
GtkObject *photon_adj;

/* reset buttons */
GtkWidget *reset_button, *button_hbox;

/* dialog */
GtkWidget *dialog, *dialog_vbox;
GtkWidget *preview;
