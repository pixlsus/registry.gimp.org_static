#!/usr/bin/env python
# Studio Tecnico Arch. Giuseppe Conte  
# via Roma, 28
# 72026 - San Pancrazio Salentino (BR) - Italy
#
# Plugin  : print_layers.py
# Author  : Arch. Giuseppe Conte 
# Date    : 10 ottobre 2011 
# Revision: 
# Version : 1.0
# Last version at: http://xoomer.alice.it/lwcon/gimp/
# Help guide at  : http://xoomer.alice.it/lwcon/python/py_print_layers.htm
#
# Dependencie: 
# Download   : http://xoomer.alice.it/lwcon/gimp/python/py_print_layers.htm
#
# Description: 
# Print all layers from active image.
# -----------------------------------------------------------------------------
#
# License:
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
# -----------------------------------------------------------------------------
#

from gimpfu import *
import os.path
import pygtk
import gtk

# something to help with debugging
def debugMessage(Message):
    dialog = gtk.MessageDialog(None, 0, gtk.MESSAGE_INFO, gtk.BUTTONS_OK, Message)
    dialog.run()
    dialog.hide()

# unique_filename from http://stackoverflow.com/questions/183480/is-this-the-best-way-to-get-unique-version-of-filename-w-python
def unique_filename(file_name):
    counter = 1
    file_name_parts = os.path.splitext(file_name) # returns ('/path/file', '.ext')
    while os.path.isfile(file_name):
      file_name = file_name_parts[0] + '_' + str(counter) + file_name_parts[1]
      counter += 1
    return file_name

# this is the bit that does all the work
def print_layers(img):
    layer_ids = img.layers                         # get the layers in the image
    directory_name = os.path.dirname(img.filename) # where is the source image
   
#    debugMessage(directory_name)
   
    num_layers = len(layer_ids)   
    for x in range (0, num_layers):
      pdb.gimp_drawable_set_visible(layer_ids[x], FALSE)
      
                    
    for layer_num in range (0, num_layers):        # work through layers (change to "num_layers-1" if you don't want the bottom layer)
      layer_name = pdb.gimp_drawable_get_name(layer_ids[layer_num]) 
#      debugMessage(layer_name)
     
      # replace any illegal characters to be on the safe side
      layer_name = layer_name.replace(":", ";")
      layer_name = layer_name.replace("/", ";")
      layer_name = layer_name.replace("\\", ";")
      layer_name = layer_name.replace("?", ";")
      layer_name = layer_name.replace("*", ";")
      layer_name = layer_name.replace("\"", ";")
     
#      debugMessage(layer_name)

      # build the new file path - puts the saved layers in the same place as the source image
      png_file = os.path.join(directory_name, layer_name + ".png")
      png_file = unique_filename(png_file)

#      debugMessage(png_file)     
      #pdb.file_png_save2(img, layer_ids[layer_num], png_file, png_file, 1, 9, 1, 1, 0, 1, 1, 1, 1)
      pdb.gimp_drawable_set_visible(layer_ids[layer_num], TRUE)
      #pdb.gimp_image_set_active_layer(img,layer_ids[layer_num])
      pdb.file_print_gtk(img, run_mode=1)
      pdb.gimp_drawable_set_visible(layer_ids[layer_num], FALSE)
      
    for x in range (0, num_layers):
      pdb.gimp_drawable_set_visible(layer_ids[x], TRUE)      

      # The End of the main routine


# menu registration
register(
    "py_print_layers",
    N_("Print all layers"),
    N_("Print all layers"),
    "Giuseppe Conte",
    "Giuseppe Conte",
    "2011",
    "Print layers",
    "",
    [
    (PF_IMAGE, "image", "Input image", None),
    ],
    [],
    print_layers,
    menu="<Image>/Python-Fu/ATG/"
    )

main()
