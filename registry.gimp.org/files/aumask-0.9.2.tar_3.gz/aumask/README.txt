ADVANCED UNSHARP MASK (Sharpening Tool) - gimp plugin
(current development version 0.9.2, stable version 0.9.0)

The purpose of this tool to provide user more control over sharpening. First intended part was 'sharpness equalizer' that would operate over blurred mask.
There are two basic modes of blurring the original image - standard and selective blur (with treshold).
Also, brightness can be modified via spinbuttons, but note, that this works with blur mask and affects image only indirectly. Benefit of this is preservation of local contrast (allways depends on the type of mask).
You can also pick what channel it should operate over - either own brightness, or Value from HSV or Luminosity from HSL.
The plugin has an option to keep values withing the range during sharpening.
The result can be exported also to new layer (without terminating the plugin)

To work with this tool you must have some basic understanding of what are you doing and how things works.

For more up-to-date description visit: http://code.google.com/p/aumask/wiki/Introduction

INSTALATION (on Linux and perhaps other unix-like OS):

plugin is distributed as C code; download and unpack *.tgz file and go to directory where aumask.c is located.
Then run:
 gimptool-2.0 --install aumask.c
and for system-wide installation (as root):
 gimptool-2.0 --install-admin aumask.c

In addition to gcc you will need 'gimptool-2.0' package - search your distribution repositories for the package.

Installation on windows - visit http://registry.gimp.org/node/25326 and check discussion below, there tend to be links to windows packages

USAGE:
Plugin is to be found as FILTERS->Enhance->AUMASK Sharpening

Note that during processing, all (RGB) pixel values are converted from 0-255 range to 0-1 range, so in this way you must understand values in spinboxes.

BUGS and SHORTCOMINGS (in regard to stable version - 0.9):
There are no significant bugs in 0.9.1 I know of.


CHANGELOG:
0.9.2 - bugfix (export-to-layer mode on image with alpha channel)
0.9.1 - out-of-range protection removed (the better approach would be to export an additional darker/lighter layer and manualy blend layers where needed)
	  - GUI rework (including coupling of sliders)
	  - Under the hood changes
0.9.0 - prograss bar-related changes
      - code housekeeping
      - mouse-over tips enhanced
0.8.3 - export to layer function added
      - some polish 
0.8.2 - few mouse-over hints added
      - under the hood changes (quite a lot)
0.8.1 - blurring algorithm changed
	  - out-of-range protection via slider added to replace checkbox
	  - plugin layout (GUI) reworked
	  - mask export enhanced 
	  - temporarily export to new layer does not work (eliminated from GUI as well)
	  - really development version
0.8   - no significant change to 0.7.6
0.7.6 - Further work on GUI
      - fixing bug in threading, when last column might not be processes (visible as black line on the right side of the preview 
0.7.5 - GUI reworked (the work is not finished yet)
0.7.4 - change in brightness adjustments ranges, now dark point can be increased to 0.7, and light point decreased to 0.5 
0.7.3 - exporting of mask and differences (mask vs. image) to separate layer added. Development version
0.7.2 - the same as 0.7.1, just marked as stable
0.7.1 - multithreading support added (3 threads by default)
0.7   - wording in plugin window changed on same labels 
      - (no inner changes)
0.7-rc- reworked blurring algorihm (simplified logic behind it)
      - button to preserver dark and light areas against oversharpeing our of image range
0.6.6 - bugfix, I hope alpha channel finally works
	  - third mode in preview - "half" (half preview is original, socend half is changed)
	  - code clean-up and enhancements
0.6.5 - support for HSV and HSL colorspaces - value and luminosity is used as mask channel
	  - support for alpha channel
	  - when calculating preview, it considers also near area around what is visible in preview window
0.6.4 - resizeable preview (increase window of plugin, preview will adjust)
	  - selective mask was enhanced
0.6.3 - reset button added
	- selective mask bit enhanced (needs much more tweaking)
	- few GUI modifications 
0.6.2 - blur masking reworked, now much faster
0.5 is the first version out.


CONTACT:
Any feedback welcomed: tiborb95 at gmail dot com

June 14, 2012
