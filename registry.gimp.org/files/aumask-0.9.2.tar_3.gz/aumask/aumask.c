//Advanced unsharp mask - sharpening tool
//gimp plugin
//to install (on linux):
//for user (compile as user):
// gimptool-2.0 --install aumask.c
//and for system-wide installation (compile as root):
// gimptool-2.0 --install-admin aumask.c
//contact: tiborb95 at gmail dot com,
//To discuss or for windows binaries visit http://registry.gimp.org/node/25326
//any feedback welcomed


#define VERSION 0.9.2
#define THREADS 3		//edit here to change number of threads; guchar !
#define VERBOSE FALSE
#define DEBUG FALSE
#define DEBUGKILL FALSE
#define MAXRADIUS 500
#define TRESHDEF 0.2
#define RADIUSDEF 20
#define POSTRADIUSDEF 3
#define MASKBOOSTDEF 2.0
#define MASKPOSDEF 0.5
#define RESPONSE_RESET   99
#define RESPONSE_OK      1
#define BASEPOS(x,y,ch,width) ch*y*width + ch*x
#define BACK_TO_INT(x) MAX(MIN(ROUND(pow(x,2.2)*255),255),0)
#define KEEP_WITHIN_0_1(x) MAX(MIN(x,1.0),0.0)
#define ITERATE(x,start,end) for(x=start;x<end;x++)
#define ITERATE_DOWN(x,start,end) for(x=start-1;x>=end;x--)
#define SUM_ARR(array,iterator,items,sum) sum=0;for (iterator=0;iterator<items;iterator++) {sum=sum+array[iterator];}
#define BRIGHT(R,G,B) 0.299*R + 0.587*G + 0.114*B
#define BRIGHT_OWN 100
#define HSV 101
#define HSL 102
#define RCHAN 103
#define GCHAN 104
#define BCHAN 105
#define P_STANDARD 10
#define P_MASK 11
#define P_HALF 12
#define NORMAL 0
#define SELBLUR 1
#define POSTBLUR 2
//#define SET_INACTIVE(toggle_button) gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON(toggle_button),FALSE)
#define ALIGNINTEND 15
#define BOXSPACING 2
#define UPINTEND 26
#define DOWNINTEND 6
#define VBOXBORDER 8
#define HBOXSPACING 12
#define BLURSTEPS 15    //guchar !!
#define DOMASK1START 0.1
#define DOMASK1END 0.6
//#define NORMAL 0 defined above as 0
#define MASK 1
#define HALFMODE 2
#define MASKDIFF 3 
#define SLIDERS 4
#define VTABLESPACING 10



#include <libgimp/gimp.h>
#include <gtk/gtk.h>
#include <stdio.h>
#include <libgimp/gimpui.h>
#include <string.h>
#include <stdlib.h> //temporary
#include <unistd.h> // for sleep



//functions
static void query (void);
static void run   (const gchar      *name,
                   gint              nparams,
                   const GimpParam  *param,
                   gint             *nreturn_vals,
                   GimpParam       **return_vals);

static void sharpen (GimpDrawable *source,GimpPreview *preview);
static gboolean sharp_dialog (GimpDrawable *source);
void  cb_changed( GtkComboBox *combo, gpointer data ) ;
void  cb2_changed( GtkComboBox *combo2, gpointer data ) ;
void  cb3_changed( GtkComboBox *combo3, gpointer data ) ;
gfloat do_main_pixel(gint x, int width,gint y,int height);
void populate_rect_in();
static void 	do_mask3(gfloat *rect_in,gfloat *rect_out,gint radius,gfloat treshold);
static void response_callback (GtkWidget *widget,  gint response_id);
static int round_to_int(gfloat number);
void get_new_RGB3 (gint basepos_1,gint basepos_3,gint basepos_In,gint basepos_Out,gint x,gint id);
void *do_mask_thread(void *arg);
void *do_final_thread(void *arg);
void sharpen_wrapper_m (GimpDrawable *source);
inline gint get_basepos(gint x, gint y,gint ch, gint width);
void export_to_layer();
void exportwrapper (GimpDrawable *source);
float get_new_sharp (float oldsharp);

//global variables
struct GimpRGB {
  gdouble r, g, b, a;
};
struct GimpHSV {
  gdouble h, s, v, a;
};
struct GimpHSL {
  gdouble h, s, l, a;
};
typedef struct
{
	gfloat boost[SLIDERS+1];
	gfloat borders[SLIDERS+2];
	guint radius;
	guint postradius;
	gfloat tresh;
	gfloat newdark,newlight; //for remapping 0 and 1 points
	guint blurmode;			//type of blur /selective or not/
	guint colormode;
	guchar channels;
	guchar outchannels; //if exporting mask, number of channels is allways 3, while source might have 4
	gfloat mask_boost;
	gfloat mask_pos;
	gint action;
	gboolean exportlayer;
	gboolean previewbool;
	guint width;
	guint height;
	guint x_half;

} MySharpVals;
static MySharpVals maindata = { {1.0,1.0,1.0,1.0,1.0},{0,0.0075,0.03,0.07,0.2,1.1},RADIUSDEF,POSTRADIUSDEF,TRESHDEF,0,1,NORMAL, BRIGHT_OWN,3,3,MASKBOOSTDEF,MASKPOSDEF,NORMAL,FALSE } ;
typedef struct
{
	gint x_relbasepos;
	gint y_relbasepos;
	gint x_rel[201]; 
	gint y_rel[201]; 
	guchar circle_points;
} MyCircleVals;
static MyCircleVals circledata;

typedef struct {
	guint startline;
	guint endline;
	guint id;
	//gint step;
	//gint relbasepos[8];
	gfloat* source;
	gfloat* target;
	guint radius;
	gfloat treshold;
	guint basepos_end; //x*y of image as basepos
	gboolean finalcheck;
	gfloat totaltresh; //for last step to trim values
} packer;
static packer threaddata[THREADS];

//static packer package[THREADS];
static GimpRGB RGBstruct[THREADS];
static GimpHSL HSLstruct[THREADS];
static GimpHSV HSVstruct[THREADS];

const static gchar *mode1 = "Standard blur (no treshold)";
const static gchar *mode2 = "Selective blur (treshold)";
const static gchar *mode3 = "Selective with postblur";
const static gchar *amode1= "Standard (Image)"; 
const static gchar *amode2= "Mask"; 
const static gchar *amode3= "Split (comparison)"; 
const static gchar *amode4= "Difference (Mask-to-Img)";
const static gchar *colormode1 = "Brightness 0.299/0.587/0.114";
const static gchar *colormode2 = "Value in HSV";
const static gchar *colormode3 = "Lightness in HSL";
const static gchar *colormode4 = "R to brightness";
const static gchar *colormode5 = "G to brightness";
const static gchar *colormode6 = "B to brightness";
const static gchar *title= "Advanced Unsharp Mask (v. 0.9.2)";
const static gchar *selectivehelp="Use this to soften edges on the selective mask. To be effective select the \"Selective with postblur\" above.";
static gfloat		gammed_values[256]; //to be used for fast conversion 
								//from raw RGB to gammed 0-1 values
static GtkWidget *slider0,*slider1,*slider2,*slider3;
static GtkWidget *spin_radius,*spin_dark,*spin_light,*spin_tresh,*spin_mask_boost,*spin_mask_pos,*spin_postrad;
static GtkWidget *combo,*combo2,*combo3;

static glong initialized=0;
static gfloat *rect_in; // rect_in_guchar in gammed values
static gfloat *rect_tmp1;
static gfloat *rect_tmp2;
static gfloat *rect_out; // final image in gammed values
static gfloat *rect_post; //to bu used for postblur
static guchar *rect_in_guchar;
static guchar *rect_out_guchar;	

gboolean process_image = FALSE;
static  GtkObject *slider0_adj,*slider1_adj,*slider2_adj,*slider3_adj,*mask_boost_adj,*mask_pos_adj;
static  GtkObject *spin_light_adj,*spin_dark_adj;
static  GtkObject *radius_adj,*tresh_adj,*postrad_adj;
static GThread *gth[THREADS];
gint32 image_ID,drawable_ID;
GimpDrawable* new_layer;
gfloat progrange[2]; // to limit range for progress bar during some operations
static gint sliders[]={0,1,2,3,4};
static gint rangestat[]={0,0,0,0,0,0};

GimpPlugInInfo PLUG_IN_INFO = { NULL, NULL, query, run};


MAIN()


static void
query (void)
{
  static GimpParamDef args[] =
  {
    { GIMP_PDB_INT32,"run-mode", "Run mode" },
    { GIMP_PDB_IMAGE,"image","Input image"  },
    { GIMP_PDB_DRAWABLE,"drawable","Input drawable" }
  };

  gimp_install_procedure (
    "plug-in-aumask",
    "Advanced Unsharp Mask",
    "Advanced Sharpening v 0.9.2. Tool to sharpen image i.e. - modify local\
    contrast, adds few enhancements to basic unsharp mask as packed with GIMP by default.",
    "Tibor Bamhor",
    "Copyright Tibor Bamhor",
    "2011",
    "_AUMASK sharpening",
    "RGB*",
    GIMP_PLUGIN,
    G_N_ELEMENTS (args), 0,
    args, NULL);

  gimp_plugin_menu_register ("plug-in-aumask",
                             "<Image>/Filters/Enhance");
}

static void
run (const gchar      *name,
     gint              nparams,
     const GimpParam  *param,
     gint             *nreturn_vals,
     GimpParam       **return_vals)
{
  static GimpParam  values[1];
  GimpPDBStatusType status = GIMP_PDB_SUCCESS;
  //GimpRunMode       run_mode;
  GimpDrawable     *drawable; //<- original layer


  image_ID = param[1].data.d_image; //<- zistujem imageID
  if (VERBOSE) printf("Image ID is: %d\n", image_ID);  


  /* Setting mandatory output values */
  *nreturn_vals = 1;
  *return_vals  = values;

  values[0].type = GIMP_PDB_STATUS;
  values[0].data.d_status = status;

  /* Getting run_mode - we won't display a dialog if
   * we are in NONINTERACTIVE mode
   */
  //run_mode = param[0].data.d_int32;

  // getting original drawable
  drawable = gimp_drawable_get (param[2].data.d_drawable);
  
  //make sure g_thread is supported
 	if( !g_thread_supported() )  g_thread_init(NULL);
 	if( !g_thread_supported() ) {
     	printf("AUMASK: g_thread NOT supported\n");
     	exit (1);}


  //starting GUI - sharp_dialog;
   if (! sharp_dialog (drawable)) return; //if it fails, plugin terminates
  
  //sharpening
  sharpen (drawable, NULL);
 
  gimp_displays_flush ();
  gimp_drawable_detach (drawable);

  return;
}

void exportwrapper (GimpDrawable *source){ 
	maindata.exportlayer=TRUE;
	sharpen (source,NULL);
	maindata.exportlayer=FALSE;	}

void  cb_changed( GtkComboBox *combo, gpointer data ) {
    
    //changes blur mode (1- standard,2-selective,3-RGB selective)
    if ( strncmp( gtk_combo_box_get_active_text( combo ), mode1,25) == 0) {
    	maindata.blurmode=NORMAL;
    	gtk_widget_set_sensitive(spin_tresh,FALSE);
		gtk_widget_set_sensitive(spin_postrad,FALSE);
    	}
    if ( strncmp((gtk_combo_box_get_active_text( combo )),mode2,25) == 0) {
    	maindata.blurmode=SELBLUR;
     	gtk_widget_set_sensitive(spin_tresh,TRUE);
		gtk_widget_set_sensitive(spin_postrad,FALSE);   	}
    if ( strncmp((gtk_combo_box_get_active_text( combo )),mode3,25) == 0) {
    	maindata.blurmode=POSTBLUR;
      	gtk_widget_set_sensitive(spin_tresh,TRUE);
		gtk_widget_set_sensitive(spin_postrad,TRUE);     	}

    if (VERBOSE) printf( "cb_changed: Changing type of mask to %d\n",maindata.blurmode );
}

inline gint get_basepos(gint x, gint y,gint ch, gint width){
	return ch*y*width + ch*x;}


void  cb2_changed( GtkComboBox *combo2, gpointer data ) {
    
    //changes channel and colormode
    if ( strncmp( gtk_combo_box_get_active_text( combo2 ), colormode1,25) == 0) {
    	maindata.colormode=BRIGHT_OWN;}
    if ( strncmp((gtk_combo_box_get_active_text( combo2 )),colormode2,25) == 0) {
    	maindata.colormode=HSV;}
    if ( strncmp((gtk_combo_box_get_active_text( combo2 )),colormode3,25) == 0) {
    	maindata.colormode=HSL;}
    if ( strncmp( gtk_combo_box_get_active_text( combo2 ), colormode4,25) == 0) {
    	maindata.colormode=RCHAN;}
    if ( strncmp((gtk_combo_box_get_active_text( combo2 )),colormode5,25) == 0) {
    	maindata.colormode=GCHAN;}
    if ( strncmp((gtk_combo_box_get_active_text( combo2 )),colormode6,25) == 0) {
    	maindata.colormode=BCHAN;}
    if (VERBOSE) printf( "cb2_changed: Changing channel&colorspace to %d\n",maindata.colormode );
}

void  cb3_changed( GtkComboBox *combo3, gpointer data ) {
    
    //changes channel and colormode
    if ( strncmp( gtk_combo_box_get_active_text( combo3 ), amode1,4) == 0) {
    	maindata.action=NORMAL;}
    if ( strncmp((gtk_combo_box_get_active_text( combo3 )),amode2,4) == 0) {
    	maindata.action=MASK;}
    if ( strncmp((gtk_combo_box_get_active_text( combo3 )),amode3,4) == 0) {
    	maindata.action=HALFMODE;}
    if ( strncmp((gtk_combo_box_get_active_text( combo3 )),amode4,4) == 0) {
    	maindata.action=MASKDIFF;}

    if (VERBOSE) printf( "cb3_changed: Changing actiontype to %d\n",maindata.action );
}

void slider_update (GtkAdjustment *adjustment,int *slider) {

	gint c; 			//iterator
	gfloat max_diff;	//content of spinbox
	const gboolean debug=FALSE;
	
	if (debug) printf (" Running slider_update\n");
	
	//setting value from actual slider
	maindata.boost[*slider]=gtk_adjustment_get_value  (adjustment);
	max_diff=0.3;
	//max_diff=gtk_adjustment_get_value((GtkAdjustment*) spin_maxdiff_adj);
	
	if (VERBOSE) printf ("value for slider %.d: %.3f\n", *slider,gtk_adjustment_get_value  (adjustment));
	//if (maindata.coupled == UNCOUPLED) return;
	
	//there are 6 values (and 4 sliders) in total
	//here we will start from current slider and go on upward and downward
	//going upward
	for (c= *slider;c<4;c++) {
		//printf ("Doing slider %.d\n",c);
		if (maindata.boost[c+1]>maindata.boost[c]+max_diff) maindata.boost[c+1]=maindata.boost[c]+max_diff;
		if (maindata.boost[c+1]<maindata.boost[c]-max_diff) maindata.boost[c+1]=maindata.boost[c]-max_diff;
		}
	//going downward	
	for (c= *slider;c>=0;c--) {
		//printf ("Doing slider %.d\n",c);
		if (maindata.boost[c-1]>maindata.boost[c]+max_diff) maindata.boost[c-1]=maindata.boost[c]+max_diff;
		if (maindata.boost[c-1]<maindata.boost[c]-max_diff) maindata.boost[c-1]=maindata.boost[c]-max_diff	;	}
		
		//now variables are set is stavals.boost, but we need to update sliders
		gtk_adjustment_set_value((GtkAdjustment*) slider0_adj,maindata.boost[0]);
		gtk_adjustment_set_value((GtkAdjustment*) slider1_adj,maindata.boost[1]);
		gtk_adjustment_set_value((GtkAdjustment*) slider2_adj,maindata.boost[2]);
		gtk_adjustment_set_value((GtkAdjustment*) slider3_adj,maindata.boost[3]);
	
	}

gfloat get_new_sharp (float oldsharp) {
	gfloat sharpboost,weight;
	guchar i;
	const gboolean debug=FALSE;
	
	if (oldsharp <0) {oldsharp=-1*oldsharp;}
	
	//iterating over values
	for (i=0;i<SLIDERS+1;i++) {
		if (oldsharp<maindata.borders[i+1]) {
			weight=(oldsharp-maindata.borders[i])/(maindata.borders[i+1]-maindata.borders[i]);
			sharpboost=( maindata.boost[i] * (1-weight) +  maindata.boost[i+1] * weight);
			if (debug) rangestat[i]+=1;
			return sharpboost;}}
	if (debug) printf (" Warning: Returning default value for oldsharp: %.3f\n", oldsharp);

	return 1;} //this should not happen


void populate_rect_in(){
	//this get data from rec_in,calculates brightness and insert results to rect_in, layer 0
	gfloat R,G,B;
	guint x,y;
	guint basepos_m,basepos_I;
	float avg;
	const gboolean debug=FALSE;
	
	ITERATE(y,0,maindata.height) { ITERATE(x,0,maindata.width) {
		basepos_m=BASEPOS(x,y,1,maindata.width);
		basepos_I=BASEPOS(x,y,maindata.channels,maindata.width);
		
		if (maindata.colormode == BRIGHT_OWN) {
			R=gammed_values[rect_in_guchar[basepos_I]];
			G=gammed_values[rect_in_guchar[basepos_I+1]];
			B=gammed_values[rect_in_guchar[basepos_I+2]];;	
			avg = BRIGHT(R,G,B);
			rect_in[basepos_m]=avg;}
			
		else if (maindata.colormode == HSV) {
			RGBstruct[0].r=rect_in_guchar[basepos_I]/255.0;
			RGBstruct[0].g=rect_in_guchar[basepos_I+1]/255.0;
			RGBstruct[0].b=rect_in_guchar[basepos_I+2]/255.0;
			gimp_rgb_to_hsv (&RGBstruct[0],&HSVstruct[0]);
			//printf ("Populating HSV with %.3f\n", HSVstruct[0].v);
			rect_in[basepos_m]=HSVstruct[0].v;}
			
		else if (maindata.colormode == HSL) {
			RGBstruct[0].r=rect_in_guchar[basepos_I]/255.0;
			RGBstruct[0].g=rect_in_guchar[basepos_I+1]/255.0;
			RGBstruct[0].b=rect_in_guchar[basepos_I+2]/255.0;
			gimp_rgb_to_hsl (&RGBstruct[0],&HSLstruct[0]);
			//printf ("HSV - value %.3f\n",HSVstruct.v);
			rect_in[basepos_m]=HSLstruct[0].l;}
			
		else if (maindata.colormode == RCHAN) {
			rect_in[basepos_m]=gammed_values[rect_in_guchar[basepos_I]];;}

		else if (maindata.colormode == GCHAN) {
			rect_in[basepos_m]=gammed_values[rect_in_guchar[basepos_I+1]];;}

		else if (maindata.colormode == BCHAN) {
			rect_in[basepos_m]=gammed_values[rect_in_guchar[basepos_I+2]];;}			
						
		else {printf ("populate_rect_in: Unknown colormode\n");exit(1);}
		
		if (DEBUG) {
			if (!rect_in[basepos_m]==rect_in[basepos_m]) {
				printf ("Populate (DEBUG) Nan inserted..\n");
				if (DEBUGKILL) exit (1);}
			if (rect_in[basepos_m]<0 || rect_in[basepos_m]>1) {
				printf ("Populate (DEBUG) Suspicious amount entered: %.3f, coordinates %.d x %.d\n",
				rect_in[basepos_m],x,y );
				if (DEBUGKILL) exit (1);}
			R=gammed_values[rect_in_guchar[basepos_I]];
			G=gammed_values[rect_in_guchar[basepos_I+1]];
			B=gammed_values[rect_in_guchar[basepos_I+2]];;	
			avg = BRIGHT(R,G,B);
			if (ABS(rect_in[basepos_m ] - avg) >0.4  ) {
				printf ("populate_rect_in (DEBUG): Too big difference for nonstandard color mode: %.3f (avg is) %.3f\n",rect_in[basepos_m ],avg);
				if (DEBUGKILL) exit(1);}
			 } // end of DEBUG block
			 

	}}
	if (debug)  { //calculating average brightness 
		gfloat sum=0;
		ITERATE(x,0,maindata.height*maindata.width) sum+=rect_in[x];
		printf (" debug - average input mask brightness: %.3f\n", sum/maindata.height/maindata.width);}	
	
	};

int round_to_int(gfloat number) {
    return (number >= 0) ? (int)(number + 0.5) : (int)(number - 0.5);
}


void do_mask3(gfloat *source_rect,gfloat *targ_rect,gint radius,gfloat treshold) {
	//takes data from source and blurs them
	gint radiuses[BLURSTEPS];
	gfloat tresholds[BLURSTEPS];
	//guchar steps,d,f;
	gint c;
	guchar uc,ud,f,steps;
	//gint uc,ud,f,steps;
	gint remaining_radius;
	gint rad_stepping;
	const gboolean debug=FALSE;

	if (debug) printf (" do_mask3 start\n");
	if (debug) printf ("  do_mask3() received: Rect pointers - source: %p, target: %p, Overall radius: %.d, treshold: %.3f\n",
	source_rect,targ_rect,radius,treshold );
	
	//assigning RADIUS
	remaining_radius =radius;
	steps=BLURSTEPS;
	ITERATE(uc,0,BLURSTEPS) {
		radiuses[uc]=remaining_radius*0.45;
		radiuses[uc]=MIN(radiuses[uc], (uc+1)*3+1);
		
		if (radiuses[uc]==0) radiuses[uc]=1;
		remaining_radius=remaining_radius-radiuses[uc];
		//printf (" -- Radius: %.d, remains: %.d\n", radiuses[c],remaining_radius);
		if (remaining_radius <= 0) {steps=uc+1;break;}
	}	
	if (remaining_radius>0) radiuses[0]=radiuses[0]+remaining_radius;
	
	if (VERBOSE) printf ("  do_mask3(): Blurring steps to be done: %.d\n", steps);
	
	//assigning TRESHOLD - used only with SELBLUR
	ITERATE(uc,0,steps) {
		tresholds[uc]=MIN(treshold, (gfloat)(uc+1)*2.0/steps*treshold) ;}
		
	//inserting TOTAL TRESHOLD
	ITERATE(uc,0,THREADS) threaddata[uc].totaltresh = treshold;
	
	
	//splitting image into parts (splitting height)
	ITERATE(uc,0,THREADS) {
		//printf ("Preparing data for thread: %.d\n",c);
		if (uc ==0) threaddata[uc].startline =0;
		else threaddata[uc].startline= threaddata[uc-1].endline;
		if (uc == THREADS-1) threaddata[uc].endline=maindata.height;
		else threaddata[uc].endline=threaddata[uc].startline+maindata.height/THREADS;
		threaddata[uc].id=uc;
		threaddata[uc].basepos_end=get_basepos(maindata.width-1,maindata.height-1,1,maindata.width)+1;
		//ITERATE(d,0,rad_steps)threaddata[c].relbasepos[d]=relbasepos[d];
		}

		
	//starting threads
	
	ITERATE(ud,0,steps) {
		if (debug) printf ("   do_mask3(): Doing step: %1d, radius: %.d, treshold: %.3f\n",
			ud,radiuses[ud],tresholds[ud]);
	
		//calculating RELATIVE BASEPOS
		rad_stepping=radiuses[ud]/6 + 1;

		f=0;
		if (debug) printf ("    do_mask3(): calculating circle data - iterating from %d to %d by %d\n",
			-radiuses[ud],radiuses[ud],rad_stepping);
		for (c=-radiuses[ud];c<radiuses[ud];c=c+rad_stepping) {
			circledata.y_rel[f]=c;
			circledata.x_rel[f]=(int)ROUND (pow( (gfloat) radiuses[ud]*radiuses[ud] - c*c, (gfloat)1/2));
			if (debug) printf ("     do_mask3():Calculated: %1d x %1d\n",circledata.x_rel[f],circledata.y_rel[f]);
			f=f+1; 		}
		for (c=radiuses[ud];c>-radiuses[ud];c=c-rad_stepping) {
			circledata.y_rel[f]=c;
			circledata.x_rel[f]=-(int)ROUND (pow( (gfloat) radiuses[ud]*radiuses[ud] - c*c, (gfloat)1/2));
			if (debug) printf ("     do_mask3():Calculated: %1d x %1d\n",circledata.x_rel[f],circledata.y_rel[f]);
			f=f+1;  	}
		circledata.circle_points=f;
		if (debug) printf ("   do_mask3(): Rad stepping: %.d, for radius: %.d, circle points %1d\n",
			rad_stepping,radiuses[ud],f);


		ITERATE(c,0,THREADS){
			//printf ("  ++ source: %.p, target: %.p\n", threaddata[c].source,threaddata[c].target);
			if (ud%2==0) {threaddata[c].source=rect_tmp1;threaddata[c].target=rect_tmp2;}
			else  {threaddata[c].source=rect_tmp2;threaddata[c].target=rect_tmp1;}
			//exemptions:
			if (ud==0) threaddata[c].source=source_rect;
			if (ud==steps-1) threaddata[c].target=targ_rect;
			if (debug && c==0) printf ("   do_mask3(): starting thread 0: step: %d, Source: %p, target %p\n",ud,threaddata[c].source,threaddata[c].target);
			threaddata[c].radius=radiuses[ud];threaddata[c].treshold=tresholds[ud];
			if (ud == steps - 1) threaddata[c].finalcheck=TRUE;
			else threaddata[c].finalcheck=FALSE;
			gth[c]=g_thread_create( (GThreadFunc) do_mask_thread,&threaddata[c],TRUE,NULL); }
	
		ITERATE(c,0,THREADS) { 			//waiting till all threads end
			g_thread_join(gth[c]);    }	
								
		//updating progress bar
		if ( (! maindata.previewbool) ||  maindata.exportlayer) {
				gimp_progress_update (progrange[0] + ((gdouble)((gdouble)ud+1)/steps) *(progrange[1]-progrange[0])  );}
			
	}
	if (DEBUG) printf (" do_mask3 end\n");
}


void *do_mask_thread(void *arg) {
	guint count,x,y,basepos_centr;
	//gint c;
	guchar c;
	gfloat sum;
	gfloat localvalue,finalvalue,invalue,centralvalue;
	packer *data;
	data=(packer *) arg;
	const gboolean debug=FALSE;


	
	ITERATE(x,0,maindata.width) {
		ITERATE(y,data->startline,data->endline) {
			basepos_centr=get_basepos(x,y,1,maindata.width);
			centralvalue=data->source[basepos_centr];
			//invalue=rect_in[basepos_centr];
			if (debug && x%100==0 && y%100==0) printf ("    *do_mask_thread(): position %1d x %1d / %1d\n",x,y,basepos_centr);
			sum=centralvalue;
			count=1;
			ITERATE(c,0,circledata.circle_points) {
				//if (DEBUG) printf ("Testing local value: %.d\n", basepos_centr + data->relbasepos[c]);
				if (x + circledata.x_rel[c] < 0) continue;
				if (x + circledata.x_rel[c] >= maindata.width ) continue;
				if (y + circledata.y_rel[c] < 0) continue;
				if (y + circledata.y_rel[c] >= maindata.height ) continue;				
			
				if (debug && x%100==0 && y%100==0) printf ("     *d_m_t():doing relative pixel: %1d x %1d\n", x+circledata.x_rel[c],y+circledata.y_rel[c]);
				localvalue=data->source[basepos_centr+circledata.x_rel[c]*circledata.x_relbasepos+circledata.y_rel[c]*circledata.y_relbasepos] ;
				//if (DEBUG) printf ("localvalue error: x: %.d, y: %.d, localstep: %.d, relbasepos: %.d\n",x,y,c,data->relbasepos[c]);
				
				if ( ! (maindata.blurmode == NORMAL) && localvalue > centralvalue + data->treshold) continue;
				if ( ! (maindata.blurmode == NORMAL) && localvalue < centralvalue - data->treshold) continue;
				sum=sum+localvalue;
				if (debug && x%100==0 && y%100==0) printf ("     *d_m_t(): Adding value %.3f to sum\n",localvalue);
				count=count+1;}
			finalvalue=sum/count;
			data->target[basepos_centr]=finalvalue;	
			if (debug && x%100==0 && y%100==0)
				printf ("    *do_mask_thread():updating value %.3f -> %.3f\n",data->source[basepos_centr],data->target[basepos_centr]);
			
			//if (data->id==0) printf ("Old value: %.3f, new value: %.3f, sum %.3f, count: %.d\n", data->source[basepos_centr],finalvalue,sum,count);
			//if (data->id==0) exit (1);
			
		}}

	if (maindata.blurmode==SELBLUR && data->finalcheck) {
		if (DEBUG) printf ("    Doing finalcheck, %.d\n",data->finalcheck);
		ITERATE(x,0,maindata.width) {
			ITERATE(y,data->startline,data->endline) {
				basepos_centr=get_basepos(x,y,1,maindata.width);
				invalue=rect_in[basepos_centr];
				if (data->target[basepos_centr] > invalue + data->totaltresh) data->target[basepos_centr]= invalue + data->totaltresh;
				if (data->target[basepos_centr] < invalue - data->totaltresh) data->target[basepos_centr]= invalue - data->totaltresh;				
			}}
		}
	return NULL;
}


void do_final() {
	guchar c;
	const gboolean debug=FALSE;
	if (debug) ITERATE(c,0,SLIDERS+1) rangestat[c]=0;
	
	ITERATE(c,0,THREADS){     //starting threads
		gth[c]=g_thread_create( (GThreadFunc) do_final_thread,&threaddata[c],TRUE,NULL); }
	
	ITERATE(c,0,THREADS) { 			//waiting till all threads end
		g_thread_join(gth[c]);    }	
	
	if (debug) ITERATE(c,0,SLIDERS+1) printf ("    Range stat for range #%1d: %1d\n",c,rangestat[c]);
	
	}


void *do_final_thread(void *arg) {
	//threaded function - run in parralel, processes its part of image
	
	guint x,y,basepos_1,basepos_3,basepos_In, basepos_Out;
	packer *data;
	data=(packer *) arg;

	if (VERBOSE) printf("   (do_final_thread) starting - id: %.d, x_half: %.d\n",data->id,maindata.x_half);
	
	ITERATE(x,0,maindata.width) {
		ITERATE(y,data->startline,data->endline)  {

			basepos_In=BASEPOS(x,y,maindata.channels,maindata.width);
			basepos_Out=get_basepos(x,y,maindata.outchannels,maindata.width);
			basepos_1=BASEPOS(x,y,1,maindata.width);
			basepos_3=get_basepos(x,y,3,maindata.width);
			
			get_new_RGB3 (basepos_1,basepos_3,basepos_In,basepos_Out,x,data->id);//this will caluclate new RGB and in save them in rect_out
		}
		if (data->id ==0){ //doing it only in first thread
	    	if (x % 10 == 0 && ( (! maindata.previewbool) || maindata.exportlayer)) {
				gimp_progress_update (progrange[0] +(gdouble) x *(progrange[1]-progrange[0]) / (gdouble) maindata.width  );}}
	
	}
	return NULL;
} //end of do_final_thread


void get_new_RGB3(gint basepos_1,gint basepos_3,gint basepos_In, gint basepos_Out,gint x,gint id) {
	
	//fills out rect_out_guchar with RGB values
	 gfloat   mask_old;
	 gfloat   mask_new;
	 gfloat   diff_new;
	 gfloat   br_old;
	 gfloat   br_new;
	gfloat Rnew,Bnew,Gnew,R,G,B;
	gint Rung,Gung,Bung;
	gfloat sharp_boost;
	
	br_old=rect_in[basepos_1];
	mask_old=rect_out[basepos_1];
	
	//1. GET RID OF PIXELS THAT ARE NOT CALCULATED
	//first "unchanged half in preview in P_HALF mode
	if (maindata.action == HALFMODE && x < maindata.x_half) {
		rect_out_guchar[ basepos_Out  ]=rect_in_guchar[ basepos_In];	
		rect_out_guchar[ basepos_Out+1]=rect_in_guchar[ basepos_In+1];	
		rect_out_guchar[ basepos_Out+2]=rect_in_guchar[ basepos_In+2];	
		if (maindata.channels ==4 && maindata.outchannels ==4) 
			rect_out_guchar[basepos_Out + 3] = rect_in_guchar[basepos_In + 3];
		return;	}
	
	//doing vertical line in half mode
	if (maindata.action == HALFMODE &&  x == maindata.x_half) {
		rect_out_guchar[ basepos_Out  ]=255 - rect_in_guchar[ basepos_In];	
		rect_out_guchar[ basepos_Out+1]=255 - rect_in_guchar[ basepos_In+1];	
		rect_out_guchar[ basepos_Out+2]=255 - rect_in_guchar[ basepos_In+2];	
		if (maindata.channels ==4 && maindata.outchannels ==4) 
			rect_out_guchar[basepos_Out + 3] = rect_in_guchar[basepos_In + 3];
		return;	}

	//2. CALCULATING SHARP BOOST
	sharp_boost = get_new_sharp(br_old-mask_old);

	//3. OUT-OF-RANGE PROTECTION IF NEEDED
	// ommited

	
	//4. CALCULATING NEW BRIGHTNESS OF MASK
	mask_new= maindata.newdark + mask_old*(maindata.newlight-maindata.newdark);
	
	//5.CALCULATING FINAL Rnew,Gnew,Bnew VALUES
	//5A. FOR MASK-TO-IMG DIFF
	if (maindata.action == MASKDIFF) {
		Rnew=(br_old - mask_old)*maindata.mask_boost + maindata.mask_pos;
		if (Rnew<0) Rnew=0;
		if (Rnew>1) Rnew=1;
		Gnew=Rnew;
		Bnew=Gnew;
		//if (Rnew >1 || Rnew <0) printf ("new RGB values in maskdiff: %.3f, %.3f, %.3f\n",Rnew,Gnew,Bnew);
		}
	
	//5B. FOR MASK OUTPUT
	else if (maindata.action == MASK) {

		if(maindata.colormode ==BRIGHT_OWN || maindata.colormode==RCHAN || 
		maindata.colormode==GCHAN || maindata.colormode==BCHAN) {
			Rnew = mask_new;
			Gnew = mask_new;
			Bnew = mask_new;}
		if(maindata.colormode == HSV ) {
			HSVstruct[id].h=0;
			HSVstruct[id].s=0;
			HSVstruct[id].v=mask_new;
			gimp_hsv_to_rgb(&HSVstruct[id],&RGBstruct[id]);
			Rnew=RGBstruct[id].r;Gnew=RGBstruct[id].g;Bnew=RGBstruct[id].b;}
		if(maindata.colormode == HSL ) {
			HSLstruct[id].h=0;
			HSLstruct[id].s=0;
			HSLstruct[id].l=mask_new;
			gimp_hsl_to_rgb(&HSLstruct[id],&RGBstruct[id]);
			Rnew=RGBstruct[id].r;Gnew=RGBstruct[id].g;Bnew=RGBstruct[id].b;}
		}

	//5C. FOR SHARPENED IMAGE
	else {
		
		//calculating new distance between brightness of pixel and mask
		diff_new=(br_old - mask_old)*sharp_boost;
		
		br_new= mask_new + diff_new;
		
		//getting original ungammed values
		Rung=rect_in_guchar[basepos_In + 0];
		Gung=rect_in_guchar[basepos_In + 1];
		Bung=rect_in_guchar[basepos_In + 2];	
			
		if(maindata.colormode ==BRIGHT_OWN || maindata.colormode==RCHAN || 
		maindata.colormode==GCHAN || maindata.colormode==BCHAN ) {
			R=gammed_values[Rung];
			G=gammed_values[Gung];
			B=gammed_values[Bung];
			if(	maindata.colormode==RCHAN || maindata.colormode==GCHAN || maindata.colormode==BCHAN) 
				br_old=BRIGHT(R,G,B);
			Rnew=br_new + (R-br_old);
			Gnew=br_new + (G-br_old);
			Bnew=br_new + (B-br_old); }
		else if(maindata.colormode ==HSV) {
			RGBstruct[id].r = Rung/255.0;
			RGBstruct[id].g = Gung/255.0;
			RGBstruct[id].b = Bung/255.0;
			gimp_rgb_to_hsv(&RGBstruct[id],&HSVstruct[id]);
			HSVstruct[id].v=KEEP_WITHIN_0_1(br_new);
			gimp_hsv_to_rgb(&HSVstruct[id],&RGBstruct[id]);
			Rnew=RGBstruct[id].r;Gnew=RGBstruct[id].g;Bnew=RGBstruct[id].b;}
		else if(maindata.colormode ==HSL) {
			RGBstruct[id].r=Rung/255.0;
			RGBstruct[id].g=Gung/255.0;
			RGBstruct[id].b=Bung/255.0;
			gimp_rgb_to_hsl(&RGBstruct[id],&HSLstruct[id]);
			HSLstruct[id].l=KEEP_WITHIN_0_1(br_new);
			gimp_hsl_to_rgb(&HSLstruct[id],&RGBstruct[id]);
			Rnew=RGBstruct[id].r;Gnew=RGBstruct[id].g;Bnew=RGBstruct[id].b;}
		else printf ("get_new_RGB: Unknown mode \n");
	} // end fo DEFAULT processing

		//putting data into RECT_OUT_GUCHAR
		if(maindata.colormode ==BRIGHT_OWN|| maindata.colormode==RCHAN || 
		maindata.colormode==GCHAN || maindata.colormode==BCHAN) {    //this included ungamming
			rect_out_guchar[basepos_Out + 0] = BACK_TO_INT(Rnew); 
			rect_out_guchar[basepos_Out + 1] = BACK_TO_INT(Gnew);     	
			rect_out_guchar[basepos_Out + 2] = BACK_TO_INT(Bnew);}
		else {               							//no ungamming
			rect_out_guchar[basepos_Out + 0] = round_to_int(Rnew*255.0);
			rect_out_guchar[basepos_Out + 1] = round_to_int(Gnew*255.0);     	
			rect_out_guchar[basepos_Out + 2] = round_to_int(Bnew*255.0);}		
		if (maindata.channels ==4 && maindata.outchannels == 4) rect_out_guchar[basepos_Out + 3] = rect_in_guchar[basepos_In + 3];
		
		}//

void export_to_layer()
{
	GimpDrawable *new_layer;
	guint height,width,layer_ID;
	guint x;
	GimpPixelRgn rgn_out_nl;
	guchar *rect_out_nl;

	
	if (VERBOSE) printf("Starting export_to_layer() function...\n");
	width=gimp_image_width(image_ID);
	height=gimp_image_height(image_ID);
	
	//creating and attaching new layer
	if (maindata.channels==3)
		layer_ID = gimp_layer_new (image_ID, "AUMask", width, height, GIMP_RGB_IMAGE, 100.0,  GIMP_NORMAL_MODE);
	else if  (maindata.channels==4)
		layer_ID = gimp_layer_new (image_ID, "AUMask", width, height, GIMP_RGBA_IMAGE, 100.0,  GIMP_NORMAL_MODE);
	else printf ("Unsupported number of channels\n");
	new_layer = gimp_drawable_get (layer_ID);
	gimp_image_add_layer (image_ID,layer_ID,-1);

	
	rect_out_nl      = g_new (guchar, maindata.width * maindata.height * maindata.channels);	
		
	//initiating rgn_out
	gimp_pixel_rgn_init (&rgn_out_nl, new_layer, 0, 0, width, height, FALSE, TRUE);

	//populating rgn_out with data
	ITERATE(x,0,width*height*maindata.channels)  rect_out_nl[x]=rect_out_guchar[x];
    
	//nahratie udajov do rgn_out
    gimp_pixel_rgn_set_rect (&rgn_out_nl, rect_out_nl,0, 0,width,height);

	g_free (rect_out_nl);
	
	gimp_drawable_flush (new_layer);
	gimp_drawable_merge_shadow (new_layer->drawable_id, TRUE);
	gimp_drawable_update (new_layer->drawable_id,0, 0, width, height);
	gimp_displays_flush ();
	gimp_progress_end();
	//g_free(new_layer);
}				



static void sharpen (GimpDrawable *source,GimpPreview *preview) {
	
	static gint xtmp1,xtmp2,ytmp1,ytmp2,heighttmp,widthtmp,xtotaltmp1,xtotaltmp2,ytotaltmp1,ytotaltmp2;
	static gint xstart,xend,ystart,yend;
	static guint i; 		//relative, "near" pixels to "main" pxls
	static gint 		c; 		//iterator
	static GimpPixelRgn rgn_in, rgn_out;
	static gint offset;

	
	
	for (i=0;i<256;i++) { //to speed up conversion from raw RGB to gammed values
		gammed_values[i]=pow((gfloat)i/255,1/2.2);}
	
	if (VERBOSE) {
		printf ("=== Running sharpen() ...\n");
		printf ("sharpen mode: action %.d\n",maindata.action);
		printf ("sharpen: Radius %d\n",maindata.radius);
		printf ("sharpen: Brightness modifications %.3f - %.3f\n",maindata.newdark,maindata.newlight);
		printf ("sharpen: Treshold %.3f\n",maindata.tresh);
		printf ("sharpen: Bluring mode (N=0,Sel=1) %.d\n", maindata.blurmode);
		printf ("sharpen:mask-to-diff params (pos/boost): %.3f, %.3f\n",maindata.mask_pos,maindata.mask_boost);		
		printf ("Drawable id: %.d\n",source->drawable_id);}

	if (!preview) gimp_progress_init ("Sharpening (AUMASK)...");

	// getting coordinates of what will be processed
	if ( preview ){
          gimp_preview_get_position (preview, &xtmp1, &ytmp1);
          gimp_preview_get_size (preview, &widthtmp, &heighttmp);
          if (widthtmp < 2) return;
          xtmp2=xtmp1+widthtmp;
          ytmp2=ytmp1+heighttmp;

          gimp_drawable_mask_bounds (source->drawable_id,&xtotaltmp1, &ytotaltmp1,&xtotaltmp2, &ytotaltmp2); //drawable size
          offset=MAX(maindata.radius*0.5,20);
          if (VERBOSE) printf ("Using offset %d\n",offset);
          xstart=MAX( xtmp1-offset , xtotaltmp1 );
          ystart=MAX( ytmp1-offset , ytotaltmp1 );
          xend  =MIN( xtmp2+offset , xtotaltmp2 );
          yend  =MIN( ytmp2+offset , ytotaltmp2 );
          //of course, new width and height must be calculated
          maindata.width=xend-xstart;maindata.height=yend-ystart;
          if (VERBOSE) printf(" Enlarging preview: old coordinates: %1d-%1d x %1d-%1d,new coordinates are %1d-%1d x %1d-%1d, (drawable's boundaries: %1d-%1d x %1d-%1d)\n",
          xtmp1,xtmp2,ytmp1,ytmp2,xstart,xend,ystart,yend,xtotaltmp1,xtotaltmp2,ytotaltmp1,ytotaltmp2);
          //end of section to enlarge area processed for preview
          maindata.x_half=maindata.width/2;
          maindata.previewbool=TRUE;
          if (VERBOSE) 	printf ("sharpen mode: x_half %.d\n",maindata.x_half);
			}
    else {
         gimp_drawable_mask_bounds (source->drawable_id,&xstart, &ystart,&xend, &yend); 
         maindata.width = xend - xstart;
         maindata.height = yend - ystart;
         maindata.x_half=maindata.width/2;
         maindata.previewbool=FALSE;
         }

	maindata.channels = gimp_drawable_bpp (source->drawable_id);//getting number of channels
	maindata.outchannels=maindata.channels; //is outchannels needed ???

	circledata.x_relbasepos=1;
	circledata.y_relbasepos=maindata.width;

	//initializing pixelrgn for input and output section
	gimp_pixel_rgn_init (&rgn_in , source, xstart, ystart, maindata.width, maindata.height, FALSE, FALSE); 
		
	if (initialized<maindata.height * maindata.width){
		gint new_initialization;
		new_initialization=maindata.height * maindata.width;
		if (DEBUG) printf ( " Reinitializing working memory for image size: %d\n",new_initialization);
		rect_in_guchar  = g_new (guchar, maindata.channels * new_initialization);	
		rect_in         = g_new (gfloat, new_initialization);
		rect_out        = g_new (gfloat, new_initialization);	
		rect_out_guchar = g_new (guchar, maindata.channels * new_initialization);	
		rect_tmp1       = g_new (gfloat, new_initialization);	
		rect_tmp2       = g_new (gfloat, new_initialization);	
		initialized=new_initialization;}
	

	if (VERBOSE) printf ("  Pinters to rects: Rect_in: %p, rect_tmp1: %p, rect_tmp2: %p\n",rect_in,rect_tmp1,rect_tmp2);
	
	//loading all data from image
	gimp_pixel_rgn_get_rect (&rgn_in,rect_in_guchar,xstart, ystart,maindata.width,maindata.height);
	
	//populating rect_in with brightness data (rect_in_guchar -> rect_in)
	populate_rect_in();
	if (! maindata.previewbool) gimp_progress_update(DOMASK1START);
 	
	//doing MASK (rect_out) (rect_in -> rect_tmpX -> rect_out)
	progrange[0]=DOMASK1START; progrange[1]=DOMASK1END;
	do_mask3(rect_in,rect_out,maindata.radius,maindata.tresh);
	
	if ( ! maindata.previewbool) gimp_progress_update(DOMASK1END);

	gimp_pixel_rgn_init (&rgn_out, source, xstart, ystart, maindata.width, maindata.height, preview == NULL, TRUE);

	if (maindata.blurmode == POSTBLUR) {
		if (VERBOSE) printf ("   Doing postblur section\n");
		rect_post  = g_new (gfloat, maindata.width * maindata.height);
		ITERATE(c,0,maindata.width*maindata.height) { // copying data
			rect_post[c]=rect_out[c];}
		progrange[0]=DOMASK1END; progrange[1]=DOMASK1END+0.1;
		do_mask3(rect_post,rect_out,maindata.postradius,1);}
			
	//calculating final values (rect_out -> rect_out_guchar)
	progrange[0]=DOMASK1END+0.1; progrange[1]=0.9;
	do_final();
	if ( ! maindata.previewbool) gimp_progress_update(0.9);

	if (maindata.exportlayer) {
		export_to_layer();
		return;}
	 
    //entering data into rgn_out
    if (VERBOSE) printf ("  copying data to rgn_out\n");
   	gimp_pixel_rgn_set_rect (&rgn_out, rect_out_guchar,xstart, ystart,maindata.width,maindata.height);
    if ( (! maindata.previewbool) || maindata.exportlayer ) gimp_progress_update(0.999);
  	gimp_progress_end();
  	
   //update (graphical) of preview/image
    if (VERBOSE) printf ("  redrawing drawable\n");  
	if (maindata.previewbool ) {
    	gimp_drawable_preview_draw_region (GIMP_DRAWABLE_PREVIEW (preview),
        &rgn_out);}
    else {
		gimp_drawable_flush (source);
		gimp_drawable_merge_shadow (source->drawable_id, TRUE);
		gimp_drawable_update (source->drawable_id,xstart, ystart,maindata.width,maindata.height);
		gimp_displays_flush ();}

}


static gboolean
sharp_dialog (GimpDrawable *source)
{
  GtkWidget *dialog;
  GtkWidget *main_hbox,*main_vbox1,*main_vbox2,*bvum_hbox,*mask_vbox;
  GtkWidget *label_bvm,*label_mo,*label_em,*label_se,*label_cm;
  GtkWidget *slid_hbox,*action_vbox;

  GtkWidget *preview;

  GtkWidget *ed_boost_label,*label_action,*ed_pos_label, *label_postrad;
  GtkWidget *exportbutton;

  GtkWidget *label_radius,*label_dark,*label_light,*label_tresh;
  GtkWidget *align_1,*align_2,*align_3,*align_4,*align_5;
  GtkWidget *align_A, *align_B, *align_C, *align_D,*align_F,*align_G;
  GtkWidget *export_table,*blur_table;
  float slider_h=160;
  float slider_w=12;
  
   gimp_ui_init ("aumask", FALSE);

  
   gimp_dialogs_show_help_button (FALSE);
  dialog = gimp_dialog_new (title, "gimp plugin",
                            NULL, 0,
                            gimp_standard_help_func, "plug-in-saturate",

                            GIMP_STOCK_RESET, RESPONSE_RESET,
                            GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                            GTK_STOCK_OK,     RESPONSE_OK,

                            NULL);

  //1. MAIN_HBOX
  main_hbox = gtk_hbox_new (FALSE, HBOXSPACING);
  gtk_container_add (GTK_CONTAINER (GTK_DIALOG (dialog)->vbox), main_hbox);
  gtk_widget_show (main_hbox);
  
  // 1.1
  main_vbox1 = gtk_vbox_new (FALSE, 6);
  gtk_box_pack_start (GTK_BOX (main_hbox), main_vbox1, TRUE, TRUE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (main_vbox1), VBOXBORDER);
  gtk_widget_show (main_vbox1);
  // 1.2 
  main_vbox2 = gtk_vbox_new (FALSE, 6);
  gtk_box_pack_end (GTK_BOX (main_hbox), main_vbox2, FALSE, FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (main_vbox2), VBOXBORDER);
  gtk_widget_show (main_vbox2);

  //POPULATING first vertical box
  // 1.1.1
  preview = gimp_drawable_preview_new (source, NULL);
  gtk_box_pack_start (GTK_BOX (main_vbox1), preview, TRUE, TRUE, 0);
  gtk_widget_show (preview);

  align_G=gtk_alignment_new(0, 0, 0, 0);
  gtk_box_pack_start (GTK_BOX (main_vbox1), align_G, FALSE, FALSE, 0);
  gtk_alignment_set_padding( GTK_ALIGNMENT( align_G ),UPINTEND,DOWNINTEND,0,0);
  gtk_widget_show (align_G);

    // 1.1.2.1.1    
	label_action = gtk_label_new ("<b>Output mode:</b>");
	gtk_widget_set_tooltip_text(label_action, "Selected mode affects preview as well as final image");
	gtk_label_set_use_markup (GTK_LABEL(label_action), TRUE);
	gtk_misc_set_alignment (GTK_MISC (label_action), 0.0, 0);
	gtk_container_add(GTK_CONTAINER(align_G),label_action );
	gtk_widget_show (label_action);
	

  // 1.1.2. vertical box for preview togle buttons
  align_1=gtk_alignment_new(0, 0, 0, 0);
  gtk_box_pack_start (GTK_BOX (main_vbox1), align_1, FALSE, FALSE, 0);
  gtk_alignment_set_padding( GTK_ALIGNMENT( align_1 ),0,0,ALIGNINTEND,0);
  gtk_widget_show (align_1);
  // 1.1.2.1    
  action_vbox=gtk_vbox_new (FALSE, BOXSPACING);
  gtk_container_add(GTK_CONTAINER(align_1),action_vbox );
  gtk_widget_show (action_vbox);
  
	// 1.1.2.1.1 
	combo3 = gtk_combo_box_new_text();
	gtk_widget_set_tooltip_text(combo3, "Selected mode affects preview as well as final image");
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo3),amode1);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo3),amode2);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo3),amode3);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo3),amode4);
	gtk_box_pack_start (GTK_BOX (action_vbox), combo3, FALSE, FALSE, 0);
	gtk_widget_set_size_request(combo3,200,-1);
	gtk_combo_box_set_active(GTK_COMBO_BOX( combo3), 0);
	gtk_widget_show (combo3);

  //1.1.2 sliders header alignment
  align_A=gtk_alignment_new(0, 0, 0, 0);
  gtk_box_pack_start (GTK_BOX (main_vbox1), align_A, FALSE, FALSE, 0);
  gtk_alignment_set_padding( GTK_ALIGNMENT( align_A ),UPINTEND,DOWNINTEND,0,0);
  gtk_widget_show (align_A);

  //1.1.2.1 sliders header
  label_se = gtk_label_new ("<b>Sharpness equalizer:</b>");
  gtk_widget_set_tooltip_text(label_se, "Sliders below adjust distance between unsharp mask and orignal brightness (working like multiplicators)");
  gtk_label_set_use_markup (GTK_LABEL(label_se), TRUE);
  gtk_misc_set_alignment (GTK_MISC (label_se), 0.1, 0);
  gtk_container_add(GTK_CONTAINER(align_A),label_se ); 
  gtk_widget_show (label_se);

  //1.1.3 SLIDERS_HBOX
  slid_hbox = gtk_hbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (main_vbox1), slid_hbox, FALSE, FALSE, 0);
  gtk_widget_show (slid_hbox);
  
  
	  //1.1.3.1 sliders
	  slider0_adj = gtk_adjustment_new (1.0, 0.0, 2.5, 0.01, 0.1, 0);
	  slider0 = gtk_vscale_new (GTK_ADJUSTMENT (slider0_adj));
	  gtk_widget_set_tooltip_text(slider0, "Controls the distance 0.0075");
	  gtk_scale_set_digits(GTK_SCALE (slider0), 2) ; 
	  gtk_range_set_inverted(GTK_RANGE (slider0),TRUE) ;
	  gtk_widget_set_size_request(slider0,slider_w,slider_h);
	  gtk_box_pack_start (GTK_BOX (slid_hbox), slider0, TRUE, TRUE, 0);
	  gtk_widget_show (slider0);
	  //1.1.3.2	  
	  slider1_adj = gtk_adjustment_new (1.0, 0.0, 2.5, 0.01, 0.1, 0);
	  slider1 = gtk_vscale_new (GTK_ADJUSTMENT (slider1_adj));
	  gtk_widget_set_tooltip_text(slider1, "Controls the distance 0.03");
	  gtk_scale_set_digits(GTK_SCALE (slider1), 2) ; 
	  gtk_range_set_inverted(GTK_RANGE (slider1),TRUE) ;
	  gtk_widget_set_size_request(slider1,slider_w,slider_h);
	  gtk_box_pack_start (GTK_BOX (slid_hbox), slider1, TRUE, TRUE, 0);
	  gtk_widget_show (slider1);
	  //1.1.3.3	  
	  slider2_adj = gtk_adjustment_new (1.0, 0.0, 2.5, 0.01, 0.1, 0);
	  slider2 = gtk_vscale_new (GTK_ADJUSTMENT (slider2_adj));
	  gtk_widget_set_tooltip_text(slider2, "Controls the distance 0.07");
	  gtk_scale_set_digits(GTK_SCALE (slider2), 2) ; 
	  gtk_range_set_inverted(GTK_RANGE (slider2),TRUE) ;
	  gtk_widget_set_size_request(slider2,slider_w,slider_h);
	  gtk_box_pack_start (GTK_BOX (slid_hbox), slider2, TRUE, TRUE, 0);
	  gtk_widget_show (slider2);
	  //1.1.3.4  	  
	  slider3_adj = gtk_adjustment_new (1.0, 0.0, 2.5, 0.01, 0.1, 0);
	  slider3 = gtk_vscale_new (GTK_ADJUSTMENT (slider3_adj));
	  gtk_widget_set_tooltip_text(slider3, "Controls the distance 0.20");
	  gtk_scale_set_digits(GTK_SCALE (slider3), 2) ; 
	  gtk_range_set_inverted(GTK_RANGE (slider3),TRUE) ;
	  gtk_widget_set_size_request(slider3,slider_w,slider_h);
	  gtk_box_pack_start (GTK_BOX (slid_hbox), slider3, TRUE, TRUE, 0);
	  gtk_widget_show (slider3);
  
  //POPULATING second vertical box
  // 1.2.1 
  align_D=gtk_alignment_new(0, 0, 0, 0);
  gtk_box_pack_start (GTK_BOX (main_vbox2), align_D, FALSE, FALSE, 0);
  gtk_alignment_set_padding( GTK_ALIGNMENT( align_D ),0,DOWNINTEND,0,0);
  gtk_widget_show (align_D);
		// 1.2.1.1
		label_mo = gtk_label_new ("<b>Mask options:</b>");
		gtk_label_set_use_markup (GTK_LABEL(label_mo), TRUE);
		gtk_misc_set_alignment (GTK_MISC (label_mo), 0.0, 0.5);
		gtk_container_add(GTK_CONTAINER(align_D),label_mo );
		gtk_widget_show (label_mo);

  //1.2.2  vertical box for preview togle buttons
  align_2=gtk_alignment_new(0, 0, 0, 0);
  gtk_box_pack_start (GTK_BOX (main_vbox2), align_2, FALSE, FALSE, 0);
  gtk_alignment_set_padding( GTK_ALIGNMENT( align_2 ),0,0,ALIGNINTEND,0);
  gtk_widget_show (align_2);

	  //1.2.2.1 Mask_options_VBOX
	  mask_vbox = gtk_vbox_new (FALSE, 10);
	  gtk_container_add(GTK_CONTAINER(align_2),mask_vbox );
	  gtk_widget_show (mask_vbox);
		  //1.2.1.1.1 
		  combo = gtk_combo_box_new_text();
		  gtk_combo_box_append_text( GTK_COMBO_BOX( combo),mode1 );
		  gtk_combo_box_append_text( GTK_COMBO_BOX( combo),mode2);
		  gtk_combo_box_append_text( GTK_COMBO_BOX( combo),mode3);
		  gtk_box_pack_start (GTK_BOX (mask_vbox), combo, FALSE, FALSE, 0);
		  gtk_widget_set_size_request(combo,100,-1);
		  gtk_combo_box_set_active(GTK_COMBO_BOX( combo), NORMAL);
		  gtk_widget_show (combo);
	
	blur_table=gtk_table_new(2,3,FALSE);
	gtk_box_pack_start (GTK_BOX (mask_vbox), blur_table, FALSE, FALSE, 0);
	gtk_table_set_col_spacings(GTK_TABLE(blur_table),VTABLESPACING);
	gtk_table_set_row_spacings(GTK_TABLE(blur_table),BOXSPACING);
	gtk_widget_show (blur_table);
 
		label_radius = gtk_label_new("Radius(px):");
		gtk_table_attach_defaults (GTK_TABLE(blur_table),label_radius,0,1,0,1);
		gtk_misc_set_alignment (GTK_MISC (label_radius), 0.0, 0.5);
		gtk_widget_show (label_radius);
		
		radius_adj = gtk_adjustment_new (maindata.radius, 1,MAXRADIUS, 1, 1, 0);
		spin_radius = gtk_spin_button_new (GTK_ADJUSTMENT (radius_adj), 1, 0);
		gtk_widget_show (spin_radius);
		gtk_table_attach_defaults (GTK_TABLE(blur_table),spin_radius,1,2,0,1);
		gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_radius), TRUE);
		gtk_widget_show (spin_radius);
		
		label_tresh = gtk_label_new("Treshold:");
		gtk_widget_set_tooltip_text(label_tresh, "Efective only for Selective blurring modes");
		gtk_table_attach_defaults (GTK_TABLE(blur_table),label_tresh,0,1,1,2);
		gtk_misc_set_alignment (GTK_MISC (label_tresh), 0.0, 0.5);
		gtk_widget_show (label_tresh);
		
		tresh_adj = gtk_adjustment_new (maindata.tresh, 0.02,1, 0.01,0.01, 0);
		spin_tresh = gtk_spin_button_new (GTK_ADJUSTMENT (tresh_adj), 0.1, 3);
		gtk_widget_set_sensitive(spin_tresh,FALSE);
		gtk_widget_set_tooltip_text(spin_tresh, "Efective only for Selective blurring modes");
		gtk_widget_show (spin_tresh);
		gtk_table_attach_defaults (GTK_TABLE(blur_table),spin_tresh,1,2,1,2);
		gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_tresh), TRUE);
		gtk_widget_show (spin_tresh);
		
		label_postrad = gtk_label_new("Postblur radius:");
		gtk_widget_set_tooltip_text(label_postrad, selectivehelp);
		gtk_table_attach_defaults (GTK_TABLE(blur_table),label_postrad,0,1,2,3);
		gtk_misc_set_alignment (GTK_MISC (label_postrad), 0.0, 0.5);
		gtk_widget_show (label_postrad);
		
		postrad_adj = gtk_adjustment_new (maindata.postradius,0 ,10, 1,1, 0);
		spin_postrad = gtk_spin_button_new (GTK_ADJUSTMENT (postrad_adj), 1,0);
		gtk_widget_set_sensitive(spin_postrad,FALSE);
		gtk_widget_set_tooltip_text(spin_postrad, selectivehelp);
		gtk_widget_show (spin_postrad);
		gtk_table_attach_defaults (GTK_TABLE(blur_table),spin_postrad,1,2,2,3);
		gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_postrad), TRUE);
		gtk_widget_show (spin_postrad);
		
   
	// 1.2.1.1.3.4 Color mode label
	label_cm = gtk_label_new ("Brightness/mask source:");
	gtk_widget_set_tooltip_text(label_cm, "Pick a method how to get a 'brightness' for individual pixels");
	gtk_label_set_use_markup (GTK_LABEL(label_cm), TRUE);
	gtk_misc_set_alignment (GTK_MISC (label_cm), 0, 1);
	gtk_box_pack_start (GTK_BOX (mask_vbox), label_cm, FALSE, FALSE, 0);
	gtk_widget_show (label_cm);
	// 1.2.1.1.3.5  
	combo2 = gtk_combo_box_new_text();
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo2),colormode1 );
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo2),colormode2);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo2),colormode3);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo2),colormode4 );
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo2),colormode5);
	gtk_combo_box_append_text( GTK_COMBO_BOX( combo2),colormode6);	
	
	gtk_box_pack_start (GTK_BOX (mask_vbox), combo2, FALSE, FALSE, 6);
	gtk_combo_box_set_active(GTK_COMBO_BOX( combo2), 0);
	gtk_widget_show (combo2);
  
  //1.2.3 Brightness via mask label
  align_B=gtk_alignment_new(0, 0, 0, 0);
  gtk_box_pack_start (GTK_BOX (main_vbox2), align_B, FALSE, FALSE, 0);
  gtk_alignment_set_padding( GTK_ALIGNMENT( align_B ),UPINTEND,DOWNINTEND,0,0);
  gtk_widget_show (align_B);

  //1.2.3.1
  label_bvm = gtk_label_new ("<b>Brightness adjustment (~levels) :</b>");
  gtk_widget_set_tooltip_text(label_bvm, "Modifies brightness via mask, so that local contrast is preserved");
  gtk_label_set_use_markup (GTK_LABEL(label_bvm), TRUE);
  gtk_misc_set_alignment (GTK_MISC (label_bvm), 0, 0);
  gtk_container_add(GTK_CONTAINER(align_B),label_bvm ); 
  gtk_widget_show (label_bvm);
  
  
  //1.2.4  Brightness via UM hbox
  align_3=gtk_alignment_new(0, 0, 0, 0);
  gtk_box_pack_start (GTK_BOX (main_vbox2), align_3, FALSE, FALSE, 0);
  gtk_alignment_set_padding( GTK_ALIGNMENT( align_3 ),0,0,ALIGNINTEND,0);
  gtk_widget_show (align_3);
  //1.2.4.1 
  bvum_hbox = gtk_hbox_new (FALSE,BOXSPACING);
  gtk_container_add(GTK_CONTAINER(align_3),bvum_hbox );
  gtk_widget_show (bvum_hbox);
      //1.2.4.1.1 
  	  label_dark = gtk_label_new("Dark:");
	  gtk_box_pack_start (GTK_BOX (bvum_hbox),  label_dark, FALSE, FALSE, 0);
	  gtk_widget_show (label_dark);
      //1.2.4.1.2 	   
	  spin_dark_adj = gtk_adjustment_new (0, -0.4,0.7, 0.01, 0.1, 0);
	  spin_dark = gtk_spin_button_new (GTK_ADJUSTMENT (spin_dark_adj), 0.1, 3);
	  gtk_widget_show (spin_dark);
	  gtk_box_pack_start (GTK_BOX (bvum_hbox), spin_dark, FALSE, FALSE, 6);
	  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_dark), TRUE);
	  gtk_widget_show (spin_dark);
      //1.2.4.1.3	  
	  label_light = gtk_label_new("Light:");
	  gtk_box_pack_start (GTK_BOX (bvum_hbox), label_light, FALSE, FALSE, 0);
	  gtk_widget_show (label_light);
      //1.2.4.1.4	  
	  spin_light_adj = gtk_adjustment_new (1, 0.5, 1.4, 0.01, 0.1, 0);
	  spin_light = gtk_spin_button_new (GTK_ADJUSTMENT (spin_light_adj), 0.1, 3);
	  gtk_widget_show (spin_light);
	  gtk_box_pack_start (GTK_BOX (bvum_hbox), spin_light, FALSE, FALSE, 6);
	  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_light), TRUE);
	  gtk_widget_show (spin_light);

 
  
  //1.2.45.2
  align_5=gtk_alignment_new(0, 0, 0, 0);
  gtk_alignment_set_padding( GTK_ALIGNMENT( align_5 ),0,0,ALIGNINTEND,0);
  gtk_box_pack_start (GTK_BOX (main_vbox2), align_5, FALSE, FALSE, 0);
  gtk_widget_show (align_5);
  	  
  //1.2.5 
  align_C=gtk_alignment_new(0, 0, 0, 0);
  gtk_box_pack_start (GTK_BOX (main_vbox2), align_C, FALSE, FALSE, 0);
  gtk_alignment_set_padding( GTK_ALIGNMENT( align_C ),UPINTEND,DOWNINTEND,0,0);
  gtk_widget_show (align_C);
  //1.2.5.1
  label_em = gtk_label_new ("<b>Mask-to-Img parameters:</b>");
  gtk_widget_set_tooltip_text(label_em, "Affects 'Difference' output mode only!");
  gtk_label_set_use_markup (GTK_LABEL(label_em), TRUE);
  gtk_misc_set_alignment (GTK_MISC (label_em), 0.0, 0.5);
  gtk_container_add(GTK_CONTAINER(align_C),label_em );
  gtk_widget_show (label_em);
 
  //1.2.6 vbox for export options
  align_4=gtk_alignment_new(0, 0, 0, 0);
  gtk_alignment_set_padding( GTK_ALIGNMENT( align_4 ),0,0,ALIGNINTEND,0);
  gtk_box_pack_start (GTK_BOX (main_vbox2), align_4, FALSE, FALSE, 0);
  gtk_widget_show (align_4);
  //1.2.6.1
  export_table=gtk_table_new(2,2,FALSE);
  gtk_container_add(GTK_CONTAINER(align_4),export_table );
  gtk_table_set_col_spacings(GTK_TABLE(export_table),VTABLESPACING);
  gtk_table_set_row_spacings(GTK_TABLE(export_table),BOXSPACING);
  gtk_widget_show (export_table);
      //1.2.6.1.1
	  ed_pos_label = gtk_label_new("Central Brightness:");
	  gtk_table_attach_defaults (GTK_TABLE(export_table),ed_pos_label,0,1,0,1);

	  gtk_misc_set_alignment (GTK_MISC (ed_pos_label), 0.0, 0.4);
	  gtk_widget_show (ed_pos_label);
      //1.2.6.1.2	  
	  mask_pos_adj = gtk_adjustment_new (MASKPOSDEF, 0,1, 0.05,0.01, 0);
	  spin_mask_pos = gtk_spin_button_new (GTK_ADJUSTMENT (mask_pos_adj), 0.05, 2);
	  gtk_widget_set_tooltip_text(spin_mask_pos, "This determines overall brightness of img-to-mask diff.");
	  gtk_table_attach_defaults (GTK_TABLE(export_table),spin_mask_pos,1,2,0,1);
	  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_mask_pos), TRUE);
	  gtk_widget_show (spin_mask_pos);
      //1.2.6.1.3			  
	  ed_boost_label = gtk_label_new("Diff Boost:");
	  gtk_widget_set_tooltip_text(ed_boost_label, "Multiplies difference between mask and image.");
	  gtk_table_attach_defaults (GTK_TABLE(export_table),ed_boost_label,0,1,1,2);
	  gtk_misc_set_alignment (GTK_MISC (ed_boost_label), 0.0, 0.4);
	  gtk_widget_show (ed_boost_label);
	  
      //1.2.6.1.4		  
	  mask_boost_adj = gtk_adjustment_new (maindata.mask_boost, -10,10, 0.1,0.01, 0);
	  spin_mask_boost = gtk_spin_button_new (GTK_ADJUSTMENT (mask_boost_adj), 0.1, 1);
	  gtk_widget_set_tooltip_text(spin_mask_boost, "Multiplies difference between mask and image.");
	  gtk_table_attach_defaults (GTK_TABLE(export_table),spin_mask_boost,1,2,1,2);
	  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spin_mask_boost), TRUE);
	  gtk_widget_show (spin_mask_boost);
  
  align_F=gtk_alignment_new(0.5, 0, 0, 0);
  gtk_box_pack_end (GTK_BOX (main_vbox2), align_F, FALSE, FALSE, 0);
  gtk_alignment_set_padding( GTK_ALIGNMENT( align_F ),UPINTEND,DOWNINTEND,0,0);
  gtk_widget_show (align_F);
  
  	  exportbutton = gtk_button_new_with_label("Export as new layer");
  	  gtk_widget_set_tooltip_text(exportbutton, "Plugin window will stay alive with all settings preserved");
	  gtk_widget_set_size_request(exportbutton,170,35);
	  gtk_button_set_alignment(GTK_BUTTON(exportbutton),0.5,0.5);
	  gtk_container_add(GTK_CONTAINER(align_F),exportbutton );
	  gtk_widget_show (exportbutton);
  
  
  //sending signal to update preview
  g_signal_connect_swapped (preview, "invalidated",  G_CALLBACK (sharpen),source);
  
  g_signal_connect_swapped (slider0_adj, "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
  g_signal_connect_swapped (slider1_adj, "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
  g_signal_connect_swapped (slider2_adj, "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
  g_signal_connect_swapped (slider3_adj, "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);

  g_signal_connect_swapped (radius_adj,       "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
  g_signal_connect_swapped (postrad_adj,      "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
  g_signal_connect_swapped (spin_dark_adj,    "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
  g_signal_connect_swapped (spin_light_adj,   "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
  g_signal_connect_swapped (tresh_adj,        "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
  g_signal_connect_swapped (G_OBJECT(combo ), "changed", G_CALLBACK (gimp_preview_invalidate), preview);
  g_signal_connect_swapped (G_OBJECT(combo2), "changed", G_CALLBACK (gimp_preview_invalidate), preview);
  g_signal_connect_swapped (G_OBJECT(combo3), "changed", G_CALLBACK (gimp_preview_invalidate), preview);

  g_signal_connect_swapped (mask_boost_adj, "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);
  g_signal_connect_swapped (mask_pos_adj,   "value_changed", G_CALLBACK (gimp_preview_invalidate), preview);  
  
  sharpen (source, GIMP_PREVIEW (preview));
  
	////receiving values from sliders and modifying sharpals
	g_signal_connect (slider0_adj, "value_changed", G_CALLBACK (slider_update), &sliders[0]);
	g_signal_connect (slider1_adj, "value_changed", G_CALLBACK (slider_update), &sliders[1]);
	g_signal_connect (slider2_adj, "value_changed", G_CALLBACK (slider_update), &sliders[2]);
	g_signal_connect (slider3_adj, "value_changed", G_CALLBACK (slider_update), &sliders[3]);

	
	g_signal_connect (radius_adj,    "value_changed", G_CALLBACK (gimp_int_adjustment_update), &maindata.radius);
	g_signal_connect (postrad_adj,   "value_changed", G_CALLBACK (gimp_int_adjustment_update), &maindata.postradius);
	g_signal_connect (spin_dark_adj, "value_changed", G_CALLBACK (gimp_float_adjustment_update), &maindata.newdark);  
	g_signal_connect (spin_light_adj,"value_changed", G_CALLBACK (gimp_float_adjustment_update), &maindata.newlight);
	g_signal_connect (tresh_adj,     "value_changed", G_CALLBACK (gimp_float_adjustment_update), &maindata.tresh);
	g_signal_connect( G_OBJECT( combo ), "changed"  , G_CALLBACK( cb_changed ), NULL );
	g_signal_connect( G_OBJECT( combo2), "changed"  , G_CALLBACK( cb2_changed ), NULL );
	g_signal_connect( G_OBJECT( combo3), "changed"  , G_CALLBACK( cb3_changed ), NULL );
	
	g_signal_connect_swapped( G_OBJECT(exportbutton),"clicked",G_CALLBACK( exportwrapper ), source );
	
	
	g_signal_connect( mask_boost_adj,"value_changed",G_CALLBACK( gimp_float_adjustment_update ), & maindata.mask_boost );
	g_signal_connect( mask_pos_adj,"value_changed",G_CALLBACK( gimp_float_adjustment_update ), & maindata.mask_pos );
	
	gtk_widget_show (dialog);
	
	//receiving signals from gimp buttons + "x" (close window button)
	g_signal_connect (dialog, "response",
                    G_CALLBACK (response_callback),
                    NULL);

  gtk_main ();

  return process_image; //TRUE if image should be processed
}

static void free_memory(){
	g_free(rect_in_guchar);	
	g_free(rect_in);
	g_free(rect_out);	
	g_free(rect_out_guchar);	
	g_free(rect_tmp1);	
	g_free(rect_tmp2);	
	}

static void response_callback (GtkWidget *widget,  gint response_id) {
	
  switch (response_id) 	 {
	case RESPONSE_RESET:
	if (VERBOSE)  printf ("Plugin window returned: Resetting... \n");
	
	gtk_range_set_value(GTK_RANGE(slider0),1.0);
	gtk_range_set_value(GTK_RANGE(slider1),1.0);
	gtk_range_set_value(GTK_RANGE(slider2),1.0);
	gtk_range_set_value(GTK_RANGE(slider3),1.0);
	
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_dark),0);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_light),1);
	gtk_combo_box_set_active(GTK_COMBO_BOX( combo3), 0);	
	gtk_combo_box_set_active(GTK_COMBO_BOX( combo), NORMAL);
		  	
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_tresh),TRESHDEF);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_radius),RADIUSDEF);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_postrad),POSTRADIUSDEF);   
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_mask_pos),MASKPOSDEF);  
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_mask_boost),MASKBOOSTDEF);
	
	gtk_widget_set_sensitive(spin_tresh,FALSE);
	gtk_widget_set_sensitive(spin_postrad,FALSE);
	
	break;

    case RESPONSE_OK:  //quitting plugin window and applying change
      if (VERBOSE) printf ("Plugin window returned: OK... \n");
      process_image=TRUE; 
      gtk_widget_destroy (widget);
      gtk_main_quit ();  
      free_memory();   
      break;

    default: // if other response - terminate plugin window
      gtk_widget_destroy (widget);
      gtk_main_quit ();
      free_memory();
      break;
    };
	
}



