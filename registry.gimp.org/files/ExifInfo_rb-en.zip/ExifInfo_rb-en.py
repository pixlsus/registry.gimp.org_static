#!/usr/bin/env python
# -*- coding: utf-8 -*-

##  Instead of the above if you use another program for exif under Windows\
##   wich may uses 'latin-1', then use (-*- coding: latin-1 -*-) or \
##   other char set. Seems a bad idea to to use different text encoding \
##   on the exif for the same photo, but I prefer unicode (utf-8). rob.brz1
# ----------------------------------------------------------------------------
# GNU General Public Licence (GPL)
# 
# This program is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation; either version 2 of the License.
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
# details.
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 59 Temple
# Place, Suite 330, Boston, MA  02111-1307  USA
# ----------------------------------------------------------------------------
#
# Introduced by WarEagle at the forum.meetthegimp.org . August 22, 2008,  V0.1
# Modified  by lhgray to support Windows and added some text options.   \
#   Sept 08, 2008,  V0.2
# Modified  by rob.brz1 : reorganising the code and adding a couple of options.\
#   May 30, 2010,  V0.3
# 
# -----------------------------------------------------------------------------
# Description :
# Prerequisite software beside Python 2.6: gimp (tested on ver 2.6.7), a text \
#   editor  and 'exiftool'. 
# It adds an info banner under or over or beside the photo already present in gimp,
#   if there is a file with exif of that photo on disk.
#   Can edit some parts of the attached exif, produce and view exif files.
# ExifTool site : http://www.sno.phy.queensu.ca/~phil/exiftool/

# -----------------------------------------------------------------------------

__metaclass__ = type
import os
import commands
import subprocess
import platform

from gimpfu import *
import os.path
import sys

# import gettext
# gettext.install("gimp20-python", gimp.locale_directory, unicode=True)

########################## PART DEPENDENT ON PLATFORM ##########################
DIR_SEPARATOR = os.sep

class FileOS:
    
    def setCmd(self, cmd):
        self.cmd = cmd
        if platform.system() == 'Windows':
            # to find the file char set for 'Windows'
            self.cmd=cmd.encode(sys.getfilesystemencoding())  
        return self.cmd
        
    def file_size(self):
        return "%.1f" % round(os.path.getsize(self.cmd)/1024.0, 1)

    def file_erase(self):
        if os.path.isfile(self.cmd): 
            os.remove(self.cmd)
            gimp.message("NOTE:\n An exif text file has been remove.")

    def editor(self):
        if platform.system() == 'Windows':
            subprocess.Popen(self.cmd)
        else:
            subprocess.Popen(self.cmd, shell=True)

def getExifInfo(exiftool, switches, tag_item, filename):
    '''
     To isolate the part of the script that call the 'exiftool' program, which
       depends on the operating system.
     Need also the above class FileOS.

          input for getExifInfo()
     exiftool   : the path to the external program exiftool
     switches   : the options to give for exiftool
     tag_item   : the tags for the info wanted in the exif
     filename	: the path to the photo file

          output of getExifInfo()
     out        : the output of exiftool
     status     : message pass to stderror by the call (function failed if this
                  is not a warning)
    '''
    # construction of the command line for ExifTool,
    #   a space between items is important.
    # for non ascii char in file path, not in utf-8 for Win XP
    tool = FileOS(); file_name = FileOS()   
    tool_val=tool.setCmd(exiftool); file_name_val=file_name.setCmd(filename)
    cmdstr = "\"" +tool_val+ "\"" +' '+ switches +' '+ tag_item +' '+ "\""\
        +file_name_val+ "\""

    PIPE = subprocess.PIPE
    # Next 'if' inspired by LHG to support windows, 05Sept2008
    if platform.system() == 'Windows':  # LHG
        p = subprocess.Popen(cmdstr, universal_newlines=True, stdout=PIPE, stderr=PIPE)
        # returns a tuple (stdoutdata, stderrdata), replaces: out = p.stdout.readlines()
        out, status = p.communicate()
        if out:
            # remove whitespace at both ends, like newline: \n, same as Linux output
            out = out.strip()

    else:                       # for Linux
        status, out = commands.getstatusoutput(cmdstr)
        # for getstatusoutput() status is a number while in Popen() it's a string
        if status: status = str(status)
    if status:                  # problem?
        gimp.message("WARNING MESSAGE from exiftool call:\n status = " + status\
            +"\n output = "+ out)
        assert status.find('already exists') != -1 or status == '256', \
            'exiftool call is in error for the command line '+cmdstr

    # gimp.message("The variable 'out' is: (%s)\n for %s.\n" %(out, tag_item))
        # for developpement
    if out.find('Warning: ') != -1 or not out:
        # 'not out': no such tag in filename?
        out = ""
    
    return(out, status)

########################## INDEPENDENT OF PLATFORM #############################

def lineExifCollect(the_line, excep, options, exiftool, filename):
    '''
     Collect and organize a line of info from exiftool with possibility of one 
     substitution from input in the initial dialog.

          input for lineExifCollect()
     the_line	: the line of info in question
     excep    : tuple for the subtitute item
     options  : the options for exiftool
     # line_dict : global

          output of lineExifCollect()
     text_line : the formatted text line of info
    '''
    # construct the composite tag and call exiftool
    tag_item = ' '.join(line_dict[the_line]['tag'])
    value = getExifInfo(exiftool, options[5:], tag_item, filename)[0]
    
    # massage output
    len_in = len(line_dict[the_line]['tag'])
    if value:
        value_corr = value.split('\n')
        len_out = len(value_corr)
        miss_num = len_in - len_out  # number of missing tag in filename?
        # identify the indices of the missing tag and correct
        i = count = 0
        while count < miss_num:
            tag_m = line_dict[the_line]['tag'][i][1:]
            tag_m = tag_m[tag_m.find(':')+1:]   # take care of 'exif:ISO' for ex.
            if value.find(tag_m) == -1:
                count += 1
                value_corr.insert(i, ' ???  ')
            i += 1
    else:
        value_corr = [' ???  ']*len_in

    # construct text_line
    text_line = line_dict[the_line]['header']
    i = 0
    for item in value_corr:
        if item != ' ???  ':
            item = item[item.find(':')+2:]
        if excep:
            if i == excep[0]:
                item = excep[1]
        text_line += line_dict[the_line]['name'][i] + item +  " , " 
        i += 1
            
    text_line = text_line[:-2] + '.'
    return(text_line)
################################################################################

def insertExifInfo(img, drw, exiftool, text_editor, do_exif, source_file,\
                   on_edge, lines, language, font, do_descrip, do_photog,\
                   written_1, do_comment, written_2, save_exif):
    #, tag_req
    '''
     Uses exiftool on the file to put some photo info in a banner under or 
     beside the photo and/or view some or all the exif, another way.

     main function
    '''
    global line_dict    # dictionary to control the info wanted on the image
    # name of the object to make filename handling more platform independent
    file_cmd = FileOS() 

    version = gimp.version  # it is a tuple like (2, 6, 11) a sequence of 3 numbers
    start_minver = 6        # starting minor version

    # gimp.message("NOTE:\n CODESET is "+locale.nl_langinfo(locale.CODESET))
    img.undo_group_start()
    layer = pdb.gimp_layer_new_from_visible(img, img, "visible")
    img.add_layer(layer, -1)
    if version[1] > 6:
        pdb.gimp_image_raise_item_to_top(img, layer)
    else: pdb.gimp_image_raise_layer_to_top(img, layer)
    pdb.gimp_image_set_active_layer(img, layer)
    
    # 1 PREPARATIONS =============================

    offsety = 0
    lines = lines.strip()
    if lines:
        if on_edge == 1 or on_edge == 2:
            # 1=Right: rotate 90° clockwise and displace to bottom
            # 2=Left: rotate 90° clockwise and place on top
            pdb.gimp_image_rotate(img, ROTATE_90)
        # on_edge = 0, Bottom: displace to
        # on_edge = 3, Top: do nothing

    width = layer.width
    height = layer.height

    if on_edge == 0 or on_edge == 1: offsety = height


    # option switches (note: -@ ARGFILE    Read command-line arguments from file)
    # language abbreviations supported for ver. 7.76: 'cs de en en_ca en_gb es \
    #   fr it ja ko nl pl ru sv tr zh_cn zh_tw'
    options = "-s -s -s -lang %s" % language

    #pdb.gimp_image_clean_all(img)
    filename=img.filename;
    if filename==None:
        gimp.message("ERROR:\n there is no filename!\n Suggestion: save your "\
            +"photo and restart the script. End of plug-in.")
        return

    # 2 COPY THE 'EXIF-DATA' FROM A FILE TO THE IMAGE =================

    # some function like 'upsize' create new image from old with no 'exif-data'\
    #    and other with truncated 'exif-data'!
    if do_exif == 1:
        source_file = file_cmd.setCmd(source_file)
        mess = getExifInfo(exiftool, '-TagsFromFile', "\"" +source_file+ "\"", \
            filename)[0]
        # Copy the values of all writable tags from source_file to filename, \
        #   writing the information to the preferred groups. 
        gimp.message("NOTE, EXIF COPYING:\n If everything is ok 'Exiftool' "\
            +"updates the photo file with the exif of the chosen "\
            +"file (%s). \nExiftool message: %s" \
            %(source_file[source_file.rfind(DIR_SEPARATOR)+1:], mess))

    if do_exif == 2:    # erase exif
        mess = getExifInfo(exiftool, '-s', '-all=', filename)[0]
        gimp.message("NOTE, EXIF ERASING:\n If everything is ok 'Exiftool' "\
            +"erases the exif of the file "\
            +"%s and renames the original. \nExiftool message: %s" \
            %(filename[filename.rfind(DIR_SEPARATOR)+1:], mess))        

    para_tupl = img.parasite_list()
    gimp.message("INFO:\n The list of 'parasites' attached to this photo is:\n "\
        +str(para_tupl))
    if not 'exif-data' in para_tupl and not do_exif == 1 or do_exif == 2:
        gimp.message("ERROR OR WARNING:\n There is or will be no exif attach "\
            +"to this photo.\nEnd of the plug-in.")
        return
    
    # the tag values in the next dictionary may be an exiftool tag or a string \
    #   (a variable name)
    file_cmd.setCmd(filename)
    size_Kb = file_cmd.file_size()
    line_dict = {
        'file':{
            'header': "",
            'name':["Photo file name: ","File size (Kb): "],
            'tag':[str(filename), size_Kb]
        },
        'title':{
            'header': "",
            'name':["Photo description: ", "Photographer: "],
            'tag':['-ImageDescription', '-Exif:Artist']
        },
        'parameters':{
            'header': "Shooting parameters:  ",
            'name':["ISO: ", "F number: ", "Expo. time (s): ", "Focal length: "],
            'tag':['-Exif:ISO', '-Exif:FNumber', '-Exif:ExposureTime', \
                '-Exif:FocalLength']
        },
        'gears':{
            'header': "Materials used:  ",
            'name':["Lens: ", "Camera: ", "Flash: "],
            'tag':['-LensID', '-Exif:Model', '-Exif:Flash']
        },
        'place':{
            'header': "",   #"Place and time:  ",
            'name':["Occasion & place: ", "Date & time: "],
            'tag':['-UserComment', '-CreateDate']
        }
    }
    # line_dict.keys()), n.b.: it's not in the order of the declaration

    
    # personal translation or interpretation for output
    if language == 'fr':
        line_dict = {
            'file':{
                'header': "",
                'name':["Nom du fichier image: ", "Taille du fichier (Ko): "],
                # 'tag' don't need translation, taken care by 'exiftool'!
                'tag':[str(filename), size_Kb]},    
            'title':{
                'header': "",
                'name':["Description de l'image: ", "Photographe: "],
                'tag':['-ImageDescription', '-Exif:Artist']},
            'parameters':{
                'header': "Paramètres de la prise:  ",
                'name':["ISO: ", "Nombre F: ", "Temps d'expo. (s): ", "Focale: "],
                'tag':['-Exif:ISO', '-Exif:FNumber', '-Exif:ExposureTime', \
                    '-Exif:FocalLength']},
            'gears':{
                'header': "Matériels:  ",
                'name':["Objectif: ", "Caméra: ", "Flash: "],
                'tag':['-LensID', '-Exif:Model', '-Exif:Flash']},
            'place':{
                'header': "",   #"Endroit et temps:  ",
                'name':["Occasion & endroit: ", "Date & heure: "],
                'tag':['-UserComment', '-CreateDate']}
        }

    # add your language here ...

    # 3 EDIT SOME EXIF ===========================

    # change exif value for 'description', 'photographer', 'copyright' and 'occasion'
    if do_descrip>0 or do_photog>0 or do_comment>0:
        written_1 = written_1.split('\n')
        written_2 = written_2.split('\n')
    
    do_bool = [do_descrip == 2 , do_photog == 1 , do_comment == 2 or \
               do_comment == 3 , do_comment > 2 ]
    if do_bool.count(True) > 0:
        do_tag = ['-Exif:ImageDescription='+ "\""+written_1[0]+"\"", '-Exif:Artist='\
            + "\""+written_1[len(written_1) -1]+"\"", '-UserComment='+ "\""\
            +written_2[0]+"\"", '-Copyright='+ "\""+written_2[len(written_2) -1]+"\""]
        do_tag_cons = []
        for i in range(0, len(do_bool)):
            if do_bool[i]:
                do_tag_cons.append(do_tag[i])
        item = ' '.join(do_tag_cons)
        mess = getExifInfo(exiftool, '-s', item, filename)[0]
        gimp.message("NOTE, CHANGE IN EXIF:\n If everything is ok 'Exiftool' "\
            +"creates an automatic new file with the updated description, "\
            +"in the same directory as the photo file and renames the original"\
            +". \nExiftool message: "+mess)

    # 4 INFO COLLECTION AND ORGANISATION =========

    # group info by subject line (a dictionary with subject as key)
    text = ''
    if lines :
        lines = lines.split(' ')
        for item in lines:
            item = item.strip()
            # item in line_dict.keys() to verify this input
            if item not in line_dict.keys():
                gimp.message("WARNING:\n The line '%s' has not been "%item\
                    +"recognized in this plug-in, so it will be skipped.")
                continue
            if item == 'file':     # case without exiftool
                # File name of the photo:
                text += line_dict['file']['name'][0] + line_dict['file']['tag'][0]\
                    + " , "
                text += line_dict['file']['name'][1] + line_dict['file']['tag'][1]\
                    + " .\n"
             # other case without exiftool
            elif item == 'title' and do_descrip > 0 and do_photog > 0: 
                # previous: if not value: value = " !no description in exif!  "
                text += line_dict['title']['name'][0] + written_1[0] + " , " \
                    + line_dict['title']['name'][1] + written_1[1] + " .\n" 
            else:       
                excep = []
                if item == 'title' and do_descrip == 1 :     # do_descrip == 1
                    excep = [0, written_1[0]]
                if item == 'place' and do_comment == 1 :
                    excep = [0, written_2[0]]
                text += lineExifCollect(item, excep, options, exiftool, filename)\
                    + " \n"
        text = text[0:-2]
    
    # 5 DISPLAY THAT INFO ========================

    if text :
        # size of the font depends on the width of the image, estimation
        font_size = int(45.0 * width / 3000.0)
        text_width, text_height, text_ascent, text_descent = \
            pdb.gimp_text_get_extents_fontname(text, font_size, PIXELS, font)
        # maximize size of the font for images with small sizes or long info
        if font_size < 22 or text_width > width:  # if not use the estimation
            font_size = int(font_size*width*0.95/float(text_width-0.45))
            text_width, text_height, text_ascent, text_descent = \
                pdb.gimp_text_get_extents_fontname(text, font_size, PIXELS, font)
        if font_size < 6:
            gimp.message("ERROR:\n The size of the photo is too small so the "\
                +"text is unreadable.\nExit from the plug-in ...")
            exit

        else:
            newWidth = width
            newHeight = int(height+text_height+font_size)  
            if on_edge == 0 or on_edge == 1:
                img.resize(newWidth, newHeight, 0, 0)
                drw.resize(newWidth, newHeight, 0, 0)
            else:
                img.resize(newWidth, newHeight, 0, text_height+font_size)
                drw.resize(newWidth, newHeight, 0, text_height+font_size)

            # place a background layer before the text layer
            layer_bg = gimp.Layer(img, "background", newWidth, newHeight, RGBA_IMAGE,\
                100, NORMAL_MODE)  # LHG
            layer_bg.fill(BACKGROUND_FILL)    # LHG
            img.add_layer(layer_bg, -1)    # LHG
            if version[1] > 6:
                pdb.gimp_image_lower_item(img, layer_bg)
            else: pdb.gimp_image_lower_layer(img, layer_bg)

            # finally an EXIF text layer, with a transparent background above
            layer_text = pdb.gimp_text_layer_new(img, text, font, font_size, PIXELS)
            img.add_layer(layer_text, -1)    # LHG
            #pdb.gimp_image_lower_item(img, layer_text)
            pdb.gimp_layer_translate(layer_text, font_size/2, offsety\
                +font_size/2)

         
    # 6 TAGS AND FILE REQUESTED  =================

    if save_exif == 1:
        # if the file already exit then keep it (good precaution before a upsize\
        #   that destroy a large part of the exif!)
        status = getExifInfo(exiftool, options[9:], '-w _exif.txt', filename)[1]
        if status:
            gimp.message("NOTE:\n There was already an exif text file with the "\
                +"name %s_exif.txt and it's the one shown by the text editor."\
                %(img.name[:-4]))
        else:
            gimp.message("NOTE:\n A complete exif text file, in the specified "\
                +"language, has been created from %s by exiftool in that"%img.name\
                +" photo dir.\n It's name: %s_exif.txt"%img.name[:-4])
        view_file = text_editor+" \"" +filename[:-4] +'_exif.txt'+"\""
        file_cmd.setCmd(view_file)
        file_cmd.editor()

    if save_exif == 2:
        # if the file already exit then erase it and create a new one
        exif_filename = filename[:-4] +'_exif.txt'
        file_cmd.setCmd(exif_filename)
        file_cmd.file_erase() 
        status = getExifInfo(exiftool, options[9:], '-w _exif.txt', filename)[1]
        gimp.message("NOTE:\n A complete exif text file, in the specified "\
            +"language, has been created from %s by exiftool in that "%img.name\
            +"photo dir.\n It's name: %s_exif.txt" %img.name[:-4])
        view_file = text_editor+ " \"" + exif_filename +"\""
        file_cmd.setCmd(view_file)
        file_cmd.editor()

    if save_exif == 3:
        status = getExifInfo(exiftool, '-s -f', '-w _tags.txt', filename)[1]
        if status:
            gimp.message("NOTE:\n There was already an exif tags file with the "\
                +"name %s_tags.txt and it's the one shown by the text editor."\
                %(img.name[:-4]))
        else:
            gimp.message("NOTE:\n A view exif tags file has been created from "\
                +"%s by exiftool in that photo dir.\n It's name: %s_tags.txt"\
                %(img.name, img.name[:-4]))
        view_file = text_editor+" \"" +filename[:-4] +'_tags.txt'+"\""
        file_cmd.setCmd(view_file)
        file_cmd.editor()

    #if tag_req.find('?') == -1 and tag_req.find('=') == -1 and tag_req:
        #tag_req_mess = getExifInfo(exiftool, '-s -f', tag_req, filename)[0]
###        tag_req_mess = tag_req_mess.decode('latin-1')
        #try:        # does not work here, bug in gimp.message?
            #gimp.message("Requested exif info for " + img.name +" :\n"+ tag_req_mess)
        #except:
            #gimp.message("Requested exif info (not in utf-8) for " + img.name \
                #+" :\n"+ repr(tag_req_mess))
            # for special char in value not in utf-8       
    
    # 7 REPLACE THING(S) =========================

    if lines:
        if on_edge == 1 or on_edge == 2:
            # return the orientation as before the script
            pdb.gimp_image_rotate(img, ROTATE_270)  

    img.undo_group_end()
    gimp.displays_flush
        

register(
    "insert_Exif_Info",
    "Insert the exif info on the photo border and other options. Necessitate the"\
        +" program exiftool.",
    #  Plug-in file: +__file__, # to reduce the dialog height
    "Insert exif info on a panel added to the photo border from the photo file"\
        +" and/or manipulates exif.",
    "Meetthegimp-Community http://forum.meetthegimp.org/index.php/topic,56",
    "GPL License",
    "2008",
    "_Info from Exiftool...",
    "*",
    [(PF_IMAGE, "img", "IMAGE:", 0),
     (PF_DRAWABLE, "drw", "DRAWABLE:", 0),
    
     (PF_FILE, "exiftool", "____________________________ PROGRAMS NEEDED "\
       +"_____\n->Location of exiftool:", r"/bin/exiftool"),
      # for Win something like "C:\Program Files\GIMP-2.0\bin\exiftool.exe"
     (PF_FILE, "text_editor", "->Text editor to use for '__ OTHER OPTION __':",\
       r"geany"),
      # for Win something like "C:\Program Files\Notepad++\notepad++.exe"
     (PF_OPTION, "do_exif", "__________________________ GLOBAL CHANGE IN EXIF?"\
       +" _____\n->Copy all writable tags from a source to a "\
       +"destination file?\nDestination file being a save copy of the open "\
       +"image.", 0, ["Don't change globally",\
       "Copy the exif from...", "Erase the exif values"]),
     (PF_FILE, "source_file", "->Source file to copy the exif from, "\
       +"if 'Copy the exif from...' above:", r""),
    
     (PF_OPTION, "on_edge", "____________________________ INFO ON THE "\
       +"IMAGE _____\n->Place the info along what edge?" , \
       +0, ["Bottom", "Right", "Left", "Top"]),
     (PF_STRING, "lines", "->Write the line names of info in the order wanted:"\
       +"\nThe names: title, file, parameters, gears, place.", "file parameters gears"),
     (PF_STRING, "language", "->Write the output language wanted (supported by "\
       +"'exiftool'):\nChoices: cs de en en__ca en__gb es fr it ja ko nl "\
       +"pl ru sv tr zh__cn zh__tw...", 'en_ca'),
     (PF_FONT, "font", "->Font type:", "Sans"),
    
     (PF_OPTION, "do_descrip", "____________________________ EDIT SOME EXIF? "\
       +"_____\n->Choice of source for description? ", 0,\
       ["Photo description from exif", "Write description below", \
       "Write description below & edit exif"]),
     (PF_OPTION, "do_photog", "->Edit the photographer name? ", 0, \
       ["No, photographer from exif", "Write photog. below & edit exif"]),
     (PF_TEXT, "written_1", "->If any precedent options was 'Write ... below ...'."
       +"\n Enter here (if both, one per line: description <enter> photographer)."\
       , r""),
     (PF_OPTION, "do_comment", "->Choice of source for comment on place or "\
       +"copyright ? ", 0, ["User comment from exif", \
      "Use comment written below", "Write comment below & edit exif", \
      "Write comment and copyright below & edit exif", \
      "Write copyright below & edit exif"]),
     (PF_TEXT, "written_2", "->If the precedent option was 'Write ... below ...'."\
       +"\nEnter here (if both, one per line: comment <enter> copyright). ", r""),
    
     (PF_OPTION, "save_exif", "____________________________ OTHER OPTION "\
       +"_____\n->Save the exif info in a text file with 'exiftool'"\
       +" and view ", 0, ["No file", "Old exif file if there, "
      +"if not new", "New exif file in all cases", "Tag file"])
     #(PF_STRING, "tag_req", "->Additional tags request to only read in the "\
       #+"'Error Console',\n(put a space between tags) "\
       #, "-DateTimeOriginal -Copyright -ColorSpace -PrimaryPlatform")
    ],
    [],
    insertExifInfo,
    menu = "<Image>/Extensions/Plugins-Python/File" )
    
main()
