#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import os

#==============================================================================
#==================== function used for error/message logging =================
#==============================================================================
def Log(text):
    '''
    Function used for testpurpose and error logging because 'print'
    doesn't work on windows systems.
    Aargh...: use cmd, go to the root, path should point to the Gimp bin then
    type at the prompt: "gimp-2.8 > error.txt 2>&1" without quotes of course.
    All the output of Gimp will be written in error.txt (here in the root path).
    
    Input: text to log
    Output: error file in the indexprint/errorlog directory
    '''
    filename = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            'errorlog/Error.log')
    f=file(filename, "a+")
    f.write(text+"\n")
    f.close()
