#ifndef __GIMP_BLP_H__
#define __GIMP_BLP_H__

gint32
ReadBLP (const gchar *name, GError **error);

#endif
