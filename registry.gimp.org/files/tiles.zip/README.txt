tiles.scm by John Irving copyright 2009

SCRIPT OPTIONS
This script takes in up to 10 different colours and creates tiles with them by selecting the colours at random.
You can choose how many colours will be used by inputting a value for "Num of Colours", the maximum being 10.
If you choose to use 5 colours by entering 5 in the "Num of Colours" field, then the first 5 colours in the list will be chosen at random to create the tiles.
The Image Width and Height fields determine the total size of the image and the Tile Width and Height fileds determine the size of the tiles.
The grout between the tiles is drawn using a selectable brush and colour.
The script uses a pencil tool to draw the grout, not a brush tool, which keeps the grout lines nice and neat.

EXAMPLE
An example of the image which is created using the default settings has also been included.

PERFORMANCE
Using the default settings means that an image of size 800x600 pixels is created with the tiles set at 7x7 pixels.  This gives approximately 9800 tiles.
As you can imagine, it can take quite a while for Gimp to draw all 9800 tiles so please be patient.
The script will take longer to execute if you make the image size larger, and you make the tile size smaller.

INSTALLING
I have included a brush which is chosen by default when the script dialogue opens up.
Copy the brush to your "Brushes" directory in your "Gimp" directory to use it or create your own brush.
Copy the "tiles.scm" file to the "Scripts" directory in your "Gimp" directory to use it.
The script appears in the "Filters -> Artistic" menu.
