/* GIMP Plug-in Guillotine-into-Layers v0.1
 * Copyright (C) 2000  Randall Sawyer <srandallsawyer@gmail.com> (the "Author").
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of the Author of the
 * Software shall not be used in advertising or otherwise to promote the
 * sale, use or other dealings in this Software without prior written
 * authorization from the Author.
 */

#include <libgimp/gimp.h>
#include <glib.h>

#include "plugin-intl.h"
#include "guillotine_into_layers.h"


/*  Function declarations */

static void   query    (void);

static void   run      (const gchar       *name,
                        gint               nparams,
                        const GimpParam   *param,
                        gint              *nreturn_vals,
                        GimpParam        **return_vals);

static gint32
guillotine_into_layers (gint32             image_ID,
                                      GimpPDBStatusType *status);

/*  Plug-in Required  */

GimpPlugInInfo PLUG_IN_INFO =
{
  NULL,  /* init_proc  */
  NULL,  /* quit_proc  */
  query, /* query_proc */
  run,   /* run_proc   */
};

MAIN ()

/*  Function definitions  */

static void
query (void)
{
  static const GimpParamDef args[] =
    {
      { GIMP_PDB_INT32, "run-mode",     "Interactive, Non-interactive"  },
      { GIMP_PDB_IMAGE, "image",        "Input image"                   }
    };
  static const GimpParamDef return_vals[] =
    {
      { GIMP_PDB_IMAGE, "image",        "Output image"                  }
    };

  gimp_install_procedure (PROCEDURE_NAME,
                          PROCEDURE_BLURB,
                          PROCEDURE_HELP,
                          PROCEDURE_AUTHOR,
                          PROCEDURE_COPYRIGHT,
                          PROCEDURE_YEAR,
                          PROCEDURE_MENU_ITEM,
                          "RGB*, INDEXED*, GRAY*",
                          GIMP_PLUGIN,
                          G_N_ELEMENTS( args ), G_N_ELEMENTS( return_vals ),
                          args, return_vals);

  gimp_plugin_domain_register (PROCEDURE_NAME, LOCALEDIR);

  gimp_plugin_menu_register (PROCEDURE_NAME, "<Image>/Image/Transform");
}

static void
run (const gchar      *name,
     gint              nparams,
     const GimpParam  *param,
     gint             *nreturn_vals,
     GimpParam       **return_vals)
{
  static  GimpParam values[2];
  GimpRunMode       run_mode;
  gint32            image;
  gint32            new_image;
  gboolean          was_dirty;
  GimpPDBStatusType status = GIMP_PDB_SUCCESS;

  *nreturn_vals = 1;
  *return_vals  = values;

 /*  Initialize i18n support  */
  bindtextdomain (PROCEDURE_NAME, LOCALEDIR);
  bind_textdomain_codeset (PROCEDURE_NAME, "UTF-8");
  textdomain (PROCEDURE_NAME);

  run_mode = param[0].data.d_int32;
  image    = param[1].data.d_image;

  was_dirty = gimp_image_is_dirty (image);
  new_image = guillotine_into_layers (image, &status);

  /*  status == GIMP_PDB_SUCCESS  */
  /*  ~~ All is as expected. ~~~  */

  if (status == GIMP_PDB_PASS_THROUGH)
  /*  Image created without expected number of layers.  */
  {
    if (run_mode == GIMP_RUN_NONINTERACTIVE)
      g_warning (STATUS_ERROR_1);
    else
      gimp_message (STATUS_ERROR_1);
  }

  if (status == GIMP_PDB_EXECUTION_ERROR)
  /*  Image not created.  */
  {
    if (run_mode == GIMP_RUN_NONINTERACTIVE)
      g_warning (STATUS_ERROR_2);
    else
      gimp_message (STATUS_ERROR_2);
  }

  if (! was_dirty && gimp_image_is_dirty (image))
    gimp_image_clean_all (image);

  if (run_mode == GIMP_RUN_INTERACTIVE)
    {
      if (status != GIMP_PDB_EXECUTION_ERROR)
        gimp_display_new (new_image);
      gimp_displays_flush();
    }

  values[0].type = GIMP_PDB_STATUS;
  values[1].type = GIMP_PDB_IMAGE;

  values[1].data.d_image  = new_image;
  values[0].data.d_status = status;
}

static gint
position_compare_func (gconstpointer pos0,
                       gconstpointer pos1)
{
  return GPOINTER_TO_INT (pos0) - GPOINTER_TO_INT (pos1);
}

static gint32
guillotine_into_layers (gint32             image_ID,
                        GimpPDBStatusType *status)
{
  gint32  new_image_ID; //  Return value: the new image

  GList  *h_guides;     //  List of horizontal guides
  GList  *v_guides;     //  List of vertical guides
  gint    n_rects;      //  Number of rectangular regions
  gint    n_layers;     //  Number of layers in new image

    /*  Tally up the guides...  */
    {
  //  GList              *h_guides;.........Defined in this block
  //  GList              *v_guides;.........Defined in this block
      gint                width;        //  Source image's width
      gint                height;       //  Source image's height
      gint32              guide;        //  A guide,
      gint                position;     //  its position, and
      GimpOrientationType orientation;  //  its orientation

      width  = gimp_image_width (image_ID);
      height = gimp_image_height (image_ID);

      h_guides = g_list_append (NULL,   GINT_TO_POINTER (0));
      h_guides = g_list_append (h_guides, GINT_TO_POINTER (height));

      v_guides = g_list_append (NULL,   GINT_TO_POINTER (0));
      v_guides = g_list_append (v_guides, GINT_TO_POINTER (width));

      for (guide = gimp_image_find_next_guide (image_ID, 0);
           guide != 0;
           guide = gimp_image_find_next_guide (image_ID, guide))
        {
            position    = gimp_image_get_guide_position (image_ID, guide);
            orientation = gimp_image_get_guide_orientation (image_ID, guide);

          switch (orientation)
            {
            case GIMP_ORIENTATION_HORIZONTAL:
              if (! g_list_find (h_guides, GINT_TO_POINTER (position)))
                h_guides = g_list_insert_sorted (h_guides,
                                                 GINT_TO_POINTER (position),
                                                 position_compare_func);
              break;

            case GIMP_ORIENTATION_VERTICAL:
              if (! g_list_find (v_guides, GINT_TO_POINTER (position)))
                v_guides = g_list_insert_sorted (v_guides,
                                                 GINT_TO_POINTER (position),
                                                 position_compare_func);
              break;

            case GIMP_ORIENTATION_UNKNOWN:
              g_assert_not_reached();
              break;
            }
        }
    }
  //  GList *h_guides;
  //  GList *v_guides;



    /*  Count and measure the rectangular regions and
        Create the new image... */
    {
  //  gint32            new_image_ID;...Defined in this block
  //  gint              n_rects;........Defined in this block
      GList            *iter;       //  List iterator for scanning guides
      gint              n_cols;     //  Number of columns of regions
      gint              n_rows;     //  Number of rows of regions
      gint              width;      //  New image width = maximum width of regions
      gint              height;     //  New image height = maximum height of regions
      GimpImageBaseType base_type;  //  Base type of source image and of new image
      gchar            *filename;   //  File name for the new image

        {
      //  gint width;....Defined in this block
      //  gint n_cols;...Defined in this block

          width = 0;
          for (n_cols = 0, iter = v_guides;
               iter && iter->next;
               n_cols++, iter = iter->next)
            {
              width = MAX (width,
                           GPOINTER_TO_INT (iter->next->data) -
                           GPOINTER_TO_INT (iter->data));
            }
        }
      //  gint n_cols;
      //  gint width;

        {
      //  gint height;...Defined in this block
      //  gint n_rows;...Defined in this block

          height = 0;
          for (n_rows = 0, iter = h_guides;
               iter && iter->next;
               n_rows++, iter = iter->next)
            {
              height = MAX (height,
                            GPOINTER_TO_INT (iter->next->data) -
                            GPOINTER_TO_INT (iter->data));
            }
        }
      //  gint n_rows;
      //  gint height;

      base_type = gimp_image_base_type (image_ID);

      /*  Create the new image here!  */
      new_image_ID = gimp_image_new (width, height, base_type);

      /*  If unsuccessful, bail out now!  */
      if (new_image_ID == -1)
        {
          *status = GIMP_PDB_EXECUTION_ERROR;
          return new_image_ID;
        }
      /*  Otherwise, continue...  */

      n_rects = n_cols * n_rows;

        {
      //  gchar *filename;..........Defined in this block
          gchar *src_filename;  //  Source image's file name
          gchar *root_name;     //  Root name

          src_filename = gimp_image_get_filename (image_ID);
          if (src_filename)
            {
              gchar *suffix = g_strrstr (src_filename, ".");
              if (suffix)
                {
                  gsize len = GPOINTER_TO_SIZE (suffix) - GPOINTER_TO_SIZE (src_filename);
                  root_name = g_strndup (src_filename, len);
                }
              else
                {
                  root_name = g_strdup (src_filename);
                }
              g_free (src_filename);
            }
          else
            root_name   = g_strdup (GIL_UNTITLED);

          filename = g_strdup_printf ("%s-%s_%d_%s.xcf",
                                      root_name, GIL_SLICED_INTO,
                                      n_rects, GIL_LAYERS);
          g_free (root_name);
        }
      //  gchar *filename;

      gimp_image_set_filename (new_image_ID, filename);
        g_free (filename);
    }
  //  gint32 new_image_ID;
  //  gint   n_rects;

  /*  Before copying selections and creating new layers,
      Disable undo's... */
  gimp_image_undo_disable (image_ID);
  gimp_image_undo_disable (new_image_ID);

    /*  Populate the new image with layers... */
    {
  //  gint          n_layers;.............Defined in this block
      gint         *layers;           //  List of layers
      GList        *h_iter, *v_iter;  //  List iterators for scanning guides
      gint          row, col;         //  Row and column indices for rectangular selection
      gint          x, y;             //  Coordinates of a rectangular selection
      gint          width;            //  Width of a rectangular selection
      gint          height;           //  Height of a rectangular selection
      gint32        layer_ID;         //  A layer,
      gchar        *layer_name;       //  its name, and
      GimpImageType layer_type;       //  its type
      gint32        float_ID;         //  A floating layer

      /*  Purge the new image of inherent layer(s)... */
      do
        layers = gimp_image_get_layers (new_image_ID, &n_layers);
      while (n_layers && gimp_image_remove_layer (new_image_ID, *layers));
  //  n_layers == 0

      /*  Determine the layer type... */
      switch (gimp_image_base_type (new_image_ID))
        {
          case GIMP_RGB:
            layer_type = GIMP_RGBA_IMAGE;
            break;
          case GIMP_GRAY:
            layer_type = GIMP_GRAYA_IMAGE;
            break;
          case GIMP_INDEXED:
            layer_type = GIMP_INDEXEDA_IMAGE;
            break;
          default:
            g_assert_not_reached();
            break;
        }

      /*  Copy rectangular regions from source image and
          paste as layers in new image... */
      for (h_iter = h_guides, row = 0;
           h_iter && h_iter->next;
           h_iter = h_iter->next, row++)
        {
          y = GPOINTER_TO_INT (h_iter->data);
          height = GPOINTER_TO_INT (h_iter->next->data) - y;

          for (v_iter = v_guides, col = 0;
               v_iter && v_iter->next;
               v_iter = v_iter->next, col++)
            {
              x = GPOINTER_TO_INT (v_iter->data);
              width = GPOINTER_TO_INT (v_iter->next->data) - x;

              layer_name = g_strdup_printf ("%s %i_%i", GIL_REGION, col, row);

              layer_ID = gimp_layer_new (new_image_ID, layer_name,
                                         width,  height,
                                         layer_type,   100.0,
                                         GIMP_NORMAL_MODE);
              g_free (layer_name);

              if (! gimp_image_add_layer (new_image_ID, layer_ID, -1))
                continue;

              n_layers++;

              if (! gimp_rect_select (image_ID,
                                      (gdouble)x,     (gdouble)y,
                                      (gdouble)width, (gdouble)height,
                                      GIMP_CHANNEL_OP_REPLACE, FALSE, 0))
                continue;

              if (! gimp_edit_copy_visible (image_ID))  //  Requires Gimp 2.2 or later
                continue;

              float_ID = gimp_edit_paste (layer_ID, FALSE);

              gimp_floating_sel_anchor (float_ID);

            }
        }
    }
  //  gint n_layers;

  /*  Deselect... */
  gimp_rect_select (image_ID, 0, 0, 0, 0, GIMP_CHANNEL_OP_REPLACE, FALSE, 0);

  /*  No more editting procedures:  Enable undo's...  */
  gimp_image_undo_enable (image_ID);
  gimp_image_undo_enable (new_image_ID);

  /*  If not all expected layers were created, then return image as is... */
  if (n_layers != n_rects)
  {
    *status = GIMP_PDB_PASS_THROUGH;
    return new_image_ID;
  }

  /*  Successful execution of filter... */

  *status = GIMP_PDB_SUCCESS;
  return  new_image_ID;
}

