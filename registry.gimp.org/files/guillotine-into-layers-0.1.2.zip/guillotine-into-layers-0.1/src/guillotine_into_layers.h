/* GIMP Plug-in Guillotine-into-Layers v0.1
 * Copyright (C) 2000  Randall Sawyer <srandallsawyer@gmail.com> (the "Author").
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of the Author of the
 * Software shall not be used in advertising or otherwise to promote the
 * sale, use or other dealings in this Software without prior written
 * authorization from the Author.
 */

#ifndef __GUILLOTINE_INTO_LAYERS_H__
#define __GUILLOTINE_INTO_LAYERS_H__


#include "plugin-intl.h"

/*  Constants  */

#define PROCEDURE_NAME         "gimp-plugin-guillotine-into-layers"
#define PROCEDURE_BLURB      _("Slice visible contents of image along guides into layers of a new image")
#define PROCEDURE_HELP       _("Guillotine-into-Layers is a variation on the standard plug-in Guillotine.  This plug-in creates a new image with a number of layers - one for each rectangular region defined by the guides and edges of the original image.  The visible contents of each rectangular region are copied, and then pasted as a unique layer of the new image.  The new image derives its name from that of the original.  It is given the suffix '*.xcf' so that it can be readily saved in a format which preserves multiple layers.  The original image is unaffected.")
#define PROCEDURE_AUTHOR     _("Randall Sawyer")
#define PROCEDURE_COPYRIGHT  _("Copyright (C) 2009 Randall Sawyer")
#define PROCEDURE_YEAR         "2009"
#define PROCEDURE_MENU_ITEM N_("Guillotine into layers")

#define STATUS_ERROR_1       _("warning:  Failed to create at least one expected layer")
#define STATUS_ERROR_2       _("error:    Unable to create new image")

#define GIL_UNTITLED    _("Untitled")
#define GIL_SLICED_INTO _("sliced_into")
#define GIL_LAYERS      _("layers")
#define GIL_REGION      _("Region")


#endif /* __GUILLOTINE_INTO_LAYERS_H__ */
