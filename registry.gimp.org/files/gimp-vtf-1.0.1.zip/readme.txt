    GIMP VTF PLUG-IN 1.0.1
Tom Edwards, 21st November 2010
*******************************

To install, extract both the EXE and DLL to your
GIMP plug-ins folder. This is typically at 
C:\Users\<USER>\.gimp-x.x\plug-ins\.

If you prefer, there is also a plug-ins folder in 
your main GIMP installation. This is at 
<install dir>\lib\gimp\2.0\plug-ins\.

To get the latest version of the plugin and download 
source code, visit <http://code.google.com/p/gimp-vtf/>.

Changes
*******

1.0.1
 * Fixed save failure when using the only layer in the
   image as the alpha channel (can no longer do this)
 * Fixed error messages not making it from the file loader
   to GIMP
 * Sorted format list so that all the DXTs are at the top
 * Corrected alpha bit depth for RGBA16161616(F)
 * Code elegance, and fixed VS post-build event for users
   not called Tom