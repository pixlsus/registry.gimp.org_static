#include <libgimp/gimp.h>
#include <libgimp/gimpui.h>
#include <string.h>
typedef struct {
	float SFR;
	float TFR;
	gint LPP;
} framevals;
static framevals fv = {30, 30, 2};
int *layer_map;
int layers = 0;
static void query();
static void run(const gchar *name, gint nparams, const GimpParam *param, gint *nreturn_vals, GimpParam **return_vals);

GimpPlugInInfo PLUG_IN_INFO = {NULL, NULL, query, run};
MAIN()

static void query(){
	static GimpParamDef args[] = { { GIMP_PDB_INT32, "run-mode", "Run mode"}, { GIMP_PDB_IMAGE, "image", "Input image" }, { GIMP_PDB_DRAWABLE, "drawable", "Input drawable" } };
	gimp_install_procedure("plug-in-framerate", "Change animation framerate", "Changes animation framerate", NULL, NULL, NULL, "Change framerate", "RGB*, GRAY*, INDEXED", GIMP_PLUGIN, G_N_ELEMENTS (args), 0, args, NULL);
	gimp_plugin_menu_register("plug-in-framerate", "<Image>/Filters/Animation");
}

static gboolean framerate_dialog(){
        GtkWidget *dialog;
        GtkWidget *main_vbox;
        GtkWidget *main_hbox;
		GtkWidget *second_hbox;
		GtkWidget *third_hbox;
        GtkWidget *frame;
		GtkWidget *sframe;
		GtkWidget *tframe;
		GtkWidget *source_label;
        GtkWidget *target_label;
		GtkWidget *loops_label;
        GtkWidget *alignment;
		GtkWidget *al3;
		GtkWidget *sspinbutton;
        GtkWidget *spinbutton;
		GtkWidget *tspinbutton;
		GtkObject *sspinbutton_adj;
        GtkObject *spinbutton_adj;
		GtkObject *tspinbutton_adj;
        GtkWidget *frame_label;
		GtkWidget *s_frame_label;
		GtkWidget *t_frame_label;
		GtkWidget *al2;
        gboolean   run;

        gimp_ui_init ("", FALSE);

        dialog = gimp_dialog_new ("Change framerate", "Change framerate",
                                  NULL, 0,
                                  gimp_standard_help_func, "plug-in-framerate",

                                  GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                                  GTK_STOCK_OK,     GTK_RESPONSE_OK,

                                  NULL);

        main_vbox = gtk_vbox_new (FALSE, 6);
        gtk_container_add (GTK_CONTAINER (GTK_DIALOG (dialog)->vbox), main_vbox);
        gtk_widget_show (main_vbox);

        frame = gtk_frame_new (NULL);
		sframe = gtk_frame_new(NULL);
		tframe = gtk_frame_new(NULL);
        gtk_widget_show (frame);
		gtk_widget_show (sframe);
		gtk_widget_show (tframe);
        gtk_box_pack_start (GTK_BOX (main_vbox), frame, TRUE, TRUE, 0);
		gtk_box_pack_start (GTK_BOX (main_vbox), sframe, TRUE, TRUE, 0);
		gtk_box_pack_start (GTK_BOX (main_vbox), tframe, TRUE, TRUE, 0);
        gtk_container_set_border_width (GTK_CONTAINER (frame), 6);

        alignment = gtk_alignment_new (0.5, 0.5, 1, 1);
		al2 = gtk_alignment_new(0.4, 0.4, 1, 1);
		al3 = gtk_alignment_new(0.5, 0.5, 1, 1);
        gtk_widget_show (alignment);
		gtk_widget_show(al2);
		gtk_widget_show(al3);
		gtk_container_add(GTK_CONTAINER(sframe), al2);
        gtk_container_add (GTK_CONTAINER (frame), alignment);
		gtk_container_add (GTK_CONTAINER(tframe), al3);
        gtk_alignment_set_padding (GTK_ALIGNMENT (alignment), 6, 6, 6, 6);
		gtk_alignment_set_padding (GTK_ALIGNMENT (al2), 6, 6, 6, 6);
		gtk_alignment_set_padding(GTK_ALIGNMENT (al3), 6, 6, 6, 6);

        main_hbox = gtk_hbox_new (FALSE, 0);
		second_hbox = gtk_hbox_new(FALSE, 0);
		third_hbox = gtk_hbox_new(FALSE, 0);
        gtk_widget_show (main_hbox);
		gtk_widget_show(second_hbox);
		gtk_widget_show(third_hbox);
		gtk_container_add(GTK_CONTAINER(al2), second_hbox);
        gtk_container_add (GTK_CONTAINER (alignment), main_hbox);
		gtk_container_add(GTK_CONTAINER (al3), third_hbox);

        target_label = gtk_label_new_with_mnemonic ("_Source:");
        gtk_widget_show (target_label);
        gtk_box_pack_start (GTK_BOX (main_hbox), target_label, FALSE, FALSE, 6);
        gtk_label_set_justify (GTK_LABEL (target_label), GTK_JUSTIFY_RIGHT);

		source_label = gtk_label_new_with_mnemonic ("_Target:");
		gtk_widget_show(source_label);
	 gtk_box_pack_start (GTK_BOX (second_hbox), source_label, FALSE, FALSE, 6);
        gtk_label_set_justify (GTK_LABEL (source_label), GTK_JUSTIFY_RIGHT);

		loops_label = gtk_label_new_with_mnemonic("_Loops per pass:");
		gtk_widget_show(loops_label);
		gtk_box_pack_start(GTK_BOX(third_hbox), loops_label, FALSE, FALSE, 6);
		gtk_label_set_justify (GTK_LABEL (loops_label), GTK_JUSTIFY_RIGHT);
		
        spinbutton_adj = gtk_adjustment_new (fv.SFR, 0.1, 1000, 1, 5, 10);
        spinbutton = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton_adj), 1, 0);
        gtk_widget_show (spinbutton);
        gtk_box_pack_start (GTK_BOX (main_hbox), spinbutton, FALSE, FALSE, 6);
        gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (spinbutton), TRUE);
		
		sspinbutton_adj = gtk_adjustment_new(fv.TFR, 0.1, 1000, 1, 5, 10);
		sspinbutton = gtk_spin_button_new (GTK_ADJUSTMENT (sspinbutton_adj), 1, 0);
		gtk_widget_show(sspinbutton);
		gtk_box_pack_start (GTK_BOX (second_hbox), sspinbutton, FALSE, FALSE, 6);
		gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (sspinbutton), TRUE);
		
		tspinbutton_adj = gtk_adjustment_new(fv.LPP, 1, 4, 1, 1, 1);
		tspinbutton = gtk_spin_button_new (GTK_ADJUSTMENT (tspinbutton_adj), 1, 0);
		gtk_widget_show(tspinbutton);
		gtk_box_pack_start (GTK_BOX(third_hbox), tspinbutton, FALSE, FALSE, 6);
		gtk_spin_button_set_numeric (GTK_SPIN_BUTTON(tspinbutton), TRUE);

        frame_label = gtk_label_new ("Modify source framerate");
        gtk_widget_show (frame_label);
        gtk_frame_set_label_widget (GTK_FRAME (frame), frame_label);
        gtk_label_set_use_markup (GTK_LABEL (frame_label), TRUE);
		
		s_frame_label = gtk_label_new ("Modify target framerate");
		gtk_widget_show(s_frame_label);
		gtk_frame_set_label_widget(GTK_FRAME(sframe), s_frame_label);
		gtk_label_set_use_markup(GTK_LABEL(s_frame_label), TRUE);

		t_frame_label = gtk_label_new ("Loops per pass");
		gtk_widget_show(t_frame_label);
		gtk_frame_set_label_widget(GTK_FRAME(tframe), s_frame_label);
		gtk_label_set_use_markup(GTK_LABEL(t_frame_label), TRUE);

        g_signal_connect (spinbutton_adj, "value_changed",
                          G_CALLBACK (gimp_float_adjustment_update),
                          &fv.SFR);
		g_signal_connect(sspinbutton_adj, "value_changed", G_CALLBACK (gimp_float_adjustment_update), &fv.TFR);
        
		g_signal_connect(tspinbutton_adj, "value_changed", G_CALLBACK (gimp_int_adjustment_update), &fv.LPP);
		
		gtk_widget_show (dialog);
				

        run = (gimp_dialog_run (GIMP_DIALOG (dialog)) == GTK_RESPONSE_OK);

        gtk_widget_destroy (dialog);

        return run;
      }
int get_ms(char *s){
	int length = strlen(s);
	int i;
	int flag = 0;
	for(i = 0;i < length;i++){
		if(s[i] == '('){flag = 1; break;}
	}
	i++;
	if(flag){
		return atoi(s+i);
	}
	return -1;
}
static void run(const gchar *name, gint nparams, const GimpParam *param, gint *nreturn_vals, GimpParam **return_vals){
	static GimpParam values[1];
	GimpPDBStatusType status = GIMP_PDB_SUCCESS;
	GimpRunMode run_mode;
    GimpDrawable     *drawable;
	*nreturn_vals = 1;
	gchar *s;
	gint *lays;
	int item;
	int image;
	int new,nl;
	int u;
	int ep;
	gint lc;
	float oft,nft;
	float err=0;
	char buf[100],b2[100];
	*return_vals = values;
	int depth;
	values[0].type = GIMP_PDB_STATUS;
	values[0].data.d_status = status;
	run_mode = param[0].data.d_int32;
	drawable = gimp_drawable_get (param[2].data.d_drawable);
	image = gimp_drawable_get_image(drawable->drawable_id);
	lays = gimp_image_get_layers(image, &nl);
	int ms = get_ms(gimp_item_get_name(lays[0]));
		if(ms > 0){
		fv.SFR = 1000/ms;
	}
	if(!framerate_dialog()){return;}
	if(nl < 2){g_message("Cannot work on image with less than 2 layers!\n"); return;}
	gimp_image_undo_group_start(image);
	oft = (float)1000/fv.SFR;
	nft = (float)1000/fv.TFR;
	lays = gimp_image_get_layers(image, &nl);
	gimp_progress_init("Changing framerate");
	for(u = 0;u < nl;u++){
		err += nft - oft;
		if(err > nft){
			gimp_image_remove_layer(image, lays[u]); 
			//lays = gimp_image_get_layers(image, &nl);
			err -= nft;
		}
		gimp_progress_update(((float)u / (float)nl) * .75);
	}
	depth = 0;
	while(-err > nft){
		for(u = 0;u < nl;u++){
			for(ep = 0;-err > nft && ep < fv.LPP;ep++){
				new = gimp_layer_copy(lays[u]);
				sprintf(buf, "%d_%s", depth+ep, gimp_item_get_name(lays[u]));
				gimp_item_set_name(new,buf);
				gimp_image_add_layer(image, new, u++);
				err += nft;
				lays = gimp_image_get_layers(image, &nl);
		  }
			gimp_progress_update(((float)u / (float)nl) * .75);
		}
		depth+=2;
	}
	lays = gimp_image_get_layers(image, &nl);
	for(u = 0;u < nl;u++){
		strcpy(buf,gimp_item_get_name(lays[u]));
		for(ep = 0;buf[ep] != '(' && ep < strlen(buf);ep++);
		buf[ep] = 0;
		sprintf(b2, "%s (%0.0fms)", buf, nft);
		gimp_item_set_name(lays[u], b2);
		gimp_progress_update((((float)u / (float)nl) * .25) + 0.75);
	}
	gimp_image_undo_group_end(image);
}