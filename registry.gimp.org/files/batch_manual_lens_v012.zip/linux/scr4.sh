#!/bin/bash
# bashufraw.sh

gimp -i -b "(manual-lens-mf \"*.tif\")" -b "(gimp-quit 0)"

echo "Done!"

# ${file%.CR2} = the $file variable without the ".CR2" part!

