#!/bin/bash
# bashufraw.sh

for file in `ls *.CR2`
do
	ufraw-batch $file --output=b${file%.CR2}n1.tif --exposure=auto --out-type=tif --noexif  --base-curve=linear --curve=linear --clip=film --restore=lch --saturation=1.30
done

gimp -i -b "(manual-lens-mf \"b*.tif\")" -b "(gimp-quit 0)"

echo "Done!"

# ${file%.CR2} = the $file variable without the ".CR2" part!

