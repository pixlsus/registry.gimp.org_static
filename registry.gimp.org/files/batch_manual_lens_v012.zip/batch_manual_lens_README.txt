MANUAL LENS FILTER, BATCH VERSION

filter version: 0.1.2
licence: GNU GPL v3
copyright: John Lakkas

USERS MANUAL


General:

	This filter package contains scripts for batch processing of pictures
	in Raw or Bitmap format. This package contains scripts witch depend
	on GIMP and extra software as UFRaw and Enblend, if you intend to try
	these scripts you will need UFRaw and Enblend.


Package contains:

	Four scripts for windows os:
	scr1.bat
	scr2.bat
	scr3.bat
	scr4.bat

	Same four scripts for linux/unix os:
	scr1.sh
	scr2.sh
	scr3.sh
	scr4.sh

	Readme file

	And the batch manual lens filter for GIMP:
	manual-lens-multifile.scm


Scripts description:

	Batch Script 1 (scr1):
		Develops every raw file found in the script folder in three different
		tiffs, each with different exposure. One tiff bright +2EV, one dark -1EV
		and one normal 0EV. Then enfuses those trios into one tiff with enfuse.
		Finally it applies the manual lens filter.

	Batch Script 2 (scr2):
		scr1 and scr3 combo

	Batch Script 3 (scr3):
		Develops every raw file found in the script folder and then applies manual
		lens filter on it.

	Batch Script 4 (scr4):
		Applies manual lens filter to tiff files found in the script folder
		(creates new tiffs, no overwrites)



IN WINDOWS:

	1. Download ufraw and enfuse for windows:
		http://ufraw.sourceforge.net/
		http://enblend.sourceforge.net/


	2. Unzip enfuse in a folder of your choice, prefer folder paths with no spaces.

	
	3. In Windows environmental variable "Path" paste the following in the end
		(Right click My Computer->Advanced System Setings->Advanced->Environmental Variables...):
		* Note: replace [ENFUSE_FOLDER] with the path of your enfuse copy.

		Windows 64bit:
		;c:\Program Files (x86)\GIMP-2.0\bin;[ENFUSE_FOLDER]

		Windows 32bit:
		;c:\Program Files\GIMP-2.0\bin;[ENFUSE_FOLDER]


	4. Create a folder and place *.cr2 or *.tiff files in it
		(for other raw files modify the scr1.bat, scr2.bat, scr3.bat files with notepad)
		Note: processing takes time


	5. Copy in the folder the batch (*.bat) files


	6. Run one of the above batch files


	7. Inspect created files
		> files starting with g mean cooked with GIMP files
		> files containing en mean they got enfused
		> files strating with b mean simple raw development (no enfusion)



IN LINUX/UNIX:

	1. Install ufraw and enfuse from the os repository


	2. Create a folder and place *.cr2 or *.tiff files in it
		(for other raw files modify the scr1.sh, scr2.sh, scr3.sh files)
		Note: processing takes time


	3. Copy in the folder the shell (*.sh) files


	4. Run one of the above shell files, you may have to give
		execution permission to the .sh files (scr1.sh, scr2.sh, scr3.sh, scr4.sh)


	5. Inspect created files
		> files starting with g mean cooked with GIMP files
		> files containing en mean they got enfused
		> files strating with b mean simple raw development (no enfusion)
