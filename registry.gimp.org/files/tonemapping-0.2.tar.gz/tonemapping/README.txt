Rainbow tonemapping - gimp plugin
(current version 0.2)

This is a tool that makes fancy/unrealistic colors in image. Even though the result seems to be quite random, there is mathematic algorithm behind it.

LOCATION (within GIMP):
You can find it under FILTERS/ARTISTIC/RAINBOW TONEMAP

HOW IT WORKS:
To explain it, I will try this:
Presume you have simple gradient from black (value: 0) to white (value: 255). If you use period 80 , then gradient with lenght 255 is splitted to about 3 gradients where color changes from 0 to 255.

This si very primitive scenario, which presumes that from original image we take brightness (ignoring individual RGB values) and also presuming that target (or border) colors are black and white. 

However, in this plugin target border colors are custom. Also plugin has two modes:
   1-band - brightness based and 
   3-bands - working on individual RGB bands

This explanation might not be sufficient, I reccomend playing with various values to see results.


INSTALLATION:
I develop on/for linux so to compile the plugin run:
   $gimptool-2.0 --install tonemapping.c         # for current user
   $gimptool-2.0 --install-admin tonemapping.c   # for system wide installation
   
As by now I can not help you with installation on other systems

CONTACT:
any comments welcomed at 
tiborb95 at gmail dot com

(2 Sep 2011)
