tiles2.scm by John Irving copyright 2009

SCRIPT OPTIONS
This script takes in up to 6 different colours and creates tiles with them by selecting the colours at random based on the percentage values for each colour.
You can choose how many colours will be used by inputting a value for "Num of Colours", the maximum being 6.
If you choose to use 3 colours by entering 5 in the "Num of Colours" field, then the first 5 colours in the list will be used to create the tiles.

The Image Width and Height fields determine the total size of the image and the Tile Width and Height fileds determine the size of the tiles.
The grout between the tiles is drawn using a selectable brush and colour.
The script uses a pencil tool to draw the grout, not a brush tool, which keeps the grout lines nice and neat.

PERCENTAGE FIELDS
The percentage values for each colour determine the percentage of tiles which will be drawn in that colour.
The percentage values for each colour that are to be used must add up to "100".
e.g. You choose to use 3 colours by entering "3" in the "Num of Colours" field and choose colours for the first 3 colour fields.
You must then enter values for the percentage fields of the first 3 colours so that they total 100.  The values could be 25, 60 and 15 which totals 100.
Or they could be 90, 8 and 2, which also totals 100.  They values for the 3 remaining percentage fields are ignored.
If you don't enter the percentage values so that they add up to 100 the script will still work but the results may not be what you expected.
e.g. If you enter 101 in the first colours percentage field, then the first colour will only ever be used to make the tiles, 
even if you have chosen to use all 6 colours by entering "6" in the "Num of Colours" field.

EXAMPLE
An example of the image which is created using the default settings has also been included.

PERFORMANCE
Using the default settings means that an image of size 800x600 pixels is created with the tiles set at 7x7 pixels.  This gives approximately 9800 tiles.
As you can imagine, it can take quite a while for Gimp to draw all 9800 tiles so please be patient.
The script will take longer to execute if you make the image size larger, and you make the tile size smaller.

INSTALLING
I have included a brush which is chosen by default when the script dialogue opens up.
Copy the brush to your "Brushes" directory in your "Gimp" directory to use it or create your own brush.
Copy the "tiles2.scm" file to the "Scripts" directory in your "Gimp" directory to use it.
The script appears in the "Filters -> Artistic" menu.

