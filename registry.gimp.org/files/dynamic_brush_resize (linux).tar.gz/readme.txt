Install
---------------
(Step 1 Ubuntu only (I think))
1. Open the terminal and run this command to get the required libraries for the script:

sudo apt-get install python-xlib


2. Copy the file "dynamic_brush_resize.py" to the 'home/.gimp-2.8/plug-ins' directory. (.gimp-2.8 is a hidden directory, press 'Ctrl+h' in the home folder to view it)

3. Make sure the script is set as executable. Right click the .py file and go to "Properties" then to the "Permissions" tab and tick "Allow executing file as program".

4. Start gimp and go to the menu "Edit > Keyboard shortcuts", search for the hotkey "Dynamic brush resize", and set it to your desired hotkey ('F' works nice (same as blender))

How to use
----------------
Create/open an image and switch to a brush type tool (brush, eraser, smudge etc..). Tap your hotkey once to start, then drag your mouse left to right to resize, tap the hotkey again to end. It also times out after around 10 seconds just incase the script gets stuck

Requirements
----------------
Gimp 2.8 (tested on 2.8.2)
Linux (tested on Ubuntu 12.04 x64)

Notes
-------------
You may notice your brush spacing changes to a strange value while the brush is resizing, this is normal behaviour (the script uses gimps spacing value to store global data and will return your spacing after you end the resizing)

