#include "sColor.h"

//sColor::sColor(void)
//{
//	r = g = b = pos = 0.;
//}

//sColor::sColor(double r, double g, double b, double a, double pos){
//	this->r = r;
//	this->g = g;
//	this->b = b;
//	this->pos = pos;
//}

int HexSingleValue(char c){
    switch(int(c)){
        case '0':
             return 0;
        case '1':
             return 1;
        case '2':
             return 2;
        case '3':
             return 3;
        case '4':
             return 4;
        case '5':
             return 5;
        case '6':
             return 6;
        case '7':
             return 7;
        case '8':
             return 8;
        case '9':
             return 9;
        case 'a':
        case 'A':
             return 10;
        case 'b':
        case 'B':
             return 11;
        case 'c':
        case 'C':
             return 12;
        case 'd':
        case 'D':
             return 13;
        case 'e':
        case 'E':
             return 14;
        case 'f':
		case 'F':
             return 15;
        default:
             return -1;
    }
}

int CharHexToInt(std::string str){
    int dig = str.size();
    int value = 0;
	int v = 0;
    for(int i = 0; i < dig; i++){
		v = HexSingleValue(str[i]);
		if(v == -1)
			return -1;
        value += v*pow(16.,double(dig -i-1));
    }
    return value;
}

char GetCharHex(int c){
    switch(c){
        case 0:
             return '0';
        case 1:
             return '1';
        case 2:
             return '2';
        case 3:
             return '3';
        case 4:
             return '4';
        case 5:
             return '5';
        case 6:
             return '6';
        case 7:
             return '7';
        case 8:
             return '8';
        case 9:
             return '9';
        case 10:
             return 'a';
        case 11:
             return 'b';
		case 12:
             return 'c';
        case 13:
             return 'd';
        case 14:
             return 'e';
        case 15:
             return 'f';
        default:
             return '-';
    }
}

std::string IntToCharHex(int v){
	int r = 0;
	std::string vStrHex;
	do{
		r = v % 16;
		v = (v - r) / 16;
		vStrHex.insert(vStrHex.begin(), GetCharHex(r));
	}while(v != 0);
	return vStrHex;
}

void HSV2RGB(float h, float s, float v, float &r, float &g, float &b)
{
int i;
h = fmod(h, 360.f);
float f, p, q, t;
if(v == 0){
	r = 0;
	g = 0;
	b = 0;
}else{
		h /= 60;
		i = int(floor(h));
		f = h - i;
		p = v * (1 - s);
		q = v * (1 - (s * f));
		t = v * (1 - (s * (1 - f)));
		if (i == 0){
			r = v;
			g = t;
			b = p;
		}else if (i == 1) {
			r = q;
			g = v;
			b = p;
		}else if (i == 2){
			r = p;
			g = v;
			b = t;
		}else if (i == 3){
			r = p;
			g = q;
			b = v;
		}else if (i == 4){
			r = t;
			g = p;
			b = v;
		}else if (i == 5){
			r = v;
			g = p;
			b = q;
		}
	}
}

void RGB2HSV(float &h, float &s, float &v, float r, float g, float b){
        float x, f, i;

        x = min(min(r, g), b);
        v = max(max(r, g), b);
        if (x == v){
            h = s = 0;
        }
        else {
            f = (r == x) ? g - b : ((g == x) ? b - r : r - g);
            i = (r == x) ? 3.f : ((g == x) ? 5.f : 1.f);
            h = fmod((i - f/(v - x)) * 60.f, 360.f);
            s = ((v - x) / v);
        }
}

sColor::~sColor(void)
{
}

void sColor::SetRGB(float r,float g, float b, float a,float pos){
	this->r = min(max(r,0.f),1.f);
	this->g = min(max(g,0.f),1.f);
	this->b = min(max(b,0.f),1.f);
	this->a = min(max(a,0.f),1.f);
	this->pos = min(max(pos,0.f),1.f);
}

void sColor::SetHSV(float r,float g, float b, float a,float pos){
	this->r = r;
	this->g = min(max(g,0.f),1.f);
	this->b = min(max(b,0.f),1.f);
	this->a = min(max(a,0.f),1.f);
	this->pos = min(max(pos,0.f),1.f);
}

bool sColor::operator ==(sColor cs){
	return bool(cs.a == a && cs.r == r && cs.g == g && cs.b == b);
}

std::string sColor::ChangeColorToHexString(){
	std::string red;
	std::string green;
	std::string blue;
	std::string alpha;

	red = IntToCharHex(int(r * 255.f));
	if(red.size() == 1)
		red.insert(red.begin(), '0');
	green = IntToCharHex(int(g * 255.f));
	if(green.size() == 1)
		green.insert(green.begin(), '0');
	blue = IntToCharHex(int(b * 255.f));
	if(blue.size() == 1)
		blue.insert(blue.begin(), '0');
	alpha = IntToCharHex(int(a * 255.f));
	if(alpha.size() == 1)
		alpha.insert(alpha.begin(), '0');

	std::string s = red;
	s += green;
	s += blue;
	s += alpha;
	
	return s;
}

bool sColor::SetColorFromHexString(std::string hStr){
	if(hStr.size() != 8u){
		return false;
	}
	std::string red;
	red.insert(0, hStr, 0, 2);
	std::string green;
	green.insert(0, hStr, 2, 2);
	std::string blue;
	blue.insert(0, hStr, 4, 2);
	std::string alpha;
	alpha.insert(0, hStr, 6, 2);

	int tr = CharHexToInt(red);
	int tg = CharHexToInt(green);
	int tb = CharHexToInt(blue);
	int ta = CharHexToInt(alpha);

	if(tr == -1 || tg == -1 || tb == -1 || ta == -1)
		return false;

	r = float(tr) / 255.f;
	g = float(tg) / 255.f;
	b = float(tb) / 255.f;
	a = float(ta) / 255.f;

	return true;
}