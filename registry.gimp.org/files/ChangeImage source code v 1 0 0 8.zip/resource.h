//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ChangeImage.rc
//
#define IDR_RULERMENU                   101
#define IDR_MDICHILDS                   102
#define IDR_NOMDICHILDMENU              103
#define IDB_BITMAP1                     128
#define IDB_SAVE_GR                     128
#define IDB_BITMAP2                     129
#define IDB_STARTUP_BITMAP              130
#define IDB_POINTS                      132
#define IDB_LINE                        133
#define IDB_BITMAP4                     133
#define IDB_CH_OPEN                     134
#define IDB_CLOSE                       135
#define IDB_CH_CLOSE                    135
#define IDB_RULER_BUTTON                201
#define IDI_CHANGEIMAGE                 401
#define IDI_BRIGHTNES                   403
#define IDI_ICON1                       404
#define IDI_GLOBAL_CONTRAST             405
#define IDC_IMAGE                       1015
#define IDC_KOMPILATOR                  1016
#define IDC_CONTRAST2                   1020
#define IDC_POSITION                    1025
#define IDC_COEFFICIENT                 1027
#define IDC_RADIO2                      1029
#define IDC_RADIO1                      1066
#define IDC_CUSTOM1                     1067
#define IDC_CUSTOM4                     1070
#define IDC_CUSTOM5                     1071
#define IDC_CUSTOM6                     1072
#define IDC_CUSTOM7                     1073
#define ID_PLIK_ZAPISZ                  40002
#define ID_PLIK_ZAMKNIJ                 40003
#define ID_OPEN                         40004
#define ID_SAVE                         40005
#define ID_CLOSEFILE                    40006
#define ID_CLOSEAPPLICATION             40007
#define ID_OKNA_KASKADOWO               40008
#define ID_KASKADOWO                    40009
#define ID_TILEV                        40010
#define ID_TILEH                        40011
#define ID_CIRCLE                       40012
#define ID_CIRCLE_FILTER                40013
#define ID_ELLIPSE_FILTER               40014
#define ID_TO_MIDDLE                    40015
#define ID_TO_RED                       40016
#define ID_TO_GREEN                     40017
#define ID_TO_BLUE                      40018
#define ID_JEDNOSTKI_PIXEL              40019
#define ID_POPUP_D                      40020
#define ID_JEDNOSTKI_MILIMITER          40021
#define ID_JEDNOSTKI_INCH               40022
#define ID_EXTEND                       40032
#define ID_PLIK_UTW40073                40073
#define ID_UTW40074                     40074
#define ID_GRPRFILE                     40075

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         40076
#define _APS_NEXT_CONTROL_VALUE         1077
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
