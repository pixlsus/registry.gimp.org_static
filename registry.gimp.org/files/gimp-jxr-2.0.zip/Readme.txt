NOTE: This plugin has been tested with GIMP version 2.8.4 only. It may not be compatible with older or newer releases.


Installation on Windows, tested on XP SP3 and higher
----------------------------------------------------

Compiling the plugin under Windows is not straightforward so I recommend you just take the pre-compiled binary.

1. Copy the binary from the "bin" folder to "%USERPROFILE%\.gimp-2.8\plug-ins" (create the folder if it doesn't exist)
   or alternatively run "<GIMP installation dir>\bin\gimptool-2.0.exe --install-bin <path to binary>"


Installation on non-Windows platforms, tested on Ubuntu 10.10
-------------------------------------------------------------

1. Make sure GIMP 2.8.x is installed and you have all required development files
   run: sudo apt-get install libgimp2.0-dev
   
2. Grab jxrlib source code via git..
   cd src
   git clone https://git01.codeplex.com/jxrlib
   ..or download from https://jxrlib.codeplex.com/SourceControl/latest and extract source into subfolder "jxrlib"
   
3. Compile jxrlib:
   cd jxrlib
   make
   
4. Compile & install gimp-jxr plugin:
   cd ..
   export CFLAGS='-w -O -I./jxrlib/common/include -I./jxrlib/image/sys -I./jxrlib/image/encode -I./jxrlib/image/decode -I./jxrlib/image/x86 -I./jxrlib/jxrgluelib -D__ANSI__ -DDISABLE_PERF_MEASUREMENT load.c save.c utils.c'
   export LIBS='-L. ./jxrlib/libjxrglue.a ./jxrlib/libjpegxr.a'
   gimptool-2.0 --install file-jxr.c