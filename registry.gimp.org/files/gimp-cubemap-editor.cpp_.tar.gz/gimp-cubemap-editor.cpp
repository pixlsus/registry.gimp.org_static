/* A gimp plugin for editing cubemaps.
 * Install using:
 *   CFLAGS=-Wall LIBS-lm gimptool-2.0 --install gimp-cubemap-editor.c
 */

#include <assert.h>
#include <string.h>
#include <libgimp/gimp.h>
#include <libgimp/gimpui.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#define SAMPLE_TILE_SIZE 128
#define PADDING 4

#define PRINT_ERROR(...) \
  g_printerr(__VA_ARGS__); \
  if (run_mode != GIMP_RUN_NONINTERACTIVE) g_message(__VA_ARGS__);

typedef struct {
  gint x,y;
  gdouble inv_fov;
} ExtractVals;

typedef struct {
  gdouble x,y;
  int tile;
} location;

typedef struct {
  glm::dmat3 rotation;
  gint32 image_ID;
  gdouble inv_fov;
} source_information;

const static glm::dvec3 nil(0,0,0);
const static guchar invisible[4] = {0,0,0,0};
const static int DX[] = {0,1,0,1};
const static int DY[] = {0,0,1,1};
static ExtractVals evals = {0, 0};
static int tilesize;
static GtkWidget *dialog = NULL;
static GtkWidget *panel = NULL;
static GtkWidget *snapshot = NULL;
static GtkWidget *preview = NULL;
static GtkWidget *label = NULL;
static GdkPixbuf *snapshot_sample = NULL;
static GdkPixbuf *preview_sample = NULL;

/** Checks if the image has a 4:3 ratio and returns the size of the cubemap tiles.
 * The cubemap is stored in the image as:
 *       up
 * left front right back
 *      down
 */
static int extract_tile_size(gint32 image_ID) {
  int width  = gimp_image_width(image_ID);
  int height = gimp_image_height(image_ID);
  if (width*3 != height*4) {
    return -1;
  }
  return width/4;
}

glm::dvec3 get_point(int px, int py) {
  int tile = (px/tilesize) + 4*(py/tilesize);
  gdouble x = 2*(px%tilesize + 0.5)/tilesize-1;
  gdouble y = 2*(py%tilesize + 0.5)/tilesize-1;
  switch(tile) {
    case 1: return glm::dvec3( x, 1,-y);
    case 4: return glm::dvec3(-1,-y,-x);
    case 5: return glm::dvec3( x,-y,-1);
    case 6: return glm::dvec3( 1,-y, x);
    case 7: return glm::dvec3(-x,-y, 1);
    case 9: return glm::dvec3( x,-1, y);
    default: return nil;
  }
}
inline glm::dvec3 get_point() {
  return get_point(evals.x, evals.y);
}

location point_get_location(glm::dvec3 a) {
  gdouble m = fmax(fmax(fabs(a.x),fabs(a.y)),fabs(a.z));
  if (m== a.y) {location r = { a.x/m,-a.z/m,1}; return r;}
  if (m==-a.x) {location r = {-a.z/m,-a.y/m,4}; return r;}
  if (m==-a.z) {location r = { a.x/m,-a.y/m,5}; return r;}
  if (m== a.x) {location r = { a.z/m,-a.y/m,6}; return r;}
  if (m== a.z) {location r = {-a.x/m,-a.y/m,7}; return r;}
  if (m==-a.y) {location r = { a.x/m, a.z/m,9}; return r;}
  {location r = {0,0,0}; return r;}
}

gboolean valid_coordinate() {
  return (evals.x>=tilesize && evals.x<tilesize*2) || (evals.y>=tilesize && evals.y<tilesize*2);
}

glm::dmat3 get_rotation() {
  return glm::dmat3(glm::lookAt(nil, get_point(), glm::dvec3(0,1,0)));
}

void extract_transform(GdkPixbuf *src, GdkPixbuf *dst) {
  guchar * src_pixels = gdk_pixbuf_get_pixels(src);
  int src_tilesize = gdk_pixbuf_get_width (src)/4;
  int src_channels = gdk_pixbuf_get_n_channels(src);
  int src_stride = gdk_pixbuf_get_rowstride(src);
  guchar * dst_pixels = gdk_pixbuf_get_pixels(dst);
  int dst_width  = gdk_pixbuf_get_width (dst);
  int dst_height = gdk_pixbuf_get_height(dst);
  int dst_channels = gdk_pixbuf_get_n_channels(dst);
  int dst_stride = gdk_pixbuf_get_rowstride(dst);
  gboolean alpha = gdk_pixbuf_get_has_alpha(src) && gdk_pixbuf_get_has_alpha(dst);
  int x,y;
  if (valid_coordinate()) {
    glm::dmat3 rotation = get_rotation();
    for (y=0; y<dst_height; y++) {
      for (x=0; x<dst_width; x++) {
        glm::dvec3 q(2*(x+0.5)/dst_width-1,1-2*(y+0.5)/dst_height,-evals.inv_fov);
        q = q*rotation;
        
        // Find pixels on src
        location l = point_get_location(q);
        int px = (l.x+1)/2*src_tilesize + src_tilesize*(l.tile%4);
        int py = (l.y+1)/2*src_tilesize + src_tilesize*(l.tile/4);
        
        dst_pixels[x*dst_channels+y*dst_stride+0] = src_pixels[px*src_channels+py*src_stride+0];
        dst_pixels[x*dst_channels+y*dst_stride+1] = src_pixels[px*src_channels+py*src_stride+1];
        dst_pixels[x*dst_channels+y*dst_stride+2] = src_pixels[px*src_channels+py*src_stride+2];
        if (alpha) {
          dst_pixels[x*dst_channels+y*dst_stride+3] = src_pixels[px*src_channels+py*src_stride+3];
        }
      }
    }
  } else {
    for (y=0; y<dst_height; y++) {
      for (x=0; x<dst_width; x++) {
        dst_pixels[x*dst_channels+y*dst_stride+0]=0x00;
        dst_pixels[x*dst_channels+y*dst_stride+1]=0x00;
        dst_pixels[x*dst_channels+y*dst_stride+2]=0x00;
        if (alpha) {
          dst_pixels[x*dst_channels+y*dst_stride+3]=0xff;
        }
      }
    }
  }
}

void merge_transform(GdkPixbuf *src, GdkPixbuf *dst, const source_information * info) {
  guchar * src_pixels = gdk_pixbuf_get_pixels(src);
  int src_width  = gdk_pixbuf_get_width (src);
  int src_height = gdk_pixbuf_get_height(src);
  int src_channels = gdk_pixbuf_get_n_channels(src);
  int src_stride = gdk_pixbuf_get_rowstride(src);
  guchar * dst_pixels = gdk_pixbuf_get_pixels(dst);
  int dst_width  = gdk_pixbuf_get_width (dst);
  int dst_height = gdk_pixbuf_get_height(dst);
  int dst_channels = gdk_pixbuf_get_n_channels(dst);
  int dst_stride = gdk_pixbuf_get_rowstride(dst);
  int x,y;
  glm::dmat3 rotation = glm::transpose(info->rotation);
  for (y=0; y<dst_height; y++) {
    for (x=0; x<dst_width; x++) {
      glm::dvec3 q = get_point(x,y);
      q = q*rotation;
      
      // Find pixels on src
      gdouble fx = q.x*info->inv_fov; 
      gdouble fy = q.y*info->inv_fov; 
      if (q.z<0 && q.z<-fabs(fx) && q.z<-fabs(fy)) {
        gdouble dx = (1-fx/q.z)/2*src_width;
        gdouble dy = (1+fy/q.z)/2*src_height;
        int px = rint(dx-0.5);
        int py = rint(dy-0.5);
        
        const guchar* values[4];
        int i;
        for (i=0; i<4; i++) {
          int qx = px+DX[i];
          int qy = py+DY[i];
          if (qx>=0 && qx<src_width && qy>=0 && qy<src_height) {
            values[i] = &src_pixels[px*src_channels+py*src_stride];
          } else {
            values[i] = invisible;
          }
        }
        gimp_bilinear_pixels_8(&dst_pixels[x*dst_channels+y*dst_stride], dx-px, dy-py,4, TRUE, const_cast<guchar**>(values));
      }
    }
  }
}

GdkPixbuf * get_pixbuf_from_layer(gint32 layer_ID) {
  int temp_width = gimp_drawable_width(layer_ID);
  int temp_height = gimp_drawable_height(layer_ID);
  GdkPixbuf * pixbuf = gdk_pixbuf_new(GDK_COLORSPACE_RGB, gimp_drawable_has_alpha(layer_ID), 8, temp_width, temp_height);
  GimpDrawable * drawable = gimp_drawable_get(layer_ID);
  GimpPixelRgn region;
  gimp_pixel_rgn_init(&region, drawable, 0, 0, temp_width, temp_height, FALSE, FALSE);
  gimp_pixel_rgn_get_rect(&region, gdk_pixbuf_get_pixels(pixbuf), 0, 0, temp_width, temp_height); 
  gimp_drawable_detach(drawable);
  return pixbuf;
}

void show_coordinates() {
  char str[60];
  if (valid_coordinate()) {
    glm::dvec3 p = get_point();
    snprintf(str, sizeof(str), "Center: (%d,%d)\nDirection: (%.3lf,%.3lf,%.3lf)", evals.x, evals.y, p.x, p.y, p.z);
  } else {
    snprintf(str, sizeof(str), "Center: (%d,%d) invalid\n", evals.x, evals.y);
  }
  gtk_label_set_text(GTK_LABEL(label), str);
  extract_transform(snapshot_sample, preview_sample);
  gtk_widget_queue_draw(preview);
}

gboolean snapshot_click (GtkWidget *widget, GdkEventButton *event, gpointer user_data) {
  if (event->type == GDK_BUTTON_PRESS && event->button == 1) {
    int x,y;
    gtk_widget_translate_coordinates(dialog, snapshot, event->x, event->y, &x, &y);
    if (x>=0 && y>=0 && x<SAMPLE_TILE_SIZE*4 && y<SAMPLE_TILE_SIZE*3) {
      evals.x = (x * tilesize + tilesize/2) / SAMPLE_TILE_SIZE;
      evals.y = (y * tilesize + tilesize/2) / SAMPLE_TILE_SIZE;
      show_coordinates();
    }
  }
  return TRUE;
}

static gboolean extract_dialog(gint32 cubemap) {
  gboolean   run;

  gimp_ui_init ("gimp-cubemap-editor", FALSE);

  dialog = gimp_dialog_new ("Extract cubemap region", "gimp-cubemap-editor",
                            NULL, GTK_DIALOG_MODAL,
                            gimp_standard_help_func, "plug-in-cubemap-extract",

                            GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                            GTK_STOCK_OK,     GTK_RESPONSE_OK,

                            NULL);

  panel = gtk_fixed_new();
  gtk_container_add(GTK_CONTAINER (GTK_DIALOG(dialog)->vbox), panel);
  gtk_widget_show (panel);
   
  // Create a sample of the cubemap.  
  snapshot_sample = gimp_image_get_thumbnail(cubemap,4*SAMPLE_TILE_SIZE,3*SAMPLE_TILE_SIZE, GIMP_PIXBUF_KEEP_ALPHA);
  snapshot = gtk_image_new_from_pixbuf(snapshot_sample);
  gtk_fixed_put (GTK_FIXED (panel), snapshot, PADDING, PADDING);
  gtk_widget_show (snapshot);
  
  // Create a preview.
  preview_sample = gdk_pixbuf_new(GDK_COLORSPACE_RGB, gdk_pixbuf_get_has_alpha(snapshot_sample), 8, 3*SAMPLE_TILE_SIZE, 3*SAMPLE_TILE_SIZE);
  preview = gtk_image_new_from_pixbuf(preview_sample);
  gtk_fixed_put (GTK_FIXED (panel), preview, 4*SAMPLE_TILE_SIZE + 2*PADDING, PADDING);
  gtk_widget_show (preview);

  // Show parameters
  label = gtk_label_new("");
  gtk_fixed_put (GTK_FIXED (panel), label, PADDING, 3*SAMPLE_TILE_SIZE + 2*PADDING);
  gtk_widget_show (label);
  show_coordinates();

  // Add click listener for snapshot.
  gtk_widget_add_events(snapshot, GDK_BUTTON_PRESS_MASK);
  g_signal_connect (GTK_OBJECT(dialog), "button-press-event", G_CALLBACK (snapshot_click), NULL);
  
  // Done
  gtk_widget_show (dialog);

  run = (gimp_dialog_run (GIMP_DIALOG (dialog)) == GTK_RESPONSE_OK);

  g_object_unref(snapshot_sample);
  gtk_widget_destroy (dialog);
    
  return run;
}

static void query (void) {
  static GimpParamDef args_extract[] = {
    { GIMP_PDB_INT32, "run-mode", "Run mode" },
    { GIMP_PDB_IMAGE, "image", "Input image" },
    { GIMP_PDB_DRAWABLE, "drawable", "Input drawable" },
    { GIMP_PDB_INT32, "x", "X-coordinate of center" },
    { GIMP_PDB_INT32, "y", "Y-coordinate of center" },
  };
  gimp_install_procedure (
    "plug-in-cubemap-extract",
    "Extract cubemap region",
    "Extracts a region from a cubemap for editing",
    "Bauke Conijn",
    "Copyright Bauke Conijn",
    "2013",
    "<Image>/Filters/Map/_Extract cubemap region...",
    "RGB*",
    GIMP_PLUGIN,
    G_N_ELEMENTS (args_extract), 0,
    args_extract, NULL
  );

  static GimpParamDef args_merge[] = {
    { GIMP_PDB_INT32, "run-mode", "Run mode" },
    { GIMP_PDB_IMAGE, "image", "Input image" },
    { GIMP_PDB_DRAWABLE, "drawable", "Input drawable" },
  };
  gimp_install_procedure (
    "plug-in-cubemap-merge",
    "Merge cubemap region",
    "Merges an extracted region back into its cubemap",
    "Bauke Conijn",
    "Copyright Bauke Conijn",
    "2013",
    "<Image>/Filters/Map/Merge _cubemap region",
    "RGB*",
    GIMP_PLUGIN,
    G_N_ELEMENTS (args_merge), 0,
    args_merge, NULL
  );
}

static void run (
  const gchar      *name,
  gint              nparams,
  const GimpParam  *param,
  gint             *nreturn_vals,
  GimpParam       **return_vals
) {
  GimpPDBStatusType status   = GIMP_PDB_SUCCESS;
  GimpRunMode       run_mode = (GimpRunMode)param[0].data.d_int32;
  gint32            image_ID = param[1].data.d_int32;

  if (strcmp(name, "plug-in-cubemap-extract")==0) {
    // Extract procedure
    tilesize = extract_tile_size(image_ID);
    if (tilesize<0) {
      status = GIMP_PDB_EXECUTION_ERROR;
      PRINT_ERROR("Image '%s' does not have a 4:3 ratio.\n", gimp_image_get_name(image_ID));
    } else {
      switch (run_mode) {
        case GIMP_RUN_INTERACTIVE:
          /* Get options last values if needed */
          gimp_get_data ("plug-in-cubemap-extract", &evals);
          evals.inv_fov = 0.7;

          /* Display the dialog */
          if (!extract_dialog(image_ID)) {
            status = GIMP_PDB_CANCEL;
          } else {
            gimp_set_data ("plug-in-cubemap-extract", &evals, sizeof (ExtractVals));
          }
          break;

        case GIMP_RUN_NONINTERACTIVE:
          if (nparams != 5) {
            status = GIMP_PDB_CALLING_ERROR;
            PRINT_ERROR("plug-in-cubemap-extract called with wrong number of arguments (got %d, expected %d).\n", nparams, 5);
          }
          break;

        case GIMP_RUN_WITH_LAST_VALS:
          /*  Get options last values if needed  */
          gimp_get_data ("plug-in-cubemap-extract", &evals);
          break;

        default:
          break;
      }
      if (status == GIMP_PDB_SUCCESS) {
        if (valid_coordinate()) {
          int base_size = tilesize * 2;
          
          // Get pixbuf of cubemap
          gint32 temp_layer = gimp_layer_new_from_visible(image_ID, image_ID, "temp");
          GdkPixbuf * cubemap = get_pixbuf_from_layer(temp_layer);
          gimp_drawable_delete(temp_layer);

          // Render projection
          GdkPixbuf * base = gdk_pixbuf_new(GDK_COLORSPACE_RGB, gdk_pixbuf_get_has_alpha(cubemap), 8, base_size, base_size);
          extract_transform(cubemap, base);
          g_object_unref(cubemap);
          
          // Create projected image
          gint32 projection = gimp_image_new(base_size, base_size, gimp_image_base_type(image_ID));
          gint32 base_layer = gimp_layer_new_from_pixbuf(projection, "Base", base, 100, GIMP_NORMAL_MODE,0,0);
          gint32 draw_layer = gimp_layer_new(projection, "Draw", base_size, base_size, GIMP_RGBA_IMAGE, 100, GIMP_NORMAL_MODE);
          gimp_image_add_layer(projection, base_layer, 0);
          gimp_image_add_layer(projection, draw_layer, 0);
          gimp_image_clean_all(projection);
          
          // Attach information
          source_information info;
          info.rotation = get_rotation();
          info.image_ID = image_ID;
          info.inv_fov = evals.inv_fov;
          GimpParasite * par_info = gimp_parasite_new("cubemap-source-info", 0, sizeof(info), &info);
          gimp_image_parasite_attach(projection, par_info);
          
          // Finish
          gimp_display_new(projection);
          g_object_unref(base);
          gimp_displays_flush();
        } else {
          status = GIMP_PDB_CALLING_ERROR;
          PRINT_ERROR("Center (%d,%d) is outside of the cubemap.\n", evals.x, evals.y);
        }
      }
    }
  } else if (strcmp(name, "plug-in-cubemap-merge")==0) {
    // Merge procedure
    GimpParasite * par_info = gimp_image_parasite_find(image_ID, "cubemap-source-info");
    if (par_info==NULL) {
      PRINT_ERROR("No source information is available.");
    } else {
      const source_information * info = (source_information*)gimp_parasite_data(par_info);
      tilesize = extract_tile_size(info->image_ID);
      gint32 layer = gimp_image_get_active_layer(image_ID);
      if (layer<0) {
        PRINT_ERROR("No layer is selected.");
      } else {
        gimp_layer_add_alpha(layer);
        GdkPixbuf * texture = get_pixbuf_from_layer(layer);
        GdkPixbuf * cubemap = gdk_pixbuf_new(GDK_COLORSPACE_RGB, TRUE, 8, 4*tilesize, 3*tilesize);
        merge_transform(texture, cubemap, info);
        g_object_unref(texture);
        gint32 new_layer = gimp_layer_new_from_pixbuf(info->image_ID, "Projection", cubemap, 100, GIMP_NORMAL_MODE,0,0);
        gimp_image_add_layer(info->image_ID, new_layer, 0);
        g_object_unref(cubemap);
        gimp_displays_flush();
      }
    }
  } else {
    PRINT_ERROR("gimp-cubemap-editor plugin called with unknown procedure '%s'.\n", name);
    status = GIMP_PDB_CALLING_ERROR;
  }

  // Handle return value
  static GimpParam  values[1];
  *nreturn_vals = 1;
  *return_vals  = values;
  values[0].type = GIMP_PDB_STATUS;
  values[0].data.d_status = status;  
}

GimpPlugInInfo PLUG_IN_INFO = {
  NULL,
  NULL,
  query,
  run  
};

MAIN();
