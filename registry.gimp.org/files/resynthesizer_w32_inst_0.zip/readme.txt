Do not copy this installer into your Gimp plug-ins directory. It is aimed to do that automatically.
The resynthesizer_setup.exe should work on any machine.
I built the resynthesizer_P4m_sse2_setup.exe for my own old 32-bit Pentium 4 machine (few people get wealthy in the free software business).
Try it at your own risks. Shoul work with any proc with sse2. Works on my wife's Turion64.
2011/07/18: I added a conditional install of libintl8.dll as it is missing in some Gimp installs.