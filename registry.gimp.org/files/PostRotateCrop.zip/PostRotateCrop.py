#!/usr/bin/env python
#
#
# File name: PostRotateCrop.py
#
# Copyright (C) 2010 Richard McLean (programmer_ceds A T yahoo D O T co D O T uk)
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


# Whilst originally intended to be used following a rotation the script can also be used following
# other transformations, such as perspective, scale and shear. The transparent areas added to the
# image by the transformation are removed to leave an opaque rectangle.
#
# The script provides options that determine how the resulting rectangle should be maximized.
#
# If the opaque area of the image is significantly smaller than the image size it will be more
# efficient to manually crop the image so that it is only slightly larger than the opaque area 
# and then run this script.
#
# The script is accessed via Tools/Transform Tools/Post Rotate Crop
#
# The script is not intended to work for opaque areas that include reflex angles.
#

# ************************************************************************
# *                                                                      *
# * If the maximization type parameter is edited in this script then     *
# * it must also be changed in StraightenAndCrop.scm                     *
# *                                                                      *
# ************************************************************************

# 18.9.2009 Fixed potential endless loop when maximizing the rectangle.
#           Fixed problem where gimp-drawable-get-pixel could be called with the coordinates of a pixel
#           that was outside the area of the unrotated image.
#			  Added aspect ratio options.
#
# 7.2.2010 Trapped potential divide by zero situations.
#			 Moved the test for an alpha channel to before the code that makes any partially transparent pixels opaque
#
# 19.7.2010 Moved a misplaced closing bracket that was causing a divide by zero error if the option
#			  to maintain the aspect ratio was selected.
# 11.8.2010 Check that GIMP 2.6.7 or later is being used. Earlier versions can generate rotated
#           images that contain embedded transparent pixels (with alpha values set to 0). The cropped
#           image produced by this script then contains transparent pixels and this is seen as an
#           error on the part of this script rather than the GIMP rotate function.
#
# 10.12.2010 This Python version of the script produced (the previous versions were all Script-Fu). It has been
#           because Python allows the reading of a pixel region into an array - this makes the processing very
#           much faster (the Script-Fu version is still available for those who have not installed Python)

import math
from gimpfu import *
from array import array

def Post_Rotate_Crop (image, layer, maximize_type, aspect_ratio_width, aspect_ratio_height):

    pixel1_opaque = FALSE
    pixel2_opaque = FALSE
    pixel3_opaque = FALSE
    pixel4_opaque = FALSE
    max_width_count = 0
    max_height_count = 0
    not_found = 1
    change_made = 1
    top_left = -1
    top_right = -1
    bottom_left = -1
    bottom_right = -1
    left_top = -1
    right_top = -1
    left_bottom = -1
    right_bottom =-1
    x = 1
    y = 1
    new_left = 0
    new_right = 0
    new_top = 0
    new_bottom = 0
    initial_left = 0
    initial_right = 0
    initial_top = 0
    initial_bottom = 0
    cropped_drawable_width = 0
    cropped_drawable_height = 0
    alpha = 3
    aspect_width = 0
    aspect_height = 0
    maximize_width = FALSE
    maximize_height = FALSE
    maximize_area = FALSE
    loop_counter = 0
    width = image.width
    height = image.height


# variables used in aspect ratio processing:
#
    top_edge = FALSE
    right_edge = FALSE
    not_finished = FALSE
    current_ratio = 0.0
    old_ratio = 0.0
    target_ratio = 0.0
    old_left = 0
    old_right = 0
    old_top = 0
    old_bottom = 0

# constant declarations:
#
    MAXIMIZE_HEIGHT_WIDTH = 0
    MAXIMIZE_HEIGHT = 1
    MAXIMIZE_HEIGHT_AREA = 2
    MAXIMIZE_WIDTH = 3
    MAXIMIZE_WIDTH_AREA = 4
    MAXIMIZE_HEIGHT_WIDTH_AREA = 5
    MAXIMIZE_KEEP_ASPECT_RATIO = 6
    MAXIMIZE_USE_SPECIFIED_ASPECT_RATIO = 7
    MAXIMIZE_NONE = 8

    MAX_LOOP_COUNT = 30000                        # used to prevent (some )while loops locking up (some don't need this)




    if (layer.has_alpha != TRUE):
        pdb.gimp_message('The drawable must have an alpha channel for the script to work' + "\n" + 'Execution terminated.')
        return

    gimp.context_push()
    image.undo_group_start()

    layer.resize_to_image_size()				    # make the drawable the same size as the image

    pdb.plug_in_threshold_alpha(image, layer, 0)    # make any partially transparent pixels opaque

######################################################################  
##
## use the following definition of Pixel_Is_Opaque() if reading the layer into an array (src_pixels[]) causes
## problems (no problems seen so far). Using the other section of code makes the script run at about three
## times the speed (and about 60 times the speed of the Script-Fu version).
##
#    def Pixel_Is_Opaque (x, y):
#        result = FALSE
#        if (x >= 0) and (x < width) and (y >= 0) and (y < height):
#            pixel = layer.get_pixel(x,y)
#            if (pixel[3] != 0):
#                result = TRUE
#        return result;
##
## end of alternative section
##
######################################################################  
        
######################################################################
##  
## use the following section of code if not using the above version of Pixel_Is_Opaque()
##
                                                    # now read the layer into an array which makes the
                                                    #  processing VERY MUCH faster
    rgn = layer.get_pixel_rgn(0,0,layer.width,layer.height,False,False)
    src_pixels = array("B", rgn[0:layer.width, 0:layer.height])

## diag code    pdb.gimp_message('T ' + str(src_pixels[36498368:36498372]) + ' ' +"\n" + 'Execution terminated.')
## diag code    pixel = src_pixels[120:124]
## diag code    pdb.gimp_message('T ' + str(pixel[3]) + ' ' +"\n" + 'Execution terminated.')

    def Pixel_Is_Opaque (x, y):
        result = FALSE
        if (x >= 0) and (x < width) and (y >= 0) and (y < height):
            temp = ((y * width) + x) * 4
            pixel = src_pixels[temp:temp + 4]
            if (pixel[3] != 0):
                result = TRUE
        return result;

## end of alternative section
##
######################################################################  
      
    if (maximize_type == MAXIMIZE_HEIGHT_WIDTH) or (maximize_type == MAXIMIZE_HEIGHT) or \
            (maximize_type == MAXIMIZE_HEIGHT_AREA) or (maximize_type == MAXIMIZE_HEIGHT_WIDTH_AREA):
        maximize_height = TRUE

    if (maximize_type == MAXIMIZE_HEIGHT_WIDTH) or (maximize_type == MAXIMIZE_WIDTH) or \
           (maximize_type == MAXIMIZE_WIDTH_AREA) or (maximize_type == MAXIMIZE_HEIGHT_WIDTH_AREA):
        maximize_width = TRUE

    if (maximize_type == MAXIMIZE_HEIGHT_AREA) or (maximize_type == MAXIMIZE_WIDTH_AREA) or \
            (maximize_type == MAXIMIZE_HEIGHT_WIDTH_AREA):
        maximize_area = TRUE

    if (maximize_type == MAXIMIZE_KEEP_ASPECT_RATIO):
        aspect_height = height
        aspect_width = width

    if (maximize_type == MAXIMIZE_USE_SPECIFIED_ASPECT_RATIO):
        aspect_height = aspect_ratio_height
        aspect_width = aspect_ratio_width

    if (maximize_type == MAXIMIZE_KEEP_ASPECT_RATIO) or (maximize_type == MAXIMIZE_USE_SPECIFIED_ASPECT_RATIO):
        if (aspect_width > aspect_height):
            maximize_width = TRUE
        else:
            maximize_height = TRUE

    new_top = 0
    new_bottom = height - 1
    new_left = 0
    new_right = width - 1

    if (maximize_width == FALSE) and (maximize_height == FALSE) and (maximize_area == TRUE):
        image.undo_group_end()
        pdb.gimp_message('Maximize Area is only applicable if Maximize Width and/or Maximize Height are selected' + "\n" + 'Execution terminated.')
        return

  # find the distance from the top left-hand corner to the first non-transparent pixel along the upper edge
  #
    gimp.progress_init("Finding ends of upper edge")	
    not_found = 1
    while (not_found == 1) and (initial_top < (height - 101)):
        x = 0
        while (not_found == 1) and (x < width):
            if (Pixel_Is_Opaque(x, initial_top) == TRUE):
                top_left = x
                not_found = 0
            x  = x + 1
        if (not_found == 1):
            initial_top = initial_top + 100

    if (not_found == 1):
        image.undo_group_end()
        pdb.gimp_message('Failed to locate non-transparent upper edge' + "\n" + 'Execution terminated.')
        return

  # find the distance from the top right-hand corner to the first non-transparent pixel along the top edge
  #
    not_found = 1
    x = width - 1
    while (not_found == 1) and  (x >= 0):
        if (Pixel_Is_Opaque(x, initial_top) == TRUE):
            top_right = (width - x) - 1
            not_found = 0
        x = x - 1

    if (not_found == 1):
        image.undo_group_end()
        pdb.gimp_message('Failed to locate non-transparent upper edge' + "\n" + 'Execution terminated.')
        return

  # find the distance from the top left-hand corner to the first non-transparent pixel down the left-hand edge
  #
    gimp.progress_init("Finding ends of left edge")	
    not_found = 1
    while (not_found == 1) and (initial_left < (width - 101)):
        y = 0 
        while (not_found == 1) and (y < height):
            if (Pixel_Is_Opaque(initial_left, y) == TRUE):
                left_top = y
                not_found = 0
            y = y + 1
        if (not_found == 1):
            initial_left = initial_left + 100

    if (not_found == 1):
        image.undo_group_end()
        pdb.gimp_message('Failed to locate non-transparent left edge' + "\n" + 'Execution terminated.')
        return

  # find the distance from the bottom left-hand corner to the first non-transparent pixel up the left-hand edge
  #
    not_found = 1
    y = height - 1
    while (not_found == 1) and (y >= 0):
        if (Pixel_Is_Opaque(initial_left, y) == TRUE):
            left_bottom  = (height - y) - 1
            not_found = 0
        y = y - 1

    if (not_found == 1):
        image.undo_group_end()
        pdb.gimp_message('Failed to locate non-transparent left edge' + "\n" + 'Execution terminated.')
        return

  # find the distance from the top right-hand corner to the first non-transparent pixel down the right-hand edge
  #
    gimp.progress_init("Finding ends of right edge")	
    not_found = 1
    initial_right = width - 1
    while (not_found == 1) and (initial_right > 99):
        y = 0 
        while (not_found == 1) and (y < height):
            if (Pixel_Is_Opaque(initial_right, y) == TRUE):
                right_top = y
                not_found = 0
            y = y + 1
        if (not_found == 1):
            initial_right = initial_right - 100

    if (not_found == 1):
        image.undo_group_end()
        pdb.gimp_message('Failed to locate non-transparent right edge' + "\n" + 'Execution terminated.')
        return

  # find the distance from the bottom right-hand corner to the first non-transparent pixel up the right-hand edge
  #
    not_found = 1
    y = height - 1
    while (not_found == 1) and (y >= 0):
        if (Pixel_Is_Opaque(initial_right, y) == TRUE):
            right_bottom = (height - y) - 1
            not_found = 0
        y = y - 1

    if (not_found == 1):
        image.undo_group_end()
        pdb.gimp_message('Failed to locate non-transparent right edge' + "\n" + 'Execution terminated.')
        return

  # find the distance from the bottom left-hand corner to the first non-transparent pixel along the bottom edge
  #
    gimp.progress_init("Finding ends of lower edge")	
    not_found = 1
    initial_bottom = height - 1
    while (not_found == 1) and (initial_bottom > 100):
        x = 0
        while (not_found == 1) and (x < width):
            if (Pixel_Is_Opaque(x, initial_bottom) == TRUE):
                bottom_left = x
                not_found = 0
            x = x + 1
        if (not_found == 1):
            initial_bottom = initial_bottom - 100

    if (not_found == 1):
        image.undo_group_end()
        pdb.gimp_message('Failed to locate non-transparent lower edge' + "\n" + 'Execution terminated.')
        return

  # find the distance from the bottom right-hand corner to the first non-transparent pixel along the bottom edge
  #
    not_found = 1
    x = width - 1
    while (not_found == 1) and (x >= 0):
        if (Pixel_Is_Opaque(x, initial_bottom) == TRUE):
            bottom_right = (width - x) - 1
            not_found = 0
        x = x - 1

    if (not_found == 1):
        image.undo_group_end()
        pdb.gimp_message('Failed to locate non-transparent lower edge' + "\n" + 'Execution terminated.')
        return

    if (top_left == -1) or (top_right == -1) or (right_top == -1) or (left_top == -1) or (bottom_right == -1) or \
            (bottom_left == -1) or (left_bottom == -1) or (right_bottom == -1):
        image.undo_group_end()
        pdb.gimp_message('Failed to detect edges' + "\n" + 'Execution terminated.')
        return

    gimp.progress_init("Removing transparent areas")	
    change_made = 1
    loop_counter = 0
    while (change_made == 1) and (loop_counter < MAX_LOOP_COUNT):
        loop_counter = loop_counter + 1
        change_made = 0

        if (top_right > 0) and ((top_right <= top_left) or (top_left == 0)) and \
                ((top_right <= right_top) or (right_top == 0)) and \
                ((top_right <= right_bottom) or(right_bottom == 0)) and \
                ((top_right <= bottom_left) or (bottom_left == 0)) and \
                ((top_right <= bottom_right) or (bottom_right == 0)) and \
                ((top_right <= left_top) or (left_top == 0)) and \
                ((top_right <= left_bottom) or (left_bottom == 0)):
            change_made = 1
            new_right = new_right - top_right
            if (top_right >= bottom_right):
                bottom_right = 0
            else:
                bottom_right = bottom_right - top_right

            top_right = 0
          
            not_found = 1
            y = new_top
            while (not_found == 1) and (y <= new_bottom):
                if (Pixel_Is_Opaque(new_right, y) == TRUE):
                    right_top = y - new_top
                    not_found = 0
                y = y + 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent upper edge' + "\n" + 'Execution terminated.')
                return


            not_found = 1
            y = new_bottom
            while (not_found == 1) and (y >= new_top):
                if (Pixel_Is_Opaque(new_right, y) == TRUE):
                    right_bottom = new_bottom - y
                    not_found = 0
                y = y - 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent lower edge' + "\n" + 'Execution terminated.')
                return

        if (right_top > 0) and \
        		((right_top <= right_bottom) or (right_bottom == 0)) and \
        		((right_top <= top_left) or (top_left == 0)) and \
    	    	((right_top <= top_right) or (top_right == 0)) and \
    		    ((right_top <= bottom_left) or (bottom_left == 0)) and \
        		((right_top <= bottom_right) or (bottom_right == 0)) and \
        		((right_top <= left_top) or (left_top == 0)) and \
    	    	((right_top <= left_bottom) or (left_bottom == 0)):
            change_made = 1
            new_top = new_top + right_top
            if (right_top >= left_top):
                left_top = 0
            else:
                left_top = left_top - right_top

            right_top = 0

            not_found = 1
            x = new_left
            while (not_found == 1) and (x <= new_right):
                if (Pixel_Is_Opaque(x, new_top) == TRUE):
                    top_left = x - new_left
                    not_found = 0
                x = x + 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent left edge' + "\n" + 'Execution terminated.')
                return

            not_found = 1
            x = new_right
            while (not_found == 1) and (x >= new_left):
                if (Pixel_Is_Opaque(x, new_top) == TRUE):
                    top_right = new_right - x
                    not_found = 0
                x = x - 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent right edge' + "\n" + 'Execution terminated.')
                return
    
        if (right_bottom > 0) and \
                ((right_bottom <= right_top) or (right_top == 0)) and \
                ((right_bottom <= bottom_left) or (bottom_left == 0)) and \
                ((right_bottom <= bottom_right) or (bottom_right == 0)) and \
                ((right_bottom <= top_left) or (top_left == 0)) and \
                ((right_bottom <= top_right) or (top_right == 0)) and \
                ((right_bottom <= left_top) or (left_top == 0)) and \
                ((right_bottom <= left_bottom) or (left_bottom == 0)):
            change_made = 1
            new_bottom = new_bottom - right_bottom
            if (right_bottom >= left_bottom):
                left_bottom = 0
            else:
                left_bottom = left_bottom - right_bottom

            right_bottom = 0

            not_found = 1
            x = new_left
            while (not_found == 1) and (x <= new_right):
                if (Pixel_Is_Opaque(x, new_bottom) == TRUE):
                    bottom_left = x - new_left
                    not_found = 0
                x = x + 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent left edge' + "\n" + 'Execution terminated.')
                return

            not_found = 1
            x = new_right
            while (not_found == 1) and (x >= new_left):
                if (Pixel_Is_Opaque(x, new_bottom) == TRUE):
                    bottom_right = new_right - x
                    not_found = 0
                x = x - 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent right edge' + "\n" + 'Execution terminated.')
                return
    
        if (left_bottom > 0) and \
                ((left_bottom <= left_top) or (left_top == 0)) and \
                ((left_bottom <= bottom_left) or (bottom_left == 0)) and \
                ((left_bottom <= bottom_right) or (bottom_right == 0)) and \
                ((left_bottom <= top_left) or (top_left == 0)) and \
                ((left_bottom <= top_right) or (top_right == 0)) and \
                ((left_bottom <= right_top) or (right_top == 0)) and \
                ((left_bottom <= right_bottom) or (right_bottom == 0)):
            change_made = 1
            new_bottom = new_bottom - left_bottom
            if (left_bottom >= right_bottom):
                right_bottom = 0
            else:
                right_bottom = right_bottom - left_bottom

            left_bottom = 0

            not_found = 1
            x = new_left
            while (not_found == 1) and (x <= new_right):
                if (Pixel_Is_Opaque(x, new_bottom) == TRUE):
                    bottom_left = x - new_left
                    not_found = 0
                x = x + 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent left edge' + "\n" + 'Execution terminated.')
                return

            not_found = 1
            x = new_right
            while (not_found == 1) and (x >= new_left):
                if (Pixel_Is_Opaque(x, new_bottom) == TRUE):
                    bottom_right = new_right - x
                    not_found = 0
                x = x - 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent right edge' + "\n" + 'Execution terminated.')
                return

        if (bottom_left > 0) and \
                ((bottom_left <= bottom_right) or (bottom_right == 0)) and \
                ((bottom_left <= left_top) or (left_top == 0)) and \
                ((bottom_left <= left_bottom) or (left_bottom == 0)) and \
                ((bottom_left <= top_left) or (top_left == 0)) and \
                ((bottom_left <= top_right) or (top_right == 0)) and \
                ((bottom_left <= right_top) or (right_top == 0)) and \
                ((bottom_left <= right_bottom) or (right_bottom == 0)):
            change_made = 1
            new_left = new_left + bottom_left
            if (bottom_left >= top_left):
                top_left = 0
            else:
                top_left = top_left - bottom_left

            bottom_left = 0
          
            not_found = 1
            y = new_top
            while (not_found == 1) and (y <= new_bottom):
                if (Pixel_Is_Opaque(new_left, y) == TRUE):
                    left_top = y - new_top
                    not_found = 0
                y = y + 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent upper edge' + "\n" + 'Execution terminated.')
                return

            not_found = 1
            y = new_bottom
            while (not_found == 1) and (y >= new_top):
                if (Pixel_Is_Opaque(new_left, y) == TRUE):
                    left_bottom = new_bottom - y
                    not_found = 0
                y = y - 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent lower edge' + "\n" + 'Execution terminated.')
                return
 
        if (bottom_right > 0) and \
                ((bottom_right <= bottom_left) or (bottom_left == 0)) and \
                ((bottom_right <= right_top) or (right_top == 0)) and \
                ((bottom_right <= right_bottom) or (right_bottom == 0)) and \
                ((bottom_right <= top_left) or (top_left == 0)) and \
                ((bottom_right <= top_right) or (top_right == 0)) and \
                ((bottom_right <= left_top) or (left_top == 0)) and \
                ((bottom_right <= left_bottom) or (left_bottom == 0)):
            change_made = 1
            new_right = new_right - bottom_right
            if (bottom_right >= top_right):
                top_right = 0
            else:
                top_right = top_right - bottom_right

            bottom_right = 0
          
            not_found = 1
            y = new_top
            while (not_found == 1) and (y <= new_bottom):
                if (Pixel_Is_Opaque(new_right, y) == TRUE):
                    right_top = y - new_top
                    not_found = 0
                y = y + 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent upper edge' + "\n" + 'Execution terminated.')
                return

            not_found = 1
            y = new_bottom
            while (not_found == 1) and (y >= new_top):
                if (Pixel_Is_Opaque(new_right, y) == TRUE):
                    right_bottom = new_bottom - y
                    not_found = 0
                y = y - 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent lower edge' + "\n" + 'Execution terminated.')
                return

        if (top_left > 0) and \
                ((top_left <= top_right) or (top_right == 0)) and \
                ((top_left <= left_top) or (left_top == 0)) and \
                ((top_left <= left_bottom) or (left_bottom == 0)) and \
                ((top_left <= right_top) or (right_top == 0)) and \
                ((top_left <= right_bottom)or  (right_bottom == 0)) and \
                ((top_left <= bottom_left) or (bottom_left==  0)) and \
                ((top_left <= bottom_right) or (bottom_right == 0)):
            change_made = 1
            new_left = new_left + top_left
            if (top_left >= bottom_left):
                bottom_left = 0
            else:
                bottom_left = bottom_left - top_left
          
            top_left = 0

            not_found = 1
            y = new_top
            while (not_found == 1) and (y <= new_bottom):
                if (Pixel_Is_Opaque(new_left, y) == TRUE):
                    left_top = y - new_top
                    not_found = 0
                y = y + 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent upper edge' + "\n" + 'Execution terminated.')
                return

            not_found = 1
            y  = new_bottom
            while (not_found == 1) and (y >= new_top):
                if (Pixel_Is_Opaque(new_left, y) == TRUE):
                    left_bottom = new_bottom - y
                    not_found = 0
                y = y - 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent lower edge' + "\n" + 'Execution terminated.')
                return
    
        if (left_top > 0) and \
                ((left_top <= left_bottom) or (left_bottom == 0)) and \
                ((left_top <= top_left) or (top_left == 0)) and \
                ((left_top <= top_right) or (top_right == 0)) and \
                ((left_top <= right_top) or (right_top == 0)) and \
                ((left_top <= right_bottom) or (right_bottom == 0)) and \
                ((left_top <= bottom_right) or (bottom_right == 0)) and \
                ((left_top <= bottom_left) or (bottom_left == 0)):
            change_made = 1
            new_top = new_top + left_top
            if (left_top >= right_top):
                right_top = 0
            else:
                right_top = right_top - left_top

            left_top = 0
          
            not_found = 1
            x = new_left
            while (not_found == 1) and (x <= new_right):
                if (Pixel_Is_Opaque(x, new_top) == TRUE):
                    top_left = x - new_left
                    not_found = 0
                x = x + 1
 
            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent left edge' + "\n" + 'Execution terminated.')
                return

            not_found = 1
            x = new_right
            while (not_found == 1) and (x >= new_left):
                if (Pixel_Is_Opaque(x, new_top) == TRUE):
                    top_right = new_right - x
                    not_found = 0
                x = x - 1

            if (not_found == 1):
                image.undo_group_end()
                pdb.gimp_message('Failed to locate non-transparent right edge' + "\n" + 'Execution terminated.')
                return

    if (loop_counter >= MAX_LOOP_COUNT):
        image.undo_group_end()
        pdb.gimp_message('Please report transparent area removal lock-up' + "\n" + 'Execution terminated.')
        return

# Maximize the rectangle
# 
# If the width is greater than the height and the maximize area option is selected the code will
# attempt to maximize the height at the expense of the width if the height can't be increased
# whilst preserving the width. This is done by moving the left edge right 2 pixels and/or the right
# edge left 2 pixels. The variable max_width_count is then set to 2. This allows the left and right
# maximizing sections to 'claw back' 1 pixel if this is possible (without reducing the height. The top
# and bottom are not maximized at the expense of the width whilst max_width_count is non-zero. Moving
# the edges in by 2 pixels allows for angles of 26.6 degrees and greater.
#
# Similar processing is employed to maximize the area by increasing the width at the expense of the height.
#
#

    if (maximize_height == TRUE) or (maximize_width == TRUE) or (maximize_area == TRUE):
        gimp.progress_init("Maximizing the rectangle")	
  
    max_width_count = 0
    max_height_count = 0
    change_made = 1
    loop_counter = 0

    while ((change_made == 1) or (max_width_count > 0) or (max_height_count > 0)) and \
            (loop_counter < MAX_LOOP_COUNT):
        loop_counter = loop_counter + 1
        change_made = 0
   
        if (max_width_count > 0):
            max_width_count = max_width_count - 1

        if (maximize_width == TRUE) and (new_left > 0):
                								                    # attempt to maximize left-hand side
            pixel1_opaque = Pixel_Is_Opaque(new_left - 1, new_top)
            pixel2_opaque = Pixel_Is_Opaque(new_left - 1, new_bottom)
            if (pixel1_opaque == TRUE) and (pixel2_opaque == TRUE):
                new_left = new_left - 1
                change_made = 1
            else:
#                if ((maximize_height == FALSE) or ((new_bottom - new_top) > (new_right - new_left + 4))) and \
                if ((maximize_height == FALSE) or ((new_bottom - new_top + 1) > 2 * (new_right - new_left + 1))) and \
                     (maximize_area == TRUE) and (max_height_count == 0):
                                                                    # height > twice width
                    pixel3_opaque = Pixel_Is_Opaque(new_left - 1, new_top + 2)
                    if (pixel3_opaque == TRUE) and (pixel2_opaque == TRUE):
                        new_top = new_top + 2
                        new_left = new_left - 1
                        max_height_count = 2
                        change_made = 1
                    else:
                        pixel4_opaque = Pixel_Is_Opaque(new_left - 1, new_bottom - 2)
                        if (pixel4_opaque == TRUE) and (pixel1_opaque == TRUE):
                            new_bottom = new_bottom - 2
                            new_left = new_left - 1
                            max_height_count = 2
                            change_made = 1
                        else:
                            if (pixel3_opaque == TRUE) and (pixel4_opaque == TRUE):
                                new_bottom = new_bottom - 2
                                new_top = new_top + 2
                                new_left = new_left - 1
                                max_height_count = 2
                                change_made = 1

        if (max_height_count > 0):
			max_height_count = max_height_count - 1

        if (maximize_height == TRUE) and (new_top > 0):				# attempt to maximize the top
            pixel1_opaque = Pixel_Is_Opaque(new_left, new_top - 1)
            pixel2_opaque = Pixel_Is_Opaque(new_right, new_top - 1)
            if (pixel1_opaque == TRUE) and (pixel2_opaque == TRUE):
                new_top = new_top - 1
                change_made = 1
            else:
#                if ((maximize_width == FALSE) or ((new_right - new_left) > (new_bottom - new_top + 4))) and \
                if ((maximize_width == FALSE) or ((new_right - new_left + 1) > 2 * (new_bottom - new_top + 1))) and \
                        (maximize_area == TRUE) and (max_width_count == 0):
                                                                        # width > twice height
                    pixel3_opaque = Pixel_Is_Opaque(new_left + 2, new_top - 1) 
                    if (pixel3_opaque == TRUE) and (pixel2_opaque == TRUE):
                        new_top = new_top - 1
                        new_left = new_left + 2
                        max_width_count = 2
                        change_made = 1
                    else:
                        pixel4_opaque = Pixel_Is_Opaque(new_right - 2, new_top - 1)
                        if (pixel4_opaque ==TRUE) and (pixel1_opaque == TRUE):
                            new_top = new_top - 1
                            new_right = new_right - 2
                            max_width_count = 2
                            change_made = 1
                        else:
                            if (pixel3_opaque == TRUE) and (pixel4_opaque == TRUE):
                                new_right = new_right - 2
                                new_left = new_left + 2
                                new_top = new_top - 1
                                max_width_count = 2
                                change_made = 1
    
        if (max_width_count > 0):
			max_width_count = max_width_count - 1

        if (maximize_width == TRUE) and (new_right < (width - 1)):				# attempt to maximize the right-hand side
            pixel1_opaque = Pixel_Is_Opaque(new_right + 1, new_top)
            pixel2_opaque = Pixel_Is_Opaque(new_right + 1, new_bottom)
            if (pixel1_opaque == TRUE) and (pixel2_opaque == TRUE):
                new_right = new_right + 1
                change_made = 1
            else:
#                if ((maximize_height == FALSE) or ((new_bottom - new_top) > (new_right - new_left + 4))) and \
                if ((maximize_height == FALSE) or ((new_bottom - new_top + 1) > 2 * (new_right - new_left + 1))) and \
                        (maximize_area == TRUE) and (max_height_count == 0):
                                                                                # height > twice width
                    pixel3_opaque = Pixel_Is_Opaque(new_right + 1, new_top + 2) 
                    if (pixel3_opaque == TRUE) and (pixel2_opaque == TRUE):
                        new_top = new_top + 2
                        new_right = new_right + 1
                        max_height_count = 2
                        change_made = 1
                    else:
                        pixel4_opaque = Pixel_Is_Opaque(new_right + 1, new_bottom - 2) 
                        if (pixel4_opaque == TRUE) and (pixel1_opaque == TRUE):
                            new_bottom = new_bottom - 2
                            new_right = new_right + 1
                            max_height_count=  2
                            change_made = 1
                        else:
                            if (pixel3_opaque == TRUE) and (pixel4_opaque == TRUE):
                                new_bottom = new_bottom - 2
                                new_top = new_top + 2
                                new_right = new_right + 1
                                max_height_count = 2
                                change_made = 1

        if (max_height_count > 0):
            max_height_count = max_height_count - 1

        if (maximize_height == TRUE) and (new_bottom < (height - 1)):			# attempt to maximize the bottom
            pixel1_opaque = Pixel_Is_Opaque(new_left, new_bottom + 1)
            pixel2_opaque = Pixel_Is_Opaque(new_right, new_bottom + 1)
            if (pixel1_opaque == TRUE) and (pixel2_opaque == TRUE):
                new_bottom = new_bottom + 1
                change_made = 1
            else:
#                if ((maximize_width == FALSE) or ((new_right - new_left) > (new_bottom - new_top + 4))) and \
                if ((maximize_width == FALSE) or ((new_right - new_left + 1) > 2 * (new_bottom - new_top + 1))) and \
                     (maximize_area == TRUE) and (max_width_count == 0):
                                                                                # width > twice height
                    pixel3_opaque = Pixel_Is_Opaque(new_left + 2, new_bottom + 1) 
                    if (pixel3_opaque == TRUE) and (pixel2_opaque == TRUE):
                        new_bottom = new_bottom + 1
                        new_left = new_left + 2
                        max_width_count = 2
                        change_made = 1
                    else:
                        pixel4_opaque = Pixel_Is_Opaque(new_right - 2, new_bottom + 1) 
                        if (pixel4_opaque == TRUE) and (pixel1_opaque == TRUE):
                            new_bottom = new_bottom + 1
                            new_right = new_right - 2
                            max_width_count = 2
                            change_made = 1
                        else:
                            if (pixel3_opaque == TRUE) and (pixel4_opaque == TRUE):
                                new_right = new_right - 2
                                new_left = new_left + 2
                                new_bottom = new_bottom + 1
                                max_width_count = 2
                                change_made = 1

    if (new_top < 0):                        # diag code
        image.undo_group_end()
        pdb.gimp_message('Please report new_top < 0' + "\n" + 'Execution terminated.')
        return

    if (new_left < 0):                        # diag code
        image.undo_group_end()
        pdb.gimp_message('Please report new_left < 0' + "\n" + 'Execution terminated.')
        return

    if (new_bottom > (height - 1)):            # diag code
        image.undo_group_end()
        pdb.gimp_message('Please report new-bottom > (height - 1)' + "\n" + 'Execution terminated.')
        return

    if (new_right > (width - 1)):            # diag code
        image.undo_group_end()
        pdb.gimp_message('Please report new_right > (width - 1)' + "\n" + 'Execution terminated.')
        return

    if (loop_counter >= MAX_LOOP_COUNT):
        image.undo_group_end()
        pdb.gimp_message('Please report rectangle maximization lock-up' + "\n" + 'Execution terminated.')
        return
  
#----------------------------------------------------------------------------------------------
#
# Check for an aspect ratio maximization
  
    if (maximize_type == MAXIMIZE_KEEP_ASPECT_RATIO) or (maximize_type == MAXIMIZE_USE_SPECIFIED_ASPECT_RATIO):
        gimp.progress_init("Adjusting for aspect ratio")

        top_edge = TRUE
        right_edge = TRUE
        not_finished = TRUE
        loop_counter =  0
    
        if ((new_bottom - new_top + 1) == 0):
            image.undo_group_end()
            pdb.gimp_message("Can't maximize for aspect ratio when the current height is 0" + "\n" + 'Execution terminated.')
            return

        current_ratio = float(new_right - new_left + 1) / float(new_bottom - new_top + 1)

        if (aspect_height == 0):
            image.undo_group_end()
            pdb.gimp_message("Can't maximize on aspect ratio when the height is 0" + "\n" + 'Execution terminated.')
            return

        target_ratio = float(aspect_width) / float(aspect_height)    # (have already checked for aspect_height being 0)
        
        if (current_ratio >= target_ratio):
                                                    # the rectangle is too wide (or exactly right)
            while (not_finished == TRUE) and ((new_right - new_left) > 1) and (loop_counter < MAX_LOOP_COUNT):
                loop_counter = loop_counter + 1
                old_ratio = current_ratio
                old_left = new_left
                old_right = new_right
                old_top = new_top
                old_bottom = new_bottom

                change_made = FALSE
                pixel1_opaque = Pixel_Is_Opaque(new_left, new_top - 1)
                pixel2_opaque = Pixel_Is_Opaque(new_right, new_top - 1)
                pixel3_opaque = Pixel_Is_Opaque(new_left, new_bottom + 1)
                pixel4_opaque = Pixel_Is_Opaque(new_right, new_bottom + 1)

                if (top_edge == TRUE):
                    if (pixel1_opaque == TRUE) and (pixel2_opaque == TRUE):
                        new_top = new_top - 1                    # can move up
                        change_made = TRUE
                    else:
                        if (pixel3_opaque == TRUE) and (pixel4_opaque == TRUE):
                            new_bottom = new_bottom + 1            # can move down
                            change_made = TRUE

                    top_edge = FALSE
                else:            # top_edge = false
                    if (pixel3_opaque == TRUE) and (pixel4_opaque == TRUE):
                        new_bottom = new_bottom + 1                # can move down
                        change_made = TRUE
                    else:
                        if (pixel1_opaque == TRUE) and (pixel2_opaque == TRUE):
                            new_top = new_top - 1                # can move up
                            change_made = TRUE
                    top_edge = TRUE
    
                if (change_made == FALSE):
                    if (pixel1_opaque == FALSE) and (pixel3_opaque == FALSE) and \
                            ((pixel2_opaque == TRUE) or (pixel4_opaque == TRUE)):
                        right_edge = FALSE                        # reduce the left-hand side

                    if (pixel2_opaque == FALSE) and (pixel4_opaque == FALSE) and \
                            ((pixel1_opaque == TRUE) or (pixel3_opaque == TRUE)):
                        right_edge = TRUE                             # reduce the right-hand side

                    if (right_edge == TRUE):
                        new_right = new_right - 1
                        right_edge = FALSE
                    else:
                        new_left = new_left + 1
                        right_edge = TRUE
              
                if ((new_bottom - new_top + 1) == 0):
                    image.undo_group_end()
                    pdb.gimp_message("Can't maximize for aspect ratio when the current height is 0" + "\n" + 'Execution terminated.')
                    return
    
                current_ratio = float(new_right - new_left + 1) / float(new_bottom - new_top + 1)
                
                if (current_ratio < target_ratio):
                    not_finished = FALSE
                    if (old_ratio - target_ratio) < (target_ratio - current_ratio):
                                                                # the previous interation was closer
                        new_top = old_top
                        new_bottom = old_bottom
                        new_left = old_left
                        new_right = old_right

        else:                                                    # the rectangle isn't wide enough
            while (not_finished == TRUE) and ((new_bottom - new_top) > 1) and (loop_counter < MAX_LOOP_COUNT):
                loop_counter = loop_counter + 1
                old_ratio = current_ratio
                old_left = new_left
                old_right = new_right
                old_top = new_top
                old_bottom = new_bottom
              
                change_made = FALSE
                pixel1_opaque = Pixel_Is_Opaque(new_right + 1, new_top)
                pixel2_opaque = Pixel_Is_Opaque(new_right + 1, new_bottom)
                pixel3_opaque = Pixel_Is_Opaque(new_left - 1, new_top)
                pixel4_opaque = Pixel_Is_Opaque(new_left - 1, new_bottom)

                if (right_edge == TRUE):
                    if (pixel1_opaque == TRUE) and (pixel2_opaque == TRUE):
                        new_right = new_right + 1                  # can move right
                        change_made = TRUE
                    else:
                        if (pixel3_opaque == TRUE) and (pixel4_opaque == TRUE):
                            new_left = new_left - 1                # can move left
                            change_made = TRUE
                    right_edge = FALSE
                else:                         #(right_edge = FALSE)
                    if (pixel3_opaque == TRUE) and (pixel4_opaque == TRUE):
                        new_left = new_left - 1                    # can move left
                        change_made = TRUE
                    else:
                        if (pixel1_opaque == TRUE) and (pixel2_opaque == TRUE):
                            new_right = new_right + 1             # can move right
                            change_made = TRUE
                    right_edge = TRUE
    
                if (change_made == FALSE):
                    if (pixel1_opaque == FALSE) and (pixel3_opaque == FALSE) and \
                            ((pixel2_opaque == TRUE) or (pixel4_opaque == TRUE)):
                        top_edge = TRUE                            # reduce the top side

                    if (pixel2_opaque == FALSE) and (pixel4_opaque == FALSE) and \
                            ((pixel1_opaque == TRUE) or (pixel3_opaque == TRUE)):
                        top_edge = FALSE                            # reduce the bottom side

                    if (top_edge == TRUE):
                        new_top = new_top + 1                      # move the top down
                        top_edge = FALSE
                    else:
                        new_bottom = new_bottom - 1               # move the bottom up
                        top_edge = TRUE
              
                if ((new_bottom - new_top + 1) == 0):
                    image.undo_group_end()
                    pdb.gimp_message("Can't maximize for aspect ratio when the current height is 0" + "\n" + 'Execution terminated.')
                    return
    
                current_ratio = float(new_right - new_left + 1) / float(new_bottom - new_top + 1)
                
                if (current_ratio > target_ratio):
                    not_finished = FALSE
                    if (target_ratio - old_ratio) < (current_ratio - target_ratio):
                                                                    # the previous interation was closer
                        new_top = old_top
                        new_bottom = old_bottom
                        new_left = old_left
                        new_right = old_right

    if (loop_counter >= MAX_LOOP_COUNT):
        image.undo_group_end()
        pdb.gimp_message("Please report aspect ratio adjustment lock-up" + "\n" + 'Execution terminated.')
        return
  
    image.crop(new_right - new_left + 1, new_bottom - new_top + 1, new_left, new_top)		    
  

#    pdb.gimp_message('bottom_right = ' + str(bottom_right))
#    pdb.gimp_message('No path defined!' + "\n" + 'Execution terminated.')

    image.undo_group_end()
    gimp.context_pop()

    return

register(
    "Post_Rotate_Crop",
    "Crop a rotated or transformed image to leave a rectangle without transparent areas. (Python version)",
    "",
    "Richard McLean",
    "2010, Richard McLean (programmer_ceds A T yahoo D O T co D O T uk)",
    "10th December 2010",
    "<Image>/Tools/Transform Tools/Post Rotate Crop",
    "RGB*, GRAY*",
[
        (PF_OPTION, "maximize", ("Maximize"), 0, ["Height and width", "Height", "Height at the expense of width",
                                         "Width", "Width at the expense of height",
                                         "Height, width and area", "Keep image aspect ratio",
                                         "Aspect ratio specified below", "No maximization"]),
        (PF_ADJUSTMENT, "aspect_ratio_width", "Aspect ratio width", 3,  (0, 9999, 1)),
        (PF_ADJUSTMENT, "aspect_ratio_height", "Aspect ratio height", 2,  (0, 9999, 1))
    ],
    [],
    Post_Rotate_Crop)
main()
