#!/usr/bin/python
# -*- coding: utf8 -*-
'''
Line Border plugin for Gimp

Copyright (C) 2010 Marián Kyral
'''

__all__ = ["gui", "LineBorder", "LineBorderProfile" ]

