#!/usr/bin/env python
# _*_ coding: utf_8 _*_
#
# Cross-Stitchify script for use with GIMP v2.1
# creates a cross-stitch pattern from an image
# by w_nightshade

# This script is released into the public domain.
# You may redistribute and/or modify this script or extract segments without prior consent.

# This script is distributed in the hope of being useful
# but without warranty, explicit or otherwise.


from gimpfu import *
import math
import os

gettext.install("gimp20_python", gimp.locale_directory, unicode=True)

def cross_stitch(theImage, theDraw, theMosaic, theBrightness, thePosterize):

	########## DEFINE VARIABLES ##########
	currPixel = [1, 1]
	mosaicModified = 1
	heightNew = 0
	widthNew = 0
	heightOld = theImage.height
	widthOld = theImage.width
	paletteFinal = []
	bigMosaic = 20
	currColor = (0, 0, 0)
	newColor = (0, 0, 0, 0, 0)
	progVal = 0.0
	progStep = 0.0
	colourUsed = (0, "")
	output = ""
	stitch = ""
	path = ""
	#This is the structure that heightOlds the palette of existing floss colours & their commercial index numbers
	fColors = [
		[0,[255,255,255],'White'],
		[208,[148,91,128],'Lavender-VY DK'],
		[209,[206,148,186],'Lavender-DK'],
		[210,[236,207,225],'Lavender-MD'],
		[211,[243,218,228],'Lavender-LT'],
		[221,[156,41,74],'Shell Pink-VY DK'],
		[223,[219,128,115],'Shell Pink-LT'],
		[224,[255,199,176],'Shell Pink-VY LT'],
		[225,[255,240,228],'Shell Pink-ULT VY L'],
		[300,[143,57,38],'Mahogany-VY DK'],
		[301,[209,102,84],'Mahogany-MD'],
		[304,[188,0,97],'Christmas Red-MD'],
		[307,[255,231,109],'Lemon'],
		[309,[214,43,91],'Rose-DP'],
		[310,[0,0,0],'Black'],
		[311,[0,79,97],'Navy Blue-MD'],
		[312,[58,84,103],'Navy Blue-LT'],
		[315,[163,90,91],'Antique Mauve-VY DK'],
		[316,[220,141,141],'Antique Mauve-MD'],
		[317,[167,139,136],'Pewter Grey'],
		[318,[197,198,190],'Steel Grey - LT'],
		[319,[85,95,82],'Pistachio Grn-VY DK'],
		[320,[138,153,120],'Pistachio Green-MD'],
		[321,[231,18,97],'Christmas Red'],
		[322,[81,109,135],'Navy Blue-VY LT'],
		[326,[188,22,65],'Rose-VY DP'],
		[327,[61,0,103],'Violet-DK'],
		[333,[127,84,130],'Blue Violet-VY DK'],
		[334,[115,140,170],'Baby Blue-MD'],
		[335,[219,36,79],'Rose'],
		[336,[36,73,103],'Navy Blue'],
		[340,[162,121,164],'Blue Violet-MD'],
		[341,[145,180,197],'Blue Violet-LT'],
		[347,[194,36,67],'Salmon-VY DK'],
		[349,[220,61,91],'Coral-DK'],
		[350,[237,69,90],'Coral-MD'],
		[351,[255,128,135],'Coral'],
		[352,[255,157,144],'Coral-LT'],
		[353,[255,196,184],'Peach Flesh'],
		[355,[189,73,47],'Terra Cotta-DK'],
		[356,[226,114,91],'Terra Cotta-MD'],
		[367,[95,112,91],'Pistachio Green-DK'],
		[368,[181,206,162],'Pistachio Green-LT'],
		[369,[243,250,209],'Pistachio Grn-VY LT'],
		[370,[184,138,87],'Mustard - MD'],
		[371,[196,155,100],'Mustard'],
		[372,[203,162,107],'Mustard - LT'],
		[400,[157,60,39],'Mahogany-DK'],
		[402,[255,190,164],'Mahogany-VY LT'],
		[407,[194,101,76],'Sportsman Flsh-VY D'],
		[413,[109,95,95],'Pewter Grey - DK'],
		[414,[167,139,136],'Steel Grey - DK'],
		[415,[221,221,218],'Pearl Grey'],
		[420,[140,91,43],'Hazel Nut Brown-DK'],
		[422,[237,172,123],'Hazel Nut Brown-LT'],
		[433,[151,84,20],'Brown-MD'],
		[434,[178,103,70],'Brown-LT'],
		[435,[187,107,57],'Brown-VY LT'],
		[436,[231,152,115],'Tan'],
		[437,[238,171,121],'Tan-LT'],
		[444,[255,176,0],'Lemon-DK'],
		[445,[255,255,190],'Lemon-LT'],
		[451,[179,151,143],'Shell Grey - DK'],
		[452,[210,185,175],'Shell Grey - MD'],
		[453,[235,207,185],'Shell Grey - LT'],
		[469,[116,114,92],'Avocado Green'],
		[470,[133,143,108],'Avocado Green-LT'],
		[471,[176,187,140],'Avocado Green-VY LT'],
		[472,[238,255,182],'Avocado Green-ULT L'],
		[498,[187,0,97],'Christmas Red-LT'],
		[500,[43,57,41],'Blue Green-VY DK'],
		[501,[67,85,73],'Blue Green-DK'],
		[502,[134,158,134],'Blue Green'],
		[503,[195,206,183],'Blue Green-MD'],
		[504,[206,221,193],'Blue Green-LT'],
		[517,[16,127,135],'Wedgewood-MD'],
		[518,[102,148,154],'Wedgewood-LT'],
		[519,[194,209,207],'Sky Blue'],
		[520,[55,73,18],'Fern Green-DK'],
		[522,[159,169,142],'Fern Green'],
		[523,[172,183,142],'Fern Green-LT'],
		[524,[205,182,158],'Fern Green-VY LT'],
		[535,[85,85,89],'Ash Grey - VY LT'],
		[543,[239,214,188],'Beige Brown-UL VY L'],
		[550,[109,18,97],'Violet-VY LT'],
		[552,[146,85,130],'Violet-MD'],
		[553,[160,100,146],'Violet'],
		[554,[243,206,225],'Violet-LT'],
		[561,[59,96,76],'Jade-VY DK'],
		[562,[97,134,97],'Jade-MD'],
		[563,[182,212,180],'Jade-LT'],
		[564,[214,230,204],'Jade-VY LT'],
		[580,[0,103,0],'Moss Green-DK'],
		[581,[151,152,49],'Moss Green'],
		[597,[128,151,132],'Turquoise'],
		[598,[208,223,205],'Turquoise-LT'],
		[600,[208,57,106],'Cranberry-VY DK'],
		[601,[222,57,105],'Cranberry-DK'],
		[602,[231,84,122],'Cranberry-MD'],
		[603,[255,115,140],'Cranberry'],
		[604,[255,189,202],'Cranberry-LT'],
		[605,[255,207,214],'Cranberry-VY LT'],
		[606,[255,0,0],'Bright Orange-Red'],
		[608,[255,91,0],'Bright Orange'],
		[610,[151,104,84],'Drab Brown - VY DK'],
		[611,[158,109,91],'Drab Brown - DK'],
		[612,[203,152,103],'Drab Brown - MD'],
		[613,[219,176,122],'Drab Brown - LT'],
		[632,[162,77,52],'Negro Flesh-MD'],
		[640,[163,163,157],'Beige Grey - VY DK'],
		[642,[174,176,170],'Beige Grey - DK'],
		[644,[224,224,215],'Beige Grey-MD'],
		[645,[113,113,113],'Beaver Grey - VY DK'],
		[646,[121,121,121],'Beaver Grey-DK'],
		[647,[190,190,185],'Beaver Grey - MD'],
		[648,[202,202,202],'Beaver Grey-LT'],
		[666,[213,39,86],'Christmas Red-LT'],
		[676,[255,206,158],'Old Gold-LT'],
		[677,[255,231,182],'Old Gold-VY LT'],
		[680,[209,140,103],'Old Gold-DK'],
		[699,[0,91,6],'Chirstmas Green'],
		[700,[0,96,47],'Christmas Green-BRT'],
		[701,[79,108,69],'Christmas Green-LT'],
		[702,[79,121,66],'Kelly Green'],
		[703,[121,144,76],'Chartreuse'],
		[704,[165,164,103],'Chartreuse-BRT'],
		[712,[245,240,219],'Cream'],
		[718,[219,55,121],'Plum'],
		[720,[200,36,43],'Orange Spice-DK'],
		[721,[255,115,97],'Orange Spice-MD'],
		[722,[255,146,109],'Orange Spice-LT'],
		[725,[255,200,124],'Topaz'],
		[726,[255,224,128],'Topaz-LT'],
		[727,[255,235,168],'Topaz-VY LT'],
		[729,[243,176,128],'Old Gold-MD'],
		[730,[132,102,0],'Olive Green-VY DK'],
		[731,[140,103,0],'Olive Green-DK'],
		[732,[145,104,0],'Olive Green'],
		[733,[206,155,97],'Olive Green-MD'],
		[734,[221,166,107],'Olive Green-LT'],
		[738,[244,195,139],'Tan-VY LT'],
		[739,[244,233,202],'Tan-ULT VY LT'],
		[740,[255,131,19],'Tangerine'],
		[741,[255,142,4],'Tangerine-MD'],
		[742,[255,183,85],'Tangerine-LT'],
		[743,[255,230,146],'Yellow-MD'],
		[744,[255,239,170],'Yellow-PALE'],
		[745,[255,240,197],'Yellow-LT PALE'],
		[746,[246,234,219],'Off White'],
		[747,[240,247,239],'Sky Blue-VY LT'],
		[754,[251,227,209],'Peach Flesh-LT'],
		[758,[255,177,147],'Terra Cotta-VY LT'],
		[760,[249,160,146],'Salmon'],
		[761,[255,201,188],'Salmon-LT'],
		[762,[232,232,229],'Pearl Grey - VY LT'],
		[772,[231,249,203],'Pine Green--LT'],
		[775,[247,246,248],'Baby Blue-VY LT'],
		[776,[255,177,174],'Pink-MD'],
		[778,[255,199,184],'Antique Mauve-VY LT'],
		[780,[181,98,46],'Topaz-ULT VY DK'],
		[781,[181,107,56],'Topaz-VY DK'],
		[782,[204,119,66],'Topaz-DK'],
		[783,[225,146,85],'Topaz-MD'],
		[791,[71,55,93],'Cornflower Blue-VYD'],
		[792,[97,97,128],'Cornflower Blue-DK'],
		[793,[147,139,164],'Cornflower Blue-MD'],
		[794,[187,208,218],'Cornflower Blue-LT'],
		[796,[30,58,95],'Royal Blue-DK'],
		[797,[30,66,99],'Royal Blue'],
		[798,[103,115,141],'Delft-DK'],
		[799,[132,156,182],'Delft-MD'],
		[800,[233,238,233],'Delft-PALE'],
		[801,[123,71,20],'Coffee Brown-DK'],
		[806,[30,130,133],'Peacock Blue-DK'],
		[807,[128,167,160],'Peacock Blue'],
		[809,[190,193,205],'Delft'],
		[813,[175,195,205],'Blue-LT'],
		[814,[162,0,88],'Garnet-DK'],
		[815,[166,0,91],'Garnet-MD'],
		[816,[179,0,91],'Garnet'],
		[817,[219,24,85],'Coral Red-VY DK'],
		[818,[255,234,235],'Baby Pink'],
		[819,[248,247,221],'Baby Pink-LT'],
		[820,[30,54,85],'Royal Blue-VY DK'],
		[822,[242,234,219],'Beige Grey-LT'],
		[823,[0,0,73],'Navy Blue-DK'],
		[824,[71,97,116],'Blue-VY DK'],
		[825,[85,108,128],'Blue-DK'],
		[826,[115,138,153],'Blue-MD'],
		[827,[213,231,232],'Blue-VY LT'],
		[828,[237,247,238],'Blue-ULT VY LT'],
		[829,[130,90,8],'Golden Olive-VY DK'],
		[830,[136,95,18],'Golden Olive-DK'],
		[831,[144,103,18],'Golden Olive-MD'],
		[832,[178,119,55],'Golden Olive'],
		[833,[219,182,128],'Golden Olive-LT'],
		[834,[242,209,142],'Golden Olive-VY LT'],
		[838,[94,56,27],'Beige Brown-VY DK'],
		[839,[109,66,39],'Beige Brown-DK'],
		[840,[128,85,30],'Beige Brown-MD'],
		[841,[188,134,107],'Beige Brown-LT'],
		[842,[219,194,164],'Beige Brown-VY LT'],
		[844,[107,103,102],'Beaver Brown -ULT D'],
		[868,[153,92,48],'Hazel Nut Brown-VYD'],
		[869,[153,92,48],'Hazel Nut Brn-VY DK'],
		[890,[79,86,76],'Pistachio Grn-ULT D'],
		[891,[241,49,84],'Carnation-DK'],
		[892,[249,90,97],'Carnation-MD'],
		[893,[243,149,157],'Carnation-LT'],
		[894,[255,194,191],'Carnation-VY LT'],
		[895,[89,92,78],'Hunter Green-VY DK'],
		[898,[118,55,19],'Coffee Brown-VY DK'],
		[899,[233,109,115],'Rose-MD'],
		[900,[206,43,0],'Burnt Orange-DK'],
		[902,[138,24,77],'Granet-VY DK'],
		[904,[78,95,57],'Parrot Green-VY DK'],
		[905,[98,119,57],'Parrot Green-DK'],
		[906,[143,163,89],'Parrot Green-MD'],
		[907,[185,200,102],'Parrot Green-LT'],
		[909,[49,105,85],'Emerald Green-VY DK'],
		[910,[48,116,91],'Emerald Green-DK'],
		[911,[49,128,97],'Emerald Green-MD'],
		[912,[115,158,115],'Emerald Green-LT'],
		[913,[153,188,149],'Nile Green-MD'],
		[915,[170,24,91],'Plum-DK'],
		[917,[171,22,95],'Plum-MD'],
		[918,[168,68,76],'Red Copper-DK'],
		[919,[180,75,82],'Red Copper'],
		[920,[197,94,88],'Copper-MD'],
		[921,[206,103,91],'Copper'],
		[922,[237,134,115],'Copper-LT'],
		[924,[86,99,100],'Grey Green--VY DK'],
		[926,[96,116,115],'Grey Green-LT'],
		[927,[200,198,194],'Grey Green-LT'],
		[928,[225,224,216],'Grey Green--VY LT'],
		[930,[102,122,140],'Antique Blue-DK'],
		[931,[124,135,145],'Antique Blue-MD'],
		[932,[182,186,194],'Antique Blue-LT'],
		[934,[62,59,40],'Black Avocado Green'],
		[935,[67,63,47],'Avocado Green-DK'],
		[936,[69,69,49],'Avocado Green--VY D'],
		[937,[73,86,55],'Avocado Green-MD'],
		[938,[99,39,16],'Coffee Brown-ULT DK'],
		[939,[0,0,49],'Navy Blue-Vy DK'],
		[943,[0,162,117],'Aquamarine-MD'],
		[945,[255,206,164],'Flesh-MD'],
		[946,[244,73,0],'Burnt Orange-MD'],
		[947,[255,91,0],'Burnt Orange'],
		[948,[255,243,231],'Peach Flesh-VY LT'],
		[950,[239,162,127],'Sportsman Flesh'],
		[951,[255,229,188],'Flesh'],
		[954,[170,213,164],'Nile Green'],
		[955,[214,230,204],'Nile Green-LT'],
		[956,[255,109,115],'Geranium'],
		[957,[255,204,208],'Gernanium-PALE'],
		[958,[0,160,130],'Sea Green-DK'],
		[959,[171,206,177],'Sea Green-MD'],
		[961,[243,108,123],'Dusty Rose-DK'],
		[962,[253,134,141],'Dusty Rose-MD'],
		[963,[0,233,233],'Dusty Rose-ULT VY L'],
		[964,[208,224,210],'Sea Green-LT'],
		[966,[206,213,176],'Baby Green-MD'],
		[970,[255,117,24],'Pumpkin-LT'],
		[971,[255,106,0],'Pumpkin'],
		[972,[255,146,0],'Canary-DP'],
		[973,[255,194,67],'Canary-BRT'],
		[975,[158,67,18],'Golden Brown-DK'],
		[976,[246,141,57],'Golden Brown-MD'],
		[977,[255,164,73],'Golden Brown-LT'],
		[986,[58,82,65],'Forest Green-VY DK'],
		[987,[83,97,73],'Forest Green-DK'],
		[988,[134,145,110],'Forest Green-MD'],
		[989,[134,153,110],'Forest Green'],
		[991,[47,91,73],'Aquamarine-DK'],
		[992,[146,183,165],'Aquamarine'],
		[993,[192,224,200],'Aquamarine-LT'],
		[995,[0,123,134],'Electric Blue-DK'],
		[996,[170,222,225],'Electric Blue-MD'],
		[3011,[123,91,64],'Khaki Green-DK'],
		[3012,[170,134,103],'Khaki Green-MD'],
		[3013,[208,195,164],'Khaki Green-LT'],
		[3021,[115,91,93],'Brown Grey - VY DK'],
		[3022,[172,172,170],'Brown Grey - MD'],
		[3023,[198,190,173],'Brown Grey - LT'],
		[3024,[210,208,205],'Brown Grey - VY LT'],
		[3031,[84,56,23],'Mocha Brown-VY DK'],
		[3032,[188,156,120],'Mocha Brown-MD'],
		[3033,[239,219,190],'Mocha Brown-VY LT'],
		[3041,[190,155,167],'Antique Violet-MD'],
		[3042,[225,205,200],'Antique Violet-LT'],
		[3045,[216,151,105],'Yellow Beige-DK'],
		[3046,[229,193,139],'Yellow Beige-MD'],
		[3047,[255,236,211],'Yellow Beige-LT'],
		[3051,[85,73,0],'Green Grey-DK'],
		[3052,[137,141,114],'Green Grey--MD'],
		[3053,[187,179,148],'Green Grey'],
		[3064,[194,101,76],'Sportsman Flsh-VY D'],
		[3072,[233,233,223],'Beaver Grey - VY LT'],
		[3078,[255,255,220],'Golden Yellow-VY LT'],
		[3325,[202,226,229],'Baby Blue-LT'],
		[3326,[255,157,150],'Rose-LT'],
		[3328,[188,64,85],'Salmon-DK'],
		[3340,[255,123,103],'Apricot-MD'],
		[3341,[255,172,162],'Apricot'],
		[3345,[97,100,82],'Hunter Green-DK'],
		[3346,[120,134,107],'Hunter Green'],
		[3347,[128,152,115],'Yellow Green-MD'],
		[3348,[225,249,190],'Yellow Green-LT'],
		[3350,[201,79,91],'Dusty Rose-ULT DK'],
		[3354,[255,214,209],'Dusty Rose-LT'],
		[3362,[96,95,84],'Pine Green-DK'],
		[3363,[116,127,96],'Pine Green-MD'],
		[3364,[161,167,135],'Pine Green'],
		[3371,[83,37,16],'Black Brown'],
		[3607,[231,79,134],'Plum-LT'],
		[3608,[247,152,182],'Plum-VY LT'],
		[3609,[255,214,229],'Plum-ULT LT'],
		[3685,[161,53,79],'Mauve-DK'],
		[3687,[203,78,97],'Mauve'],
		[3688,[250,151,144],'Mauve-MD'],
		[3689,[255,213,216],'Mauve-LT'],
		[3705,[255,85,91],'Melon-DK'],
		[3706,[255,128,109],'Melon-MD'],
		[3708,[254,212,219],'Melon-LT'],
		[3712,[230,101,107],'Salmon-MD'],
		[3713,[253,229,217],'Salmon-VY LT'],
		[3716,[255,211,212],'Dusty Rose-VY LT'],
		[3721,[184,75,77],'Shell Pink-DK'],
		[3722,[184,89,88],'Shell Pink-MD'],
		[3726,[195,118,123],'Antique Mauve-DK'],
		[3727,[255,199,196],'Antique Mauve-LT'],
		[3731,[209,93,103],'Dusty Rose-VY DK'],
		[3733,[255,154,148],'Dusty Rose'],
		[3740,[156,125,133],'Antique Violet-DK'],
		[3743,[235,235,231],'Antique Violet-VY L'],
		[3746,[149,102,162],'Blue Violet-DK'],
		[3747,[230,236,232],'Blue Violet-VY LT'],
		[3750,[12,91,108],'Antique Blue-VY DK'],
		[3752,[194,209,206],'Antique Blue-VY LT'],
		[3753,[237,247,247],'Ant. Blue-ULT VY LT'],
		[3755,[158,176,206],'Baby Blue'],
		[3756,[248,248,252],'Baby Blue-ULT VY LT'],
		[3760,[102,142,152],'Wedgewood'],
		[3761,[227,234,230],'Sky Blue-LT'],
		[3765,[24,128,134],'Peacock Blue-VY DK'],
		[3766,[24,101,111],'Peacock Blue-LT'],
		[3768,[92,110,108],'Grey Green-DK'],
		[3770,[255,250,224],'Flesh-VY LT'],
		[3772,[173,83,62],'Negro Flesh'],
		[3773,[231,134,103],'Sportsman Flsh-MD'],
		[3774,[255,220,193],'Sportsman Flsh-VY L'],
		[3776,[221,109,91],'Mahogony-LT'],
		[3777,[191,64,36],'Terra Cotta-VY DK'],
		[3778,[237,122,100],'Terra Cotta-LT'],
		[3779,[255,177,152],'Ter. Cotta-ULT VY L'],
		[3781,[113,71,42],'Mocha Brown-DK'],
		[3782,[206,175,144],'Mocho Brown-LT'],
		[3787,[139,109,115],'Brown Grey - DK'],
		[3790,[140,117,109],'Beige Grey - ULT DK'],
		[3799,[81,76,83],'Pewter Grey - VY DK']
	]

	########## DEFINE FUNCTIONS ##########
	#  match colours
	def matchFloss(iColor):
		#for each colour in floss palette...
		match = (0, 255, 255, 255, 300) #'match' contains 'index', 'red', 'green', 'blue' and 'score' values
		score = 0
		for fIndex, fColor, fName in fColors:
			#score is difference in composite number of R, G & B i.e. sqrt((iR - fR)^2 + (iG - fG)^2 + (iB - fB)^2)
			score = pow(abs(iColor[0] - fColor[0]), 2) + pow(abs(iColor[1] - fColor[1]), 2) + pow(abs(iColor[2] - fColor[2]), 2)
			score = pow(score, 0.5) #for some reason sqrt(x) is not working for me...
			#low score = best match
			if score < match[4]:
				match = (fIndex, fColor[0], fColor[1], fColor[2], score, fName)
			if score == 0:
				#don't bother if this matches previous pixel
				break

		#swap source colour for matched colour
		if score > 0:
			pdb.plug_in_exchange(theImage, theDraw, iColor[0], iColor[1], iColor[2], match[1], match[2], match[3], 0, 0 ,0)
		return match
	
	# Add text to the active layer
	def addText(tDraw, x, y, myText):
		newText = pdb.gimp_text_fontname(theImage, tDraw, x, y, myText, 0, FALSE, 7, PIXELS, 'Small Fonts')
		pdb.gimp_floating_sel_anchor(newText)
		return
	
	########## START CODE ##########
	#check to make sure the file has been saved
	# Begin Undo Group
	pdb.gimp_image_undo_group_start(theImage)
	
	# Set temporary context area (to maintain previous user options for when script terminates)
	pdb.gimp_context_push
	
	#Pixelate
	pdb.plug_in_pixelize(theImage, theDraw, theMosaic)
	
	#Brightness
	pdb.gimp_brightness_contrast(theDraw, theBrightness, 0)
	
	#Posterize
	pdb.gimp_posterize(theDraw, thePosterize)
	
	#crop useless tiles
	widthOld = theMosaic * (int(theImage.width / theMosaic))
	heightOld = theMosaic * (int(theImage.height / theMosaic))
	pdb.gimp_image_crop(theImage, widthOld, heightOld, 0, 0)
	
	#resize layer shrinking mosaic=5 to run faster
	mosaicModified = 5 / theMosaic
	widthNew = widthOld * mosaicModified
	heightNew = heightOld * mosaicModified
	theImage.resize(widthNew, heightNew, 0, 0)
	pdb.gimp_drawable_transform_scale(theDraw, 0.0, 0.0, widthNew, heightNew, TRANSFORM_FORWARD, INTERPOLATION_NONE, 1, 3, 0)
	
	# Update display
	gimp.displays_flush

	#check each grid square to match floss colours
	# initialise progress bar
	progStep = 100/float((theImage.height/5) * (theImage.width/5))
	gimp.progress_init("Swapping for floss colours ...")
	# for each grid row...
	while (currPixel[1] < theImage.height):
		#for each grid column...
		while (currPixel[0] < theImage.width):
			#...pick up colour of pixel
			currColor = pdb.gimp_image_pick_color(theImage, theDraw, currPixel[0], currPixel[1], 0, 0, 0)
			if (currColor[0:2]) != (newColor[1:3]):
				newColor = matchFloss(currColor)
			#...capture location of final pixel placement for text label
			lX = ((currPixel[0]-1)/5*20)+1
			lY = ((currPixel[1]-1)/5*20)+1
			#...add new colour, label position & label text to list for later use
			paletteFinal.append((newColor[0], lX, lY, newColor[5]))
			#step progress bar forward
			progVal += progStep
			gimp.progress_update(progVal/100)
			#...move forward to next column
			currPixel[0] = currPixel[0] + 5
		#...move down to next row, start at first column
		currPixel[1] = currPixel[1] + 5
		currPixel[0] = 1

	#resize layer shrinking mosaic=20 to make labels visible
	mosaicModified = 20 / theMosaic
	widthNew = widthOld * mosaicModified
	heightNew = heightOld * mosaicModified
	theImage.resize(widthNew, heightNew, 0, 0)
	pdb.gimp_drawable_transform_scale(theDraw, 0.0, 0.0, widthNew, heightNew, TRANSFORM_FORWARD, INTERPOLATION_NONE, 1, 3, 0)
	bigMosaic = 20
	
	# Update display
	gimp.displays_flush

	#work on new layer
	theNewLayer = gimp.Layer(theImage, "Grid", theImage.width, theImage.height, RGBA_IMAGE, 100.0, NORMAL_MODE)
	theImage.add_layer(theNewLayer, -1)

	#Add grid
	pdb.plug_in_grid(theImage, theNewLayer, 1, bigMosaic, 0, (0,0,0), 255, 1, bigMosaic, 0, (0,0,0), 255, 0, 0, 0, (0,0,0), 255)
	
	#add text marker to each grid square
	# initialise progress bar
	progVal = 0.0
	progStep = 0.0
	progStep = 100/float(len(paletteFinal))
	gimp.progress_init("Adding labels ...")
	# for each mosaic tile in final pattern...
	for tile in paletteFinal:
		addText(theNewLayer, tile[1], tile[2], tile[0])
		#step progress bar forward
		progVal += progStep
		gimp.progress_update(progVal/100)

	# Update display
	gimp.displays_flush

	# Ditch temporary context area
	pdb.gimp_context_pop

	# End Undo Group
	pdb.gimp_image_undo_group_end(theImage)

	#build buying guide (with stitch count)
	# get index and label for each used colour
	indexUsed = [(indices[0],indices[3]) for indices in paletteFinal]
	# strip out duplicates & sort output by index
	paletteUsed = list(set(indexUsed))
	paletteUsed.sort()
	# initialise progress bar
	progVal = 0.0
	progStep = 0.0
	progStep = 100/float(len(paletteUsed))
	gimp.progress_init("Adding stitch count ...")
	#create text for adding to buying guide
	# for each colour used...
	for c, n in paletteUsed:
		colourUsed = (c, n)
		#...set plural agreement
		if indexUsed.count(colourUsed) == 1:
			stitch = " stitch"
		else:
			stitch = " stitches"
		#...build output string
		output += n + " (index #" + str(c) + ") - " + str(indexUsed.count(colourUsed)) + stitch + " \n"
		#step progress bar forward
		progVal += progStep
		gimp.progress_update(progVal/100)
	# write buying guide to text file
	#  set file path and name for text file based on current image
	if theImage.filename is not None:
		split = os.path.splitext(theImage.filename)
		path = split[0] + '.txt'
	else:
		path = os.getcwd() + os.tmpnam() + 'txt'
	#  add file path and name to output text
	output = "(This file saved as: " + path + ") \n" + output
	file = open(path,'w')
	file.write(output)
	file.close()
	if os.name == "nt":
		os.startfile(file.name)
	else:
		pdb.gimp_message("Text file saved as: " + path)

register(
    "python_fu_cross_stitch",
    "v 2.0: This script generates a cross-stitch pattern from an image, and a text file outlining the floss you need to purchase.  NOTE: This script takes a good few minutes to run, as it must iterate through MANY mosaic tiles.  Please wait until the script finishes running until performing any operations.",
    "This script pixellates & posterises the source image and adds a grid. It then does colour matching to a floss-friendly palette, and generates a text file listing the amounts of needed floss.",
    "w_nightshade",
    "GPL License",
    "2008",
    "<Image>/Filters/Decor/Cross-Stitchify...",
    "",
    [
		(PF_SPINNER, "theMosaic", "Mosaic size", 10, (1, 50, 1, 1, 1, 1)) , 
		(PF_SPINNER, "theBrightness", "Brightness", 35, (1, 120, 1, 1, 1, 1)) , 
		(PF_SPINNER, "thePosterize", "Posterize", 15, (2, 255, 1, 1, 1, 1)) 
    ],
    [],
    cross_stitch)

main()
