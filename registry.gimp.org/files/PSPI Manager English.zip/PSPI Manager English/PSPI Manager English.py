#-*- coding: utf-8 -*-

# version 1.0 alfa [ http://www.gimpuj.info/]
# Searh: available filters without rebooting [no refresh Gimp].
# The idea for PSPI Manager is based on the Brush Manager 2.00 by Sean Bogie
# You can find the original Brush Manager here:
# http://myweb.msoe.edu/~bogies/brushmanager/
# modified by: MareroQ [marero@02.pl]
# Windows
ACTIVE_DIR=r"C:\Documents and Settings\MarQ\.gimp-2.7\Plugin_ps_active" #<<--SET HERE<<--(Active identical directory how  folder in Photoshop Plug-in Settings)
INSTALL_DIR=r"C:\Documents and Settings\MarQ\.gimp-2.7\Plugin_ps"#<<--SET HERE<<--(Directory, where you place your filters 8bf)
# Linuks
# ACTIVE_DIR=r"/home/x/.gimp-2.y/Plugin_ps_active"
# INSTALL_DIR=r"/home/x/.gimp-2.y/Plugin_ps"

EXTENTIONS = [".8bf", ".8BF"] # Valid filter extentions

import pygtk
pygtk.require('2.0')
import gtk
import shutil
import os
try:
    from gimpfu import *
    import gimp
except ImportError:
    def main():
        do_pspimanager()

PROC_NAME = "python_fu_pspi_manager"

class PSPIManager:
    
    dialog = None

    def listDirs( self, path ):
        dirs=[]
        for i in os.listdir( path ):
            if os.path.isdir( os.path.join( path, i ) ):
                dirs.append( i )
        return dirs

    def listFiles( self, path ):
        files=[]
        for i in os.listdir( path ):
            if os.path.splitext( i )[1] in EXTENTIONS:
                if os.path.isfile( os.path.join( path, i ) ):
                    files.append( i )
        return files

    def getActive( self ):
        try:
            f=open( os.path.join( INSTALL_DIR, "8bf_active.txt" ) )
        except IOError:
            return []
        line=f.readline()
        a=line.split( "," )
        f.close()
        return a[:-1]

    def dialog_delete( self, widget, event, data=None ):
        return True

    def makedialog( self ):
        self.dialog = gtk.Dialog( "Please Wait...", self.win,
            gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT )
        self.dialog.connect( "delete_event", self.dialog_delete )
        self.dialog.set_size_request( 200, 50 )
        
        self.statuslabel = gtk.Label( "Status:" )
        self.dialog.vbox.pack_start( self.statuslabel, False, False, 0 )
        
        self.progressbar = gtk.ProgressBar()
        self.dialog.vbox.pack_start( self.progressbar, False, True, 0 )

    def showdialog( self ):
        self.statuslabel.show()
        self.progressbar.show()
        self.dialog.show()

    def hidedialog( self ):
        self.statuslabel.hide()
        self.progressbar.hide()
        self.dialog.hide()

    def do_copy( self, add, remove ):
        count = 0.0
        total = len( add ) + len( remove )
        if not self.dialog:
            self.makedialog()
        self.showdialog()
        self.progressbar.set_fraction( 0 )
        self.statuslabel.set_text( "Status: Removing old files..." )
        for f in remove:
            gtk.main_iteration()
            try:
                os.remove( f )
            except:
                continue
            finally:
                count += 1.0
                self.progressbar.set_fraction( count / total )
        self.statuslabel.set_text( "Status: Copying new files..." )
        for f in add:
            gtk.main_iteration()
            try:
                shutil.copy( f, ACTIVE_DIR )
            except:
                continue
            finally:
                count += 1.0
                self.progressbar.set_fraction( count / total )
        gtk.main_iteration()
        self.statuslabel.set_text( "Status: Refreshing pspi..." )
        gtk.main_iteration()
        self.hidedialog()

    def ok_clicked( self, widget, data=None ):
        active = []
        for i in self.checkboxes:
            if i.get_active():
                active.append( i.get_label() )
        oldActive = self.getActive()

        add = []
        for i in active:
            if not i in oldActive:
                for j in self.listFiles( os.path.join( INSTALL_DIR, i ) ):
                    add.append( os.path.join( INSTALL_DIR, i, j ) )
        
        remove = []
        for i in oldActive:
            if not i in active:
                for j in self.listFiles( os.path.join( INSTALL_DIR, i ) ):
                    remove.append( os.path.join( ACTIVE_DIR, j ) )

        self.do_copy( add, remove )

        try:
            f=open( os.path.join( INSTALL_DIR, "8bf_active.txt" ), "w" )
        except IOError:
            return -1
        try:
            for i in active:
                f.write( i + "," )
        except Exception:
            return -1
        finally:
            f.close()

    def destroy( self, widget, data=None ):
        gtk.main_quit()

    def __init__( self ):

        self.win = gtk.Dialog()
        self.win.connect( "destroy", self.destroy )
        self.win.set_title( "Gimp Filters *.8bf Manager" )
        self.win.set_border_width( 10 )
        self.win.set_size_request( 230, 400 )
        
    
        scroll_box = gtk.ScrolledWindow()
        scroll_box.set_border_width( 10 )
        scroll_box.set_policy( gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC )
        self.win.vbox.pack_start( scroll_box, True, True, 0 )
        scroll_box.show()

        vbox = gtk.VBox()
        self.checkboxes=[]
        dirs = self.listDirs( INSTALL_DIR )
        dirs.sort()
        for i in dirs:
            self.checkboxes.append( gtk.CheckButton( os.path.split( i )[1] ) )
        active = self.getActive()
        for i in self.checkboxes:
            vbox.pack_start( i, False, False, 1 )
            if i.get_label() in active:
                i.set_active( True )
            i.show()
        scroll_box.add_with_viewport( vbox )
        vbox.show()

        cancelButton = gtk.Button( stock=gtk.STOCK_CLOSE )
        cancelButton.connect_object( "clicked", gtk.Widget.destroy, self.win )
        self.win.action_area.pack_start( cancelButton, True, True, 0 )
        cancelButton.show()

        okButton = gtk.Button( stock=gtk.STOCK_OK )
        okButton.connect( "clicked", self.ok_clicked )
        self.win.action_area.pack_start( okButton, True, True, 0 )
        okButton.show()

        self.win.show()

    def main(self):
        gtk.main()

def do_pspimanager():
    mgr = PSPIManager()
    mgr.main()

try:
    register(
        PROC_NAME,
        N_("Gimp PSPI manager - enable and/or disable filters *.8bf\nfor plugin pspi.exe.\nAccessibility to filters from newly marked directories requires refresh Gimp."),
        "Enable and/or disable for pspi.",
        "Original-Brush Manager: Sean Bogie",
        "Modified-PSPI Manager: MareroQ",
        "29.10.2010",
        N_("Photoshop Plug-in Manager..."),
        "",
        [],
        [],
        do_pspimanager,
        menu="<Image>/Filters/Extensions")
except:
    pass

main()

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
