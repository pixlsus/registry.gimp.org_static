##B&P Glossy Web 2.0 style Button 01
##Gimp Python plugin - Glossy Button 1
##Copyright (C) 2010 Andrei Roslovtsev ~ www.byes-and-pixels.com
##
##This program is free software; you can redistribute it and/or
##modify it under the terms of the GNU General Public License
##as published by the Free Software Foundation version 2
##of the License.
##
##This program is distributed in the hope that it will be useful,
##but WITHOUT ANY WARRANTY; without even the implied warranty of
##MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##GNU General Public License for more details.
##
##You should have received a copy of the GNU General Public License
##along with this program; if not, write to the Free Software
##Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

# Creates creates a glossy Web2.0 style button
# Accepted parameters are dimensions, color,
# corner radius, shadow amount, Add optional text - size, font, color,
# create button states, flatten resulting image(s).
#
# Works best with light colors and low saturation.
#
# Note:
# Developed and tested with Python 2.6 only.
#
# Version:1.0
# 2010-Jun-07
# Andrei Roslovtsev
# www.bytes-and-pixels.com
# andrei@bytes-and-pixels.com


#-----------------------------------------------------------
from gimpfu import *

def make_button(width_var,height_var,rounding,
                shadow_amount,main_col,text_flag,
                text_size,button_txt,font,text_col,
                flatten_flag,states_flag):

    if font==None:
        font='Sans'
        
    # define margin width to accomodate shadow
    margin = shadow_amount*2

    if (margin<8):
        margin=8
    
    # set image dimensions
    img_w = width_var+margin*2
    img_h = height_var+margin*2
        
    image = pdb.gimp_image_new(img_w, img_h, 0)
    pdb.gimp_image_set_filename(image, "Up_image")
    
    layer1 = pdb.gimp_layer_new(image, img_w, img_h, 1, 'BG', 100, 0)
    layer2 = pdb.gimp_layer_new(image, img_w, img_h, 1, 'Base Color', 100, 0)
    pdb.gimp_image_add_layer(image, layer1, 0)
    pdb.gimp_image_add_layer(image, layer2,-1)
    gimp.pdb.gimp_edit_fill(layer1, 3)
    
    display = pdb.gimp_display_new(image)

    pdb.gimp_round_rect_select(image, margin, margin, width_var,
                               height_var, rounding, rounding, 2, 1, 0, 1, 1)

    pdb.gimp_context_set_foreground(main_col)
    
    #pdb.gimp_bucket_fill(drawable, fill_mode, paint_mode, opacity, threshold, sample_merged, x, y)
    pdb.gimp_bucket_fill(layer2, 0, 0, 100, 0, 0, 0, 0)

    #Save original selection (shape of the button)
    orig_shape = pdb.gimp_selection_save(image)
    
    #get feather amount based on button dimensions
    if width_var-height_var<0:
        feather=width_var-(width_var/10)
    else:
        feather=height_var-(height_var/10)
    #gimp.pdb.gimp_message(feather)
    
    pdb.gimp_selection_feather(image, feather)
    pdb.gimp_edit_clear(layer2)

    layer2_tmp1=pdb.gimp_layer_copy(layer2, 1)
    layer2_tmp2=pdb.gimp_layer_copy(layer2, 1)
    pdb.gimp_image_add_layer(image, layer2_tmp1,-2)
    pdb.gimp_image_add_layer(image, layer2_tmp2,-3)

    #merge duplicated layers
    pdb.gimp_layer_set_visible(layer1, 0)
    layer2 = pdb.gimp_image_merge_visible_layers(image, 0)
    pdb.gimp_layer_set_visible(layer1, 1)
    
    #load original shape selection
    pdb.gimp_selection_load(orig_shape)

#Add matte layer --------------------------------------------------------
    pdb.gimp_context_set_background((255,255,255))
    layer_matte = pdb.gimp_layer_new(image, img_w, img_h, 1, 'Matte', 100, 0)
    pdb.gimp_image_add_layer(image, layer_matte, 1)
    pdb.gimp_selection_load(orig_shape)

    pdb.gimp_edit_bucket_fill(layer_matte, 1, 0, 100, 0, 0, 0, 0)

    
#Add reflection ---------------------------------------------------------


    #pdb.gimp_ellipse_select(image, x, y, width, height, operation, antialias, feather, feather_radius)
    pdb.gimp_ellipse_select(image, img_w*-1, img_h/2, img_w*3, (width_var+height_var)/2, 3, 1, 0, 0)

    layer3 = pdb.gimp_layer_new(image, img_w, img_h, 1, 'Reflection', 25, 3)
    pdb.gimp_image_add_layer(image, layer3, 0)

    #pdb.gimp_selection_shrink(image, 10)

    pdb.gimp_context_set_default_colors()
    
    #pdb.gimp_context_set_gradient('FG to Transparent')
    pdb.gimp_edit_blend(layer3, 2, 0, 0, 100, 0, 0, 0, 0,
                        0, 0, 1, img_w/2, img_h,
                        img_w/2, img_h/3)

# Specular 1 layer -----------------------------------------------------------    
    
    layer4 = pdb.gimp_layer_new(image, img_w, img_h, 1, 'Specular', 100, 0)
    pdb.gimp_image_add_layer(image, layer4, 0)

    #load original shape selection
    pdb.gimp_selection_load(orig_shape)
    pdb.gimp_selection_shrink(image, margin*0.2)
    pdb.gimp_rect_select(image,0,margin+margin*0.4,img_w+margin*2,
                         img_h+margin*2,1, 0, 0)


    pdb.gimp_context_swap_colors()
    
    pdb.gimp_edit_blend(layer4, 2, 0, 1, 100, 0, 0, 0, 0,
                        0, 0, 1, img_w/2, 0, rounding*2, 0)
    
    pdb.gimp_context_swap_colors()
    pdb.gimp_selection_none(image)

    pdb.plug_in_gauss(image, layer4, width_var*0.02, height_var*0.01, 0)

# Shadow layer ---------------------------------------------------------------
    if (shadow_amount!=0):
        
        layer5 = pdb.gimp_layer_new(image, img_w, img_h, 1, 'Shadow', 75, 0)
        pdb.gimp_image_add_layer(image, layer5, 3)

        #load original shape selection
        pdb.gimp_selection_load(orig_shape)

        pdb.gimp_selection_border(image,shadow_amount)

        pdb.gimp_bucket_fill(layer5, 0, 0, 100, 0, 0, 0, 0)

        pdb.gimp_selection_none(image)

        # Do blur operation a few times depending on shadow_amount
        i=0
        while (i<shadow_amount):
            # set limit for itererations
            if (shadow_amount<10):
                pdb.plug_in_blur(image, layer5)
            i=i+1
        
#Reflection 2 layer (window frame)--------------------------------------------
    
    layer6 = pdb.gimp_layer_new(image, img_w, img_h,
                                1, 'Window Refl', 30, 4)
    pdb.gimp_image_add_layer(image, layer6, 0)

    pdb.gimp_selection_all(image)
    pdb.gimp_rect_select(image, img_w/2-margin/2, 0, margin,
                         img_h, 1, 0, 0)
    pdb.gimp_rect_select(image, 0, img_h/2-margin/2, img_w,
                         margin, 1, 0, 0)

    #pdb.gimp_bucket_fill(drawable, fill_mode, paint_mode, opacity, threshold, sample_merged, x, y)
    pdb.gimp_bucket_fill(layer6, 1, 0, 100, 0, 0, 0, 0)

    pdb.gimp_selection_none(image)
    
    pdb.gimp_layer_scale(layer6, img_w/3, img_h/3, 0)
    pdb.gimp_layer_translate(layer6, img_w/2-rounding/2, margin*1.2)

    pdb.plug_in_lens_distortion(image, layer6, 100, 80,
                                50, 0, 0, 0)
    pdb.gimp_layer_resize_to_image_size(layer6)

# Text Layer (optional) --------------------------------------------
    if text_flag == 1:
        layer7 = pdb.gimp_text_layer_new(image, button_txt, font, text_size, 0)
        pdb.gimp_image_add_layer(image, layer7, 0)
        pdb.gimp_text_layer_set_color(layer7, text_col)
        
        txt_x = (image.width-layer7.width)/2
        txt_y = (image.height-layer7.height)/2
        layer7.set_offsets(txt_x, txt_y)

# Create state images -----------------------------------------------
    if states_flag == 1:
        over_image = pdb.gimp_image_duplicate(image)
        down_image = pdb.gimp_image_duplicate(image)

        pdb.gimp_image_set_filename(over_image, "Over_image")
        pdb.gimp_image_set_filename(down_image, "Down_image")

        display = pdb.gimp_display_new(over_image)
        display = pdb.gimp_display_new(down_image)

        # Edit "Over" state
        o_layer5 = find_layer_by_name(over_image,"Shadow")
        o_layer6 = find_layer_by_name(over_image,"Window Refl")
        o_layer3 = find_layer_by_name(over_image,"Reflection")
        
        pdb.gimp_layer_set_opacity(o_layer5, 90) #shadow layer
        pdb.gimp_layer_set_opacity(o_layer6, 80) #window refl layer
        pdb.gimp_layer_set_opacity(o_layer3, 50) # refl layer


        # Edit "Down" state
        d_layer4 = find_layer_by_name(down_image,"Base Color")
        pdb.gimp_image_set_active_layer(down_image, d_layer4)
        pdb.gimp_hue_saturation( d_layer4, 0, -50, 0, -50)

# Flatten Image routine ---------------------------------------------
    if flatten_flag == 1:
        pdb.gimp_image_remove_layer(image, layer1)
        layer1 = pdb.gimp_image_merge_visible_layers(image, 0)

        pdb.gimp_image_remove_layer(over_image, find_layer_by_name(over_image,"BG"))
        o_layer1 = pdb.gimp_image_merge_visible_layers(over_image, 0)

        pdb.gimp_image_remove_layer(down_image, find_layer_by_name(down_image,"BG"))
        d_layer1 = pdb.gimp_image_merge_visible_layers(down_image, 0)
        
    pdb.gimp_image_set_active_layer(image, layer1)

    
#--------------------------------------------------------------------
#Helper functions
#Author:  Joao S. O. Bueno
#source:  http://www.gimpusers.com/forums/gimp-user/
#    11870-set-active-layer-by-referring-to-its-name

def find_layer_by_name (image, name):
    for layer in image.layers:
        if layer.name == name:
            return layer
            return None


#---------------------------------------------------------------------
register(
    "Glossy_Button_01",
    N_("Create a glossy button"),
    "Create a glossy Web 2.0 style button",
    "Andrei Roslovtsev",
    "www.bytes-and-pixels.com",
    "2010",
    N_("_Glossy button 01"),
    #"RGB*, GRAY*",
    "",
    [
        (PF_SPINNER, "width_var", "Button Width:", 140, (1, 2000, 1)),
        (PF_SPINNER, "height_var", "Button Height:", 50, (1, 2000, 1)),
        (PF_SPINNER, "rounding", "Corner Radius:", 12, (0, 100, 1)),
        (PF_SPINNER, "shadow_amount", "Shadow amount:", 4, (0, 100, 1)),
        (PF_COLOR, "main_col", "Color:", (161, 179, 196) ),
        (PF_TOGGLE, "text_flag", "Add Text:", 1),
        (PF_SPINNER, "text_size", "Text Size (px):", 20, (1, 2000, 1)),
        (PF_STRING, "button_txt", "Text:", "Download"),
        (PF_FONT, "font", "FONT:", 0),
        (PF_COLOR, "text_col", "Text Color:", (0, 0, 0) ),
        (PF_TOGGLE, "flatten_flag", "Flatten Image", 0),
        (PF_TOGGLE, "states_flag", "Generate Button States", 0)
    ],
    [],
    make_button,
    menu="<Toolbox>/Xtns/Web Page Themes/www.bytes-and-pixels.com",
    domain=("gimp20-python", gimp.locale_directory)
    )

main()
