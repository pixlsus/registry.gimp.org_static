// ----------------------------------------------------
// RAWTEX
// Gimp 2.2.x & 2.3.x plugin to create raw textures & pictures.
//
// Copyright (C) 2006-2008 Franck Charlet
// All Rights Reserved.
//
// hitchhikr@australia.edu
// http://perso.wanadoo.fr/franck.charlet/
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the "Software"),
// to deal in the Software without restriction, including without limitation
// the rights to use, copy, modify, merge, publish, distribute, sublicense,
// and / or sell copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
// THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
// WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
// ----------------------------------------------------

// ----------------------------------------------------
// Includes
#include <gtk/gtk.h>

// ----------------------------------------------------
// Functions
void on_CbTex_changed(GtkComboBox *combobox, gpointer user_data);
void on_CbPal_changed(GtkComboBox *combobox, gpointer user_data);
void on_CbMipmap_changed(GtkComboBox *combobox, gpointer user_data);
void on_CbDxt_changed(GtkComboBox *combobox, gpointer user_data);
void on_TxtColorKey_editing_done(GtkCellEditable *celleditable, gpointer user_data);
void on_ChkKey_toggled(GtkToggleButton *togglebutton, gpointer user_data);
void on_ChkSwizzle_toggled(GtkToggleButton *togglebutton, gpointer user_data);
void on_ChkSrcPicture_toggled(GtkToggleButton *togglebutton, gpointer user_data);
void on_ChkSrcPalette_toggled(GtkToggleButton *togglebutton, gpointer user_data);
void on_BtnCancel_clicked(GtkButton *button, gpointer user_data);
void on_BtnOk_clicked(GtkButton *button, gpointer user_data);
void on_BtnColor_clicked(GtkButton *button, gpointer user_data);
void on_Color_Changed(GtkColorSelection *ColorSelection, gpointer user_data);
