/* 
 * Copyright (C) 2005 Alexandre Heitor Schmidt <alexsmith@solis.coop.br>
 * (the "Author").
 * All Rights Reserved.
 *
 * This file is part of GIMP Image Subtraction Plug-In.
 * Foobar is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * GIMP Image Subtraction Plug-In is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * GIMP Image Subtraction Plug-In; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
 *
 */

#ifndef __RENDER_H__
#define __RENDER_H__

/*  Public functions  */

void   render (PlugInVals         *vals);

#endif /* __RENDER_H__ */
