 NON-INERACTIVE mode in Color-based Blur plugin for gimp
 
 The mode introduced in 0.3.5.
 
 The noninteractive mode will let you process images in batches, that means without your assistance,
 and withouth a need for graphical interface (f.e. over ssh on remote server - I have linux in mind here).
 
 You need 2 things:
 
 *.scm script in ~/.gimp-2.X/scripts/ directory - the package contains one: colorblur-simple.scm
 It will just take given image, process it and save as output.jpg in current directory.
 
 Second, a command like this:
 
 >gimp -i -b '(colorblur-simple "your_image.jpg" 1 5 5 0.03 0.1   -1 0 -1 -1 -1   0 -1 -1)' -b '(gimp-quit 0)' 

the parameters (after input image filename) are:
1. Processing mode 				<0-3> ordered as in GUI
2. Radius						INT
3. Iterations					INT
4. Color treshold				FLOAT
5. Brightness treshold			FLOAT
6. Lines creation treshold		FLOAT
7. Clean small noise/detials	BOOL(0=no,1=yes)
8. darkpoint 					FLOAT #experimental !
9. lightpoint					FLOAT #experimental !
10. saturation					FLOAT
11. Fastmode					BOOL (0=no,1=yes)
12. Min dir count (strictness)	INT <1-4>				
13. Soft clean					BOOL (0=no,1=yes)

As you noticed in above example, I used "-1" couple of times, this has special meaning = 'use the default value'.
So I suggest you when testing this mode, start with all '-1' and change only values that are relevant for you - the 
same way as you work in GUI....


*********  TROUBLESHOOTING   *********  

You can run into various problems when working interactively, so I tried to make my plugin as user-friendly as I could,
so f.e. you can run into errors like this:

---------- sample error console output------------
  Incorrect argument 3: 10.000 (expecting float in range 0.000 - 1.000)            <=== LOOK HERE

GIMP-Error: Plug-in crashed: "colorblur"
(/home/tibor/.gimp-2.8/plug-ins/colorblur)

The dying plug-in may have messed up GIMP's internal state. You may want to save your images and restart GIMP to be on the safe side.

GIMP-Error: Calling error for procedure 'plug-in-colorblur':
Procedure 'plug-in-cartoonizer' returned no return values

batch command experienced an execution error:
Error: (<unknown> : 163233500) Procedure execution of plug-in-colorblur failed on invalid input arguments: Procedure 'plug-in-colorblur' returned no return values 
----------------------------------------


I marked (with simple arrow) where to look. Two comments:

1. 'argument 3' reffer to item 3 in above list. So it is not an position in GimpParamDef or elsewhere!
2. some errors can happen when decimal numbers are converted to integers if the argument is to be of integer type. 
F.e. if you use '-0.4' for parameter that is to be integer, it is treated as '0' and can be accepted as such. 
So it can lead to confusion during debugging....


If you are unsure whether the correct parameters are passed, compile the plugin in verbose mode,
edit following line in cartoonizer.c (circa row 26) (this is how it should look):

#define VERBOSE TRUE

And during processing check following section:


== Running Selective Color Blur plugin... ==
 Processed area: 2048 x 1536, channels: 3
 Processing mode: 3
 Radius: 4 px,  Iterations: 20
 Hue tresh: 0.015 / 0.0002, brtresh: 0.040
 Lines creation sensitivity: 3.000 
 Saturation mode: 0
 Small details cleaning: yes
 Exporting as new layer: no



The noninteractive mode is new (as in 0.3.5) so some problems are still possible.

If any problems, contact me...



Updated: 02 Aug 2013
