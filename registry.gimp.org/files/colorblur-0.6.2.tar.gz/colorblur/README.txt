Selective color-based blur
(actual version 0.6.2, no development version for now)

is gimp plugin that blurs the color information (both hue and saturation) in image. 


==PURPOSE==

There are two basic usages:

1.) for poorly saturated images - blur the color and saturate it. This way
you should avoid artifacts that could happen during saturation
2.) Alternatively you can use it for creating of cartoon like images.


==HOW IT WORKS AND USE MINIGUIDE:==

The plugin works in iterations and with each iteration it tests n (n=radius) pixels in eight directions - up, right, down, left and diagonally between them.
If color  distance of all n pixels to central pixel is below the treshold (in normalized RGB colorspace, i.e. brightness is ignored) then those pixels
are considered for blurring. So final values are calculated as average from averages of up to 8 lines of pixels. (Perhaps some graphical explanation
would be usefull here.)
Since about 0.2.2 you can set up also brightness treshold, seems to be very usefull option as well.

User defines five basic parameters:
RADIUS -  distance in 8 directions from central pixel. The single direction (set of RADIUS pixels) is either accepted or rejected as an entity.
ITERATIONS - how many times the procedure described above is repeated. 
(I can say that RADIUS * ITERATIONS = overall radius of blurring)
COLOR TRESHOLD - should be obvious
VALUE (BRIGHTNESS) TRESHOLD - should be obvious as well just keep in mind that brightness is converted to values 0 - 1.
LINESENSITIVITY - this controls how many pixels will be made black (~become lines)

Moreover there is an slider to MODIFY SATURATION. The main goal of it is to preserve (via boosting it) the saturation of poorly saturated pixels.

And then 2 checkbuttons:
 FORCED SMOOTHING - selfexplanatory
 FAST MODE - faster but less accurate
 SOFT CLEANING - to be rid of pixels that are too different from its surrounding (effect might be not so visible)
  
EXPORT TO NEW LAYER is available as well

NON-INTERACTIVE mode added in 0.3.5 (see attached Readme-NON-INT.txt for more info)

==INSTALLATION:==

On LINUX:
might be needed:
  export LDFLAGS="$LDFLAGS -lm"
for user:
  gimptool-2.0 --install colorblur.c
and for system-wide installation:
  gimptool-2.0 --install-admin colorblur.c

For WINDOWS and others:
I'm not able to compile it for windows, but visit this page and search within the discussion: http://registry.gimp.org/node/25801
 or visit gimpchat.com site


plugin can be found at: FILTERS -> BLUR -> COLOR SELECTIVE BLUR


==ISSUES & SHORTCOMINGS ==

Nothing I know of (so far :) )


==CONTACT AND FURTHER INFO==


For more info you can visit: http://code.google.com/p/selective-color-blur/wiki/Introduction

For some other info, to discuss and for windows packages visit: http://registry.gimp.org/node/25801 

Goog place to visit is also www.gimpchat.com

And the most reliable way how to contact me is via email: tiborb95 at gmail dot com

....any feedback welcomed


Last update: 06. Aug 2013

