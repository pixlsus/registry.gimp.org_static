/*  ShapeFS Messages Class Source File.
	A GIMP Plug-in to render shape from shading.
	(c) 2003, Alfred P. Reaud
	Created: May 11, 2003
	Current: October 20, 2005
	Version: 1.2.0.0

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/

#include "shapefs.h"

MESSAGES text;	// Declare text static so that all portions can use it.
extern COMMON_ALGORITHM common;	// Common algorithms.

extern SFSSemaphore SFSint;

// -----------------------------------------------------------------------------
MESSAGES::MESSAGES (void)
/*
  Name: Messages Class Constructor
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:52
  Description: Constructs the message class, clearing the buffer and setting
			   the buffer pointer.
*/
{
	gint i;

	// Initialize the message buffers.
	for (i = 0; i < NUMB_BUFF_SIZE; i++) number_buffer[i] = '\0';
	number_ptr = number_buffer;
	for (i = 0; i < MSG_BUFF_SIZE; i++) message_buffer[i] = '\0';
	message = message_buffer;
	sort_error_count = 0;
}

// -----------------------------------------------------------------------------
void MESSAGES::attach_number (const gchar *format, const gint value)
/*
  Name: Attach Integer Number to String Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:54
  Description: Attaches an integer with the given format and value to the
			   message string
*/
{
	sprintf(number_buffer, format, value);
	rtrim (number_buffer);
	strcat (message, number_buffer);
}

// -----------------------------------------------------------------------------
void MESSAGES::attach_number (const gchar *format, const gdouble value)
/*
  Name: Attach Double Precision Number to String Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:54
  Description: Attaches an double precision number with the given format and
  			   value to the message string
*/
{
	sprintf(number_buffer, format, value);
	rtrim (number_buffer);
	strcat (message, number_buffer);
}

// -----------------------------------------------------------------------------
#ifdef DEBUG_AP
void MESSAGES::debug_array_print (const gdouble *array, const gint width,
			const gint wth, const char *descriptor, const char *filename)
/*
  Name: Debug Double Array Print Method.
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 04/10/05 21:40
  Description: Prints out an array to the location specified in the filename
			   variable
*/
{
 gint x = 0, y = 0;
 gdouble *array_ptr = const_cast<gdouble *>(array);

	if (stop_print) return;
	std::ofstream debug_print(filename);
	if (!debug_print)
	{	// An error occurred, message user!
		strcpy (message, "Unable to open file ");
		strcat (message, filename);
		strcat (message, " for writing!");
		dialog_message(message, GTK_MESSAGE_WARNING);
		return;
	}
	// Indicate process in status area.
	strcpy (message, "Debug writing array(");
	strcat (message, descriptor);
	strcat (message, ") to ");
	strcat (message, filename);
	common.update_status(message);
	while ( gtk_events_pending() ) gtk_main_iteration();
	// Write the array in Excel format.
	for (y = 0; y != wth; y += width)
	{	// Loop through the image columns.
		for (x = 0; x != width; x++) debug_print << *array_ptr++ << ",";
		debug_print << std::endl;
		if (check_events-- == 0)
		{   // Check for events only on countdown.
			while (gtk_events_pending()) gtk_main_iteration();
			check_events = CHECK_COUNT;
		}
	}
	debug_print.flush();
	debug_print.close();
}

// -----------------------------------------------------------------------------
void MESSAGES::debug_array_print (const GimpVector4 *array, const gint count,
								const char *descriptor, const char *filename)
/*
  Name: Debug Gimp 4-Vector Array Print Method.
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 04/10/05 21:40
  Description: Prints out an array to the location specified in the filename
			   variable.
*/
{
 gint i = 0;
 GimpVector4 *array_ptr = const_cast<GimpVector4 *>(array);

	if (stop_print) return;
	std::ofstream debug_print(filename);
	if (!debug_print)
	{	// An error occurred, message user!
		strcpy (message, "Unable to open file ");
		strcat (message, filename);
		strcat (message, " for writing!");
		dialog_message(message, GTK_MESSAGE_WARNING);
		return;
	}
	// Indicate process in status area.
	strcpy (message, "Debug writing array(");
	strcat (message, descriptor);
	strcat (message, ") to ");
	strcat (message, filename);
	common.update_status(message);
	while ( gtk_events_pending() ) gtk_main_iteration();
	// Write the array in column format.
	for (i = 0; i != count; i++)
	{
		debug_print << array_ptr->x << ",";
		debug_print << array_ptr->y << ",";
		debug_print << array_ptr->z << std::endl;
		array_ptr++;
		if (check_events-- == 0)
		{   // Check for events only on countdown.
			while (gtk_events_pending()) gtk_main_iteration();
			check_events = CHECK_COUNT;
		}
	}
	debug_print.flush();
	debug_print.close();
}
#endif
// -----------------------------------------------------------------------------
void MESSAGES::dialog_message (const gchar *text_message,
									 const GtkMessageType message_type)
/*
  Name: Generate Dialog Message Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:53
  Description: Generates a temporary message dialog box to flag the user with
			   the passed text message.
*/
{
 GtkWidget *dialog;
 
	dialog = gtk_message_dialog_new ( GTK_WINDOW(SFSint.SFSdialog),
									GTK_DIALOG_MODAL, message_type,
									GTK_BUTTONS_OK, "%s",
									text_message
	);
	gtk_widget_grab_focus (dialog);
	gtk_dialog_run (GTK_DIALOG (dialog));
	gtk_widget_destroy (dialog);
	gtk_widget_queue_draw (SFSint.SFSdialog);
}

// -----------------------------------------------------------------------------
void MESSAGES::new_error ( gchar *error_text, gint number )
{
	// Pop out if user has selected to ignore memory errors.
	if (!SFSint.app_button[IGNORE_MEMORY]) return;

	strcpy (message, error_text);
	strcat (message, "Attempting to create new array of ");
	attach_number("-%12d", number);
	strcat (message, " elements!");
	gimp_message (message);
}

// -----------------------------------------------------------------------------
void MESSAGES::rtrim (gchar *str)
/*
  Name: Right Trim String Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:56
  Description: Trims trailing spaces from the passed string by converting the
			   first space character to a null character.
*/
{
	gchar *ptr;

	if ( (ptr = strchr (str, ' ')) != NULL ) *ptr = '\0';
}

// -----------------------------------------------------------------------------
void MESSAGES::sort_error (gint element, gint element_cnt, gint limit,
						gint xlimit, gint ylimit, gint amount, gdouble x,
						gdouble y, gdouble z, gdouble w)
/*
  Name: Annunciate Sort Algorithim Error
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 08/10/05 15:40
  Description: Flags the user that an overrange index value was given to the
  			sorted vector array.
*/
{
	if ( !SFSint.app_button[IGNORE_MEMORY] || sort_error_count != 0 ) return;

	strcpy (message, "Non-Fatal OVER-RANGE WARNING\nin VECTOR SORT algorithm!\n");
	strcat (message, "Element index: ");
	text.attach_number("%-12d", element);
	strcat (message, " of ");
	text.attach_number("%-12d", element_cnt);
	strcat (message, ".\nArray limit: ");
	text.attach_number("%-12d", limit);
	strcat (message, "\nAttempt to access address: ");
	text.attach_number("%-12d", amount);
	strcat (message, "\nSorted array limits: [");
	text.attach_number("%-12d", xlimit);
	strcat (message, "][");
	text.attach_number("%-12d", ylimit);
	strcat (message, "].");
	strcat (message, "\nAt vector element: ( ");
	text.attach_number("%-4G", x);
	strcat (message, ", ");
	text.attach_number("%-4G", y);
	strcat (message, ", ");
	text.attach_number("%-12G", z);
	strcat (message, ", ");
	text.attach_number("%-12G", w);
	strcat (message, " ).\n");
	strcat (message, "Try to change viewer azimuth or angle to correct.");

	gimp_message (message);
	// Handle events.
	while (gtk_events_pending()) gtk_main_iteration();
}

// -----------------------------------------------------------------------------
void MESSAGES::wait_seconds (const gdouble t)
/*
  Name: Wait Seconds Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:58
  Description: Wait for a given amount of time doing nothing other than checking
  			   the clock and looking for pending events.
*/
{	
	clock_t start;
	clock_t end;
	const gdouble end_time = (gdouble)CLOCKS_PER_SEC * t;
	
	start = clock();
	end = start + (glong)end_time;
	while (end > clock())
	{	// While we wait, handle events.
		while (gtk_events_pending()) gtk_main_iteration();
	}
}
