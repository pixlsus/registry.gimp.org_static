/*  ShapeFS Top Level Source File.
	A GIMP Plug-in to render shape from shading.
	(c) 2003, Alfred P. Reaud
	Created: April 1, 2003
	Current: October 20, 2005
	Version: 1.2.0.0

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "shapefs.h"
#include "gtk/gtkdialog.h"

GIMP_SFS shapefs;

extern COMMON_ALGORITHM common;	// Common algorithms.
extern HORN_ALGORITHM horn;		// Horm algorithm coding.
extern MESSAGES text;	// Declare text static so that all portions can use it.

static void Plugin_Query (void);
static void Plugin_Run (gchar *, gint, GimpParam *, gint *, GimpParam ** );
static void SFS_cancel_callback (GtkWidget *, gpointer);
static void SFS_done_callback (GtkWidget *, gpointer);
static void SFS_start_callback (GtkWidget *, gpointer);
static gboolean SFS_pulse_bar_timer_callback (gpointer *);

#ifdef G_OS_WIN32
	static void SFS_watchdog_callback (HWND, guint, guint, gulong);
#else
	static gboolean SFS_watchdog_callback (void);
#endif

static GimpPlugInInfo PLUG_IN_INFO = { // Set PLUG_IN_INFO
	(GimpInitProc) NULL,			// init_proc
	(GimpQuitProc) NULL,			// quit_proc
	(GimpQueryProc) Plugin_Query,	// query_proc
	(GimpRunProc) Plugin_Run,		// run_proc
};

static GimpParamDef params[] = {
	{ GIMP_PDB_INT32, "run_mode", "Interactive" },
	{ GIMP_PDB_IMAGE, "image_id", "(unused)" },
	{ GIMP_PDB_DRAWABLE, "drawable_id", "Input drawable" }
};

static GimpParamDef return_vals[] = {
	{ GIMP_PDB_IMAGE, "new_image", "Output image" },
	{ GIMP_PDB_IMAGE, "new_layer", "Output layer" },
};

// Global user parameters and control semaphores.
SFSAntiBounce SFSMab = {false};		// Movie anti-bounce structure.
SFSControls SFSctrl = {NULL};		// GtkObject storage structure.
SFSMemory SFSMem = {false};			// Scope memory semaphore.
SFSSemaphore SFSint = { false };	// Control semaphores.
SFSValues SFSVal = { false };		// Values of user inputs at OK.
SFSValues SFSLast_Val = { false };	// Values of last user inputs at OK.

static gchar file_name_buffer[FILENAME_BUFF_SIZE];
static GimpRGB			foreground_color;

#ifdef DEBUG
// Debug variables.
static gboolean d_l = true;		// Debug loop exit test flag.
static gint32 d_v = 0x55AA55AA; // Dummy variable to allow the debug routine something to do.
#endif

MAIN()

// -----------------------------------------------------------------------------
static void Plugin_Query (void)
/*
  Name: Plug-in Query Function
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 30/09/05 17:03
  Description: Performs the plug-in query function called by GIMP on its
				initialization.
*/
{
	const int nparams = sizeof (params) / sizeof (params[0]);
	const int nreturn_vals = sizeof (return_vals) / sizeof (return_vals[0]);
	
	gimp_install_procedure ( "shapefs",
		"Shape From Shading",
		"Generates shape from shading, currently only applicable to greyscale images.",
		"Alfred P. Reaud, <alreaud@yahoo.com>, http://www.geocities.com/alreaud/",
		"Copyright 2003-2005 by Alfred P. Reaud, Happy Cat Technologies",
		"1.2.0.0 - Thursday, September 29, 2005",
		"<Image>/Filters/Map/Shape From Shading...",
		"GRAY",
		GIMP_PLUGIN,
		nparams, nreturn_vals,
		params, return_vals
	);
}

// -----------------------------------------------------------------------------
static void Plugin_Run
( gchar *procedure_name, gint parameter_count, GimpParam *parameters, 
gint *number_of_ret_vals, GimpParam **return_values )
/*
  Name: Plug-in Run Function
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 30/09/05 17:04
  Description: Performs the plug-in run function, called by GIMP when the
				plug-in is started.  This function also activates a crash
				watchdog timer and saves the user configuration in shapefs.ini,
				usually in the bin directory of GIMP.
*/
{
	static GimpParam values[3];
	GimpRunMode run_mode;
	GimpPDBStatusType status = GIMP_PDB_SUCCESS;

	gint32 image_ID;
	
#ifdef DEBUG
	do
	{	// Debug wait here.
		shapefs.d_c();
	// Make d_l false to continue with program flow.
	} while (d_l == true);	// Make this variable false to continue with program flow.
	d_l = true;
#endif

	gimp_message_set_handler (GIMP_MESSAGE_BOX);
	run_mode = (GimpRunMode)parameters[0].data.d_int32;
	SFSint.not_first_pass = false;
	SFSint.status = SFS_CANCEL;

	//  Get the specified drawable
	shapefs.drawable = gimp_drawable_get (parameters[2].data.d_drawable);
	image_ID = parameters[1].data.d_image;

	//  Make sure that the drawable is Grey color
	if (gimp_drawable_is_gray (shapefs.drawable->drawable_id))
	{	// Awake the watchdog!
#ifdef G_OS_WIN32
		SFSint.watchdog = SetTimer (NULL, 0, 500, (TIMERPROC)SFS_watchdog_callback);
#else
		SFSint.watchdog = gtk_timeout_add (500, (GtkFunction)SFS_watchdog_callback, NULL);
#endif
		SFSint.watchdog_awake = true;

		gimp_tile_cache_ntiles (2 * (shapefs.drawable->width / gimp_tile_width () + 1));
		shapefs.Plugin_Dialog(procedure_name);

		if (run_mode != GIMP_RUN_NONINTERACTIVE) gimp_displays_flush ();

		switch (SFSint.status)
		{
			case SFS_CANCEL :
				status = GIMP_PDB_CANCEL;
				break;
			case SFS_OK :
				status = GIMP_PDB_SUCCESS;
				break;
			default :
				status = GIMP_PDB_EXECUTION_ERROR;
				break;
		}
	}
	else
	{
		status = GIMP_PDB_CALLING_ERROR;
	}

	SFSint.elev_done = false;		// So that we can actually clean out the declarations.
	if (SFSint.watchdog_awake)
	{	// Check if the watchdog is still awake!
#ifdef G_OS_WIN32
		if (!KillTimer (NULL, SFSint.watchdog)) gimp_message ("Couldn't kill the watchdog!");
		else SFSint.watchdog_awake = false;
#else
		gtk_timeout_remove (SFSint.watchdog);
		SFSint.watchdog_awake = false;
#endif
	}
	*number_of_ret_vals = 2;
	*return_values = values;
	values[0].type = GIMP_PDB_STATUS;
	values[0].data.d_status = status;
	values[1].type = GIMP_PDB_IMAGE;
	values[1].data.d_image = SFSint.output_display;

	gimp_drawable_detach (shapefs.drawable);
	std::ofstream init_file(INIT_FILENAME);
	if (init_file)
	{   // Save the current user configuration.
		gint i, line_size;
		for (i = 0; i != ALGO_BUTTONS; i++) init_file << SFSint.algo_button[i] << std::endl;
		for (i = 0; i != APP_BUTTONS; i++) init_file << SFSint.app_button[i] << std::endl;
		for (i = 0; i != MOVIE_BUTTONS; i++) init_file << SFSint.movie_button[i] << std::endl;
		init_file << SFSVal.Sun_Azimuth << std::endl;
		init_file << SFSVal.Emission_Angle << std::endl;
		init_file << SFSVal.Incidence_Angle << std::endl;
		init_file << SFSVal.Phase_Angle << std::endl;
		init_file << SFSVal.Pixel_Width << std::endl;
		init_file << SFSVal.Pixel_Aspect_Ratio << std::endl;
		init_file << SFSVal.Slant_Distance << std::endl;
		init_file << SFSVal.Scale << std::endl;
		if (SFSint.movie)
		{   // Parse the movie axis.
			switch (SFSint.movie_axis)
			{	// Restore entry angle value to modified axis.
				case XAXIS :
					SFSVal.Viewer_Xaxis = SFSint.orig_axis_value.x;
					break;
				case YAXIS :
					SFSVal.Viewer_Yaxis = SFSint.orig_axis_value.y;
					break;
				case ZAXIS :
				default :
					SFSVal.Viewer_Zaxis = SFSint.orig_axis_value.z;
			}
		}
		init_file << SFSVal.Viewer_Xaxis << std::endl;
		init_file << SFSVal.Viewer_Yaxis << std::endl;
		init_file << SFSVal.Viewer_Zaxis << std::endl;
		init_file << SFSVal.Focal_Distance << std::endl;
		init_file << SFSVal.Output_Size << std::endl;
		init_file << SFSVal.Movie_Start << std::endl;
		init_file << SFSVal.Movie_End << std::endl;
		init_file << SFSVal.Movie_Frame_Count << std::endl;
		line_size = strlen (SFSint.heightmap_filename);
		init_file.write(SFSint.heightmap_filename, line_size);
		init_file << std::endl;
		init_file.flush();
		init_file.close();
	}
	common.cleanup();	// Cleanup any allocated arrays that are still declared.
}

// -----------------------------------------------------------------------------
static void SFS_cancel_callback(GtkWidget *widget, gpointer data)
/*
  Name: Dialog Cancel Call Back
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 22/09/05 16:47
  Description: Processes the cancel button on command from user.  Destroies
					the current drawing result of the plug-in.
*/
{
	SFSint.cancel = true;
	// Check to see if we're deleting images.
	if (SFSint.app_button[DELETE_IMAGES]) {
		if (SFSint.output_display)
		{	// Check for an output image and delete.
			gimp_display_delete (SFSint.output_display);
			SFSint.output_display = 0;
		}
		if (SFSint.movie_image)
		{	// Check for a movie image and delete.
			if (!gimp_display_delete (SFSint.movie_image)) {
				gtk_label_set_text (GTK_LABEL(SFSint.status_messages), "Couldn't delete movie image!" );
				text.wait_seconds (2.0);
			}
			else SFSint.movie_image = 0;
		}
	}
	else
	{	// Detatch the drawables.
		if (SFSint.output_drawable) gimp_drawable_detach (SFSint.output_drawable);
		if (SFSint.movie_drawable) gimp_drawable_detach (SFSint.movie_drawable);
	}
	// Kill the user interface widget.
	SFSint.status = SFS_CANCEL;
	gtk_widget_destroy(GTK_WIDGET(data));
	gtk_main_quit();
}

// -----------------------------------------------------------------------------
static void SFS_delete_callback(GtkWidget *widget, gpointer data)
/*
  Name: Window Delete Call Back
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 22/09/05 16:11
  Description: Callback processing for the main window close command.
*/
{
	SFS_cancel_callback(widget, data);
}

// -----------------------------------------------------------------------------
static void SFS_destroy_callback(GtkWidget *widget, gpointer data)
/*
  Name: Window Destroy Call Back
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 22/09/05 15:36
  Description: Callback processing for the main window destroy command.
*/
{
	gtk_main_quit ();
}

// -----------------------------------------------------------------------------
static void SFS_done_callback(GtkWidget *widget, gpointer data)
/*
  Name: Dialog Done Call Back
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 22/09/05 16:12
  Description: Processes the done button on command from user.  Does not destroy
					the current drawing result of the plug-in.
*/
{	// We're done, so don't delete anything!
	SFSint.done = true;
	if (SFSint.output_drawable) gimp_drawable_detach (SFSint.output_drawable);
	if (SFSint.movie_drawable) gimp_drawable_detach (SFSint.movie_drawable);
	// Kill the user interface widget.
	gtk_widget_destroy(GTK_WIDGET(data));
	gtk_main_quit();
}

// -----------------------------------------------------------------------------
static void SFS_start_callback(GtkWidget *widget, gpointer data)
/*
  Name:  Start Button Callback Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud, Happy Cat Technologies
  Date: 17/09/05 17:08
  Description: Processes the Ok button, including movie generation control.
*/
{
	gchar	message[20] = { '\0' };
	gchar	frame_number[5] =  { '\0' };
	gint	i;
	const gint width = (gint)(SFSVal.Output_Size * SFSVal.Scale);
	gdouble		angle = 0.0, angle_delta = 0.0;
	gint32		image_dest = 0, layer = 0, float_sel = 0;
	GimpRGB		foreground_black = {0.0, 0.0, 0.0, 0.0};
	GimpDrawable	*movie = NULL;

#ifdef DEBUG
	SFSint.process_count_calls = 0;
	SFSint.render_count_calls = 0;
#endif

	SFSint.height_map_saved = false;
	
	if (!SFSint.pulse_bar)
	{  // Only create the widget if it hasn't been.
		SFSint.pulse_bar = gtk_progress_bar_new ();
		gtk_table_attach_defaults (GTK_TABLE(SFSint.pulse_bar_table),
							SFSint.pulse_bar, 0, 1, 3, 4);
		gtk_progress_bar_set_bar_style (GTK_PROGRESS_BAR(SFSint.pulse_bar),
							GTK_PROGRESS_CONTINUOUS);
		gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR(SFSint.pulse_bar), 0.0);
		gtk_progress_bar_set_pulse_step (GTK_PROGRESS_BAR(SFSint.pulse_bar), 0.01);
	}
	SFSint.pulse_bar_enable = true;
	g_timeout_add (PULSE_BAR_TIMEOUT, (GSourceFunc)SFS_pulse_bar_timer_callback,
						&SFSint.pulse_bar_enable);
	gtk_widget_show (SFSint.pulse_bar);
	// Initialize progress.
	SFSint.progress_delta = 1.0 / (HORN_PROCESS_COUNT - 1.0);
	SFSint.progress_value = -SFSint.progress_delta;
	// Set variables.
	SFSint.status = SFS_UNKNOWN;
	SFSint.movie = false;
	SFSint.cancel = false;
	SFSint.done = false;
	for (i = 0; i != ALGO_BUTTONS; i++) {
		if (SFSint.algo_button[i] == true) {
			SFSVal.Algorithm = (SFSAlgorithms)i;
			break;
		}
	}
#ifdef DEBUG	// Reset to MOC M0203051 parameters if in debug mode.
	if (!SFSint.init_file_found)
	{   // Only load if no initialization file is present.
		gtk_spin_button_set_value (GTK_SPIN_BUTTON(SFSctrl.Sun_Azimuth), 14.12);
		gtk_spin_button_set_value (GTK_SPIN_BUTTON(SFSctrl.Phase_Angle), 39.25);
		gtk_spin_button_set_value (GTK_SPIN_BUTTON(SFSctrl.Pixel_Width), 5.78);
	}
#endif
	SFSVal.Sun_Azimuth = gtk_spin_button_get_value (GTK_SPIN_BUTTON(SFSctrl.Sun_Azimuth));
	SFSVal.Emission_Angle = gtk_spin_button_get_value (GTK_SPIN_BUTTON(SFSctrl.Emission_Angle));
	SFSVal.Incidence_Angle = gtk_spin_button_get_value (GTK_SPIN_BUTTON(SFSctrl.Incidence_Angle));
	SFSVal.Phase_Angle = gtk_spin_button_get_value (GTK_SPIN_BUTTON(SFSctrl.Phase_Angle));
	SFSVal.Pixel_Width = gtk_spin_button_get_value (GTK_SPIN_BUTTON(SFSctrl.Pixel_Width));
	SFSVal.Pixel_Aspect_Ratio = gtk_spin_button_get_value (GTK_SPIN_BUTTON(SFSctrl.Pixel_Aspect_Ratio));
	SFSVal.Slant_Distance = gtk_spin_button_get_value (GTK_SPIN_BUTTON(SFSctrl.Slant_Distance));
	SFSint.heightmap_filename = strcpy(SFSint.heightmap_filename,
 		const_cast<gchar *>(gtk_entry_get_text( GTK_ENTRY(SFSint.save_height_map_widget) )));

	// Lose images or detatch as required.
	if ( SFSint.not_first_pass && SFSint.app_button[DELETE_IMAGES])
	{
		if (SFSint.output_display)
		{
			gimp_display_delete (SFSint.output_display);
			SFSint.output_display = 0;
		}
		if (SFSint.movie_image)
		{	// Check for a movie image and delete.
			if (!gimp_display_delete (SFSint.movie_image))
				common.update_status("Couldn't delete movie image!");
			SFSint.movie_image = 0;
		}
	}
	else
	{
		if (SFSint.status == SFS_OK)
		{
			gimp_drawable_detach (SFSint.output_drawable);
			if (SFSint.movie) gimp_drawable_detach (SFSint.movie_drawable);
		}
	}
	// Check that we still hav the same value.
	if ( SFSint.elev_done )
	{
		SFSint.elev_done = false;
		if ( FP_EQ(SFSVal.Sun_Azimuth, SFSLast_Val.Sun_Azimuth) )
			if ( FP_EQ(SFSVal.Phase_Angle, SFSLast_Val.Phase_Angle) )
				if ( FP_EQ(SFSVal.Pixel_Width, SFSLast_Val.Pixel_Width) )
					if (SFSint.app_button[DRAW_AXES] == SFSint.draw_axes_state)
						SFSint.elev_done = true;
	}

	// Check if we're doing a movie!
	if ( SFSint.app_button[GEN_MOVIE] )
	{	// Initialize variables.
		SFSint.not_first_movie_pass = false;
		SFSint.movie = true;
		if ( FP_EQ(SFSVal.Movie_Start, SFSVal.Movie_End) )
		{
			shapefs.movie_error ("MOVIE: Movie start and end angles can't be the same!");
			common.update_status("Please change the value of the movie start and end angles!");
			SFSint.pulse_bar_enable = false;
			if (SFSint.pulse_bar) gtk_widget_destroy (SFSint.pulse_bar);
			return;
		}
		// Decode axis selection button.
		for (i = 0; i != MOVIE_BUTTONS; i++)
		{
			if (SFSint.movie_button[i])
			{
				SFSint.movie_axis = (SFSMovie)i;
				SFSint.movie = true;
				break;
			}
		}
		switch (SFSint.movie_axis)
		{	// Save entry axis value.
			case XAXIS :
				SFSint.orig_axis_value.x = SFSVal.Viewer_Xaxis;
				break;
			case YAXIS :
				SFSint.orig_axis_value.y = SFSVal.Viewer_Yaxis;
				break;
			case ZAXIS :
			default :
				SFSint.orig_axis_value.z = SFSVal.Viewer_Zaxis;
		}
		angle = SFSVal.Movie_Start;
		angle_delta = (SFSVal.Movie_End - SFSVal.Movie_Start) / SFSVal.Movie_Frame_Count;
		if (SFSint.elev_done)
		{	// Set the progress delta to correspond to the movie frames times
			// the count of processes in the 3D section.
			SFSint.progress_delta = 1.0 / ((MOVIE_PROCESS_COUNT * SFSVal.Movie_Frame_Count)
								  + SFSVal.Movie_Frame_Count - 1.0);
		}
		else
		{   // Add the process count in the Horn algorithm to the value.
			SFSint.progress_delta = 1.0 /
				( (MOVIE_PROCESS_COUNT * SFSVal.Movie_Frame_Count)
									  + SFSVal.Movie_Frame_Count
									  + HORN_MOVIE_PROCESS_COUNT - 1.5 );
		}
		// Reset the progress bar to insure that a changed delta has no effect.
		SFSint.progress_value = -(SFSint.progress_delta);
		common.update_status("Starting movie...");
		// Loop for the angles given.
		for ( i = 0; i != (gint)SFSVal.Movie_Frame_Count; i++)
		{
			// Check for pending events. Don't move these around, they
			// generate errors.
			while (gtk_events_pending()) gtk_main_iteration();

			// Have we cancel'd?
			if (SFSint.cancel || SFSint.done)
			{
				SFSint.pulse_bar_enable = false;
				return;
			}
			// Select which axis to vary and create the layer label string.
			switch (SFSint.movie_axis)
			{
				case XAXIS :
					SFSVal.Viewer_Xaxis = angle;
					gtk_adjustment_set_value (GTK_ADJUSTMENT(SFSctrl.Viewer_Xaxis),
								SFSVal.Viewer_Xaxis);
					strcpy( message, "X-Axis" );
					break;
				case YAXIS :
					SFSVal.Viewer_Yaxis = angle;
					gtk_adjustment_set_value (GTK_ADJUSTMENT(SFSctrl.Viewer_Yaxis),
								SFSVal.Viewer_Yaxis);
					strcpy( message, "Y-Axis" );
					break;
				case ZAXIS :
				default :
					SFSVal.Viewer_Zaxis = angle;
					gtk_adjustment_set_value (GTK_ADJUSTMENT(SFSctrl.Viewer_Zaxis),
								SFSVal.Viewer_Zaxis);
					strcpy( message, "Z-Axis" );
			}
			strcat( message, " Frame: " );
			// Append frame number to label string.
			strncpy( frame_number, "\0", 5);
			sprintf( frame_number, "%i", i + 1 );
			strcat( message, frame_number );

			// Try and draw it!  Will need case statement here when other
			// algorithms are implemented. 
			if ( shapefs.SFS_Do (shapefs.drawable) )
			{
				 SFSint.not_first_pass = true;
				// Drop out if canceled.
				if (SFSint.cancel)
				{
					SFSint.pulse_bar_enable = false;
					return;
				}
				if (!SFSint.not_first_movie_pass)
				{
					// Not first pass, create a new drawable and copy this one to it.
					SFSint.not_first_movie_pass = true;
					image_dest = gimp_image_new (width, width, GIMP_GRAY);
					SFSint.movie_image = gimp_display_new (image_dest);
				}
				layer = gimp_layer_new (image_dest, NULL, width, width,
										GIMP_GRAYA_IMAGE, 100, GIMP_NORMAL_MODE);
				g_assert( gimp_image_add_layer(image_dest, layer, -1) );
				movie = gimp_drawable_get(layer);
				SFSint.movie_drawable = movie;
				// Save the current foreground color and then force it to black.
				//gimp_palette_get_foreground (&foreground.red, &foreground.green, &foreground.blue);
				gimp_palette_get_foreground (&foreground_color);
				gimp_palette_set_foreground (&foreground_black);
				gimp_drawable_fill (movie->drawable_id, GIMP_FOREGROUND_FILL);
				// Restore the original foreground color.
				gimp_palette_set_foreground (&foreground_color);
				g_assert( gimp_selection_all (SFSint.output_image) );
				g_assert( gimp_edit_copy (SFSint.output_drawable->drawable_id) );
				float_sel = gimp_edit_paste (movie->drawable_id, true);

				if (!gimp_floating_sel_to_layer (float_sel))
				{
					shapefs.movie_error ("MOVIE: Unable to transform the floating selection into a layer!");
					SFSint.pulse_bar_enable = false;
					if (SFSint.pulse_bar) gtk_widget_destroy (SFSint.pulse_bar);
					return;
				}
				layer = gimp_image_get_active_layer (image_dest);
				g_assert( gimp_layer_translate (layer, SFSMab.col_adj, SFSMab.row_adj) );
				g_assert( gimp_layer_resize_to_image_size (layer) );
				layer = gimp_image_merge_down (image_dest, layer,
													GIMP_EXPAND_AS_NECESSARY);
				layer = gimp_image_get_active_layer (image_dest);
				if (!gimp_drawable_set_name(layer, message))
				{
					shapefs.movie_error ("MOVIE: Unable to label layer!");
					SFSint.pulse_bar_enable = false;
					return;
				}

				// Check for pending events. Don't move these around, they
				// generate errors.
				while (gtk_events_pending()) gtk_main_iteration();

				gimp_drawable_flush (movie);
				g_assert( gimp_displays_flush () );
				if (gimp_display_delete (SFSint.output_display))
				{
					SFSint.output_display = 0;
					SFSint.output_drawable = NULL;
				}
			}
			else
			{	// We failed drawing something!
				if (!SFSint.cancel) shapefs.movie_error("MOVIE: Loop terminated due to error!");
				SFSint.pulse_bar_enable = false;
				return;
			}
			common.update_status("Computing movie...");
			angle += angle_delta;
#ifdef DEBUG
			if (SFSMem.debug_display_id != -1 ) {
				gimp_display_delete (SFSMem.debug_display_id);
				SFSMem.debug_display_id = -1;
			}
#endif
		}
		// Pop out if we canceled so we don't draw image.
		if (SFSint.cancel)
		{
			SFSint.pulse_bar_enable = false;
			return;
		}
		gimp_drawable_flush (movie);
		gimp_drawable_merge_shadow (movie->drawable_id, false);
		gimp_drawable_update (movie->drawable_id, 0, 0, width, width);
		gimp_drawable_flush (movie);
		gimp_displays_flush ();
		// Clear out the output variables.
		SFSint.output_display = 0;
		SFSint.output_drawable = NULL;
		SFSint.status = SFS_OK;
		switch (SFSint.movie_axis)
		{	// Restore entry angle value to modified axis.
			case XAXIS :
				SFSVal.Viewer_Xaxis = SFSint.orig_axis_value.x;
				gtk_adjustment_set_value (GTK_ADJUSTMENT(SFSctrl.Viewer_Xaxis),
							SFSVal.Viewer_Xaxis);
				break;
			case YAXIS :
				SFSVal.Viewer_Yaxis = SFSint.orig_axis_value.y;
				gtk_adjustment_set_value (GTK_ADJUSTMENT(SFSctrl.Viewer_Yaxis),
							SFSVal.Viewer_Yaxis);
				break;
			case ZAXIS :
			default :
				SFSVal.Viewer_Zaxis = SFSint.orig_axis_value.z;
				gtk_adjustment_set_value (GTK_ADJUSTMENT(SFSctrl.Viewer_Zaxis),
							SFSVal.Viewer_Zaxis);
		}
		common.update_status("Movie done!");
	}
	else
	{	// Draw it!
		if ( shapefs.SFS_Do (shapefs.drawable) )
		{
			SFSint.not_first_pass = true;
			SFSint.output_display = gimp_display_new (SFSint.output_image);
			gimp_displays_flush ();
		}
#ifdef DEBUG
		if (SFSMem.debug_display_id != -1 )
		{
			gimp_display_delete (SFSMem.debug_display_id);
			SFSMem.debug_display_id = -1;
		}
#endif
		if (SFSint.cancel)
		{
			SFSint.pulse_bar_enable = false;
			return;
		}
	}
	SFSLast_Val.Sun_Azimuth = SFSVal.Sun_Azimuth;
	SFSLast_Val.Phase_Angle = SFSVal.Phase_Angle;
	SFSLast_Val.Pixel_Width = SFSVal.Pixel_Width;
	SFSint.draw_axes_state = SFSint.app_button[DRAW_AXES];
	SFSint.pulse_bar_enable = false;
	gtk_widget_hide (SFSint.pulse_bar);
}

// -----------------------------------------------------------------------------
static gboolean SFS_pulse_bar_timer_callback (gpointer *data)
/*
  Name: Pulse Bar Timer Callback
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 28/09/05 22:10
  Description:  Pulses the timer until the data is false.
*/
{
	if (SFSint.cancel) return false;
	gtk_progress_bar_pulse ( GTK_PROGRESS_BAR(SFSint.pulse_bar) );
	if (!(*data) ) return false;
	else return true;
}
// -----------------------------------------------------------------------------
#ifdef G_OS_WIN32	// Windows specific watchdog.
static void SFS_watchdog_callback (HWND winhandle, guint msg, guint id, 
											gulong current_time )
/*
  Name: Plug-in Crash Watchdog Function
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:09
  Description:  Attempts to insure that that if the plug-in crashes it doesn't
				stay as a zombie process.
*/
{	// Checks to see that GIMP is still active, and terminates if not.
	static gint watchdog = 0;
	static gboolean not_first_pass = false;
	static char buffer[26] = { '\0' };
	
	watchdog++;
	
	if (watchdog > 2)
	{
		KillTimer (NULL, SFSint.watchdog);
		SFSint.watchdog_awake = false;
		// This may kill us if GTK is down!
		common.update_status("Watchdog doesn't detect GIMP!");
		text.wait_seconds(3.0);
		SFSint.elev_done = false;
		common.cleanup();
		gtk_exit ( false );	// First try the easy way.
		FatalExit ( -1 );	// Then try the hard way.
		return;
	}
	if (!not_first_pass)
	{	// Save the version the first time.
		not_first_pass = true;
		strcpy (buffer, gimp_version());
		watchdog = 0;
	}
	else
	{	// Check that GIMP returns the same version always.
		if ( strcmp(buffer, gimp_version()) == 0 ) watchdog = 0;
		else
		{
			KillTimer (NULL, SFSint.watchdog);
			SFSint.watchdog_awake = false;
			// This may kill us if GTK is down!
			common.update_status("Watchdog doesn't verify GIMP!");
			text.wait_seconds(3.0);
			SFSint.elev_done = false;
			common.cleanup();
			gtk_exit ( false );	// First try the easy way.
			FatalExit ( -1 );	// Then try the hard way.
		}
	}
	return;
}
#else		// GTK watchdog for Linux/Unix.
static gboolean SFS_watchdog_callback (void)
{
	static gint watchdog = 0;
	static gboolean not_first_pass = false;
	static char buffer[26] = { '\0' };
	
	watchdog++;
	
	if (watchdog > 2)
	{
		gtk_timeout_remove (SFSint.watchdog);
		SFSint.watchdog_awake = false;
		// This may kill us if GTK is down!
		common.update_status("Watchdog doesn't detect GIMP!");
		text.wait_seconds(3.0);
		SFSint.elev_done = false;
		common.cleanup();
		gtk_exit ( false );	// First try the easy way.
		return false;
	}
	if (!not_first_pass)
	{	// Save the version the first time.
		not_first_pass = true;
		strcpy (buffer, gimp_version());
		watchdog = 0;
	}
	else
	{	// Check that GIMP returns the same version always.
		if ( strcmp(buffer, gimp_version()) == 0 ) watchdog = 0;
		else
		{
			gtk_timeout_remove (SFSint.watchdog);
			SFSint.watchdog_awake = false;
			// This may kill us if GTK is down!
			common.update_status("Watchdog doesn't verify GIMP!");
			text.wait_seconds(3.0);
			SFSint.elev_done = false;
			common.cleanup();
			gtk_exit ( false );	// First try the easy way.
			return false;
		}
	}
	return true;
}
#endif
// -----------------------------------------------------------------------------
#ifdef DEBUG
void GIMP_SFS::d_c (void)
/*
  Name: Debug Locking Loop Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:13
  Description:	If DEBUG is defined, will loop in this function forever until
  				attached by the debugger and the value d_l set to false. This is
  				done because this is not a stand alone executable, but is
  				actually a thread of GIMP.
*/
{
	d_v = ~d_v;	// Just something to do.
}
#endif
// -----------------------------------------------------------------------------
GtkWidget* GIMP_SFS::SFS_frame_new_in_box (
	const gchar *framename, GtkWidget *box, const gboolean expand, const gboolean fill)
/*
  Name: New Frame in Box Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:14
  Description: Creates a frame widget in a box widget.  Hacked shamelessly whole
  				from yeti_frame_new_in_box in plasma2.c (v2.2)!
Much thanks to Stephen Norris and Yeti (David Necas) for their very instructive
Gimp plug-in plasma2 at http://trific.ath.cx/software/gimp-plugins/plasma2/
*/
{
	GtkWidget *frame;

	frame = gtk_frame_new(framename);
	gtk_frame_set_shadow_type(GTK_FRAME(frame), GTK_SHADOW_ETCHED_IN);
	gtk_box_pack_start(GTK_BOX(box), frame, expand, fill, 0);
	gtk_widget_show(frame);

return frame;
}

// -----------------------------------------------------------------------------
GtkWidget* GIMP_SFS::SFS_table_new_in_frame (
		const gint cols, const gint rows, GtkWidget *frame)
/*
  Name: New Table in Frame Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:14
  Description: Creates a table widget in a frame widget. Hacked shamelessly whole
  				from yeti_table_new_in_frame in plasma2.c (v2.2)!
Much thanks to Stephen Norris and Yeti (David Necas) for their very instructive
Gimp plug-in plasma2 at http://trific.ath.cx/software/gimp-plugins/plasma2/
*/
{
	GtkWidget *table;
	GtkWidget *align;

	align = gtk_alignment_new(0.5, 0.0, 1.0, 0.0);
	gtk_container_set_border_width(GTK_CONTAINER(align), 0);
	gtk_container_add(GTK_CONTAINER(frame), align);
	gtk_widget_show(align);

	table = gtk_table_new(cols, rows, false);
	gtk_table_set_col_spacings(GTK_TABLE(table), 4);
	gtk_table_set_row_spacings(GTK_TABLE(table), 2);
	gtk_container_set_border_width(GTK_CONTAINER(table), 4);
	gtk_container_add(GTK_CONTAINER(align), table);
	gtk_widget_show(table);

return table;
}

// -----------------------------------------------------------------------------
GtkObject* GIMP_SFS::SFS_scale_entry_new_double (
					const gchar *scalename,
					const gchar *tooltip,
					GtkWidget *table,
					const gint row,
					double *value,
					const double min, const double max,
					const double step, const double page,
					const gint digits)
/*
  Name: New Scale Entry in Table Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:14
  Description: Creates a scale entry widget in a table widget. Hacked shamelessly
  				whole from yeti_scale_entry_new_double in plasma2.c (v2.2)!
Much thanks to Stephen Norris and Yeti (David Necas) for their very instructive
Gimp plug-in plasma2 at http://trific.ath.cx/software/gimp-plugins/plasma2/
*/
{
 GtkObject *adj;
	
	adj = gimp_scale_entry_new(GTK_TABLE(table), 0, row, scalename, SCALE_WIDTH, 0,
							*value, min, max, step, page, digits,
							true, 0, 0, tooltip, NULL);
	gtk_signal_connect(adj, "value_changed",
						GTK_SIGNAL_FUNC(gimp_double_adjustment_update),
						value);

return adj;
}

// -----------------------------------------------------------------------------
GSList* GIMP_SFS::SFS_radio_button_new_in_table (
					const gchar *rb_name,
					GSList *group,
					const GtkWidget *table,
					const gint col_start, const gint col_end,
					const gint row_start, const gint row_end,
					gint *button_store, gboolean active_state,
					GtkTooltips *tips_list, const gchar *tip )
/*
  Name: New Radio Button in Table Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:14
  Description: Creates a radio button widget in a table widget.
*/
{
	GtkWidget *radio_button;
	
	radio_button = gtk_radio_button_new_with_label (group, rb_name);
	group = gtk_radio_button_group (GTK_RADIO_BUTTON (radio_button));
	gtk_table_attach_defaults (GTK_TABLE(const_cast<GtkWidget *>(table)),
								radio_button, col_start, col_end, row_start,
								row_end);
	gtk_signal_connect (GTK_OBJECT (radio_button), "toggled",
				GTK_SIGNAL_FUNC (gimp_toggle_button_update), button_store);
	gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radio_button), active_state);
	*button_store = active_state;
	gtk_tooltips_set_tip (tips_list, radio_button, tip, NULL);
	gtk_widget_show (radio_button);

	return group;
}

// -----------------------------------------------------------------------------
GtkWidget* GIMP_SFS::SFS_spin_button_new_in_table (
					GtkWidget *table,
					GtkObject *adj,
					GtkWidget *label,
					const gdouble rate,
					const guint digits,
					const gint col_start, const gint col_end,
					const gint row_start, const gint row_end,
					GtkTooltips *tips_list, const gchar *tooltip )
/*
  Name: New Spin Button in Table Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:14
  Description: Creates a spin button widget in a table widget. Hacked shamelessly
  				whole from yeti_scale_entry_new_double in plasma2.c (v2.2)!
Much thanks to Stephen Norris and Yeti (David Necas) for their very instructive
Gimp plug-in plasma2 at http://trific.ath.cx/software/gimp-plugins/plasma2/
*/
{
	GtkWidget *widget;

	widget = gtk_spin_button_new (GTK_ADJUSTMENT(adj), rate, digits);
	gtk_spin_button_set_numeric (GTK_SPIN_BUTTON(widget), true);
	gtk_spin_button_set_update_policy (GTK_SPIN_BUTTON(widget), GTK_UPDATE_IF_VALID);
	gtk_table_attach_defaults (GTK_TABLE(table), label,
								col_start - 1, col_end - 1,
								row_start, row_end);
	gtk_table_attach_defaults (GTK_TABLE(table), widget,
								col_start, col_end, row_start, row_end);
	gtk_tooltips_set_tip (tips_list, widget, tooltip, NULL);
	gtk_widget_show (widget);

return widget;
}

// -----------------------------------------------------------------------------
GtkWidget* GIMP_SFS::SFS_text_entry_new_in_table (
						const GtkWidget *table, const gchar *initial_text,
						const gint col_start, const gint col_end,
						const gint row_start, const gint row_end,
						GtkTooltips *tips_list, const gchar *tip )
/*
  Name: New Text Entry in Table Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:14
  Description: Creates a text entry widget in a table widget.
*/
{
	GtkWidget *text_widget;
	
	text_widget = gtk_entry_new ();
	gtk_table_attach_defaults(GTK_TABLE(const_cast<GtkWidget *>(table)),
							text_widget, col_start, col_end, row_start,
							row_end);
	// Max length is 65K.
	gtk_entry_set_max_length ( GTK_ENTRY(text_widget), 0);
	// Set default text.
	gtk_entry_set_text ( GTK_ENTRY(text_widget), initial_text);
	gtk_editable_set_editable ( GTK_EDITABLE(text_widget), true);
	gtk_tooltips_set_tip (tips_list, text_widget, tip, NULL);
	gtk_widget_show (text_widget);

	return text_widget;
}

// -----------------------------------------------------------------------------
GtkWidget* GIMP_SFS::SFS_toggle_button_new_in_table (
						const gchar *tb_name,
						const GtkWidget *table,
						const gint col_start, const gint col_end,
						const gint row_start, const gint row_end,
						gint *button_store, gboolean active_state,
						GtkTooltips *tips_list, const gchar *tip )
/*
  Name: New Toggle Button in Table Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:14
  Description: Creates a toggle button (check box) widget in a table widget.
*/
{
	GtkWidget *toggle_button;
	
	toggle_button = gtk_check_button_new_with_label (tb_name);
	gtk_table_attach_defaults(GTK_TABLE(const_cast<GtkWidget *>(table)),
							toggle_button, col_start, col_end, row_start,
							row_end);
	gtk_signal_connect (GTK_OBJECT (toggle_button), "toggled",
				GTK_SIGNAL_FUNC (gimp_toggle_button_update), button_store);
	gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(toggle_button), active_state);
	gtk_tooltips_set_tip (tips_list, toggle_button, tip, NULL);
	gtk_widget_show (toggle_button);

	return toggle_button;
}

// -----------------------------------------------------------------------------
void GIMP_SFS::Plugin_Dialog (gchar *name)
/*
  Name:  Plugin Dialog Construction Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 16/09/05 14:51
  Description: Creates the main dialog window, frames, tables and widgets.
*/
{
	gboolean button_value = false;
	gchar *hm_file_name = file_name_buffer;
	SFSint.heightmap_filename = hm_file_name;
	// Algorithm control variables.
	GtkWidget *acp_hbox = NULL;
	// Ancillary parameters variables.
	GtkWidget *ap_hbox = NULL;
	GtkObject *adj_sunAzimuth = NULL;
	GtkWidget *label_sunAzimuth = NULL;
	GtkObject *adj_emissionAngle = NULL;
	GtkWidget *label_emissionAngle = NULL;
	GtkObject *adj_incidenceAngle = NULL;
	GtkWidget *label_incidenceAngle = NULL;
	GtkObject *adj_phaseAngle = NULL;
	GtkWidget *label_phaseAngle = NULL;
	GtkObject *adj_pixelWidth = NULL;
	GtkWidget *label_pixelWidth = NULL;
	GtkObject *adj_pixelAspectRatio = NULL;
	GtkWidget *label_pixelAspectRatio = NULL;
	GtkObject *adj_slantDistance = NULL;
	GtkWidget *label_slantDistance = NULL;
	// Dialog, Frame, and Table widgets.
	GtkWidget *dialog = NULL;
	GtkWidget *main_hbox = NULL;
	GtkWidget *main_frame = NULL;
	GtkWidget *frame = NULL;
	GtkWidget *main_table = NULL;
	GtkWidget *table = NULL;
	GtkWidget *tdr_hbox = NULL;
	GtkWidget *fc_hbox = NULL;
	GtkWidget *mc_hbox = NULL;
	GtkBox	*dialog_box = NULL;
	// Control and toggle button widgets.
	GtkWidget *start = NULL;
	GtkWidget *done = NULL;
	GtkWidget *tbutton_del_image = NULL;
	GtkWidget *tbutton_ignore_matrix = NULL;
	GtkWidget *tbutton_ignore_mem = NULL;
	GtkWidget *tbutton_axes = NULL;
	GtkWidget *tbutton_create_movie = NULL;
	GtkWidget *tbutton_height_map = NULL;
	GtkWidget *tbutton_hm_type = NULL;
	GtkWidget *tentry_heightmapname = NULL;
	GtkWidget *tbutton_auto_correct = NULL;
	GtkWidget *tbutton_formula = NULL;
	GtkTooltips *button_tips = NULL;
	GtkTooltips *entry_tips = NULL;
	// Progress and Status widgets.
	GtkWidget *label_Progress = NULL;
	GtkWidget *status_hbox = NULL;
	// Groups
	GSList *algo_radb_group = NULL;
	GSList *movie_radb_group = NULL;
	// Load up the initialization file if present.
	std::ifstream init_file(INIT_FILENAME);
	if (init_file)
	{   // It's present! So load all user parameters.
		gint i;
		gchar *ptr = SFSint.heightmap_filename;
		gchar *first_letter = ptr;
		gchar *result_ptr = ptr;
		SFSint.init_file_found = true;
		for (i = 0; i != ALGO_BUTTONS; i++) init_file >> SFSint.algo_button[i];
		for (i = 0; i != APP_BUTTONS; i++) init_file >> SFSint.app_button[i];
		for (i = 0; i != MOVIE_BUTTONS; i++) init_file >> SFSint.movie_button[i];
		init_file >> SFSVal.Sun_Azimuth;
		init_file >> SFSVal.Emission_Angle;
		init_file >> SFSVal.Incidence_Angle;
		init_file >> SFSVal.Phase_Angle;
		init_file >> SFSVal.Pixel_Width;
		init_file >> SFSVal.Pixel_Aspect_Ratio;
		init_file >> SFSVal.Slant_Distance;
		init_file >> SFSVal.Scale;
		init_file >> SFSVal.Viewer_Xaxis;
		init_file >> SFSVal.Viewer_Yaxis;
		init_file >> SFSVal.Viewer_Zaxis;
		init_file >> SFSVal.Focal_Distance;
		init_file >> SFSVal.Output_Size;
		init_file >> SFSVal.Movie_Start;
		init_file >> SFSVal.Movie_End;
		init_file >> SFSVal.Movie_Frame_Count;
		init_file.getline(SFSint.heightmap_filename, FILENAME_BUFF_SIZE, '\0');
		// Strip the newlines newline from the string.
		while ((result_ptr = strtok(ptr, "\n")) != NULL )
		{	// Strip the newline character.
			first_letter = result_ptr;
			ptr = NULL;
				// Check if it is the only one.
			if (strtok(NULL, "\n") == NULL) break;
		}
		strcpy(SFSint.heightmap_filename, first_letter);
		init_file.close();
	}
	else
	{   // No initialization file present.  Set defaults.
		SFSint.init_file_found = false;
		SFSVal.Pixel_Aspect_Ratio = 1.0;
		SFSVal.Focal_Distance = 250.0;
		SFSVal.Slant_Distance = 380.0;

#ifdef DEBUG	// Reset to MOC M0203051 parameters if in debug mode.
		SFSVal.Scale = 2.0;
		SFSVal.Viewer_Xaxis = 30.0;
		SFSVal.Viewer_Yaxis = 31.4;
		SFSVal.Viewer_Zaxis = 0.0;
		SFSVal.Output_Size = 250.0;
		SFSVal.Movie_Start = -180.0;
		SFSVal.Movie_End = 180.0;
		SFSVal.Movie_Frame_Count = 19.0;
#else
		SFSVal.Scale = 1.0;
		SFSVal.Viewer_Xaxis = 0.0;
		SFSVal.Viewer_Yaxis = 0.0;
		SFSVal.Viewer_Zaxis = 0.0;
		SFSVal.Output_Size = 250.0;
		SFSVal.Movie_Start = -90.0;
		SFSVal.Movie_End = 90.0;
		SFSVal.Movie_Frame_Count = 10.0;
#endif
	}
	
	gimp_ui_init (name, false );
	button_tips = gtk_tooltips_new ();
	entry_tips = gtk_tooltips_new ();
	
	// Create top level window.
	SFSint.top_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_resizable (GTK_WINDOW(SFSint.top_window), false);
	gtk_window_set_position (GTK_WINDOW(SFSint.top_window), GTK_WIN_POS_CENTER_ALWAYS);

	// Create dialog widget.
	dialog = gtk_dialog_new_with_buttons( "Shape From Shading - 1.2.0.0",
			GTK_WINDOW(SFSint.top_window), GTK_DIALOG_DESTROY_WITH_PARENT,
			NULL);
	SFSint.SFSdialog = dialog;
	gtk_window_set_resizable (GTK_WINDOW(dialog), false);
	gtk_window_set_transient_for (GTK_WINDOW(dialog), GTK_WINDOW(SFSint.top_window));

	// Create the dialog containers.
	dialog_box = GTK_BOX(GTK_DIALOG(dialog)->vbox);
	main_hbox = gtk_hbox_new(false, 4);
	gtk_container_set_border_width(GTK_CONTAINER(main_hbox), 6);
	gtk_box_pack_start(dialog_box, main_hbox, true, true, 0);

	// Add the main buttons.
	start = gtk_dialog_add_button (GTK_DIALOG(dialog), "START", START_BUTTON);
	SFSint.start_button_handler = g_signal_connect (GTK_OBJECT(start),
								"clicked",
								GTK_SIGNAL_FUNC(SFS_start_callback), NULL);
	gtk_tooltips_set_tip (button_tips, start, "Start processing of the image...",
			"Use cancel if you start the processing with the wrong parameters!");

	done = gtk_dialog_add_button (GTK_DIALOG(dialog), "DONE", DONE_BUTTON);
	SFSint.done_button_handler = g_signal_connect (GTK_OBJECT(done),
								"clicked",
								GTK_SIGNAL_FUNC(SFS_done_callback),
								SFSint.top_window);
	gtk_tooltips_set_tip (button_tips, done, "Done with processing, save results and quit...",
			"Saves the current processing results then quits the plug-in.");

	SFSint.SFScancel = gtk_dialog_add_button (GTK_DIALOG(dialog), "CANCEL", CANCEL_BUTTON);
	SFSint.cancel_button_handler = g_signal_connect (GTK_OBJECT(SFSint.SFScancel),
								"clicked",
								GTK_SIGNAL_FUNC(SFS_cancel_callback),
								SFSint.top_window);
	gtk_tooltips_set_tip (button_tips, SFSint.SFScancel, "Done with processing, delete results and quit...",
		"Delets the current processing results then quits the plug-in. Also will cancel the plug-in the same as window close.");

	// Point the handlers for the delete and destroy user commands.
	SFSint.delete_handler_id = g_signal_connect_swapped(GTK_OBJECT(dialog),
			"delete-event",
			G_CALLBACK(SFS_delete_callback),
			SFSint.top_window);
	SFSint.destroy_handler_id = g_signal_connect_swapped(GTK_OBJECT(dialog),
			"destroy-event",
			G_CALLBACK(SFS_destroy_callback),
			SFSint.top_window);
	// Add the main frame.
	main_frame = SFS_frame_new_in_box (NULL, main_hbox, true, true);
	main_table = SFS_table_new_in_frame(3, 4, main_frame);
	// Add the status bar.
	SFSint.status_bar = gtk_statusbar_new();
	SFSint.status_bar_context = gtk_statusbar_get_context_id (GTK_STATUSBAR(SFSint.status_bar),
								"sfs process status");
	gtk_table_attach_defaults (GTK_TABLE(main_table), SFSint.status_bar,
								1, 2, 4, 5);
	gtk_statusbar_push (GTK_STATUSBAR(SFSint.status_bar), SFSint.status_bar_context,
								" Plug-in not active... Awaiting user input.");

// Algorithm control parameters box. ---------------------------------------
	acp_hbox = gtk_hbox_new(false, 4);
	gtk_table_attach_defaults(GTK_TABLE(main_table), acp_hbox,
								1, 2, 1, 2);
	frame = SFS_frame_new_in_box( "Algorithm Selection:", acp_hbox, true, true);
	table = SFS_table_new_in_frame(4, 2, frame);

	// Algorithm control buttons, with default being "Horn".
	algo_radb_group = SFS_radio_button_new_in_table ("Horn",
							algo_radb_group, table, 1, 2, 1, 2,
							&SFSint.algo_button[HORN], true,
							button_tips,
"Implements SFS method described by Horn (1977, 1981, 1990). See: http://www.newfrontiersinscience.com/martianenigmas/Articles/SFS/sfs.html"
	);

	algo_radb_group = SFS_radio_button_new_in_table ("Ghasemlou",
							algo_radb_group, table, 2, 3, 1, 2,
							&SFSint.algo_button[GHASEMLOU], false,
							button_tips,
"Implements SFS method described by Mani Ghasemlou (2001). See: http://www.cs.mcgill.ca/~mghase/shading/shading.html"
	);

	algo_radb_group = SFS_radio_button_new_in_table ("Lee",
							algo_radb_group, table, 3, 4, 1, 2,
							&SFSint.algo_button[LEE], false,
							button_tips,
"Implements SFS method described by Tai Sing Lee (2003). See: http://www-2.cs.cmu.edu/afs/andrew/scs/cs/15-385/www/handouts/lecture5_shading.pdf"
	);

	// Ancillary parameters box. -----------------------------------------------
	ap_hbox = gtk_hbox_new(false, 8);
	gtk_table_attach_defaults(GTK_TABLE(main_table), ap_hbox,
								1, 2, 2, 3);

	// Ancillary parameters box frame.
	frame = SFS_frame_new_in_box( "MOC/THEMIS Image Ancillary Parameters:", ap_hbox, true, true);
	table = SFS_table_new_in_frame(2, 7, frame);

	/* Angle measured from the center to the right edge of the image,
			to the direction of the Sun. */
	label_sunAzimuth = gtk_label_new ("Sun Azimuth(deg):");
	adj_sunAzimuth = gtk_adjustment_new (0.0, 0.0, 360.0, 0.01, 5.0, 0.0);
	SFSctrl.Sun_Azimuth = SFS_spin_button_new_in_table (table, adj_sunAzimuth,
						label_sunAzimuth, 0.01, 3, 2, 3, 1, 2, entry_tips,
"Azimuth of Sun from right center, clockwise.");
	if (SFSint.init_file_found)
	{
		gtk_spin_button_set_value (GTK_SPIN_BUTTON(SFSctrl.Sun_Azimuth),
				SFSVal.Sun_Azimuth);
	}

	// Angle between the camera and a "normal" drawn perpendicular to the planet's surface.
	label_emissionAngle = gtk_label_new ("Emission Angle(deg):");
	adj_emissionAngle = gtk_adjustment_new (0.0, 0.0, 90.0, 0.01, 1.0, 0.0);
	SFSctrl.Emission_Angle = SFS_spin_button_new_in_table (table, adj_emissionAngle,
						label_emissionAngle, 0.01, 3, 2, 3, 2, 3, entry_tips,
"Angle of camera from surface normal. NOT USED IN HORN ALGORITHM!");
	if (SFSint.init_file_found)
	{
		gtk_spin_button_set_value (GTK_SPIN_BUTTON(SFSctrl.Emission_Angle),
				SFSVal.Emission_Angle);
	}

	// Angle between the Sun and a "normal" drawn perpendicular to the planet's surface.
	label_incidenceAngle = gtk_label_new ("Incidence Angle(deg):");
	adj_incidenceAngle = gtk_adjustment_new (0.0, 0.0, 90.0, 0.01, 1.0, 0.0);
	SFSctrl.Incidence_Angle = SFS_spin_button_new_in_table (table, adj_incidenceAngle,
						label_incidenceAngle, 0.01, 3, 2, 3, 3, 4, entry_tips,
"Angle of Sun from surface normal. NOT USED IN HORN ALGORITHM!");
	if (SFSint.init_file_found)
	{
		gtk_spin_button_set_value (GTK_SPIN_BUTTON(SFSctrl.Incidence_Angle),
				SFSVal.Incidence_Angle);
	}
	
	// Angle between the Sun, the surface, and the camera .
	label_phaseAngle = gtk_label_new ("Phase Angle(deg):");
	adj_phaseAngle = gtk_adjustment_new (0.0, 0.0, 180.0, 0.01, 5.0, 0.0);
	SFSctrl.Phase_Angle = SFS_spin_button_new_in_table (table, adj_phaseAngle,
						label_phaseAngle, 0.01, 3, 2, 3, 4, 5, entry_tips,
"Angle between Sun and camera.");
	if (SFSint.init_file_found)
	{
		gtk_spin_button_set_value (GTK_SPIN_BUTTON(SFSctrl.Phase_Angle),
				SFSVal.Phase_Angle);
	}

	// Image resolution in meters per pixel at the center of the image.
	label_pixelWidth = gtk_label_new ("Pixel Width(m):");
	adj_pixelWidth = gtk_adjustment_new (0.0, 0.0, 1000.0, 0.01, 5.0, 0.0);
	SFSctrl.Pixel_Width = SFS_spin_button_new_in_table (table, adj_pixelWidth,
						label_pixelWidth, 0.01, 3, 2, 3, 5, 6, entry_tips,
"Actual pixel width.");
	if (SFSint.init_file_found)
	{
		gtk_spin_button_set_value (GTK_SPIN_BUTTON(SFSctrl.Pixel_Width),
				SFSVal.Pixel_Width);
	}

	// Ratio of pixel height to pixel width.
	label_pixelAspectRatio = gtk_label_new ("Pixel Aspect Ratio:");
	adj_pixelAspectRatio = gtk_adjustment_new (1.0, 0.0, 10.0, 0.01, 0.1, 0.0);
	SFSctrl.Pixel_Aspect_Ratio = SFS_spin_button_new_in_table (table, adj_pixelAspectRatio,
						label_pixelAspectRatio, 0.01, 3, 2, 3, 6, 7, entry_tips,
"Ratio of pixel height to pixel width.");
	if (SFSint.init_file_found)
	{
		gtk_spin_button_set_value (GTK_SPIN_BUTTON(SFSctrl.Pixel_Aspect_Ratio),
				SFSVal.Pixel_Aspect_Ratio);
	}

	// Average distance from surface to camera, taking into account the emission angle.
	label_slantDistance = gtk_label_new ("Slant Distance (km):");
	adj_slantDistance = gtk_adjustment_new (0.0, 0.0, 50000.0, 0.01, 10.0, 0.0);
	SFSctrl.Slant_Distance = SFS_spin_button_new_in_table (table, adj_slantDistance,
						label_slantDistance, 0.01, 3, 2, 3, 7, 8, entry_tips,
"Distance from surface to camera. NOT USED IN HORN ALGORITHM!");
	if (SFSint.init_file_found)
	{
		gtk_spin_button_set_value (GTK_SPIN_BUTTON(SFSctrl.Slant_Distance),
				SFSVal.Slant_Distance);
	}

	// 3D rendering parameters box. --------------------------------------------
	tdr_hbox = gtk_hbox_new(false, 8);
	gtk_table_attach_defaults(GTK_TABLE(main_table), tdr_hbox,
								2, 3, 2, 3);

	// 3D rendering parameters frame.
	frame = SFS_frame_new_in_box( "3D Rendering Parameters:", tdr_hbox, true, true);
	table = SFS_table_new_in_frame(1, 7, frame);

	SFSctrl.Scale = SFS_scale_entry_new_double( "Image Scale:",
"Scales image by this value. Same as Image->Scale Image command.",
											table, 1, &SFSVal.Scale,
											1.0, 16.0, 0.1, 1.0, 2);

	SFSctrl.Viewer_Xaxis = SFS_scale_entry_new_double( "Viewer X-Axis Angle(deg):",
"Counterclockwise rotation looking into the X-axis. Some viewer angle combinations may fail.",
											table, 2, &SFSVal.Viewer_Xaxis,
											-180.0, 180.0, 1.0, 5.0, 2);

	SFSctrl.Viewer_Yaxis = SFS_scale_entry_new_double( "Viewer Y-Axis Angle(deg):",
"Counterclockwise rotation looking into the Y-axis. Some viewer angle combinations may fail. It will be modified if you check the Auto-Correct X-Axis Tilt check box.  The modified value will be retained until manually cleared if you un-check the Auto-Correct X-Axis Tilt check box.",
											table, 3, &SFSVal.Viewer_Yaxis,
											-180.0, 180.0, 1.0, 5.0, 2);

	SFSctrl.Viewer_Zaxis = SFS_scale_entry_new_double( "Viewer Z-Axis Angle(deg):",
"Clockwise rotation looking into the Z-axis. Some viewer angle combinations may fail.",
											table, 4, &SFSVal.Viewer_Zaxis,
											-180.0, 180.0, 1.0, 5.0, 2);

	SFSctrl.Focal_Distance = SFS_scale_entry_new_double( "Focal Distance:",
"Distance of viewer from image surface.",
											table, 5, &SFSVal.Focal_Distance,
											1.0, 500.0, 1.0, 25.0, 0);

	SFSctrl.Output_Size = SFS_scale_entry_new_double( "Max. Output Size(pixel):",
"Maximum edge size of output image box.",
											table, 6, &SFSVal.Output_Size,
											100.0, 1280.0, 1.0, 25.0, 0);

	if (SFSint.init_file_found) button_value = SFSint.app_button[AUTO_CORRECT];
	else button_value = false;
	tbutton_auto_correct = SFS_toggle_button_new_in_table ("Auto-Correct X-Axis Tilt",
							table, 0, 1, 7, 8,
							&SFSint.app_button[AUTO_CORRECT], button_value,
							button_tips,
"Corrects the tilt of the X-axis that is a processing artifact. Remember to null out the Viewer Y-Axis Angle, above, if you change the state of this button."
	);

	if (SFSint.init_file_found) button_value = SFSint.app_button[FORMULA];
	else button_value = false;
	tbutton_formula = SFS_toggle_button_new_in_table ("Alternate Formula",
							table, 1, 2, 7, 8,
							&SFSint.app_button[FORMULA], button_value,
							button_tips,
"Uses an alternative formula for rendering the height map. If checked the elevation map formula is (ref_map_ptr->ref-a_cos_s )/a*sin_s, else it is (ref_map_ptr->ref-a_cos_s )/(a*sin_s). See: http://www.newfrontiersinscience.com/martianenigmas/Articles/SFS/sfs.html for the ambiguity relating to this checkbox."
	);

	// Add box, frame, table, and buttons for file control.
	fc_hbox = gtk_hbox_new(false, 4);
	gtk_table_attach_defaults(GTK_TABLE(main_table), fc_hbox,
								2, 3, 1, 2);
	frame = SFS_frame_new_in_box ( "Application Control:", fc_hbox, true, true);
	table = SFS_table_new_in_frame (4, 4, frame);
	gtk_table_set_col_spacings (GTK_TABLE(table), 1);

	if (SFSint.init_file_found) button_value = SFSint.app_button[DELETE_IMAGES];
	else button_value = true;
	tbutton_del_image = SFS_toggle_button_new_in_table ("Delete Images",
							table, 1, 2, 1, 2,
							&SFSint.app_button[DELETE_IMAGES], button_value,
							button_tips,
"Deletes previous generated image, otherwise they stay, except for the last image after the DONE button is clicked."
	);

	if (SFSint.init_file_found) button_value = SFSint.app_button[IGNORE_MATRIX];
	else button_value = true;
	tbutton_ignore_matrix = SFS_toggle_button_new_in_table ("Matrix Warnings",
							table, 2, 3, 1, 2,
							&SFSint.app_button[IGNORE_MATRIX], button_value,
							button_tips,
"Enables reporting of singular or ill conditioned matricies."
	);

	if (SFSint.init_file_found) button_value = SFSint.app_button[IGNORE_MEMORY];
	else button_value = true;
	tbutton_ignore_mem = SFS_toggle_button_new_in_table ("Memory Warnings",
							table, 3, 4, 1, 2,
							&SFSint.app_button[IGNORE_MEMORY], button_value,
							button_tips,
"Enables reporting of any memory allocation warnings and viewer azimuth / angle warnings."
	);

	if (SFSint.init_file_found) button_value = SFSint.app_button[DRAW_AXES];
	else button_value = true;
	tbutton_axes = SFS_toggle_button_new_in_table ("Draw Axes",
							table, 1, 2, 2, 3,
							&SFSint.app_button[DRAW_AXES], button_value,
							button_tips,
"Enables drawing of x and y axes."
	);

	if (SFSint.init_file_found) button_value = SFSint.app_button[GEN_MOVIE];
	else button_value = false;
	tbutton_create_movie = SFS_toggle_button_new_in_table ("Generate Movie",
							table, 2, 3, 2, 3,
							&SFSint.app_button[GEN_MOVIE], button_value,
							button_tips,
"Enables generation of layer movie."
	);
	
	if (SFSint.init_file_found) button_value = SFSint.app_button[WRITE_MAP];
	else button_value = false;
	tbutton_height_map = SFS_toggle_button_new_in_table ("Save Height Map",
							table, 3, 4, 2, 3,
							&SFSint.app_button[WRITE_MAP], button_value,
							button_tips,
"Enables saving of height map."
	);
	
	if (SFSint.init_file_found) button_value = SFSint.app_button[HM_TYPE];
	else button_value = false;
	tbutton_hm_type = SFS_toggle_button_new_in_table ("Row Series Type",
							table, 4, 5, 1, 2,
							&SFSint.app_button[HM_TYPE], button_value,
							button_tips,
"Height map type. If on, formatted for row series, as with Microsoft Excel Surface plots, else x,y,z row format."
	);

	if (SFSint.init_file_found) hm_file_name = SFSint.heightmap_filename;
	else
#ifdef G_OS_WIN32
	hm_file_name = strcpy(hm_file_name, ".\\heightmap.txt");
#else
	hm_file_name = strcpy(hm_file_name, "./heightmap.txt");
#endif
	tentry_heightmapname = SFS_text_entry_new_in_table (table,
							hm_file_name,
							4, 5, 2, 3,
							entry_tips,
"Path specification of height map file."
	);
	SFSint.save_height_map_widget = tentry_heightmapname;
	strcpy(SFSint.heightmap_filename, hm_file_name);

	// Add box, frame, and table for movie control.
	mc_hbox = gtk_hbox_new(false, 4);
	gtk_table_attach_defaults(GTK_TABLE(main_table), mc_hbox,
								1, 2, 3, 4);
	frame = SFS_frame_new_in_box ( "Movie Control:", mc_hbox, true, true);
	table = SFS_table_new_in_frame (4, 4, frame);
	gtk_table_set_col_spacings (GTK_TABLE(table), 1);

	// Axis selection radio buttons.
	if (SFSint.init_file_found) button_value = SFSint.movie_button[ZAXIS];
	else button_value = true;
	movie_radb_group = SFS_radio_button_new_in_table ("Z-Axis",
							movie_radb_group, table, 0, 1, 1, 2,
							&SFSint.movie_button[ZAXIS], button_value,
							button_tips,
"Loops movie on Z-Axis."
	);

	if (SFSint.init_file_found) button_value = SFSint.movie_button[YAXIS];
	else button_value = false;
	movie_radb_group = SFS_radio_button_new_in_table ("Y-Axis",
							movie_radb_group, table, 1, 2, 1, 2,
							&SFSint.movie_button[YAXIS], button_value,
							button_tips,
"Loops movie on Y-Axis."
	);

	if (SFSint.init_file_found) button_value = SFSint.movie_button[XAXIS];
	else button_value = false;
	movie_radb_group = SFS_radio_button_new_in_table ("X-Axis",
							movie_radb_group, table, 2, 3, 1, 2,
							&SFSint.movie_button[XAXIS], button_value,
							button_tips,
"Loops movie on X-Axis."
	);

	// Sliders to select begining, end, and count of layers.
	SFSctrl.Movie_Start = SFS_scale_entry_new_double( "Starting Movie Angle(deg):",
"Movie will start with this angle.",
											table, 2, &SFSVal.Movie_Start,
											-180.0, 180.0, 1.0, 10.0, 2);

	SFSctrl.Movie_End = SFS_scale_entry_new_double( "Ending Movie Angle(deg):",
"Movie will end with this angle.",
											table, 3, &SFSVal.Movie_End,
											-180.0, 180.0, 1.0, 10.0, 2);

	SFSctrl.Movie_Frame_Count = SFS_scale_entry_new_double( "Movie Frame Count:",
"Movie will have this many frames.",
											table, 4, &SFSVal.Movie_Frame_Count,
											2.0, 100.0, 1.0, 10.0, 0);

	// Add box, frame, for status output.
	status_hbox = gtk_hbox_new(false, 4);
	gtk_table_attach_defaults(GTK_TABLE(main_table), status_hbox,
								2, 3, 3, 4);
	frame = SFS_frame_new_in_box ( "Status:", status_hbox, true, true);
	table = SFS_table_new_in_frame (1, 4, frame);
	SFSint.status_messages = gtk_label_new (NULL);
	gtk_label_set_justify ( GTK_LABEL(SFSint.status_messages), GTK_JUSTIFY_LEFT );
	gtk_label_set_line_wrap ( GTK_LABEL(SFSint.status_messages), true );
	gtk_table_attach_defaults ( GTK_TABLE(table), SFSint.status_messages, 0, 1, 0, 1 );
	strcpy( text.message,"Welcome to Shapefs 1.2.0.0\nSource: " );
	strcat( text.message, gimp_image_get_name(
			gimp_drawable_get_image(shapefs.drawable->drawable_id)) );
	strcat( text.message, ", " );
	sprintf( text.number_ptr, "%d", shapefs.drawable->width );
	strcat( text.message,text.number_ptr );
	strcat( text.message,"x" );
	sprintf( text.number_ptr, "%d", shapefs.drawable->height );
	strcat( text.message,text.number_ptr );
	strcat( text.message,"\nPlease set the algorithm, control, ancillary, rendering, and movie parameters as required." );
	common.update_status( text.message );

	// Add a progress bar.
	label_Progress = gtk_label_new ("PROGRESS:");
	gtk_misc_set_alignment (GTK_MISC(label_Progress), 0.0, 0.0);
	gtk_table_attach_defaults (GTK_TABLE(table), label_Progress, 0, 1, 1, 2);
	SFSctrl.progress = gtk_progress_bar_new ();
	gtk_table_attach_defaults (GTK_TABLE(table), SFSctrl.progress, 0, 1, 2, 3);
	SFSint.pulse_bar_table = table;
	gtk_progress_bar_set_bar_style (GTK_PROGRESS_BAR(SFSctrl.progress),
										GTK_PROGRESS_CONTINUOUS);
	gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR(SFSctrl.progress), 0.0);
	
	// Show the GTK Widgets.
	gtk_widget_show_all (dialog);
	// Start the main gtk loop.
	gtk_main();
}

// -----------------------------------------------------------------------------
gint GIMP_SFS::SFS_Do (GimpDrawable *do_drawable)
/*
  Name: Do Shape From Shading Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:24
  Description: Starts the main algorithm, checking to see that the algorithm
				is actually implemented.
*/
{
	gint ret_val = false;   // Flag an error initially.
	switch (SFSVal.Algorithm)
	{	// Test for Algorithm type.
		case HORN :
			ret_val = horn.SFS_Horn (do_drawable);
			break;
		case GHASEMLOU :
			SFS_not_implemented ("Ghasemlou");
			break;
		case LEE :
			SFS_not_implemented ("Lee");
			break;
		default :
			break;
	}

	return ret_val;
}

// -----------------------------------------------------------------------------
void GIMP_SFS::SFS_not_implemented (gchar *ni_name)
/*
  Name: Shape From Shading Algorithm Not Implemented Method.
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:24
  Description: Creates a GIMP message that the selected algorithm is not
				currently implemented.
*/
{
	strcpy (text.message, ni_name);
	strcat (text.message, " algorithm not implemented yet!");
	gimp_message (text.message);
}

// -----------------------------------------------------------------------------
void GIMP_SFS::movie_error (gchar *error_text)
/*
  Name: Movie Error Method.
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 30/09/05 17:24
  Description: Flags the user that a movie error has occurred and then
				configures the status to indicate such.
*/
{	// Configure status and semaphores to be correct!
	gimp_message (error_text);
	SFSint.status = SFS_MOVIE_FAILED;
	SFSint.movie_image = 0;
	SFSint.movie_drawable = NULL;
}
