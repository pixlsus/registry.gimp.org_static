/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef SHAPEFS_PRIVATE_H
#define SHAPEFS_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.2.0.0"
#define VER_MAJOR	1
#define VER_MINOR	2
#define VER_RELEASE	0
#define VER_BUILD	0
#define COMPANY_NAME	"Happy Cat Technologies"
#define FILE_VERSION	"1.2.0.0"
#define FILE_DESCRIPTION	"Shape From Shading Image Mapping Plug-in for 3D Image Rendering"
#define INTERNAL_NAME	"shapefs"
#define LEGAL_COPYRIGHT	"Alfred P. Reaud, 2003-2005"
#define LEGAL_TRADEMARKS	"Free software under GNU-GPL Ver. 2"
#define ORIGINAL_FILENAME	"shapefs.exe"
#define PRODUCT_NAME	"ShapeFS"
#define PRODUCT_VERSION	"1.2.0.0-20051020"

#endif /*SHAPEFS_PRIVATE_H*/
