/*  ShapeFS Horn Algorithm Class Source File.
	A GIMP Plug-in to render shape from shading.
	(c) 2003, Alfred P. Reaud
	Created: April 17, 2003
	Current: October 20, 2005
	Version: 1.2.0.0

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "shapefs.h"

COMMON_ALGORITHM common;	// Common algorithms.

extern HORN_ALGORITHM horn;	// Horm algorithm coding.
extern MATRIX matrix;	// Common matrix functions.
extern MESSAGES text;	// Declare text static so that all portions can use it.

extern SFSAntiBounce SFSMab;
extern SFSMemory SFSMem;
extern SFSSemaphore SFSint;
extern SFSValues SFSVal;
extern SFSControls SFSctrl;

static gint check_events = CHECK_COUNT;

// -----------------------------------------------------------------------------
COMMON_ALGORITHM::COMMON_ALGORITHM (void)
{
	// Dummy constructor for future need.
}

// -----------------------------------------------------------------------------
gboolean COMMON_ALGORITHM::check_parameters (void)
{
	if ( FP_EQ(SFSVal.Sun_Azimuth,0.0) )
	{
		gimp_message ("Sun Azimuth CANNOT BE 0 DEGREES!");
		error_status (SFS_SUN_AZIMUTH_INVALID);
		return false;
	}
	if ( FP_EQ(SFSVal.Phase_Angle, 0.0) )
	{
		gimp_message ("Phase Angle CANNOT BE 0 DEGREES!");
		error_status (SFS_PHASE_ANGLE_INVALID);
		return false;
	}
	if ( FP_EQ(SFSVal.Pixel_Width, 0.0) )
	{
		gimp_message ("Pixel Width CANNOT BE 0 METERS!");
		error_status (SFS_PIXEL_SIZE_INVALID);
		return false;
	}
	if (SFSVal.Phase_Angle < 30.0)
	{
		gimp_message ("WARNING: Phase Angle should be greater than 30 deg.");
	}
	if (SFSVal.Phase_Angle > 150.0)
	{
		gimp_message ("WARNING: Phase Angle should be less than 150 deg.");
	}
	return true;
}

// -----------------------------------------------------------------------------
void COMMON_ALGORITHM::cleanup()
{	// Frees declacred arrays and insures that the pointers don't dangle.
#ifdef DEBUG
	if (SFSMem.debug_display_id != -1 )
	{	// Free rotated image display. HORN
		gimp_display_delete (SFSMem.debug_display_id);
		SFSMem.debug_display_id = -1;
	}
#endif
	if ( SFSMem.d_tile_map )
	{	// Free drawable tile map. HORN
		delete[] d_tile_map;
		d_tile_map = NULL;
		SFSMem.d_tile_map = false;
	}
	
	if ( SFSMem.tiled_ref_map )
	{	// Free tiled reflectance map. HORN
		delete[] tiled_ref_map;
		tiled_ref_map = NULL;
		SFSMem.tiled_ref_map = false;
	}

	if ( SFSMem.ref_map )
	{	// Free reflectance map. HORN
		delete[] ref_map;
		ref_map = NULL;
		SFSMem.ref_map = false;
	}
	
	if ( SFSMem.elevation_map && !SFSint.elev_done )
	{	// Free elevation map. HORN
		delete[] horn.elevation_map;
		horn.elevation_map = NULL;
		SFSMem.elevation_map = false;
	}

	if ( SFSMem.sorted_vect_map )
	{	// Free sorted vector map. COMMON_ALGORITHM
		delete[] sorted_vect_map;
		sorted_vect_map = NULL;
		SFSMem.sorted_vect_map = false;
	}
	
	if ( SFSMem.screen_tile_map )
	{	// Free screen tile map. COMMON_ALGORITHM
		delete[] screen_tile_map;
		screen_tile_map = NULL;
		SFSMem.screen_tile_map = false;
	}
	
	if ( SFSMem.tiled_vect_map )
	{	// Free tiled vector map. COMMON_ALGORITHM
		delete[] tiled_vect_map;
		tiled_vect_map = NULL;
		SFSMem.tiled_vect_map = false;
	}
}

// -----------------------------------------------------------------------------
void COMMON_ALGORITHM::clear_array ( Vector_XY *array, const gint count )
/*
  Name: Clear Sort Array Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 15/10/05 20:10
  Description: Nulls out the pertinent parameters of the sort map so that we
			   don't get bogus displaying.
*/
{	// Required because new, unlike calloc, doesn't null out the array!
	gint i;
	Vector_XY *ptr = array;
	
	for (i = 0; i != count; i++)
	{
		ptr->value = '\0';
		ptr->hit_count = 0;
		ptr->depth = -1.0E100;
		ptr->z = -1.0E100;
		ptr++;
	}
		
}

// -----------------------------------------------------------------------------
void COMMON_ALGORITHM::error_status (SFSResult status)
/*
  Name: Error Status Method.
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Date: 15/10/05 20:11
  Description:  Sets up the status semaphores to indicate an error exit.
*/
{
	cleanup ();
	SFSint.status = status;
	SFSint.output_image = 0;
	SFSint.output_drawable = NULL;
}

// -----------------------------------------------------------------------------
gboolean COMMON_ALGORITHM::render_3D (SFSScreenSize *SS_Struct, Vertex *rend_vector_map, 
							const gint width,  const gint height)
/*
  Name: Render 3D Method.
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 25/09/05 21:13
  Description:  Creates the 3D image from the given height map.
*/
{
#ifdef DEBUG	
	gint vm_count = 0;
	gint svm_count = 0;
	gint tvm_count = 0;
	gint out_count = 0;
	SFSint.render_count_calls++;
#endif
	// Iteration variables.
	gint		i = 0;
	const gint	wth = width * height;
	// Global matricies.
	gdouble		global[4][4] = { 0.0 };
	// Image variables.
	gint32		image_dest = 0;
	gint32		layer = 0;
	GimpDrawable	*three_D = NULL;
	// Rotation and direction cosine variables.
	gdouble		a = 0.0, b = 0.0, c = 0.0;
	gdouble		temp_x_angle = 0.0, temp_y_angle = 0.0, temp_z_angle = 0.0;
	// Sorted map variables.
	gint		x = 0, xmin = 0, xmax = 0;
	gint		y = 0, ymin = 0, ymax = 0;
	gint		offset = 0;
	static gdouble	divisor = 0.0;
	gdouble		depth = 0.0;
	gdouble		temp_z = 0.0;
	gdouble		xdivisor = 0.0, ydivisor = 0.0;
	Vector_XY	*sort_vect_map_ptr = NULL;
	Vector_XY	*svm_ptr = NULL;
	// Scaling variables.
	gint		new_width = 0, new_height = 0;
	// Tile mapping variables.
	guchar		*dest = NULL;
	gint		i_max = 0, s_tile_map_count = 0;
	gint		tile_offset = 0, tile_row_sum = 0;
	gint		tile_x = 0, tile_y = 0;
	gint		xcoord = 0, ycoord = 0;
	gint		xcoord_ref = 0, ycoord_ref = 0;
	gdouble		td_height = 0.0, td_width = 0.0;
	gpointer	pr = NULL;
	guchar		*tiled_vect_map_ptr = NULL;
	GimpPixelRgn	dest_rgn;
	// Vector map variables.
	Vertex		*vect_map_ptr = NULL;
	// Initialize counters that need it.
	text.sort_error_count = 0;

	// Create the scaling matrix and process for global coordinates. ------------
	matrix.identity (global);
	matrix.scale (global, SFSVal.Pixel_Width, SFSVal.Pixel_Width,
								SFSVal.Pixel_Width * SFSVal.Pixel_Aspect_Ratio );
	matrix.check_det ( (gdouble *)global, "viewer scaleing");
	if (SFSint.cancel) return false;
	// Create world coordinates. -----------------------------------------------
	vect_map_ptr = rend_vector_map;
	for (i = 0; i != wth; i++)
	{   // Create a world coordinate set.
		matrix.vect_mult ( &vect_map_ptr->Local, global, &vect_map_ptr->World );
		vect_map_ptr++;
		if (check_events-- == 0)
		{   // Check for events only on countdown.
			while (gtk_events_pending()) gtk_main_iteration();
			check_events = CHECK_COUNT;
		}
	}
	update_progress(" World coordinates done. Viewer rotation matrix...");
	if (SFSint.cancel) return false;

	// Create the viewer projection matrix and process for aligned coordinates.
	if ( !FP_EQ(SFSVal.Viewer_Xaxis, 0.0) )
	{	// Check for bad value and fudge.
		temp_x_angle = gimp_deg_to_rad(90.0 - SFSVal.Viewer_Xaxis);
	}
	else
	{
		temp_x_angle = gimp_deg_to_rad(90.0 - SMALL_NUMB);
	}
	if ( !FP_EQ(SFSVal.Viewer_Yaxis, 0.0) )
	{
		temp_y_angle = gimp_deg_to_rad(SFSVal.Viewer_Yaxis);
	}
	else
	{
		temp_y_angle = gimp_deg_to_rad(SMALL_NUMB);
	}
	if ( !FP_EQ(SFSVal.Viewer_Zaxis, 0.0) )
	{
		temp_z_angle = gimp_deg_to_rad(SFSVal.Viewer_Zaxis);
	}
	else
	{
		temp_z_angle = gimp_deg_to_rad(SMALL_NUMB);
	}
	// Compute direction cosines.
	a = cos( -temp_x_angle );
	b = cos( temp_y_angle );
	c = cos( -temp_z_angle );

	// Generate the viewer rotation matrix. ------------------------------------
	matrix.identity (global);
	// Angles for y and z axis swapped for consistency.
	matrix.rotate_3D (global, -temp_x_angle, temp_y_angle, -temp_z_angle );
	matrix.check_det ( (gdouble *)global, "viewer rotation");
	matrix.ortho_check (global, "Rotation matrix");
	vect_map_ptr = rend_vector_map;
	for (i = 0; i != wth; i++)
	{	// Loop through the vector map.
		matrix.vect_mult ( &vect_map_ptr->World, global, &vect_map_ptr->Aligned );
		vect_map_ptr++;
		if (check_events-- == 0)
		{   // Check for events only on countdown.
			while (gtk_events_pending()) gtk_main_iteration();
			check_events = CHECK_COUNT;
		}
	}
	update_progress(" Viewer rotation applied. Viewer perspective...");
	if (SFSint.cancel) return false;

	// Generate the perspective then the screen coordinates. -------------------
	// matrix.identity(global);
	matrix.identity(global);
	matrix.perspective (global, SFSVal.Focal_Distance);
	matrix.check_det ( (gdouble *)global, "viewer perspective");

	vect_map_ptr = rend_vector_map;
	for (i = 0; i != wth; i++)
	{	// Loop through the vector map.
		matrix.vect_mult ( &vect_map_ptr->Aligned, global, &vect_map_ptr->Screen );
		vect_map_ptr++;
		if (check_events-- == 0)
		{   // Check for events only on countdown.
			while (gtk_events_pending()) gtk_main_iteration();
			check_events = CHECK_COUNT;
		}
	}
	update_progress(" Perspective applied. Resizing...");
	if (SFSint.cancel) return false;

	// Convert to real coordinates from homogoneous coordinates. ---------------
	vect_map_ptr = rend_vector_map;
	for (i = 0; i != wth; i++ )
	{	// Insure we don't get division by zero!
		if ( FP_EQ(vect_map_ptr->Screen.w, 0.0) ) vect_map_ptr->Screen.w = 1.0;
		vect_map_ptr->Screen.x /= vect_map_ptr->Screen.w;
		vect_map_ptr->Screen.y /= vect_map_ptr->Screen.w;
		vect_map_ptr->Screen.z /= vect_map_ptr->Screen.w;
		vect_map_ptr++;
		if (check_events-- == 0)
		{   // Check for events only on countdown.
			while (gtk_events_pending()) gtk_main_iteration();
			check_events = CHECK_COUNT;
		}
	}

	// Get new image size and normalize. ---------------------------------------
	screen_size (rend_vector_map, SS_Struct, wth);
	do {
		xdivisor = ydivisor = 1.0;
		if ( ((gdouble)SS_Struct->width) > SFSVal.Output_Size )
			xdivisor = (gdouble)SS_Struct->width / (gdouble)SFSVal.Output_Size;
		if ( ((gdouble)SS_Struct->height) > SFSVal.Output_Size )
			ydivisor = (gdouble)SS_Struct->height / (gdouble)SFSVal.Output_Size;
		if ( (xdivisor <= 1.0) && (ydivisor <= 1.0) ) break;
		// If in a movie, keep the first divisor we get so that size variations
		// do not occur. Hope we don't resurrect address errors!
		if ( !(SFSint.movie && SFSint.not_first_movie_pass) )
		{
			divisor = sqrt (xdivisor * xdivisor + ydivisor * ydivisor);
		}
		vect_map_ptr = rend_vector_map;
		for (i = 0; i != wth; i++) {
			vect_map_ptr->Screen.x /= divisor;
			vect_map_ptr->Screen.y /= divisor;
			vect_map_ptr++;
			if (check_events-- == 0)
			{   // Check for events only on countdown.
				while (gtk_events_pending()) gtk_main_iteration();
				check_events = CHECK_COUNT;
			}
		}
		screen_size (rend_vector_map, SS_Struct, wth);
	// Take abs value just in case we have a major faux pas!
	} while ( ((abs(SS_Struct->width) > SFSVal.Output_Size) || (abs(SS_Struct->height) > SFSVal.Output_Size)) && !SFSint.movie );
	// Final check before comitting ourselves!
	if ( (SS_Struct->width <= 0) || (SS_Struct->height <= 0) || (SS_Struct->wth <= 0) ) {
		if (SFSint.app_button[IGNORE_MEMORY]) {
			strcpy (text.message, "UNABLE TO CREATE SORTED VECTOR MAP:\n");
			strcat (text.message, "Failsafe test invoked for one of screen\n");
			strcat (text.message, "width, heigth, or both, being zero or negative!");
			gimp_message (text.message);
		}
		error_status (SFS_MEMERROR);
		return false;
	}
	update_progress(" Resize & normalization done. Hidden element removal...");
	if (SFSint.cancel) return false;

	// Create sorted x-y vector map. -------------------------------------------
	if ( (sorted_vect_map = new Vector_XY [SS_Struct->wth]) != NULL )
	{
		SFSMem.sorted_vect_map = true;
		clear_array (sorted_vect_map, SS_Struct->wth);
	}
	else
	{
		text.new_error ("UNABLE TO CREATE SORTED VECTOR MAP:\n", SS_Struct->wth);
		error_status (SFS_MEMERROR);
		return false;
	}
#ifdef DEBUG
	vect_map_ptr = rend_vector_map;
	for (i = 0; i != wth; i++) if ( !((vect_map_ptr++)->dont_process) ) vm_count++;
#endif
/* DONE (20031025#2#): Image bouncing during movie is caused by the offsets
				created by the axis generation.  Investigation indicates
				that the center offset generated here is what gets propagated
				to the movie. */
	// Initialize variables that point.
	vect_map_ptr = rend_vector_map;
	for (i = 0; i != wth; i++)
	{	// The x-y addressed is assumed in the array.
		if ( !vect_map_ptr->dont_process )
		{	// Do only for actual elements.
			x = (gint)ceil(vect_map_ptr->Screen.x) + SS_Struct->xoffset;
			y = (gint)ceil(vect_map_ptr->Screen.y) + SS_Struct->yoffset;
			temp_z = vect_map_ptr->Screen.z;
			offset = x + y * SS_Struct->width;
// See: http://www.ece.eps.hw.ac.uk/~dml/cgonline/hyper00/polypipe/render/hsremove.html
			depth = -(a * x + b * y + temp_z) / c;
			if ( (offset > SS_Struct->wth) || (offset < 0) )
			{	// Major place where we can fail with a sort error!
				text.sort_error (i, wth, SS_Struct->wth, SS_Struct->width,
						SS_Struct->height, offset, x, y, temp_z,
						vect_map_ptr->Screen.w);
				text.sort_error_count++;
				vect_map_ptr++;
				continue;
			}
			svm_ptr = &sorted_vect_map[offset];
			/* TODO (20051018#5#): Still some slight bugs in this section, mostly with 
								angles around 0 degrees in any of the axes.
								Seperating the movie axes helped, however it also
								made the effect very subtle and hard to debug.  A
								close eye needs to be kept on non-sequitor surfaces
								when generating movies. */
			if (svm_ptr->hit_count == 0)
			{	// See if we are the first element set.
				svm_ptr->value = vect_map_ptr->value;
				svm_ptr->depth = depth;
				svm_ptr->x = x;
				svm_ptr->y = y;
				svm_ptr->z = temp_z;
				svm_ptr->hit_count++;
				if (x < xmin) xmin = x;
				else if (x > xmax) xmax = x;
				if (y < ymin) ymin = y;
				else if (y > ymax) ymax = y;
			}
			else
			{	// Check if we are hidden.
				if ( svm_ptr->depth < depth )
				{   // Check z for low horizontal angle ambiguity.
					if (!SFSint.movie)
					{   // Not a movie so test for z-axis.
						if (svm_ptr->z < temp_z)
						{   // Not hidden, so draw it.
							svm_ptr->value = vect_map_ptr->value;
							svm_ptr->x = x;
							svm_ptr->y = y;
							svm_ptr->z = temp_z;
							svm_ptr->depth = depth;
							svm_ptr->hit_count++;
							if (x < xmin) xmin = x;
							else if (x > xmax) xmax = x;
							if (y < ymin) ymin = y;
							else if (y > ymax) ymax = y;
						}
					}
					else
					{   // Needed due to hidden element removal bugs in movies
						// relating to which axis is being used to loop on.
						switch (SFSint.movie_axis)
						{   // Test according to which movie axis is being used.
							case XAXIS:
								if (svm_ptr->y < x)
								{   // Not hidden, so draw it.
									svm_ptr->value = vect_map_ptr->value;
									svm_ptr->x = x;
									svm_ptr->y = y;
									svm_ptr->z = temp_z;
									svm_ptr->depth = depth;
									svm_ptr->hit_count++;
									if (x < xmin) xmin = x;
									else if (x > xmax) xmax = x;
									if (y < ymin) ymin = y;
									else if (y > ymax) ymax = y;
								}
								break;
							case YAXIS:
								if (svm_ptr->x < y)
								{   // Not hidden, so draw it.
									svm_ptr->value = vect_map_ptr->value;
									svm_ptr->x = x;
									svm_ptr->y = y;
									svm_ptr->z = temp_z;
									svm_ptr->depth = depth;
									svm_ptr->hit_count++;
									if (x < xmin) xmin = x;
									else if (x > xmax) xmax = x;
									if (y < ymin) ymin = y;
									else if (y > ymax) ymax = y;
								}
								break;
							case ZAXIS:
							default:
								if (svm_ptr->z < temp_z)
								{   // Not hidden, so draw it.
									svm_ptr->value = vect_map_ptr->value;
									svm_ptr->x = x;
									svm_ptr->y = y;
									svm_ptr->z = temp_z;
									svm_ptr->depth = depth;
									svm_ptr->hit_count++;
									if (x < xmin) xmin = x;
									else if (x > xmax) xmax = x;
									if (y < ymin) ymin = y;
									else if (y > ymax) ymax = y;
								}
								break;
						}
					}
				}
			}
#ifdef DEBUG
			svm_ptr->image_data.iter = i;
			svm_ptr->image_data.x = x;
			svm_ptr->image_data.y = y;
#endif
		}
		vect_map_ptr++;
		if (check_events-- == 0)
		{   // Check for events only on countdown.
			while (gtk_events_pending()) gtk_main_iteration();
			check_events = CHECK_COUNT;
		}
		if (SFSint.cancel) return false;
	}

#ifdef DEBUG
	sort_vect_map_ptr = sorted_vect_map;
	for (i = 0; i != SS_Struct->wth; i++) {
		if ( (sort_vect_map_ptr++)->value) svm_count++;
	}
#endif
#ifdef DEBUG_AP
// #define DEBUG_AP_SVM
 #ifdef DEBUG_AP_SVM
	GimpVector4 *debug_print_object_svm = new GimpVector4[SS_Struct->wth];
	Vector_XY *svmXY_ptr = sorted_vect_map;
	for (i = 0; i != SS_Struct->wth; i++)
	{
		debug_print_object_svm[i].x = svmXY_ptr->image_data.x;
		debug_print_object_svm[i].y = svmXY_ptr->image_data.y;
		debug_print_object_svm[i].z = svmXY_ptr->z;
		debug_print_object_svm[i].w = svmXY_ptr->image_data.iter;
		svmXY_ptr++;
	}
	gchar *filename = new gchar[128];
	gchar *numbuf = new gchar[26];
	strcpy( filename, "d:\\data\\sorted_vector_map[" );
	strcat( filename, itoa(SFSint.render_count_calls, numbuf, 10) );
	strcat( filename, "].txt" );
	text.debug_array_print( debug_print_object_svm, SS_Struct->width,
								"3D sorted vector map", filename );
	delete[] numbuf;
	delete[] filename;
	delete[] debug_print_object_svm;
 #endif
#endif

	update_progress(" Hidden element removal done. Tileing...");
	if (SFSint.cancel) return false;

	// Create the new drawable so that we can get the tile information. --------
	image_dest = gimp_image_new (SS_Struct->width, SS_Struct->height, GIMP_GRAY);
	layer = gimp_layer_new (image_dest, "Background", SS_Struct->width, SS_Struct->height,
							GIMP_GRAY_IMAGE, 100, GIMP_NORMAL_MODE);
	g_assert( gimp_image_add_layer(image_dest, layer, 0) );
	three_D = gimp_drawable_get(layer);

	// Create the new tile mapping. --------------------------------------------
	s_tile_map_count = three_D->ntile_rows * three_D->ntile_cols;
	if ( (screen_tile_map = new SFSTileSize [s_tile_map_count]) != NULL )
	{
		SFSMem.screen_tile_map = true;
	}
	else
	{   // Flag user of critical error and leave.
		text.new_error ("UNABLE TO CREATE SCREEN TILE MAP:\n", s_tile_map_count);
		error_status (SFS_MEMERROR);
		return false;
	}

	// Next the screen tile map.
	sfs_tile_map (screen_tile_map, three_D);

	update_progress(" Screen tile map done. Vectorizing...");
	if (SFSint.cancel) return false;

	// Convert x-y vector map to tiled vector map.
	if ( (tiled_vect_map = new guchar [SS_Struct->wth]) != NULL )
	{
		SFSMem.tiled_vect_map = true;
	}
	else
	{   // Flag user of critical error and leave.
		text.new_error ("UNABLE TO CREATE TILE'D VECTOR MAP:\n", SS_Struct->wth);
		error_status (SFS_MEMERROR);
		return false;
	}
	// Initialize variables that point.
	tiled_vect_map_ptr = tiled_vect_map;
	sort_vect_map_ptr = sorted_vect_map;
	for (tile_y = 0; tile_y != (int)three_D->ntile_rows; tile_y++)
	{	// Map x-y array into tiled array.
		for (tile_x = 0; tile_x != (int)three_D->ntile_cols; tile_x++)
		{	// Compute reference offsets.
			xcoord_ref = ycoord_ref = 0;
			for (y = 0; y != tile_y; y++)
			{
				if (tile_y == 0) break;
				tile_row_sum = 0;
				for (i = 0; i != (int)three_D->ntile_cols; i++)
				{
					offset = i + (tile_y - 1) * three_D->ntile_cols;
					tile_row_sum += screen_tile_map[offset].w *
									screen_tile_map[offset].h;
				}
				ycoord_ref += tile_row_sum;
			}
			for (x = 0; x != tile_x; x++)
			{
				if (tile_x == 0) break;
				xcoord_ref += screen_tile_map[x + tile_y * three_D->ntile_cols].w;
			}
			// Initialize variables.
			tile_offset = tile_x + tile_y * three_D->ntile_cols;
			ycoord = ycoord_ref;
			xcoord = xcoord_ref;
			for (y = 0; y != screen_tile_map[tile_offset].h; y++)
			{	// Loop through the tile rows.
				for (x = 0; x < screen_tile_map[tile_offset].w; x++)
				{	// Loop through the tile columns.
					*tiled_vect_map_ptr++ = sorted_vect_map[xcoord + ycoord].value;
					xcoord++;
				}
				xcoord = xcoord_ref;
				ycoord += SS_Struct->width;
			}
			if (check_events-- == 0)
			{   // Check for events only on countdown.
				while (gtk_events_pending()) gtk_main_iteration();
				check_events = CHECK_COUNT;
			}
		}
		if (SFSint.cancel) return false;
	}
#ifdef DEBUG
	tiled_vect_map_ptr = tiled_vect_map;
	for (i = 0; i != SS_Struct->wth; i++)
	{
		if ((guchar)*(tiled_vect_map_ptr++) != '\0' ) tvm_count++;
	}
#endif
	update_progress(" XY vector map to tiled vector map done. Copying...");
	if (SFSint.cancel) return false;

	// Initialize variables that point.
	tiled_vect_map_ptr = tiled_vect_map;
	// Generate new image structures.
	gimp_pixel_rgn_init(&dest_rgn, three_D, 0, 0, SS_Struct->width, SS_Struct->height, true, true);
	for (pr = gimp_pixel_rgns_register (1, &dest_rgn);
							pr != NULL; pr = gimp_pixel_rgns_process (pr))
	{	// Loop through the tiles and copy to the destination region.
		dest = dest_rgn.data;
		i_max = dest_rgn.w * dest_rgn.h;
		for (i = 0; i != i_max; i++)
		{// Loop through the rows and columns.
			*dest++ = *tiled_vect_map_ptr++;
#ifdef DEBUG
			if ((guchar)*(dest-1) != '\0') out_count++;
#endif
		}
		if (check_events-- == 0)
		{   // Check for events only on countdown.
			while (gtk_events_pending()) gtk_main_iteration();
			check_events = CHECK_COUNT;
		}
	}

	update_progress(" Tiled vector map copied to destination.");
	if (SFSint.cancel) return false;

	// Compute row and column adjustments.
	td_width = (gdouble)three_D->width;
	td_height = (gdouble)three_D->height;
	if ( td_width >= SFSVal.Output_Size )
	{   // Correct column offset for oversize image.
		SFSMab.col_adj = (gint)ceil( (SFSVal.Output_Size - td_width) / 2.0 );
	}
	else
	{   // Correct column offset for off center image.
		SFSMab.col_adj = (gint)ceil( (td_width - (gdouble)xmax
					+ (gdouble)xmin) / 2.0 );
	}
	if ( td_height >= SFSVal.Output_Size )
	{   // Correct row offset for oversize image.
		SFSMab.row_adj = (gint)ceil( (SFSVal.Output_Size - td_height) / 2.0 );
	}
	else
	{   // Correct row offset for off center image.
		SFSMab.row_adj = (gint)ceil( (td_height - (gdouble)ymax
					+ (gdouble)ymin) / 2.0 );
	}
	if (SFSVal.Scale > 1.0)
	{	// Scale, flush, and display final drawable.
		new_width = SS_Struct->width * (gint)SFSVal.Scale;
		new_height = SS_Struct->height * (gint)SFSVal.Scale;
		gimp_drawable_flush (three_D);
		g_assert( gimp_drawable_merge_shadow (three_D->drawable_id, false) );
		g_assert( gimp_drawable_update (three_D->drawable_id, 0, 0,
													new_width, new_height) );
		gimp_scale (three_D->drawable_id, true, 0.0, 0.0,
							(gdouble)new_width, (gdouble)new_height);
		g_assert( gimp_image_resize (image_dest, new_width, new_height, 0, 0) );
		three_D = gimp_drawable_get (layer);
	}
	else
	{
		gimp_drawable_flush (three_D);
		g_assert( gimp_drawable_merge_shadow (three_D->drawable_id, true) );
		g_assert( gimp_drawable_update (three_D->drawable_id, 0, 0,
										SS_Struct->width, SS_Struct->height) );
		gimp_drawable_flush (three_D);
	}
#ifdef DEBUG
	gint32 new_disp_id = 0;
	if ( (new_disp_id = gimp_display_new (image_dest)) != 0 ) {
		SFSMem.debug_display_id = new_disp_id;
	}
	else {
		SFSMem.debug_display_id = -1;
	}
	gimp_displays_flush ();
#endif

	SFSint.output_image = image_dest;
	SFSint.output_drawable = three_D;
	SFSint.status = SFS_OK;

	if ( SFSMem.sorted_vect_map )
	{	// Free sorted vector map.
		delete[] sorted_vect_map;
		sorted_vect_map = NULL;
		SFSMem.sorted_vect_map = false;
	}
	
	if ( SFSMem.screen_tile_map )
	{	// Free screen tile map.
		delete[] screen_tile_map;
		screen_tile_map = NULL;
		SFSMem.screen_tile_map = false;
	}
	
	if ( SFSMem.tiled_vect_map )
	{	// Free tiled vector map.
		delete[] tiled_vect_map;
		tiled_vect_map = NULL;
		SFSMem.tiled_vect_map = false;
	}

	return true;
}

// -----------------------------------------------------------------------------
void COMMON_ALGORITHM::screen_size(SFSScreenSize *ptr)
/*
  Name:  Screen Size Correct
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 08/10/05 15:46
  Description: Checks and corrects for negative values and oversizes the correct screen if so.
*/
{   // Check and correct for negative values and oversize screen.
	if (ptr->x_min < 0.0)
	{
		ptr->xoffset = (gint)fabs( ceil(ptr->x_min) );
		ptr->width = (gint)ceil( ptr->x_max - ptr->x_min );
	}
	else
	{
		ptr->xoffset = -(gint)ceil( ptr->x_min );
		ptr->width = (gint)ceil( ptr->x_max ) + ptr->xoffset;
	}
	if (ptr->y_min < 0.0)
	{
		ptr->yoffset = (gint)fabs( ceil(ptr->y_min) );
		ptr->height = (gint)ceil( (ptr->y_max - ptr->y_min) );
	}
	else
	{
		ptr->yoffset = -(gint)ceil( ptr->y_min );
		ptr->height = (gint)ceil( ptr->y_max ) + ptr->yoffset;
	}
	ptr->wth = (ptr->width + 1) * (ptr->height + 1);
}

// -----------------------------------------------------------------------------
void COMMON_ALGORITHM::screen_size (Vertex *map, SFSScreenSize *SS_Struct, gint count)
/*
  Name:  Screen Size Query Vertex Map
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 08/10/05 15:46
  Description: Computes the offsets and array sizes required for the output
  			   image display.
*/
{
#ifdef DEBUG_AP
// #define DEBUG_AP_SS
 #ifdef DEBUG_AP_SS
	Vertex	*v_ptr = map;
	GimpVector4 *debug_print_object = new GimpVector4[count];
	for (gint j = 0; j != count; j++)
	{
		debug_print_object[j] = v_ptr->Screen;
		v_ptr++;
	}
	text.debug_array_print(debug_print_object, count,
					"sort map", "d:\\sort_map.txt");
	delete[] debug_print_object;
 #endif
#endif
	gint i;
	Vertex *ptr = map;
	gdouble *SSxmin = &SS_Struct->x_min;
	gdouble *SSxmax = &SS_Struct->x_max;
	gdouble *SSymin = &SS_Struct->y_min;
	gdouble *SSymax = &SS_Struct->y_max;
	gdouble *ptrx, *ptry;
	/* Intitialize minimums and maximums.
		Set them to exceed whatever we can normally get executing the range of
		possible values in an image. Optimized for speed via gprof.
	*/
	*SSxmin = *SSymin = 1.0E100;
	*SSxmax = *SSymax = -1.0E100;

	for (i = 0; i != count; i++)
	{	// Loop through all elements, however only process actual pixels.
		if (!ptr->dont_process)
		{	// Get maximum and minimum screen x-axis value.
			ptrx = &ptr->Screen.x;
			ptry = &ptr->Screen.y;
			if (*ptrx < *SSxmin ) *SSxmin = *ptrx;
			// Check only if we didn't have a minimum.
			else if (*ptrx > *SSxmax ) *SSxmax = *ptrx;
			// Get maximum and minimum screen y-axis value.
			if (*ptry < *SSymin ) *SSymin = *ptry;
			// Check only if we didn't have a minimum.
			else if (*ptry > *SSymax ) *SSymax = *ptry;
		}
		// Prepare for next element.
		ptr++;
		if (check_events-- == 0)
		{   // Check for events only on countdown.
			while (gtk_events_pending()) gtk_main_iteration();
			check_events = CHECK_COUNT;
		}
	}
	screen_size (SS_Struct);
}

// -----------------------------------------------------------------------------
void COMMON_ALGORITHM::sfs_tile_map (SFSTileSize *current_tile_map,
	 								GimpDrawable *drawable)
/*
  Name:  Shape From Shading Tile to Array Mapping Method.
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 30/09/05 14:08
  Description: This method maps the tiles used by GIMP to create images into
				 an array that can be incremented through.
*/
{
	gint			x, y, y_tile;
	const gint		tile_map_count = drawable->ntile_cols * drawable->ntile_rows;
	gpointer		pr = NULL;
	GimpPixelRgn	source;

	// Initialize the pixel region for reading the drawable data.
	gimp_pixel_rgn_init ( &source, drawable, 0, 0,
						 drawable->width, drawable->height, false, false );
	// Point the region pointer.
	pr = gimp_pixel_rgns_register (1, &source);
	for (y = 0; y != tile_map_count; y += drawable->ntile_cols)
	{   // Scan through the columns.
		y_tile = y / drawable->ntile_cols;
		for (x = 0; x != (int)drawable->ntile_cols; x++)
		{   // Scan through the row.
			current_tile_map[x + y].tile_x = x;
			current_tile_map[x + y].tile_y = y_tile;
			current_tile_map[x + y].w = source.w;
			current_tile_map[x + y].h = source.h;
			// Point to the next region.
			pr = gimp_pixel_rgns_process (pr);
		}
		// Process pending events if necessary.
		while (gtk_events_pending()) gtk_main_iteration();
	}
}

// -----------------------------------------------------------------------------
void COMMON_ALGORITHM::update_progress (gchar *status_bar_text)
/*
  Name:  Update Progress Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 15/09/05 14:24
  Description: Updates the plug-in progress bar to indicate the proper progress
				 value.
*/
{
 gchar pct[32] = { '\0' }; 	// Buffer for numeric to character conversion.
 gchar *pv_pct = pct;		// Pointer to character buffer.
 gdouble progress_temp;	 // Temporary value for progress bar.

#ifdef DEBUG
	SFSint.process_count_calls++;
#endif
	// Return if we have canceled so we don't get bogus errors.
	if (SFSint.cancel) return;
	// Increment the progress bar.
	SFSint.progress_value += SFSint.progress_delta;
	progress_temp = SFSint.progress_value;
	// Correct possible excursions outside of valid range.
	if ( progress_temp < 0.0 ) progress_temp = 0.0;
	else if ( progress_temp > 1.0 ) progress_temp = 1.0;
	gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR(SFSctrl.progress),
									progress_temp);
	// Create a percentage string.
	sprintf (pv_pct, "%3.0f", ceil(progress_temp * 100.0));
	strcat (pv_pct, "%");
	// Update the progress bar.
	gtk_progress_bar_set_text (GTK_PROGRESS_BAR(SFSctrl.progress), pv_pct);
	gtk_statusbar_push (GTK_STATUSBAR(SFSint.status_bar), SFSint.status_bar_context,
							status_bar_text);

	// Check for events.
	while (gtk_events_pending()) gtk_main_iteration();
}

// -----------------------------------------------------------------------------
void COMMON_ALGORITHM::update_status (gchar *status_text)
/*
  Name: Update Status Method
  Copyright: Alfred P. Reaud, Happy Cat Technologies, 2002-2005
			Released under GNU-GPL Version 2.
  Author: Alfred P. Reaud
  Date: 23/09/05 16:35
  Description: Updates the status window to indicate the message to the user.
*/
{
	// Return if we have canceled so we don't get bogus errors.
	if (SFSint.cancel) return;
	gtk_label_set_text (GTK_LABEL(SFSint.status_messages), status_text);
}
