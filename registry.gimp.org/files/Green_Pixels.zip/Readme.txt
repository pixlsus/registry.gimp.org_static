Compiled with Ubuntu 12.04 LTS
Just copy into plug-in folder or

use this command
gimptool-2.0 --install *.c
