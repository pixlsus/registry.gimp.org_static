/*
 ============================================================================
 Name        : Gimp_Plugin_Bno.c
 Author      : THG
 Version     : 1.0
 Copyright   : 
 Description : Plugin gimp
 ============================================================================
 */
#include <libgimp/gimp.h>

/* Declare local functions.
 */
static void      query  (void);
static void      run    (gchar      *name,
                         gint        nparams,
                         GimpParam  *param,
                         gint       *nreturn_vals,
                         GimpParam **return_vals);

static void      plug_in         (GimpDrawable *drawable);
static unsigned char testBit( int n, int pos );


GimpPlugInInfo PLUG_IN_INFO =
{
  NULL,  /* init_proc  */
  NULL,  /* quit_proc  */
  query, /* query_proc */
  run,   /* run_proc   */
};

MAIN()

static void
query (void)
{
  static GimpParamDef args[] =
  {
    { GIMP_PDB_INT32, "run_mode", "Interactive, non-interactive" },
    { GIMP_PDB_IMAGE, "image", "Input image" },
    { GIMP_PDB_DRAWABLE, "drawable", "Input drawable" }
  };
  static gint nargs = sizeof (args) / sizeof (args[0]);

  gimp_install_procedure ("green_pixels",
                          "Demonstration plug-in - creates a green pixel image",
                          "This simple plug-in creates a green pixel image.",
                          "Brunothg",
                          "Brunothg",
                          "2013",
                          "<Image>/Filters/Pixel/Green Pixels",
                          "RGB*",
                          GIMP_PLUGIN,
                          nargs, 0,
                          args, NULL);
}

static void
run (gchar      *name,
     gint        nparams,
     GimpParam  *param,
     gint       *nreturn_vals,
     GimpParam **return_vals)
{
  static GimpParam values[1];
  GimpDrawable *drawable;
  GimpRunMode run_mode;
  GimpPDBStatusType status = GIMP_PDB_SUCCESS;

  gint32 image_ID;

  run_mode = param[0].data.d_int32;

  /*  Get the specified drawable  */
  drawable = gimp_drawable_get (param[2].data.d_drawable);
  image_ID = param[1].data.d_image;

  /*  Make sure that the drawable is RGB color  */
  if (gimp_drawable_is_rgb (drawable->drawable_id))
    {
      gimp_progress_init ("Modify Pixel ...");
      gimp_tile_cache_ntiles (2 * (drawable->width / gimp_tile_width () + 1));
      plug_in (drawable);

      if (run_mode != GIMP_RUN_NONINTERACTIVE)
        gimp_displays_flush ();
    }
  else
    {
      status = GIMP_PDB_EXECUTION_ERROR;
    }

  *nreturn_vals = 1;
  *return_vals = values;

  values[0].type = GIMP_PDB_STATUS;
  values[0].data.d_status = status;

  gimp_drawable_detach (drawable);
}


static void
plug_in (GimpDrawable *drawable)
{
  GimpPixelRgn src_rgn, dest_rgn;
  guchar *src, *s;
  guchar *dest, *d;
  gint    progress, max_progress;
  gint    has_alpha, red, green, blue, alpha;
  gint    x1, y1, x2, y2;
  gint    x, y;
  gpointer pr;

  /* Get selection area */
  gimp_drawable_mask_bounds (drawable->drawable_id, &x1, &y1, &x2, &y2);
  has_alpha = gimp_drawable_has_alpha (drawable->drawable_id);

  red = 0; green = 1; blue = 2;

  alpha = (has_alpha) ? drawable->bpp - 1 : drawable->bpp;

  /* Initialize progress */
  progress = 0;
  max_progress = (x2 - x1) * (y2 - y1);

  /* substitute pixel vales */
  gimp_pixel_rgn_init (&src_rgn, drawable,
                       x1, y1, (x2 - x1), (y2 - y1), FALSE, FALSE);
  gimp_pixel_rgn_init (&dest_rgn, drawable,
                       x1, y1, (x2 - x1), (y2 - y1), TRUE, TRUE);


  int b,col;
  guchar mr,mg,mb;

  for (pr = gimp_pixel_rgns_register (2, &src_rgn, &dest_rgn);
       pr != NULL;
       pr = gimp_pixel_rgns_process (pr))
    {
      src = src_rgn.data;
      dest = dest_rgn.data;

      for (y = 0; y < src_rgn.h; y++)
        {
          s = src;
          d = dest;

          for (x = 0; x < src_rgn.w; x++)
            {

        	  b=0;
        	  mr=0; mg=0; mb=0;
        	  col=s[0];


        	  	  	  	  	  	 if((x*y)%3==0){
        	  						if(testBit(col, 3)){
        	  						b=0;
        	  						}else{
        	  							b=1;
        	  						}
        	  					}else if((x*y)%5==0){
        	  						if(testBit(col, 5)){
        	  							b=2;
        	  							}else{
        	  								b=3;
        	  							}
        	  					}else if((x*y)%7==0){
        	  						if(testBit(col, 7)){
        	  							b=4;
        	  							}else{
        	  								b=5;
        	  							}
        	  					}else{

        	  						if(testBit(col, 1)){
        	  							b=6;
        	  							}else{
        	  								b=7;
        	  							}

        	  					}

        	  	  	  	  	  	 	 	 	 	switch(b){

        	  	  	  	  						case 0:
        	  	  	  	  								mr=255; mg=0; mb=0;
        	  	  	  	  							break;
        	  	  	  	  						case 1:
        	  	  	  	  							mr=0; mg=255; mb=0;
        	  	  	  	  						break;
        	  	  	  	  						case 2:
        	  	  	  	  							mr=0; mg=0; mb=255;
        	  	  	  	  						break;
        	  	  	  	  						case 3:
        	  	  	  	  					mr=255; mg=255; mb=0;
        	  	  	  	  						break;
        	  	  	  	  						case 4:
        	  	  	  	  					mr=255; mg=0; mb=255;
        	  	  	  	  						break;
        	  	  	  	  						case 5:
        	  	  	  	  					mr=0; mg=255; mb=255;
        	  	  	  	  						break;
        	  	  	  	  						case 6:
        	  	  	  	  					mr=255; mg=255; mb=255;
        	  	  	  	  						break;
        	  	  	  	  						case 7:
        	  	  	  	  					mr=0; mg=0; mb=0;  	  	  	  	  						break;
        	  	  	  	  						default:
        	  	  	  	  							break;

        	  	  	  	  						}




              d[0] = mr;
              d[1] = mg;
              d[2] = mb;
              if (has_alpha){
                d[alpha] = s[alpha];
              }

              s += src_rgn.bpp;
              d += dest_rgn.bpp;
            }

          src += src_rgn.rowstride;
          dest += dest_rgn.rowstride;
        }

      /* Update progress */
      progress += src_rgn.w * src_rgn.h;

      gimp_progress_update ((double) progress / (double) max_progress);
    }

  /*  update the region  */
  gimp_drawable_flush (drawable);
  gimp_drawable_merge_shadow (drawable->drawable_id, TRUE);
  gimp_drawable_update (drawable->drawable_id, x1, y1, (x2 - x1), (y2 - y1));
}



static unsigned char testBit( int n, int pos )
	{
	  int mask = 1 << pos;
	  //return (n & 1<<pos) != 0;
	   return (n & mask) == mask;
	  // alternativ: return (n & 1<<pos) != 0;
	}





