/* 
GIMP Plug-in Laso
Ondrej Fiala

render.h

prakticky main

pouzit Plug-in template - Michael Natterer
*/

#ifndef __RENDER_H__
#define __RENDER_H__

/*  Public functions  */

void   render (gint32              image_ID,
	       GimpDrawable       *drawable,
	       PlugInVals         *vals,
	       PlugInImageVals    *image_vals,
	       PlugInDrawableVals *drawable_vals);


#endif /* __RENDER_H__ */
