/* 
GIMP Plug-in Laso
Ondrej Fiala

edge.h

edge detection module
*/

#ifndef __EDGE_H__
#define __EDGE_H__


/*  Public functions  */

guint** laplacian (guint **image_intensity_field, GimpDrawable *drawable);
gdouble** laplacian_normalized (guint **image_intensity_field, GimpDrawable *drawable);

#endif /* __EDGE_H__ */
