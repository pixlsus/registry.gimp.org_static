/* 
GIMP Plug-in Laso
Ondrej Fiala

snake.h

THE REAL MATH
*/

#ifndef __SNAKE_H__
#define __SNAKE_H__

#define Inf (1<<30)

// number of iterations when not specified by user
#define SNAKE_ITERATIONS 2000

#define SNAKE_POINT_MOVE_MIN	0.1

// minimal value for stopping (% of all points)
#define SNAKE_POINT_STAY_STOP	0.7

// maximal value for stopping (distance between old and new point position)
#define SNAKE_POINT_DIFF_STOP	0.25

gint snake_iterate(gint *num_gimp_points, gdouble **gimp_points, PlugInVals *vals, GimpDrawable *drawable);

#endif /* __SNAKE_H__ */
