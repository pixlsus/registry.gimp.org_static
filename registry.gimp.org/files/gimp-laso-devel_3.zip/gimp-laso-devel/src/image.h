/* 
GIMP Plug-in Laso
Ondrej Fiala

image.h

extraction informations from image
*/

#ifndef __IMAGE_H__
#define __IMAGE_H__

#define Inf (1<<30)

/* data structures */
#include "curve.h"

guint** image_intensity_field(GimpDrawable *drawable);
gdouble** image_intensity_field_normalized(GimpDrawable *drawable);

Point** image_gradient_field(gdouble** image_field_normalized, GimpDrawable *drawable);
Point** image_gvf(Point** image_gradient_normalized, gint iterations, gdouble mu, GimpDrawable *drawable);

void image_get_bound_points(gint* num_points, gdouble** points, GimpDrawable *drawable);

#endif /* __IMAGE_H__ */
