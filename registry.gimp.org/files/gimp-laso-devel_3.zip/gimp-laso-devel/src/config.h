/* config.h.in.  Generated from configure.in by autoheader.  */

/* always defined to indicate that i18n is enabled */
#undef ENABLE_NLS

/* The gettext translation domain. */
#define GETTEXT_PACKAGE "gimp20-plugin-laso"

/* Define to 1 if you have the `bind_textdomain_codeset' function. */
#undef HAVE_BIND_TEXTDOMAIN_CODESET

/* Define to 1 if you have the `dcgettext' function. */
#undef HAVE_DCGETTEXT

/* Define if the GNU gettext() function is already present or preinstalled. */
#undef HAVE_GETTEXT

/* Define to 1 if you have the <inttypes.h> header file. */
#undef HAVE_INTTYPES_H

/* Define if your <locale.h> file defines LC_MESSAGES. */
#undef HAVE_LC_MESSAGES

/* Define to 1 if you have the <locale.h> header file. */
#undef HAVE_LOCALE_H

/* Define to 1 if you have the <memory.h> header file. */
#undef HAVE_MEMORY_H

/* Define to 1 if you have the <stdint.h> header file. */
#undef HAVE_STDINT_H

/* Define to 1 if you have the <stdlib.h> header file. */
#undef HAVE_STDLIB_H

/* Define to 1 if you have the <strings.h> header file. */
#undef HAVE_STRINGS_H

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H "1"

/* Define to 1 if you have the <sys/stat.h> header file. */
#undef HAVE_SYS_STAT_H

/* Define to 1 if you have the <sys/types.h> header file. */
#undef HAVE_SYS_TYPES_H

/* Define to 1 if you have the <unistd.h> header file. */
#undef HAVE_UNISTD_H

/* Define to the address where bug reports for this package should be sent. */
#undef PACKAGE_BUGREPORT

/* Define to the full name of this package. */
#undef PACKAGE_NAME

/* Define to the full name and version of this package. */
#undef PACKAGE_STRING

/* Define to the one symbol short name of this package. */
#undef PACKAGE_TARNAME

/* Define to the version of this package. */
#undef PACKAGE_VERSION

/* Plug-In major version */
#undef PLUGIN_MAJOR_VERSION

/* Plug-In micro version */
#undef PLUGIN_MICRO_VERSION

/* Plug-In minor version */
#undef PLUGIN_MINOR_VERSION

/* Plug-In name */
#define PLUGIN_NAME "Laso plugin"

/* Plug-In version */
#define PLUGIN_VERSION "Version 1.0 2006-2010"

/* Define to 1 if you have the ANSI C header files. */
#undef STDC_HEADERS

#define LOCALEDIR gimp_locale_directory()

#define DATADIR "laso"

#define GIMP_PLUGIN_DEBUG "laso"

/* enabling internal debugging messages */
#define DEBUGGING 0

/* linker - cmd  /SUBSYSTEM:WINDOWS /ENTRY:mainCRTStartup */