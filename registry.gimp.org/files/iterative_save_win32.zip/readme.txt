ITERATIVE SAVE
plugin for GIMP 2.x
version 0.1
2009/09/25



0. About
_______________________________________________________________

Once installed, this plugin will add an 'Iterative Save' entry 
in your GIMP menu, under File -> Save. Using this with an 
image which has been previously saved as an XCF will now save 
the image with an added numeric suffix. The first time this 
feature is invoked, it will save your image as 
yourfile_0000.xcf; subsequent calls will continue to save the 
image with an increased numeric suffix (i.e. image_0001.xcf, 
image_0002.xcf, etc). 

Note that for safety reasons, this plugin will only work on 
XCF files. You can easily modify the source code to override
this limitation, but given the non-interative saving procedure,
that might not be a very good idea.



1. Installation
_______________________________________________________________

You can either use the included binary, or you can compile the
source code (iterative_save.c) yourself. 

If you wish to use the binary, then you need to copy this to 
the GIMP's 'plugins' directory. This will normally be at
'~/.gimp-x.x/plugins', where ~ is your home folder (or your 
user folder on Windows: 'C:\Users\yourusername' on Vista or 
'C:\Documents and Settings\yourusername' on Windows 2000).

If you wish to compile the source code, you can use the 
following command:

gimptool-2.0 --install iterative_save.c

This will create the binary and place it your home directory, 
under '~/.gimp-x.x/plugins'. 

Note that in order to use the gimptool-2.0 utility, you will
generally need to have the gimp-dev package installed on your
system. Installing this package may be as simple as using 
your package system (apt, Synaptic, yum, etc), or it may be 
more convoluted (under Windows, for example). 



2. Credits
_______________________________________________________________

This plugin was created by Mircea Purdea, and is distributed 
under an Apache license. You are welcome to use and modify it 
as you see fit.

Note that this plugin is distributed "AS IS". No warranty of 
any kind is expressed or implied. You use it at your own risk. 
The author will not be liable for data loss, damages, loss of 
profits or any other kind of loss while using or misusing 
this software.