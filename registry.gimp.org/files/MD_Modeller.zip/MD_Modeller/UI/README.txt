README

MD Modeller ver 0.09 for Linux Gimp, Qt.

(C) 2010-2011 Ivan Makarov. Yevheniia Holovchanska
Email: ivmakarov@yahoo.com


This program is designed to demostrate clothes modeling process using the same basic model and set of details. it was created for demonstration purposes.

tested in openSUSE 11.4, gimp 2.6.11, Python 2.7, Qt 4.7.1
	  ubuntu 11.3, gimp 2.6, Python 2.7, Qt 4.7


Installation and use:

first download file MD_Modeller.zip
and extract it to a catalog in your home directory:

> unzip MD_Modeller.zip

then cd to this directory and to UI subdirectory:

> cd MD_Modeller\UI\

Then start Gimp from there:

> gimp&

then go to Filters/Pyhon-fu/Console and start it.

in the opened consol window type ( substitute "username" for your home directory name ) :

execfile("/home/username/MD_Modeller/UI/CD2QtGui5.py");

in the opened window select front, sleeve, collar and decoration detail. selection must be done from up to down selecting each time only 1 detail.
then press the "Draw" button and see the model appearing in the new gimp window, if the details are compatible. 
in the same time this image is saved in the UI direstory under the name "model_listeddetails.xcf"

if you press "Random" button then the random set of details would be checked for compatibility and drowen in the new gimp window.

to finish you work just press the "close" button on the phyton console window.


the program also includes bash detail counting script:

to count all possible detail combinations in this set you can start from the Bash  terminal the next script:

> python CD6sc_co1.py 

and get the number of all possible combinations in this set.




Problems.


closing the application window cause the message in the gimp error console:   "  GIMP Error Plug-in crashed: "python-console.py" (/usr/lib64/gimp/2.0/plug-ins/python-console.py)

The dying plug-in may have messed up GIMP's internal state. You may want to save your images and restart GIMP to be on the safe side."

this problem appears only when you are closing the window after you have finished your work so, you can just close the phyton console window as suggested.

scrolling the phyton console causes the console and application crash so better do not touch it when working with the program.





