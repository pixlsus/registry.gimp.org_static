#include <iostream>
#include <conio.h>
#include <fstream>
#include <string>
#include <time.h>

#define min(a,b) (a<b?a:b)
#define max(a,b) (a>b?a:b)

double r = -1;
double g = -1;
double b = -1;

bool w = false;
int tryb2 = 0;

std::string GetRandomColor(){
	double r = 0, g = 0, b = 0;

	r = (double)rand()/RAND_MAX;
	if(tryb2 == 1){
		g = b = r;
	}else{
		g = (double)rand()/RAND_MAX;
		b = (double)rand()/RAND_MAX;
	}

	char buf[255];

	sprintf(buf,"%f %f %f 1.0000",r,g,b);

	std::string s(buf);

	return s;
}

std::string GetRandomColor2(){
	w = true;
	r = (double)rand()/RAND_MAX;
	if(tryb2 == 1){
		g = b = r;
	}else{
		g = (double)rand()/RAND_MAX;
		b = (double)rand()/RAND_MAX;
	}

	char buf[255];

	sprintf(buf,"%f %f %f 1.0000",r,g,b);

	std::string s(buf);

	return s;
}

std::string GenerateRecordLine(float lPos,float cPos, float rPos){
	char buf[1024];
	sprintf(buf, "%f %f %f %s %s 0 0 0 0%c",lPos, cPos, rPos, GetRandomColor().c_str(), GetRandomColor().c_str(),char(10u));

	return std::string(buf);
}

std::string GenerateRecordLine2(float lPos,float cPos, float rPos){
	char buf[1024];
	if(!w)
		sprintf(buf, "%f %f %f %s %s 0 0 0 0%c",lPos, cPos, rPos, GetRandomColor2().c_str(), GetRandomColor2().c_str(),char(10u));
	else{
		double r2 =r, g2 = g, b2 = b;	
		sprintf(buf, "%f %f %f %f %f %f 1.0000 %s 0 0 0 0%c",lPos, cPos, rPos, r2, g2, b2, GetRandomColor2().c_str(),char(10u));
	}

	return std::string(buf);
}

std::string GenerateRecordLine3(float lPos,float cPos, float rPos){
	char buf[1024];
	std::string s =  GetRandomColor2().c_str();
	sprintf(buf, "%f %f %f  %s %f %f %f 1.0000 0 0 0 0%c",lPos, cPos, rPos, s.c_str(), r, g, b,char(10u));

	return std::string(buf);
}

int main(){
	srand((unsigned)time( NULL ));

	std::cout<<"Application randomGradient made by Krzysztof Zajaczkowski\n designed to automatic generate of random gradients consisting\n many  ranges specifically for the program GIMP."<<std::endl<<
		"Licence: GPL"<<std::endl<<
		"Contakt: ProgrammingMalyszKZ@wp.pl"<<std::endl<<"Designed in: Dev C++\n\n";


	std::cout<<"========================================\n"<<"PL: Podaj z ilu przedzialow bedzie skladal sie gradient (liczba z zakresu od 2 do 500);\nEN: Enter with as many ranges will consist of a gradient (number from 2 to 500): ";
	int rekordy = 2;
	std::cin>>rekordy;

	rekordy = min(max(rekordy,2),500);  // if You dont write correct number, then I must correct that

	std::cout<<"========================================\n"<<"PL: Wybierz tryb gradientu:"<<std::endl<<"1 - losowanie kolor�w po obu stronach przedzia��w;"<<std::endl<<"2 - kolory po obu stronach przedzia��w takie same"<<std::endl<<"3 - kolory po lewej i prawej stronie przedzialu beda takie same (powstana paski jednolitych kolorow)"<<std::endl;
	std::cout<<"EN: Select the gradient mode:"<<std::endl<<"1 - random colors on both sides of the ranges;"<<std::endl<<"2 - colors on both side of ranges will be the same"<<std::endl<<"3 - colors on left and right side of ranges will be the same (rise up strips of uniform colors)"<<std::endl;

	int tryb = 0;

	std::cin>>tryb;

	std::cout<<"========================================\n"<<"PL: Jesli chcesz gradient w skali odcieni szarosci wybierz 1, w przeciwnym razie wybierz 2;\nEN: If You want gradirnt in gray scale type 1, otherwise type 2: "<<std::endl;

	std::cin>>tryb2;

	std::cout<<"========================================\n"<<"PL: Podaj lokalizacje i nazwe pliku (bez zadnych spacji i z rozszerzeniem .ggr);\nEN: Type localization and file name (without spaces and with the extension .ggr): ";

	char location[256];

	std::cin>>location;

	std::fstream file2(location,std::ios_base::out);

	std::cout<<"========================================\n"<<"PL: Podaj nazwe wewnetrzna gradientu (bez spacji):\nEN: Type name of gradient, that was appears in gimp (no space):";

	char name[256];

	std::cin>>name;

	switch(tryb){
		case 1:
			{
	
				if(!file2.fail()){
					std::string buffor("GIMP Gradient");
					buffor += char(10u);
					buffor += "Name: ";
					buffor += name;
					buffor += char(10u);
					char buf[100];
					sprintf(buf, "%i",rekordy);
					buffor += buf;
					buffor += char(10u);
					double steep = 1.0 / (double)rekordy;
					for(int i =0; double(i) * steep < 1.0; i++){
						buffor += GenerateRecordLine(double(i) * steep, double(i) * steep + 0.5 * steep,double(i) * steep + steep);
					}
					file2.write(buffor.c_str(),buffor.size());
				}
			}
			break;
		case 2:
			{
				if(!file2.fail()){
					std::string buffor("GIMP Gradient");
					buffor += char(10u);
					buffor += "Name: ";
					buffor += name;
					buffor += char(10u);
					char buf[100];
					sprintf(buf, "%i",rekordy);
					buffor += buf;
					buffor += char(10u);
					float steep = 1.0 / (double)rekordy;
					for(int i =0; double(i) * steep < 1.0; i++){
						buffor += GenerateRecordLine2(double(i) * steep, double(i) * steep + 0.5 * steep,double(i) * steep + steep);
					}
					file2.write(buffor.c_str(),buffor.size());
				}
			}
			break;
		case 3:
			{
				if(!file2.fail()){
					std::string buffor("GIMP Gradient");
					buffor += char(10u);
					buffor += "Name: ";
					buffor += name;
					buffor += char(10u);
					char buf[100];
					sprintf(buf, "%i",rekordy);
					buffor += buf;
					buffor += char(10u);
					float steep = 1.0 / (double)rekordy;
					for(int i =0; double(i) * steep < 1.0; i++){
						buffor += GenerateRecordLine3(double(i) * steep, double(i) * steep + 0.5 * steep,double(i) * steep + steep);
					}
					file2.write(buffor.c_str(),buffor.size());
				}
			}
			break;
		}

	file2.close();


	getch();
	return 0;
}
