                           Stit-ch-art 2.0

Contents
--------

Overview
Distribution package
Installation
Usage
Nuances
History
Licence
Copyright


Overview
--------

The Stit-ch-art is a script-fu extension for the GIMP. Stit-ch-art creates
a cross-stitching chart based on a given image. It applies the modified
Madeira palette with 256 colors on the copy of the image, and then scans
it pixel by pixel for color codes while generating black and white chart
ready for printing (includes color legend from Madeira).

Please note, that it may take a while for generating the chart for images
of sizes 50*50 and larger. A handiwork of something about 200*150 stitches
should be considered as very large, and may require months of actual
stitching.

Distribution package
--------------------

The package consists of the following files:
- Stitchart.scm - the script itself;
- Madeira.gpl - the standard Madeira palette;
- Madeira256.gpl - a shrinked down to 256 colors version of Madeira;
- readme.txt - this file;

Installation
------------

Just copy Madeira.gpl and Madeira256.gpl files into "palettes" folder of
your instance of the GIMP. Then copy stitchart.scm file into "scripts"
folder of the GIMP and restart the GIMP, if it was running.

Usage
-----

1. Using the GIMP open an image which you would like to cross-stitch.

2. Scale the image down to the size of the planned handiwork.

Please note, that 1 pixel is equal to 1 stitch, so the new dimentions of
the image in pixels should correspond to the size of the handiwork in
stitches.

Usually cross-stitches are not larger than 200*150, most often it is about
50*40 stitches. So, this is a good choice for resizing initial image to
similar dimentions. While resizing the image, do not forget to preserve
aspect ratio, if you do not really need to change it otherwise.

More pixels/stitches you decided to generate, more time the generation will
take.

3. Invoke the command "Script-Fu/Alchemy/Stit-ch-art..." in the image menu.

4. Adjust the script settings, as you wish, and press OK.

The script will produce a new image with a cross-stitch chart and a color
legend aside. The operation may take a while, depending from the size
of the image.

Nuances
-------

The script does not scale images in the same process and requires a user
to do so him/her-self beforehand. This is because the resizing can be
performed in a different manner, and many options may affect the result.
The GIMP's built-in facilities for resizing images are much better than
that the script could afford via the restricted script settings dialog.

There is a known problem with the GIMP while using indexed images. It only
allows for working with indexed images in palettes, which have less than
257 colors. Unfortunately, Madeira palette has 369 colors by default. In
order to use a part of Madeira colors in the GIMP, the original Madeira
palette should be shrinked to 256 colors. Which colors to keep in the
shrinked version, and which to omit, is up to a user. Once we have
369 colors, there will possibly be easy to find some of them, which are not
important or can be substituted with other near colors. The package contains
one of such shrinked palettes, namely Madeira256.gpl. It is ready for use,
but if some missing color is really needed for a particular picture, you
can create another shrinked pallete from Madeira.gpl or edit Madeira256.gpl -
they are simple text files with obvious syntax. While doing alterations in
the palettes, do not edit colors themselves, but simply include or exclude
entire lines, leaving all numbers intact.

In the settings dialog of the script do never enter palettes with more than
256 colors.

The selected maximum number of colors will not necessarily be used in the
output. A rule of thumb states that the maximum number of colors should be
selected at least as twice the number of actual colors to be used in
a handiwork.

There is no precise answer for this question because the quality of
color mapping to the Madeira palette depends, to a great extent, from
the image peculiarities.

If the image can be properly mapped to a given palette by means
of lesser number of colors, or - just the contrary - if a palette lacks
many close tinges, which exist in the image, then the number of used colors
are smaller than the maximum. First, switch the option "Automatic number
of colors" on and see what number of colors is used in the output. If it
is too many, then switch the option off and set the maximum number to 256,
and then iteratively reduce it, until the number of actually used colors
meets your needs.

On the generated chart, first 50 colors are denoted by single symbols,
all the others are denoted by their ordinal numbers, starting from 51.

Play with font size settings to get most readable notation on the chart.

If the ouput is too large, you can split it into several images before
printing.

History
-------

21/August/2006 - version 1.0 official release with unknown bugs.
02/May/2010 - version 2.0 has been built for compatibility with GIMP 2.6

Licence
-------

This program is free software. You can redistribute and use it freely.
If you want to use the sources in derived products and/or modify
the script for your own purposes, you must keep the original
copyright statement.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY, without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

Copyright
---------

Copyright (c) 2006-2010, Stanislav Korotky, stasson@orc.ru
