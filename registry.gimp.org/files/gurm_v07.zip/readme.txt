# GIMP Unified Resource Manager (GURM)
# The idea for GURM is based on the Brush Manager by Sean Bogie
# You can find the original Brush Manager here:
# http://myweb.msoe.edu/~bogies/brushmanager/

# Please be sure to read this README before you use the plug-in

# GURM was done by Sagenlicht from Cartographers Guild
# http://cartographersguild.com

# Its name did it get from Rob Antonishen
# http://ffaat.pointclark.net

# Version 0.7

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

Table of Content

1. What is GURM
2. Initial Setup
3. How to use it
4. What GURM cant do
5. Error Handling
6. Plans for the Future

1. What is Gurm
Gimp Unified Resource Manager (or short GURM) is a python script and plug-in for GIMP.
GURM allows you to handle the addition and removal of resources in GIMP via a
small GUI. Currently you can handle Brushes, Gradients, Palettes, Patterns and Script-Fu.

2. Initial Setup
2.1 "Installation"
	* Copy the gurm.py into your plug-ins folder, which is *normaly* located at:
	"C:\Documents and Settings\<Your windows user>\<your gimp version>\plug-ins", e.g.
	"C:\Documents and Settings\Paula Smith\gimp-2.6\plug-ins"
	* Copy the gurm.ini wherever you want to, I would recommend to copy it to the same folder.
2.2 Prepare the python script
	Open the gurm.py and edit the path in the third row. It has to be the path to
	where you did copy the gurm.ini and the gurm.ini at the end of the path. 
	You have to use quotations, it needs to look like this:
	GURMINI = "C:\Documents and Settings\Paula Smith\gimp-2.6\plug-ins\gurm.ini"
	If you are a windows user and dont have any special editors like notepad++, I would
	recommend to open the gurm.py with wordpad not with notepad.
2.3 Prepare the gurm.ini
	Open the gurm.ini. Again if you dont have any special editors, use wordpad.
	What do you have to do in the gurm.ini? For every manager type you have to edit the
	"gimpPath" and the "userPath".
2.3.1 The gimpPath
	You have to add the path to your GIMP resource folder of the specific manager. 
	Please be sure to NOT use quotations in this file.
	Example: You want to edit the Brush Manager gimpPath. It would look like:
	C:\Documents and Settings\<Your windows user>\<your gimp version>\brushes, e.g.:
	C:\Documents and Settings\Paula Smith\gimp-2.6\brushes
2.3.2 The userPath
	The userpath is the path where you store all of your files for that manager. You
	can create this folder wherever you want to, e.g. in your own documents. You have
	to create this path in the filesystem on your own. Just open the explorer and
	browse to the location you want to store them and create your folder. Afterwards
	you have to add that path to the userPath in the gurm.ini.
	Example: Lets asume that Paula Smith has decided to create following folder
	"D:\GIMP\Brushes" for her brushes. She then adds the path to the gurm.ini, again without
	quotations. It would look like this:
	D:\GIMP\Brushes
	She then does the same with her other resources and adds them as well.
2.4 Prepare the user folders
	Now browse again to the user folders you just created. You will need to add more folders.
	For every set you plan to use at once you have to create one more folder. Again I will
	use an example to explain it.
	Lets assume Paula wants to use 4 different brush sets:
	One for grundge brushes, one for frame brushes, one for symbols and one for all her
	other brushes.
	She then browses to her user folder D:\GIMP\Brushes and creates 4 new folders in that
	directory: Grundge, Frames, Symbols and Other. 
	She does the same for her other resources (Gradients, Palettes, Patterns and Script-Fu).
2.5 Prepare GIMP
	I assume that at the moment you have a lot of resources allready in your GIMP folders.
	You have to clear them before we can start use GURM. Now before you do anything I would
	recommend you to backup your GIMP resource folders (brushes, gradients, palettes,
	patterns and Script-Fu).
	Once you did this start moving your files to the folders you just created.
	Another example:
	Paula now moves all of her brushes from 
	C:\Documents and Settings\Paula Smith\gimp-2.6\brushes to her user folders,
	the grundge brushes to D:\GIMP\Brushes\Grundge, the frame brushes to
	D:\GIMP\Brushes\Frames etc. She does this until all of her GIMP resource folders
	are empty.
2.6 useManager 
	If you dont wanna use one of the managers GURM provides, simply replace the "yes"
	with a "no" in the useManager row of the Manager.
	Example: You dont wanna use the palette Manager:
	Open the gurm.ini file and browse to [Palette Manager], the next line should be
	useManager = yes. Simply overwrite yes with no and GURM does not use it
	anymore. Of course you dont have to set any paths for the Palette Manager now.
	If you want to use it again, just overwrite the no with a yes again. Be sure
	not to use quotations.
	
Now the initial setup is finished. I admit it reads way more complicated than it
actually is :)

3 How to use it
3.1 Use it while you have GIMP opened
	You find the plug-in directly in the "Filters" menu. Just click on it
	and GURM opens. 
	GURM is pretty much self-explanatory. Just click
	on the set you want to use and click ok. GURM then copies the needed
	files for you and refreshes your resource list in GIMP.
	If you want to remove a set just click again on the set and then on
	ok. GURM again, will remove the no longer needed files and refreshes
	your resource list in GIMP.
3.2 Use it without GIMP opened
	The script runs as well without GIMP opened. It works exactly the
	same way as with GIMP opened except it wont refresh your resource
	list, though there aint a need for it ;)

4 What GURM cant do
	GURM does not handle zip-archives atm, so if you used Sean Bogies
	Brush Manager and did zip all your resources you either need to
	unzip them or keep on using Seans tool. I plan to add the zip
	feature in the future.
	GURM cant handle any user setup errors atm. If you mess up the 
	gurm.ini GURM will most likely wont work. Please be sure
	to check what you do in the gurm.ini. GURM only checks for
	valid paths, nothing else. Yes I know this needs to be changed 
	and is on my to do list.
	
5 Error Handling
	If GURM does not copy anything, but everything else seems to
	work fine, check if you have the needed file rights. 
	You need to have write rights on the gimpPaths. 
	Windows users should not have to worry about this, but
	if you are a linux user you maybe have to do a chmod.
	You just need read rights on the userPaths.
	Same holds true if GURM does not write anything back
	into the gurm.ini. Please check if you have the
	proper file rights and if the file is write-protected.
	Remove the write-protected status if needed.
	If GURM does strange things I bet you messed up
	the gurm.ini. Better use a fresh one.

6 Plans for the Future
	- Adding an improved error handling (Check if gurm.ini was messed up)
	- Write an installer for easier initial setup 
	
I hope you find GURM useful. Thanks for using it :)
If you have any comments, remarks, ideas for improvement, found bugs
or just find it useful, let me know it :)
