/*
 * This is copyrighted software.  Originally uploaded at the GIMP Plugin
 * Registry (http://registry.gimp.org/).  This is to be distributed
 * ("conveyed") under the terms of version 3 of the GNU General Public License
 * (no other version, see the file "COPYING" for details).  THERE IS NO IMPLIED
 * WARRANTY FOR THIS PROGRAM.  USE AT YOUR OWN RISK.  For inquiries, email the
 * author at stamit@stamit.gr .  You may not remove this notice.
 */
#ifndef __INTERFACE_H__
#define __INTERFACE_H__

#include "main.h"


gboolean dialog(gint32 image_ID, GimpDrawable *drawable, PlugInVals *vals, PlugInUIVals *ui_vals);

#endif /* __INTERFACE_H__ */
