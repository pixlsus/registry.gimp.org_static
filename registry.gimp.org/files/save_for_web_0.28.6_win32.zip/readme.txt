Save for Web plug-in for The Gimp 2.6
**************************************

Save for Web allows to find compromise between minimal file size and acceptable quality of image quickly. While adjusting various settings, you may explore how image and file size change. Options to decrease image file size include setting quality, number or colors, resizing, cropping, Exif information removal, etc. 

********************
*** Requirements ***
********************

The Gimp version 2.4 or later.

********************
*** Installation ***
********************

Copy webexport.exe file to your personal plug-ins folder:

C:\Documents and Settings\<username>\.gimp-2.6\plug-ins

(Here <username> - name of your user account).

********************
*** Source code  ***
********************

If you want to change the program and get the source code, you can download it from http://registry.gimp.org (from the same page where you found this package).