#!/usr/bin/python
# -*- coding: utf8 -*-
'''
Indexprint plugin for Gimp

Elmar Sullock Enzlin at moroquendo@gmail.com
(C) 2009, ..., 2012 Utrecht, The Netherlands
'''

__all__ = ["gui", "GenerateIndexprint" ]

