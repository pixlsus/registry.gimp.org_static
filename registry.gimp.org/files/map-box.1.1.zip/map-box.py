import sys
from gimpfu import *
from math import *
from pprint import pprint, pformat

import pygtk
pygtk.require('2.0')
import gtk
import base64

class BoxDialog(gtk.Dialog):
    data =["95 124 215 2","       c None",".      c #000000","+      c #9F9F9F","@      c #B3B3B3","#      c #8F8F8F","$      c #BDBDBD","%      c #FCFCFC","&      c #FFFFFF","*      c #B0B0B0","=      c #F1F1F1","-      c #A6A6A6",";      c #DDDDDD",">      c #FEFEFE",",      c #989898","'      c #C8C8C8",")      c #FDFDFD","!      c #858585","~      c #B8B8B8","{      c #F8F8F8","]      c #ACACAC","^      c #E9E9E9","/      c #A2A2A2","(      c #D3D3D3","_      c #919191",":      c #C0C0C0","<      c #7B7B7B","[      c #F2F2F2","}      c #A8A8A8","|      c #E1E1E1","1      c #9B9B9B","2      c #CCCCCC","3      c #898989","4      c #BCBCBC","5      c #F5F5F5","6      c #AEAEAE","7      c #EBEBEB","8      c #CECECE","9      c #686868","0      c #767676","a      c #BABABA","b      c #EDEDED","c      c #A3A3A3","d      c #D8D8D8","e      c #DEDEDE","f      c #8A8A8A","g      c #474747","h      c #242424","i      c #464646","j      c #E2E2E2","k      c #949494","l      c #C5C5C5","m      c #E7E7E7","n      c #6E6E6E","o      c #101010","p      c #030303","q      c #626262","r      c #DFDFDF","s      c #808080","t      c #B6B6B6","u      c #F4F4F4","v      c #C9C9C9","w      c #6B6B6B","x      c #131313","y      c #0C0C0C","z      c #606060","A      c #BEBEBE","B      c #AAAAAA","C      c #E3E3E3","D      c #E0E0E0","E      c #282828","F      c #9D9D9D","G      c #CFCFCF","H      c #414141","I      c #020202","J      c #2C2C2C","K      c #E4E4E4","L      c #F9F9F9","M      c #D5D5D5","N      c #FBFBFB","O      c #B9B9B9","P      c #5B5B5B","Q      c #0A0A0A","R      c #161616","S      c #6F6F6F","T      c #CDCDCD","U      c #8B8B8B","V      c #DCDCDC","W      c #616161","X      c #2A2A2A","Y      c #888888","Z      c #757575","`      c #1B1B1B"," .     c #070707","..     c #555555","+.     c #FAFAFA","@.     c #939393","#.     c #454545","$.     c #A7A7A7","%.     c #F0F0F0","&.     c #363636","*.     c #2D2D2D","=.     c #3B3B3B","-.     c #999999",";.     c #EFEFEF",">.     c #ABABAB",",.     c #AFAFAF","'.     c #CACACA",").     c #A9A9A9","!.     c #A4A4A4","~.     c #BBBBBB","{.     c #515151","].     c #060606","^.     c #1E1E1E","/.     c #B2B2B2","(.     c #EEEEEE","_.     c #9E9E9E",":.     c #D1D1D1","<.     c #ECECEC","[.     c #959595","}.     c #373737","|.     c #787878","1.     c #A5A5A5","2.     c #E5E5E5","3.     c #D7D7D7","4.     c #7D7D7D","5.     c #717171","6.     c #ADADAD","7.     c #D9D9D9","8.     c #B1B1B1","9.     c #BFBFBF","0.     c #A0A0A0","a.     c #C3C3C3","b.     c #C4C4C4","c.     c #9C9C9C","d.     c #DADADA","e.     c #DBDBDB","f.     c #B7B7B7","g.     c #B5B5B5","h.     c #C7C7C7","i.     c #D2D2D2","j.     c #D4D4D4","k.     c #D6D6D6","l.     c #E6E6E6","m.     c #5C5C5C","n.     c #575757","o.     c #F6F6F6","p.     c #2F2F2F","q.     c #1C1C1C","r.     c #5D5D5D","s.     c #707070","t.     c #585858","u.     c #3A3A3A","v.     c #4B4B4B","w.     c #909090","x.     c #141414","y.     c #151515","z.     c #5E5E5E","A.     c #343434","B.     c #3D3D3D","C.     c #929292","D.     c #232323","E.     c #656565","F.     c #838383","G.     c #121212","H.     c #424242","I.     c #7C7C7C","J.     c #323232","K.     c #818181","L.     c #4F4F4F","M.     c #CBCBCB","N.     c #7A7A7A","O.     c #181818","P.     c #252525","Q.     c #6A6A6A","R.     c #565656","S.     c #C6C6C6","T.     c #8E8E8E","U.     c #191919","V.     c #393939","W.     c #747474","X.     c #C2C2C2","Y.     c #0D0D0D","Z.     c #696969","`.     c #0E0E0E"," +     c #8C8C8C",".+     c #010101","++     c #6D6D6D","@+     c #D0D0D0","#+     c #F7F7F7","$+     c #6C6C6C","%+     c #EAEAEA","&+     c #636363","*+     c #050505","=+     c #3F3F3F","-+     c #171717",";+     c #9A9A9A",">+     c #353535",",+     c #303030","'+     c #272727",")+     c #868686","!+     c #222222","~+     c #8D8D8D","{+     c #262626","]+     c #E8E8E8","^+     c #F3F3F3","/+     c #292929","(+     c #313131","_+     c #444444",":+     c #7F7F7F","<+     c #979797","[+     c #C1C1C1","}+     c #B4B4B4","|+     c #878787","1+     c #969696","2+     c #777777","                                                                                                                                                                                              ","                                                                                                                                                                                              ","                                                                                                                                                                                              ","                                                                                                                                                                                              ","                  . .                                                                                                                                                           . .           ","              . . .                                                                                                                                                           . . . .         ","            . .                                                                                                                                                             . . . . .         ","        . . .                                                                                                                                                               . .   . .         ","        . .                                                                                                                                                               . .     . .         ","        . .                                                                                                                                                             . .       . .         ","        . .     . . .                                                                                                                                                   .         . .         ","        . . . . . . . .                                                                                                                                                 .         . .         ","        . . .       . .                                                                                                                                                 . . .     . .         ","        .           . .                                                                     + @ +                                                                           . . . . .         ","                    . .                                                                 # $ % & % $ #                                                                           . . .         ","                    . .                                                               * = & & & & & = *                                                                           . . .       ","                    .                                                             - ; > & & & & & & & > ; -                                                                       . . . .     ","                  . .                                                         , ' ) & & & & & & & & & & & ) ' ,                                                                   . .         ","                . .       . .                                             ! ~ { & & & & & & & & & & & & & & & { ~ !                                                               . .         ","              . .         . . . .                                       ] ^ & & & & & & & & & & & & & & & & & & & ^ ]                                           . .                 .         ","        . . . .               . . .                                 / ( > & & & & & & & & & & & & & & & & & & & & & > ( /                                   . . . .                           ","        . .                     . . . .                         _ : % & & & & & & & & & & & & & & & & & & & & & & & & & % : _                             . . .                               ","                                    . . .                   < @ [ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & [ @ <                     . . . .                                 ","                                      . . .               } | & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & | }                 . . .                                     ","                                          .           1 2 ) & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & ) 2 1           . . .                                       ","                                                  3 4 { & & & & & & & & & & & & & & & & & & & & & & 5 % & & & & & & & & & & & & & & & { 4 3                                                   ","                                                6 7 & & & & & & & & & & & & & & & & & & & & & & & 8 9 0 a b > & & & & & & & & & & & & & & 7 6                                                 ","                                            c d > & & & & & & & & & & & & & & & & & & & & & & & & e f g h i # j & & & & & & & & & & & & & & > d c                                             ","                                        k l % & & & & & & & & & & & & & & & & & & & & & & & & & & & > m n o p q r & & & & & & & & & & & & & & & % l k                                         ","                                    s t u & & & & & & & & & & & & & & & & & & & & & & & & & & & & > v w x y z A > & & & & & & & & & & & & & & & & & u t s                                     ","                                  B C & & & & & & & & & & & & & & & & & & & & & & & & & & & & & D ! E p i c u & & & & & & & & & & & & & & & & & & & & & C B                                   ","                              F G > & & & & & & & & & & & & & & & & & & & & & & & & & & & & [ + H I J 3 K & & & & & & & & & & & & & & & & & & & & & & & & > G F                               ","                          f A L & & & & & & & & & & & & & & & & & & & & & & & ; M > & & N O P Q R S T > & & & & & & & & & & & & & & & & & & & & & & & & & & & L A f                           ","                          U V & & & & & & & & & & & & & & & & & & & & & & & e W X Y j ( Z `  ...@ +.& & & & & & & & & & & & & & & & & & & & & & & & & & & & & & ; @.#.                        ","                          $.$.B %.& & & & & & & & & & & & & & & & & & & & & > v w R &.*.. =.-.;.& & & & & & & & & & & & & & & & & & & & & & & & & & & & & & %.>.,.'.).                        ","                          j L ,.!.~.+.& & & & & & & & & & & & & & & & & & & & & L ,.{.].^.-.% & & & & & & & & & & & & & & & & & & & & & & & & & & & & & +.~.B /.% & ).                        ","                          j & & (.} _.:.> & & & & & & & & & & & & & & & & & & & & & <.[.}.^.|.m & & & & & & & & & & & & & & & & & & & & & & & & & & > :.1.] [ & & & ).                        ","                          j & & & & :.$./ 2.& & & & & & & & & & & & & & & & & & & & & & 3.4.5.| & & & & & & & & & & & & & & & & & & & & & & & & & 2.1.6.7.& & & & & ).                        ","                          j & & & & & > t c 8.5 & & & & & & & & & & & & & & & & & & & & & ) L & & & & & & & & & & & & & & & & & & & & & & & & 5 8.] 9.& & & & & & & ).                        ","                          j & & & & & & & u ).0.a.% & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & % b.$.6 L & & & & & & & & ).                        ","                          j & & & & & & & & & C } c.d.> & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & > e.!.6.^ & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & : c } b & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & b B 6.T & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & N * 0.~ +.& & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & +.~ B f.> & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & b - c.2 > & & & & & & & & & & & & & & & & & & & & & & & & & & & & & > 2 - 6.u & & & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & & ( 1.0.C & & & & & & & & & & & & & & & & & & & & & & & & & & & C $.6 r & & & & & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & & & ) g.0.6 u & & & & & & & & & & & & & & & & & & & & & & & u * 6 a.& & & & & & & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & & & & & u B F 9.% & & & & & & & & & & & & & & & & & & & % 9.)./.% & & & & & & & & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & & & & & & & C 1.1 M > & & & & & & & & & & & & & & & > M } 6 (.& & & & & & & & & & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & & & & & & & & & a.0.- 7 & & & & & & & & & & & & & 7 B ,.M & & & & & & & & & & & & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & & & & & & & & & & L 6 _.g.+.& & & & & & & & & +.g.,.$ & & & & & & & & & & & & & & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & > & & & & & & & & & & & & & & (.- c.' > & & & & & > h.] * { & & & & & & & & & & & & & & & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & N i.j.b ) & & & & & & & & & & & & & k./ + r > & > r >.,.l.& & & & & & & & & & & & & & & & & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & <.m.E n./ ^ & & & & & & & & & & & & & ) O _.>.<.,.* 2 & & & & & & & & & & & & & & [ m o.& & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & = s #.p.q.r.G & & & & & & & & & & & & & & u } s.,.) & & & & & & & & & & & & & (.c t.u.|.b & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & > = b d.-.&.v.G & & & & & & & & & & & & & & +.w.(.& & & & & & & & & & & & & b.m.x.y.I x.~ & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & : =.z.^ & & & & & & & & & & & & & +._ (.& & & & & & & & & & & N 1.A.B.C.f.v. ./ & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & & c D./ ) & & & & & & & & & & & & +._ (.& & & & & & & & & & > /.h E.( ) & F.G.@ & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & & l.H.n.(.& & & & & & & & & & & & +._ (.& & & & & & & & & & ) 1 I.7 & & % 0 J.e.& & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & & 5 z J 3.& & & & & & & & & & & & +._ (.& & & & & & & & & & > l.[ & & & | H.K.N & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & & <.L.q.M.& & & & & & & & & & & & +._ (.& & & & & & & & & & & > & & & %.N.{.k.& & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & +.F O.P.:.& & & & & & & & & & & & +._ (.& & & & & & & & & & & & & > T Q.y h R.S.& & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & m T.D.. m.<.& & & & & & & & & & & & +._ (.& & & & & & & & & & & & > ,.*.U.V.q.. W.{ & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & L X.z.Y.p #.l & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & % w.Z.X.%.+ `.m.u & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & > j  +*..+O.++@+& & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & > 7 #+& & M.O.$+{ & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & %+&+y *+=+/ ;.& & & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & & & & @ -+;+> & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & e >+p v.@+) & & & & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & & & L ++J.M & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & u w.,+'+)+d.> & & & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & & & c !+~+) & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & +.'.S {+H _.]+& & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & > u ;+'+Q.b & & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & ^+t R.^.R.f.+.& & & & & & & & & & & & +._ (.& & & & & & & & & & > ^ D g.&+` S 2.& & & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & ^ ;+B.,+h.& & & & & & & & & & & & +._ (.& & & & & & & & & & %.w /+y.(+k [ & & & & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & & ) k.U G & & & & & & & & & & & & +._ (.& & & & & & & & & & %.&+_+Y i.& & & & & & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & & & & #++.& & & & & & & & & & & & +._ (.& & & & & & & & & & > j b > & & & & & & & & & & & & & & & & & & & ).                        ","                          j & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & 1.                        ","                          9.{ & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & & & & & & & & & & & & & & & & & & { '.:+                        ","                            $.M > & & & & & & & & & & & & & & & & & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & & & & & & & & & & & & & & & & ) 7.0.                            ","                                t 2.& & & & & & & & & & & & & & & & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & & & & & & & & & & & & & & & 2.6                                 ","                                  Y a.#+& & & & & & & & & & & & & & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & & & & & & & & & & & & & = $ )+                                  ","                                      0.@+% & & & & & & & & & & & & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & & & & & & & & & & & +.T <+                                      ","                                          ,.V & & & & & & & & & & & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & & & & & & & & & > e.!.                                          ","                                            N.~ ;.& & & & & & & & & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & & & & & & & & ]+@                                               ","                                                [.' +.& & & & & & & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & & & & & & u [+3                                                 ","                                                    $.k.> & & & & & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & & & & % 8 c.                                                    ","                                                        }+2.& & & & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & & & e.B                                                         ","                                                          |+A #+& & & & & & & & & & & & & & +._ (.& & & & & & & & & & & & & & <.~ |.                                                          ","                                                              _.G ) & & & & & & & & & & & & +._ (.& & & & & & & & & & & & { a.#                                                               ","                                                                  ,.e.& & & & & & & & & & & +._ (.& & & & & & & & & & ) :.0.                                                                  ","                                                                    N.g.[ & & & & & & & & & +._ (.& & & & & & & & & | 6                                                                       ","                                                                        <+S.N & & & & & & & +._ (.& & & & & & & = O s                                                                         ","                                                                            - 3.& & & & & & +._ (.& & & & & N S.1+                                                                            ","                                                                                8.]+& & & & +._ (.& & & & k.!.                                                                                ","                                                                                  U O +.& & +._ (.& & ^ *                                                                                     ","                                                                                      + i.% +._ (.L a 3                                                                                       ","                                                                                          } V C.~ ;+                                                                                          ","                                                                                            2+V.                                                                                              ","                                                                                                                                                                                              ","                                                                                                                                                                                              ","                                                                                                                                                                                              ","                                                                                              .                                                                                               ","                                                                                            . .                                                                                               ","                                                                                            . .                                                                                               ","                                                                                            . .                                                                                               ","                                                                                            . .                                                                                               ","                                                                                            . .                                                                                               ","                                                                                            . .                                                                                               ","                                                                                                                                                                                              ","                                                                                                                                                                                              ","                                                                                            . . . . .                                                                                         ","                                                                                        . . .       .                                                                                         ","                                                                                        . .                                                                                                   ","                                                                                      . .                                                                                                     ","                                                                                      . .                                                                                                     ","                                                                                      . . . . . . .                                                                                           ","                                                                                      . . .       . .                                                                                         ","                                                                                      . .           . .                                                                                       ","                                                                                      . .           . .                                                                                       ","                                                                                      . .           . .                                                                                       ","                                                                                      . .           . .                                                                                       ","                                                                                        .           . .                                                                                       ","                                                                                        . .       . .                                                                                         ","                                                                                          . . . . .                                                                                           ","                                                                                                                                                                                              ","                                                                                                                                                                                              ","                                                                                                                                                                                              ","                                                                                                                                                                                              "]

    def __init__(self):
        super(BoxDialog, self).__init__("Map-To-Box", None,gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,(gtk.STOCK_CANCEL, gtk.RESPONSE_REJECT,gtk.STOCK_OK, gtk.RESPONSE_OK))

        self.set_resizable(False)

        self.img = gtk.Image()
        self.img.set_from_pixbuf(gtk.gdk.pixbuf_new_from_xpm_data(self.data))

        self.vbox.pack_start(self.img, False, False)

        label = gtk.Label("side:")
        label.set_justify(gtk.JUSTIFY_LEFT)

        self.vbox.pack_start(label, False, False)

        self.combobox = gtk.combo_box_new_text()
        for i in range(5):
            self.combobox.append_text("%d"%(i+1))
        self.combobox.set_active(0)

        self.vbox.pack_start(self.combobox, False, False)

        self.result = None

    def run(self):
        result = super(BoxDialog, self).run()

        if result == gtk.RESPONSE_OK:
            self.result = {"side":self.combobox.get_active()+1}

        return result

class FixedDialog(BoxDialog):
    points = [(1,0.8164965809,1),(.344,1,1),(0.8164965809,1,1),(1.112,1,1),(1,1,0.344),(1,1,0.8164965809),(1,1,1.112)]
    octants = ["(+ + +)","(+ + --)","(-- + --)","(-- + +)","(+ -- +)","(+ -- --)","(-- -- --)","(-- -- +)"]

    def __init__(self):
        BoxDialog.__init__(self)

        ###############################################

        label = gtk.Label("octant:")
        label.set_justify(gtk.JUSTIFY_LEFT)

        self.vbox.pack_start(label, False, False)

        self.octant = gtk.combo_box_new_text()
        for txt in self.octants:
            self.octant.append_text(txt)
        self.octant.set_active(0)

        self.vbox.pack_start(self.octant, False, False)

        ###############################################
        def _column(title, iid, width):
            # create the TreeViewColumn to display the data
            tvcolumn = gtk.TreeViewColumn(title)
            tvcolumn.set_sort_column_id(iid)
            tvcolumn.set_sizing(gtk.TREE_VIEW_COLUMN_FIXED)
            tvcolumn.set_fixed_width(width)

            # create a CellRendererText to render the data
            cell = gtk.CellRendererText()
            tvcolumn.pack_start(cell, True)
            tvcolumn.add_attribute(cell, 'text', iid)

            return tvcolumn

        self.treestore = gtk.TreeStore(float, float, float)

        # we'll add some data now - 4 rows with 3 child rows each
        for tup in self.points:
            self.treestore.append(None, tup)

        # create the TreeView using treestore
        self.treeview = gtk.TreeView(self.treestore)
        self.tvcolumns = []

        for t in ("X","Y","Z"):
            self.tvcolumns.append(_column(t, len(self.tvcolumns), 96))
            self.treeview.append_column(self.tvcolumns[-1])

        # select first row by default
        self.treeview.get_selection().select_iter(self.treestore.get_iter_root())

        self.vbox.pack_start(self.treeview, False, False)

        ###############################################

        self.vbox.show_all()

    def run(self):
        result = super(FixedDialog, self).run()

        if result == gtk.RESPONSE_OK:
            tup = self.treeview.get_selection().get_selected()
            point = tup[0].get(tup[1],0,1,2)
            sign = {0:(1,1,1),1:(1,1,-1),2:(-1,1,-1), 3:(-1,1,1),4:(1,-1,1),5:(1,-1,-1),6:(-1,-1,-1), 7:(-1,-1,1)}[self.octant.get_active()]

            self.result["a"] = float(point[0]) * sign[0]
            self.result["b"] = float(point[1]) * sign[1]
            self.result["c"] = float(point[2]) * sign[2]

        return result

class GeneralDialog(BoxDialog):
    def __init__(self):
        BoxDialog.__init__(self)
        hbox = gtk.HBox()

        label = gtk.Label("  X: ")
        label.set_justify(gtk.JUSTIFY_RIGHT)
        hbox.pack_start(label, False, False)

        self.x = gtk.Entry()
        hbox.pack_start(self.x, False, False)

        self.vbox.pack_start(hbox)

        ###############################################
        hbox = gtk.HBox()

        label = gtk.Label("  Y: ")
        label.set_justify(gtk.JUSTIFY_RIGHT)
        hbox.pack_start(label, False, False)

        self.y = gtk.Entry()
        hbox.pack_start(self.y, False, False)

        self.vbox.pack_start(hbox)

        ###############################################
        hbox = gtk.HBox()

        label = gtk.Label("  Z: ")
        label.set_justify(gtk.JUSTIFY_RIGHT)
        hbox.pack_start(label, False, False)

        self.z = gtk.Entry()
        hbox.pack_start(self.z, False, False)

        self.vbox.pack_start(hbox)

        ###############################################

        self.vbox.show_all()

    def run(self):
        result = super(GeneralDialog, self).run()

        if result == gtk.RESPONSE_OK:
            try:
                self.result["a"] = float(self.x.get_text())
                self.result["b"] = float(self.y.get_text())
                self.result["c"] = float(self.z.get_text())
            except ValueError:
                result = gtk.RESPONSE_REJECT

        return result

def side_transform(side):

        if 1 == side:
                return [[1,0,0],[0,0,-1],[0,1,0]]
        if 2 == side:
                return [[1,0,0],[0,1,0],[0,0,1]]
        if 3 == side:
                return [[0,0,1],[0,1,0],[-1,0,0]]
        if 4 == side:
                return [[-1,0,0],[0,1,0],[0,0,-1]]
        if 5 == side:
                return [[0,0,-1],[0,1,0],[1,0,0]]
        if 6 == side:
                return [[-1,0,0],[0,0,1],[0,1,0]]

        return [[1,0,0],[0,1,0],[0,0,1]]

def transform(item, matrix):
        return pdb.gimp_item_transform_matrix(item, *[coeff for row in matrix for coeff in row])

def multiply(n=[[1,0,0],[0,1,0],[0,0,1]],o=[[1,0,0],[0,1,0],[0,0,1]]):

        m=[[0,0,0],[0,0,0],[0,0,1]]

        m[0][0] = n[0][0]*o[0][0] + n[0][1]*o[1][0] + n[0][2]*o[2][0]
        m[0][1] = n[0][0]*o[0][1] + n[0][1]*o[1][1] + n[0][2]*o[2][1]
        m[0][2] = n[0][0]*o[0][2] + n[0][1]*o[1][2] + n[0][2]*o[2][2]

        m[1][0] = n[1][0]*o[0][0] + n[1][1]*o[1][0] + n[1][2]*o[2][0]
        m[1][1] = n[1][0]*o[0][1] + n[1][1]*o[1][1] + n[1][2]*o[2][1]
        m[1][2] = n[1][0]*o[0][2] + n[1][1]*o[1][2] + n[1][2]*o[2][2]

        return m

def orthogonal_projection(img, drawable, a, b, c, o=[[1,0,0],[0,1,0],[0,0,1]]):

        p_xz = sqrt(a**2 + c**2)
        p = sqrt(a**2 + b**2 + c**2)
        n = [[c/p_xz,0,(-1*a)/p_xz],\
                [(a*b)/(p_xz*p),p_xz/p,(b*c)/(p_xz*p)],\
                [0,0,1]]

        transform(img.active_layer, multiply(n,o))
        img.active_layer.set_offsets(0,0)

        return None

def stub(img, drawable, dialog):

        dlg = dialog()
        result = dlg.run()

        if gtk.RESPONSE_OK == result:
            orthogonal_projection(img, drawable, dlg.result["a"], dlg.result["b"], dlg.result["c"], side_transform(dlg.result["side"]))

        dlg.destroy()

        return result

def map_box_fixed(img, drawable):
        return stub(img, drawable, FixedDialog)

def map_box_general(img, drawable):
        return stub(img, drawable, GeneralDialog)

register(
        #name
        "map-box-general",
        #blurb
        "map the image to a box",
        #help
        "Map the image to a box and a given camera coordinate",
        #author
        "Bradley Workman",
        #copyright
        "MIT 2014",
        #date
        "01/25/2014",
        #menu path
        "<Image>/Filters/Map/Box.../General",
        #image types
        "*",
        #params
        [],
        #results
        [],
        #function
        map_box_general
)

register(
        #name
        "map-box-fixed",
        #blurb
        "map the image to a box",
        #help
        "Map the image to a box and a fixed camera coordinate",
        #author
        "Bradley Workman",
        #copyright
        "MIT 2014",
        #date
        "01/25/2014",
        #menu path
        "<Image>/Filters/Map/Box.../2-to-1",
        #image types
        "*",
        #params
        [],
        #results
        [],
        #function
        map_box_fixed
)

main()