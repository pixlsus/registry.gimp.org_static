#include "main.h"

//void *__gxx_personality_v0;

//glowne ustawienia i funkcja main
GimpPlugInInfo PLUG_IN_INFO =
{
  NULL,
  NULL,
  CPlugin::query,
  CPlugin::run
};


int main(int argc, char* argv[])
{
  sciezka_wtyczki = argv[0];

  gtk_init(&argc, &argv);

  return gimp_main(&PLUG_IN_INFO, argc, argv);
}

