#include <string>

#include <libgimp/gimp.h>
#include "CPlugin.h"

std::string sciezka_wtyczki;


