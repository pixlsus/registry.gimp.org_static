#include <fstream>
#include <string>

#ifndef __CPLUGINIMIONA__
#define __CPLUGINIMIONA__

extern std::string sciezka_wtyczki;

class CPluginImiona
{
  private:
    bool wczytano;
    std::string staraNazwa;
    std::string imiona[366][10];

  public:
    CPluginImiona():wczytano(false){};
    ~CPluginImiona(){};

    bool WczytajImiona(std::string filename);
    void Wyczysc();
    std::string PobierzImiona(unsigned int dzien, unsigned int msc, unsigned int ile);
};


#endif
