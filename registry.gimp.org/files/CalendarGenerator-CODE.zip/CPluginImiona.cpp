#include "CPluginImiona.h"


/*****************WczytajImiona*******************/
/**wczytuje liste imion z pliku, jezeli juz jest wczytana to nic nie robi***/
bool CPluginImiona::WczytajImiona(std::string filename)
{
  char buf[128];
  std::ifstream plik;

  if(staraNazwa==filename && wczytano)    //jezeli juz wczytany to nic nie rob
    return true;

  plik.open(filename.c_str());

  if(!plik.is_open())
  {
    std::string nowaNazwa(sciezka_wtyczki, 0, sciezka_wtyczki.size()-4);   //szukaj w katalogu domyslnym
    nowaNazwa+='\\';
    nowaNazwa+=filename;

    plik.open(nowaNazwa.c_str());

    if(!plik.is_open())
    {
      wczytano=false;
      return false;
    }

  }

  plik.seekg(3, std::ios_base::beg);    //pomin sygnature UTF-8

  for(unsigned int d = 0; d<366; d++)     //dla kazdego dnia w roku...
  {
    for(unsigned int i = 0; i<10; i++)    //...wczytaj po 10 imion...
    {
      plik.getline(buf, 128, ';');
      imiona[d][i] = buf;

      for(unsigned int s=0; s<imiona[d][i].size(); s++)
        imiona[d][i][s]=imiona[d][i][s]=='|'?'\n':imiona[d][i][s];
    }

    plik.getline(buf, 128, '\n');       //... i pomin komentarz po ostatnim imieniu
  }


  plik.close();

  wczytano = true;
  return true;
}


/****************Wyczysc*******************/
/**************czysci liste imion**********/
void CPluginImiona::Wyczysc()
{
  wczytano = false;
}


/***********PobierzImiona***************/
/*****zwraca liste imion z danego dnia******/
std::string CPluginImiona::PobierzImiona(unsigned int dzien, unsigned int msc, unsigned int ile)
{
  std::string buf;
  unsigned int dniMsc[] = {0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335};
  unsigned int ktoryDzien = 0;

  if(!wczytano)
    return std::string("");

  if(dzien>31 || dzien<1 || msc<1 || msc>12 || ile<1 || ile>10)
    return std::string("");

  ktoryDzien+=dniMsc[msc-1];
  ktoryDzien+=dzien;
  ktoryDzien--;


  for(unsigned int i = 0; i<ile; i++)
    buf+=imiona[ktoryDzien][i];

  return buf;
}

