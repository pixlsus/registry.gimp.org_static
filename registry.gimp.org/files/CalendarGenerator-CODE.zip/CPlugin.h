#include <libgimp/gimp.h>
#include <libgimp/gimpui.h>
#include <gdk/gdk.h>

#include <fstream>
#include <string>
#include <algorithm>

#include "SUstawienia.h"
#include "CPluginGenerator.h"
#include "CPluginGUI.h"


#ifndef __CPLUGIN__
#define __CPLUGIN__

#define PLUGIN_NAZWA "CalendarGeneratot v0.1"
#define PLIK_OKNA "\\OknoDialogowe.glade"


class CPlugin
{
  private:
    SUstawienia ust;
    bool Wykonaj();
    void RGB2BGR(GdkPixbuf* pixbuf);
    void WczytajUstawienia();


  public:
    static void run (const gchar *name, gint nparams, const GimpParam *param, gint *nreturn_vals, GimpParam **return_vals);
    static void query ();


};


#endif

