import gimp
from gimpfu import pdb
from gimpfu import *

def CreateFrame(image,name, width, color, median_color):
        import gimp
        from gimpfu import pdb
        from gimpfu import *
        image_width  = pdb.gimp_image_width(image)
        image_height = pdb.gimp_image_height(image)
        # get a copy of background
        background_copy = pdb.gimp_image_get_active_layer (image)
        border = pdb.gimp_layer_copy(background_copy,0)
        pdb.gimp_image_add_layer(image, border, -1)
        #select and make stroke
        pdb.gimp_rect_select(image, width, width,  image_width - 2*width , image_height - 2*width , CHANNEL_OP_REPLACE,  0, 0.0)
        pdb.gimp_context_set_foreground(median_color)
        drawable = pdb.gimp_image_active_drawable (image)
        # TODO somehow set the width for the stroke
        pdb.gimp_edit_stroke(drawable)
        # fill by foreground color
        pdb.gimp_selection_invert(image)
        pdb.gimp_context_set_foreground(color)
        drawable = pdb.gimp_image_active_drawable (image)
        pdb.gimp_bucket_fill(drawable,FG_BUCKET_FILL,NORMAL_MODE,100,0,0,width/2,width/2)
        pdb.gimp_layer_set_opacity(border,50)
        pdb.gimp_selection_none (image)
        # megre visible layers
        pdb.gimp_image_merge_visible_layers(image,EXPAND_AS_NECESSARY)

outer_width, outer_color,median_color = (20,(216,255,255),(232,232,232))
images = gimp.image_list() 
image = images[0]

image.undo_group_start()
CreateFrame(image,'Frame Border', outer_width, outer_color,median_color)
image.undo_group_end()

gimp.displays_flush()  