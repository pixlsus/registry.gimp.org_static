#!/usr/bin/python
# -*- coding: utf8 -*-
"""localization"""
import gettext,locale,os.path
global _
locale_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),'locale')
locale.setlocale(locale.LC_ALL, '')
gettext.bindtextdomain('gimpide', locale_dir)
gettext.textdomain('gimpide')
_ = gettext.gettext


