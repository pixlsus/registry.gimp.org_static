#!/usr/bin/python
# -*- coding: utf8 -*-
"""Default config"""

#CONFIG
CONF_FONT                           =       "inconsolata 9"
CONF_HIGHLIGHT_CURRENT_LINE         =       True
CONF_HIGHLIGHT_MATCHING_BRACKETS    =       True
CONF_OVERWRITE                      =       False              # insert/overwrite mode
CONF_SHOW_LINE_NUMBERS              =       True
CONF_AUTO_INDENT                    =       True
CONF_INDENT_ON_TAB                  =       True
CONF_SHOW_RIGHT_MARGIN              =       True
CONF_RIGHT_MARGIN_POSITION          =       72
CONF_HIGHLIGHT_SYNTAX               =       True
CONF_SPACES_INSTEAD_OF_TABS         =       True
CONF_TAB_WIDTH                      =       4
CONF_INDENT_WIDTH                   =       -1                  # -1 means use same as tab width
CONF_MAX_UNDO_LEVELS                =       50                  # -1 means no limit

CONF_HIGHLIGHT_CHANGES_SINCE_SAVE   =       True

# color for highlighting changes since last save
CONF_CHANGE_HIGHLIGHT               =       "dark slate gray"      # from /etc/X11/rgb.txt

# color for highlighting find/replace matches
CONF_FIND_HIGHLIGHT                 =       "IndianRed4"

# gtksrcview color scheme
CONF_STYLE_SCHEME                   =       ("oblivion","kate","tango","classic")

# 'note pad'. will open this file on startup instead of untitled. empty string means no default file.
CONF_DEFAULT_FILE                   =       ""


# whether to load plugins when running as the super user. 'no' by default.
CONF_LOAD_PLUGINS_AS_ROOT           =       False

# move whichever you want as default into the first position
CONF_WRAP                           =   ('None','Character','Word')
CONF_SMART_HOME_END_TYPE            =   ('Before','Disabled','After','Always')

