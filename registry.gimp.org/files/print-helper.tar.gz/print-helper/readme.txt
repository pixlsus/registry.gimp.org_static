Print helper

a small utility to support colour-managed printing, tested with gimp 2.4

####################################################
DISCLAIMER
 
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

(c) 2008

####################################################

WHAT DOES THIS DO?

Typically colour rendering differs between devices (monitors,
printers). Aside of calibrating the devices to a defined state 
colour-profiles are used to describe the behaviour of the output-
devices. Gimp realises colour-management by using a working-colour 
-space, a monitor-colour-space to get a good vision on a monitor 
and a printer-colour-space to be able to render print-previews.

With the availability of good photo-printers there is a need to 
include them into the colour-management chain by:


1 keeping the printer in a controlled state (for example HP 9180 
  and HP 8850 can calibrate themselves, calibrate always with the 
  same paper). 

2 get a colour-profile (or make it) for each paper-type. Leave 
  the colour-relevant settings of your printer-driver untouched 
  after calibration and profiling.

3 convert the image from the working-colour-space to the printer-  
  colour-space and

4 do eventually some enhancements (rotation, scaling, sharpening)  
  and at last

5 print it. 


This script assist for the steps 3 to 5. Colour-Management is only
supported for RGB-Images.



INSTALLATION

1) Copy the script print-helper.scm to the global script directory 
   (for example /usr/share/gimp/2.0/scripts) 
   or to your local script directory 
   (for example /home/a_user/.gimp-2.4/scripts 
 
2) Get the colour-profiles, a example for a hp 8850 with advanced 
   photo paper is attached. The default profile-name can be change 
   by editing this line of the script:
   SF-FILENAME   _"Print color profile" 
        "/usr/share/color/icc/hp_advanced-glossy.icc"

3) To use the sharpening by refocus which is outstanding for 
   colour-images - you have to install the gimp refocus plug-in 
   (see the plug-in registry on www.gimp.org)

4) Restart gimp or fresh up the script-fu system.

5) You will find a entry print-helper in your FILE menu.


GETTING PRINTER-COLOUR-PROFILES

There are a several ways to get printer-colour-profiles:

a)Use vendor supplied profiles from printer or paper manufactors. 
  These are mostly produced not with linux systems, therefore it 
  is questionable it they are reliable for linux systems

b)Some vendors offer to make profiles for you

c)You can use vuescan (www.hamrick.com)to profile a printer by 
  using a scanner. Vuescan can even profile your scanner by using 
  an IT8-target (for example from www.targets.coloraid.de/)

