MBB plugin for The GIMP
Copyright (C) 2014 Saulo A. Pessoa <saulopessoa@gmail.com>
==========================================

This is a plugin for GIMP which implements a multi-band blending technique. Conceptually speaking, this technique blends images using a different weighting function for each frequency band. It has the benefit of producing more natural transitions between images boundaries than the usual alpha blending technique.

Features/Restrictions
==========================================
* Blends two images according to mask.
* The images and the mask must be in separated layers with equal size.
* A new layer is created with the final result.
* By default, blending is performed for the whole image.
* If part of the image is selected, blending is restricted to this part.

Changes
==========================================
Current version:
0.1 (2014-04-20)
* Initial release.

Installation
==========================================
To a user based installation, extract the plugin file to your GIMP user plugin directory (usually C:\Users\<user_name>\.gimp-2.8\plug-ins). For a system-wide installation, extract the plugin to the system GIMP plugin directory (usually C:\Program Files\GIMP 2\lib\gimp\2.0\plug-ins).

The plugin was tested with GIMP version 2.8.x.

Usage
==========================================
Plugin is accessed by the menu Filters/Multi-Band Blending/...

Known Issues
==========================================
* The windows version of the plugin crashes when big images are used. It is probably because the plugin cannot allocate enough memory to perform the blending (since it is a 32-bits executable). I hope that with the 64-bits version this issue will be solved.
