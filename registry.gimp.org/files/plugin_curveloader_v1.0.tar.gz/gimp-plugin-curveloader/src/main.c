/* GIMP Plug-in Curveloader
 * Copyright (C) 2011  Rüdiger Schneider <remschneid@web.de> (the "Author").
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of the Author of the
 * Software shall not be used in advertising or otherwise to promote the
 * sale, use or other dealings in this Software without prior written
 * authorization from the Author.
 */

#include "config.h"

#include <string.h>
#include <glib/gstdio.h>
#include <libgimp/gimp.h>

#include "main.h"
#include "plugin-intl.h"
 
GimpPlugInInfo PLUG_IN_INFO={NULL,NULL,query,run};

MAIN ()

void query (void)
  {
	gchar *help_path;
	gchar *help_uri;
   
	static const GimpParamDef retvals[]=
		{
		{GIMP_PDB_INT32,"Element count", "Number of elements in the curve"},	
		{GIMP_PDB_INT8ARRAY,"Array of values","Array of curve values (value, red, green, blue or alpha curve)."},
		{GIMP_PDB_INT32,"Element count", "Number of elements in the red curve, only used if curves==5."},	
		{GIMP_PDB_INT8ARRAY,"Array of values", "Array of curve values (red curve), only used if curves==5."},
		{GIMP_PDB_INT32,"Element count", "Number of elements in the green curve, only used if curves==5."},	
		{GIMP_PDB_INT8ARRAY,"Array of values", "Array of curve values (green curve), only used if curves==5."},
		{GIMP_PDB_INT32,"Element count", "Number of elements in the blue curve, only used if curves==5."},	
		{GIMP_PDB_INT8ARRAY,"Array of values", "Array of curve values (blue curve), only used if curves==5."},
		{GIMP_PDB_INT32,"Element count", "Number of elements in the alpha curve, only used if curves==5."},	
		{GIMP_PDB_INT8ARRAY,"Array of values", "Array of curve values (alpha curve), only used if curves==5."} 
		};
  
	static GimpParamDef inargs[]=
		{
		{GIMP_PDB_INT32,"curves","Which curves to return. HISTOGRAM-VALUE (0), HISTOGRAM-RED (1), HISTOGRAM-GREEN (2), HISTOGRAM-BLUE (3), HISTOGRAM-ALPHA (4) or 5 (for all curves)."},
		{GIMP_PDB_STRING,"filename","The name of the curve file to load"}
		};
		                    
	gimp_install_procedure(PROCEDURE_NAME,
		"Creates curves from a curve file",
		"This plug-in reads in the curves from a curve file "
		"and returns arrays for use with gimp-curves-spline"
		" or gimp-curves-explicit.",
		"Rüdiger Schneider",
		"Copyright Rüdiger Schneider",
		"2011",
		NULL,
		NULL,
		GIMP_PLUGIN,
		G_N_ELEMENTS(inargs),G_N_ELEMENTS(retvals),
		inargs,retvals);

#ifdef ENABLE_NLS
	gimp_plugin_domain_register (GETTEXT_PACKAGE,LOCALEDIR);
#endif
 
	help_path=g_build_filename(DATADIR,"help",NULL);
	help_uri=g_filename_to_uri(help_path, NULL, NULL);
	g_free(help_path);
	gimp_plugin_help_register("http://developer.gimp.org/plug-in-curveloader/help",help_uri);
}

void run(const gchar *name,gint nparams,const GimpParam *param,gint *nreturn_vals,GimpParam **return_vals)
{
	static GimpParam values[11];
	GimpPDBStatusType status=GIMP_PDB_SUCCESS;
	gchar *filename;
	FILE *file=NULL;
	gint32 which_curve=-1;
	gint i,count;
	gint8 is_valid=0;
	static CLVars clvars={{0,0,0,0,0},{NULL,NULL,NULL,NULL,NULL}};
	
	INIT_I18N();
	
	which_curve=param[0].data.d_int32;
	filename=g_strdup(param[1].data.d_string);
	
	if (nparams!=2) {status=GIMP_PDB_CALLING_ERROR;}
	if ((which_curve<0)||(which_curve>5)) {status=GIMP_PDB_CALLING_ERROR;}
	if (!filename) {status=GIMP_PDB_CALLING_ERROR;}
	if ((status==GIMP_PDB_SUCCESS)&&(filename))
		{
		file=open_file(filename,&status,&is_valid);
		g_free(filename);
		if (is_valid)
			{
        	if (import_toolcurve(file,&clvars,which_curve,is_valid))
				{
				*nreturn_vals=(which_curve==5)?11:3;
				*return_vals=values;
				values[0].type=GIMP_PDB_STATUS;
				values[0].data.d_status=status;
				count=(which_curve==5)?5:1;
				for (i=0;i<count;i++)
					{
					values[(2*i)+1].type=GIMP_PDB_INT32;			
					values[(2*i)+1].data.d_int32=clvars.count[i];
					values[(2*i)+2].type=GIMP_PDB_INT8ARRAY;
					values[(2*i)+2].data.d_int8array=*clvars.arrays[i];
					}
				if (file) {fclose (file);}
				return;
				}
			else 
				{
				status=GIMP_PDB_EXECUTION_ERROR;	
				}	
			}
		}	
	*nreturn_vals=1;
	*return_vals=values;
	values[0].type=GIMP_PDB_STATUS;
	values[0].data.d_status=status;
	if (file) {fclose (file);}
	return;
}

FILE* open_file(gchar* filename,GimpPDBStatusType* status,gint8 *isvalid)
{
	gchar header[64];
	FILE *file=NULL;
	*status=GIMP_PDB_EXECUTION_ERROR;
	
	file=g_fopen(filename,"rt");
	if (!file) {return NULL;}
	
	if (!fgets(header,sizeof(header),file))
		{
      fclose (file);
		return NULL;
		}
		
	 if (g_str_has_prefix(header,"# GIMP curves tool settings\n")) 
	 	{
		*isvalid=1;
	 	}
	 else if (g_str_has_prefix(header,"# GIMP Curves File\n"))
		{
		*isvalid=2;
		}
	else		
	 	{
	 	fclose (file);		
		return NULL;
		}
	 
	 rewind(file);
	 *status=GIMP_PDB_SUCCESS;
    return file;
}

gboolean import_toolcurve(FILE *file,CLVars *clvars,gint32 curve,gint8 curvetype)
{
	gint16 *types=NULL;
	guint32 *offsets=NULL;
	gint8 retval=0;
	types=g_new(gint16,5);
	offsets=g_new(guint32,5);
	
	if (!parse_file(file,types,offsets,curvetype))	
		{
		g_free(types);
		g_free(offsets);
		return FALSE;
		}

	if (curve==HISTOGRAM_ALL)
		{
		retval+=parse_values(file,clvars,0,types[0],offsets[0],curvetype);
		retval+=parse_values(file,clvars,1,types[1],offsets[1],curvetype);
		retval+=parse_values(file,clvars,2,types[2],offsets[2],curvetype);
		retval+=parse_values(file,clvars,3,types[3],offsets[3],curvetype);
		retval+=parse_values(file,clvars,4,types[4],offsets[4],curvetype);
 		}
 	else 
 		{
 		retval+=parse_values(file,clvars,0,types[curve],offsets[curve],curvetype);
 		}
 	
	g_free(types);
	g_free(offsets);
	return ((retval==5)||(retval==1))?TRUE:FALSE;
}

gboolean parse_file(FILE *file,gint16 *types,guint32 *offsets,gint8 curvetype)
{
	gboolean allok=FALSE,smooth=FALSE;
	gint i=0,j=0,k=0;
	char* pos=NULL;
	gchar buf[2400],*in=NULL;
	const char *type="(curve-type smooth)";
	const char *needles[5]={"(channel value)","(channel red)","(channel green)","(channel blue)","(channel alpha)"};
	
	pos=fgets(buf,sizeof(buf),file);
	in=g_strstrip(buf);
	
	if (curvetype==1)
		{
		while ((in)&&(pos))
			{
		 	if (g_str_has_prefix(in,needles[i]))
		 		{
		 		for (j=0;j<2;j++)	 
		 			{
		 			pos=fgets(buf,sizeof(buf),file);
		 			in=g_strstrip(buf);
		 			if (!pos) {break;}
		 			}
		 		smooth=g_str_has_prefix(in,type);
		 		types[i]=(smooth)?GIMP_CURVE_SMOOTH:GIMP_CURVE_FREE;
				k=(smooth)?1:3;
		 		for (j=0;j<k;j++)
		 			{
		 			pos=fgets(buf,sizeof(buf),file);
		 			in=g_strstrip(buf);
		 			}
		 		offsets[i]=ftell(file);
		 		i++;
		 		if (i==5)
		 			{
		 			allok=TRUE;
		 			break;
		 			}
		 		}
			pos=fgets(buf,sizeof(buf),file);
			in=g_strstrip(buf);
			}
		}
	else if (curvetype==2)
		{
		while ((in)&&(pos))
			{
		 	types[i]=GIMP_CURVE_SMOOTH;
		 	offsets[i]=ftell(file);
		 	i++;
		 	if (i==5)
		 		{
		 		allok=TRUE;
		 		break;
		 		}
			pos=fgets(buf,sizeof(buf),file);
			in=g_strstrip(buf);
			}
		}
				
	rewind(file);	
	return allok;
}

gint8 check_element_count(gchar *firstpos)
{
	gdouble in;
	gint elements=0,i=0;
	gchar *nextpos;
	
	for (i=0;i<34;i++)
		{
		in=g_ascii_strtod(firstpos,&nextpos);
		if (nextpos!=firstpos)	
			{
			firstpos=nextpos+1;
			elements++;
			}
		}
		
	if ((elements%2)||(elements<4)) {return 0;}
	return 	(elements/2);
}

gint8 parse_values(FILE *file,CLVars *clvars,gint8 curvenum,gint16 count,guint32 offset,gint8 curvetype)
{
	gdouble in_x,in_y;
	gint numelements=0;
	guint8 *temp=NULL,*helper1=NULL,*helper2=NULL;
	static guint8 *ptr[5]={NULL,NULL,NULL,NULL,NULL};
	gchar *pos=NULL,*needle=(count==17)?"34 ":"256 ";
	gchar the_values[2400],*in=NULL,*nextpos;
	
	if (count==17)
	 	{
		helper1=temp=g_new(guint8,count*2);
		if (!temp) {return FALSE;}
		if (fseek(file,offset,SEEK_SET)==-1)
			{
			g_free(temp);
			return 0;
			}
		fgets(the_values,sizeof(the_values),file);
		in=g_strstrip(the_values);
		pos=(curvetype==1)?g_strstr_len(in,-1,needle):in;
		if (!pos)
			{
			g_free(temp);
			return 0;
			}	
		if (curvetype==1) {pos+=strlen(needle);}
		count=check_element_count(pos);
		numelements=count;
		while (count--) 
			{
			in_x=g_ascii_strtod(pos,&nextpos);
			pos=nextpos+1;
			in_y=g_ascii_strtod(pos,&nextpos);
			pos=nextpos+1;
			if ((in_x!=-1.0)&&(in_y!=-1.0)) 
				{
				*helper1++=(curvetype==1)?ROUND(in_x*255.0):CLAMP0255(in_x);
				*helper1++=(curvetype==1)?ROUND(in_y*255.0):CLAMP0255(in_y);
				}
			else 
				{
				numelements	--;
				}
			}
		if (numelements<2)
			{
			//Error: wrong count of elements
			g_free(temp);
			return 0;	
			}
		else 
			{
			helper2=ptr[curvenum]=g_new(guint8,numelements*2);
			if (!helper2)
				{
				g_free(temp);
				return 0;
				}
			helper1=temp;
			count=numelements*2;
			while (count--) {*helper2++=*helper1++;}
			g_free(temp);
			clvars->arrays[curvenum]=&ptr[curvenum];
			clvars->count[curvenum]=numelements*2;
			}
	 	}
	else if (count==256)
		{
		helper1=ptr[curvenum]=g_new(guint8,count);
		if (fseek(file,offset,SEEK_SET)==-1)
			{
			g_free(helper1);
			return 0;
			}
		fgets(the_values,sizeof(the_values),file);
		in=g_strstrip(the_values);
		pos=g_strstr_len(in,-1,needle);	
		if (!pos)
			{
			g_free(helper1);
			return 0;	
			}
		pos+=strlen(needle);
		numelements=count;
		while (numelements--)
			{
			in_x=g_ascii_strtod(pos,&nextpos);
			pos=nextpos+1;
			*helper1++=ROUND(in_x*255.0);
			}
		helper1=ptr[curvenum];
		if (numelements!=-1)
			{
			//Error: wrong count of elements
			g_free(helper1);
			return 0;	
			}
		clvars->arrays[curvenum]=&ptr[curvenum];
		clvars->count[curvenum]=count;
		}
	else 
		{
		return 0;	
		}

	return 1;
}