/* GIMP Plug-in Curveloader
 * Copyright (C) 2011  Rüdiger Schneider <remschneid@web.de> (the "Author").
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of the Author of the
 * Software shall not be used in advertising or otherwise to promote the
 * sale, use or other dealings in this Software without prior written
 * authorization from the Author.
 */

#ifndef __MAIN_H__
#define __MAIN_H__

#define GIMP_CURVE_SMOOTH 17
#define GIMP_CURVE_FREE 256
#define PROCEDURE_NAME   "plug-in-curveloader"

typedef enum
{
	HISTOGRAM_VALUE, 
	HISTOGRAM_RED, 
	HISTOGRAM_GREEN, 
	HISTOGRAM_BLUE, 
	HISTOGRAM_ALPHA, 
	HISTOGRAM_ALL
} CurveType;

typedef struct
{
	gint16 count[5];
	guint8	**arrays[5];
} CLVars;

void query(void);
void run(const gchar *name,gint nparams,const GimpParam  *param,gint *nreturn_vals,GimpParam **return_vals);
FILE* open_file(gchar* filename,GimpPDBStatusType* status,gint8 *isvalid);
gboolean import_toolcurve(FILE *file,CLVars *clvars,gint32 curve,gint8 curvetype);
gboolean parse_file(FILE *file,gint16 *types,guint32 *offsets,gint8 curvetype);
gint8 check_element_count(gchar *firstpos);
gint8 parse_values(FILE *file,CLVars *clvars,gint8 curvenum,gint16 count,guint32 offset,gint8 curvetype);
#endif /* __MAIN_H__ */
